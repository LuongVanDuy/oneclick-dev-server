<?php
/**
 * Giao diện quản trị.
 *
 * @package duyanhweb
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DAWP_WebP_Admin {

	/** Slug trang quản trị nằm dưới menu Thư viện (Media). */
	const SLUG = 'dawp-webp-optimizer';

	public function __construct() {
		add_action( 'admin_menu', array( $this, 'add_menu' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue' ) );
		add_action( 'admin_post_dawp_webp_save_settings', array( $this, 'handle_save_settings' ) );
		add_action( 'admin_post_dawp_webp_reset_log', array( $this, 'handle_reset_log' ) );
	}

	/**
	 * Thêm menu "Nén ảnh WebP" vào Thư viện (Media).
	 */
	public function add_menu() {
		add_media_page(
			__( 'Nén ảnh WebP — Duy Anh Web', 'duyanhwebpro' ),
			__( 'Nén ảnh WebP', 'duyanhwebpro' ),
			'manage_options',
			self::SLUG,
			array( __CLASS__, 'render_page' )
		);
	}

	/**
	 * Nạp CSS/JS chỉ ở trang của plugin.
	 *
	 * @param string $hook Hook hiện tại.
	 */
	public function enqueue( $hook ) {
		// Nạp trên trang Thư viện > Nén ảnh WebP, và cả tab trong DAW Pro Settings.
		if ( 'media_page_' . self::SLUG !== $hook && 'toplevel_page_dawp-settings' !== $hook ) {
			return;
		}

		wp_enqueue_style(
			'dawp-webp-admin',
			DAWP_WebP_URL . 'assets/css/dawp-webp-admin.css',
			array(),
			DAWP_WebP_VERSION
		);

		wp_enqueue_script(
			'dawp-webp-admin',
			DAWP_WebP_URL . 'assets/js/dawp-webp-admin.js',
			array(),
			DAWP_WebP_VERSION,
			true
		);

		wp_localize_script(
			'dawp-webp-admin',
			'dawpWebpData',
			array(
				'restUrl'   => esc_url_raw( rest_url( DAWP_WebP_REST_NS ) ),
				'nonce'     => wp_create_nonce( 'wp_rest' ),
				'workerUrl' => DAWP_WebP_URL . 'assets/js/dawp-webp-worker.js?ver=' . DAWP_WebP_VERSION,
			)
		);
	}

	/**
	 * Lưu cấu hình.
	 */
	public function handle_save_settings() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Bạn không có quyền.', 'duyanhwebpro' ) );
		}

		check_admin_referer( 'dawp_webp_settings' );

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		DAWP_WebP_Settings::save( wp_unslash( $_POST ) );

		wp_safe_redirect( add_query_arg( array( 'page' => 'dawp-settings', 'tab' => 'webp-converter', 'dawp_webp_msg' => 'saved' ), admin_url( 'admin.php' ) ) );
		exit;
	}

	/**
	 * Xoá nhật ký.
	 */
	public function handle_reset_log() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Bạn không có quyền.', 'duyanhwebpro' ) );
		}

		check_admin_referer( 'dawp_webp_reset_log' );

		DAWP_WebP_DB::truncate();

		wp_safe_redirect( add_query_arg( array( 'page' => 'dawp-settings', 'tab' => 'webp-converter', 'dawp_webp_msg' => 'log_reset' ), admin_url( 'admin.php' ) ) );
		exit;
	}

	/**
	 * Định dạng dung lượng.
	 *
	 * @param int $bytes Byte.
	 * @return string
	 */
	private static function bytes( $bytes ) {
		return size_format( (float) $bytes, 2 );
	}

	/**
	 * Render trang quản trị.
	 */
	public static function render_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$settings = DAWP_WebP_Settings::all();
		$stats    = DAWP_WebP_DB::stats();
		$pending  = DAWP_WebP_Scanner::count_pending();
		$total    = DAWP_WebP_Scanner::count_total();
		$recent   = DAWP_WebP_DB::recent( 30 );

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$msg = isset( $_GET['dawp_webp_msg'] ) ? sanitize_key( wp_unslash( $_GET['dawp_webp_msg'] ) ) : '';
		?>
		<div class="wrap dawp-webp-wrap">

			<h1 class="dawp-webp-title">
				<span class="dashicons dashicons-images-alt2"></span>
				<?php esc_html_e( 'Nén ảnh WebP — Duy Anh Web', 'duyanhwebpro' ); ?>
				<span id="dawp-webp-status-badge" class="dawp-webp-badge is-idle"><?php esc_html_e( 'Sẵn sàng', 'duyanhwebpro' ); ?></span>
			</h1>

			<p class="dawp-webp-lead">
				<?php esc_html_e( 'Toàn bộ quá trình nén ảnh chạy bằng CPU và RAM trên máy tính của bạn (trình duyệt), không tiêu tốn hiệu năng máy chủ. Plugin xử lý từng ảnh một và cập nhật đường dẫn trong database ngay sau mỗi ảnh — xong ảnh nào chắc ảnh đó.', 'duyanhwebpro' ); ?>
			</p>

			<?php if ( 'saved' === $msg ) : ?>
				<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Đã lưu cấu hình.', 'duyanhwebpro' ); ?></p></div>
			<?php elseif ( 'log_reset' === $msg ) : ?>
				<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Đã xoá nhật ký.', 'duyanhwebpro' ); ?></p></div>
			<?php endif; ?>

			<?php if ( ! DAWP_WebP_Server_Rules::is_apache() && $settings['enable_server_rules'] ) : ?>
				<div class="notice notice-warning">
					<p><strong><?php esc_html_e( 'Máy chủ không phải Apache.', 'duyanhwebpro' ); ?></strong>
					<?php esc_html_e( 'Hãy thêm đoạn cấu hình Nginx bên dưới vào server block, hoặc chỉ dùng chế độ lọc HTML.', 'duyanhwebpro' ); ?></p>
					<pre class="dawp-webp-code"><?php echo esc_html( DAWP_WebP_Server_Rules::nginx_snippet() ); ?></pre>
				</div>
			<?php endif; ?>

			<!-- Thẻ thống kê -->
			<div class="dawp-webp-cards">
				<div class="dawp-webp-card">
					<span class="dawp-webp-card-label"><?php esc_html_e( 'Tổng số ảnh', 'duyanhwebpro' ); ?></span>
					<strong class="dawp-webp-card-value"><?php echo esc_html( number_format_i18n( $total ) ); ?></strong>
				</div>
				<div class="dawp-webp-card">
					<span class="dawp-webp-card-label"><?php esc_html_e( 'Chờ nén', 'duyanhwebpro' ); ?></span>
					<strong class="dawp-webp-card-value dawp-webp-warn"><?php echo esc_html( number_format_i18n( $pending ) ); ?></strong>
				</div>
				<div class="dawp-webp-card">
					<span class="dawp-webp-card-label"><?php esc_html_e( 'Đã nén', 'duyanhwebpro' ); ?></span>
					<strong class="dawp-webp-card-value dawp-webp-ok"><?php echo esc_html( number_format_i18n( $stats['optimized_count'] ) ); ?></strong>
				</div>
				<div class="dawp-webp-card">
					<span class="dawp-webp-card-label"><?php esc_html_e( 'Dung lượng tiết kiệm', 'duyanhwebpro' ); ?></span>
					<strong class="dawp-webp-card-value dawp-webp-ok">
						<?php echo esc_html( self::bytes( $stats['bytes_saved'] ) ); ?>
					</strong>
					<span class="dawp-webp-card-sub"><?php echo esc_html( $stats['percent_saved'] ); ?>%</span>
				</div>
				<div class="dawp-webp-card">
					<span class="dawp-webp-card-label"><?php esc_html_e( 'Dòng DB đã đổi URL', 'duyanhwebpro' ); ?></span>
					<strong class="dawp-webp-card-value"><?php echo esc_html( number_format_i18n( $stats['db_rows_updated'] ) ); ?></strong>
				</div>
			</div>

			<!-- Bảng điều khiển -->
			<div class="dawp-webp-panel">
				<h2><?php esc_html_e( 'Nén hàng loạt', 'duyanhwebpro' ); ?></h2>

				<div class="dawp-webp-controls">
					<label class="dawp-webp-control">
						<span><?php esc_html_e( 'Chất lượng WebP', 'duyanhwebpro' ); ?>
							<output id="dawp-webp-quality-out"><?php echo esc_html( round( $settings['quality'] * 100 ) ); ?>%</output>
						</span>
						<input type="range" id="dawp-webp-quality" min="0.4" max="1" step="0.01"
							value="<?php echo esc_attr( $settings['quality'] ); ?>">
						<small><?php esc_html_e( '80–85% là điểm cân bằng tốt: mắt thường không phân biệt được nhưng file nhẹ hơn nhiều.', 'duyanhwebpro' ); ?></small>
					</label>

					<label class="dawp-webp-control">
						<span><?php esc_html_e( 'Cạnh dài tối đa (px)', 'duyanhwebpro' ); ?></span>
						<input type="number" id="dawp-webp-max-width" min="0" step="100"
							value="<?php echo esc_attr( $settings['max_width'] ); ?>">
						<small><?php esc_html_e( '1920 = chuẩn Full HD, hiển thị tràn màn hình vẫn nét mà file nhẹ. Áp cho cả ảnh ngang lẫn dọc. Đặt 0 để giữ nguyên kích thước.', 'duyanhwebpro' ); ?></small>
					</label>

					<label class="dawp-webp-control">
						<span><?php esc_html_e( 'Số luồng nén song song', 'duyanhwebpro' ); ?></span>
						<input type="number" id="dawp-webp-concurrency" min="1" max="6"
							value="<?php echo esc_attr( $settings['concurrency'] ); ?>">
						<small><?php esc_html_e( 'Càng cao càng nhanh nhưng máy bạn càng nặng. Máy yếu nên để 1.', 'duyanhwebpro' ); ?></small>
					</label>
				</div>

				<div class="dawp-webp-actions">
					<button type="button" class="button button-primary button-hero" id="dawp-webp-start">
						<?php esc_html_e( 'Nén', 'duyanhwebpro' ); ?>
					</button>
					<button type="button" class="button" id="dawp-webp-stop" disabled>
						<?php esc_html_e( 'Dừng nén', 'duyanhwebpro' ); ?>
					</button>
				</div>

				<!-- Thanh tiến trình -->
				<div class="dawp-webp-progress">
					<div class="dawp-webp-bar">
						<div class="dawp-webp-bar-fill" id="dawp-webp-bar-fill"></div>
						<span class="dawp-webp-bar-text" id="dawp-webp-bar-text">0%</span>
					</div>

					<div class="dawp-webp-progress-meta">
						<span><?php esc_html_e( 'Tiến độ:', 'duyanhwebpro' ); ?> <strong id="dawp-webp-counter">0 / 0</strong></span>
						<span><?php esc_html_e( 'Đang xử lý:', 'duyanhwebpro' ); ?> <strong id="dawp-webp-current">—</strong></span>
						<span><?php esc_html_e( 'Tiết kiệm:', 'duyanhwebpro' ); ?> <strong id="dawp-webp-saved">0 B</strong></span>
						<span><?php esc_html_e( 'Lỗi:', 'duyanhwebpro' ); ?> <strong id="dawp-webp-failed">0</strong></span>
						<span><?php esc_html_e( 'Còn khoảng:', 'duyanhwebpro' ); ?> <strong id="dawp-webp-eta">—</strong></span>
					</div>
				</div>

				<div class="dawp-webp-log-wrap">
					<h3><?php esc_html_e( 'Nhật ký trực tiếp', 'duyanhwebpro' ); ?></h3>
					<div id="dawp-webp-log" class="dawp-webp-log"></div>
				</div>
			</div>

			<!-- Cấu hình -->
			<div class="dawp-webp-panel">
				<h2><?php esc_html_e( 'Cấu hình', 'duyanhwebpro' ); ?></h2>

				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="dawp_webp_save_settings">
					<?php wp_nonce_field( 'dawp_webp_settings' ); ?>

					<table class="form-table" role="presentation">
						<tr>
							<th scope="row"><?php esc_html_e( 'Định dạng chuyển đổi', 'duyanhwebpro' ); ?></th>
							<td>
								<label><input type="checkbox" name="convert_jpeg" value="1" <?php checked( $settings['convert_jpeg'] ); ?>> JPEG / JPG</label><br>
								<label><input type="checkbox" name="convert_png" value="1" <?php checked( $settings['convert_png'] ); ?>> PNG</label>
								<p class="description"><?php esc_html_e( 'GIF động và SVG luôn được bỏ qua để tránh mất hiệu ứng.', 'duyanhwebpro' ); ?></p>
							</td>
						</tr>
						<tr>
							<th scope="row"><label for="dawp-webp-quality-setting"><?php esc_html_e( 'Chất lượng mặc định', 'duyanhwebpro' ); ?></label></th>
							<td>
								<input type="number" id="dawp-webp-quality-setting" name="quality" min="0.1" max="1" step="0.01"
									value="<?php echo esc_attr( $settings['quality'] ); ?>" class="small-text">
							</td>
						</tr>
						<tr>
							<th scope="row"><label for="dawp-webp-maxwidth-setting"><?php esc_html_e( 'Cạnh dài tối đa', 'duyanhwebpro' ); ?></label></th>
							<td>
								<input type="number" id="dawp-webp-maxwidth-setting" name="max_width" min="0" step="100"
									value="<?php echo esc_attr( $settings['max_width'] ); ?>" class="small-text"> px
							</td>
						</tr>
						<tr>
							<th scope="row"><?php esc_html_e( 'Ảnh gốc', 'duyanhwebpro' ); ?></th>
							<td>
								<label>
									<input type="checkbox" name="keep_original" value="1" <?php checked( $settings['keep_original'] ); ?>>
									<strong><?php esc_html_e( 'Giữ lại ảnh gốc bên cạnh bản WebP', 'duyanhwebpro' ); ?></strong>
								</label>
								<p class="description">
									<?php esc_html_e( 'Mặc định TẮT để giảm tối đa dung lượng: ảnh gốc bị xoá sau khi nén, URL cũ được rule .htaccess tự trả về bản WebP. Bật lên nếu muốn có đường lùi trong lần nén đầu tiên — kiểm tra ổn rồi tắt đi nén lại cũng được.', 'duyanhwebpro' ); ?>
								</p>
							</td>
						</tr>
						<tr>
							<th scope="row"><?php esc_html_e( 'Cập nhật database', 'duyanhwebpro' ); ?></th>
							<td>
								<label>
									<input type="checkbox" name="update_database" value="1" <?php checked( $settings['update_database'] ); ?>>
									<?php esc_html_e( 'Tự động đổi đường dẫn ảnh trong toàn bộ database sau mỗi ảnh', 'duyanhwebpro' ); ?>
								</label>
								<p class="description"><?php esc_html_e( 'Quét post_content, postmeta, options, termmeta, usermeta, comment. Xử lý an toàn dữ liệu serialize của Elementor, ACF, WPBakery…', 'duyanhwebpro' ); ?></p>
							</td>
						</tr>
						<tr>
							<th scope="row"><?php esc_html_e( 'Phục vụ ảnh', 'duyanhwebpro' ); ?></th>
							<td>
								<label>
									<input type="checkbox" name="enable_rewrite" value="1" <?php checked( $settings['enable_rewrite'] ); ?>>
									<?php esc_html_e( 'Lọc HTML đầu ra, đổi URL .jpg/.png sang .webp khi bản WebP tồn tại', 'duyanhwebpro' ); ?>
								</label><br>
								<label>
									<input type="checkbox" name="enable_server_rules" value="1" <?php checked( $settings['enable_server_rules'] ); ?>>
									<?php esc_html_e( 'Ghi rule .htaccess để URL cũ vẫn trả về ảnh WebP', 'duyanhwebpro' ); ?>
									<?php if ( DAWP_WebP_Server_Rules::is_active() ) : ?>
										<span class="dawp-webp-pill dawp-webp-ok"><?php esc_html_e( 'đang hoạt động', 'duyanhwebpro' ); ?></span>
									<?php endif; ?>
								</label>
							</td>
						</tr>
					</table>

					<?php submit_button( __( 'Lưu cấu hình', 'duyanhwebpro' ) ); ?>
				</form>
			</div>

			<!-- Nhật ký đã lưu -->
			<div class="dawp-webp-panel">
				<h2><?php esc_html_e( 'Lịch sử gần đây', 'duyanhwebpro' ); ?></h2>

				<?php if ( empty( $recent ) ) : ?>
					<p><?php esc_html_e( 'Chưa có ảnh nào được xử lý.', 'duyanhwebpro' ); ?></p>
				<?php else : ?>
					<table class="widefat striped dawp-webp-table">
						<thead>
							<tr>
								<th><?php esc_html_e( 'Ảnh', 'duyanhwebpro' ); ?></th>
								<th><?php esc_html_e( 'Trước', 'duyanhwebpro' ); ?></th>
								<th><?php esc_html_e( 'Sau', 'duyanhwebpro' ); ?></th>
								<th><?php esc_html_e( 'Giảm', 'duyanhwebpro' ); ?></th>
								<th><?php esc_html_e( 'File', 'duyanhwebpro' ); ?></th>
								<th title="<?php esc_attr_e( 'Số dòng trong database có URL ảnh được cập nhật. Dấu — nghĩa là ảnh gắn theo ID, không có URL nào cần thay.', 'duyanhwebpro' ); ?>">
									<?php esc_html_e( 'Dòng DB', 'duyanhwebpro' ); ?>
								</th>
								<th><?php esc_html_e( 'Trạng thái', 'duyanhwebpro' ); ?></th>
								<th><?php esc_html_e( 'Thời gian', 'duyanhwebpro' ); ?></th>
							</tr>
						</thead>
						<tbody>
						<?php foreach ( $recent as $row ) : ?>
							<?php
							$before  = (int) $row['size_before'];
							$after   = (int) $row['size_after'];
							$percent = $before > 0 ? round( ( $before - $after ) / $before * 100, 1 ) : 0;
							?>
							<tr>
								<td>
									<?php if ( $row['attachment_id'] ) : ?>
										<a href="<?php echo esc_url( (string) get_edit_post_link( (int) $row['attachment_id'] ) ); ?>">
											#<?php echo esc_html( $row['attachment_id'] ); ?>
										</a>
									<?php endif; ?>
									<code><?php echo esc_html( $row['webp_file'] ? $row['webp_file'] : $row['orig_file'] ); ?></code>
								</td>
								<td><?php echo esc_html( self::bytes( $before ) ); ?></td>
								<td><?php echo esc_html( self::bytes( $after ) ); ?></td>
								<td><strong class="dawp-webp-ok"><?php echo esc_html( $percent ); ?>%</strong></td>
								<td><?php echo esc_html( $row['files_count'] ); ?></td>
								<td>
									<?php if ( (int) $row['db_rows_updated'] > 0 ) : ?>
										<strong><?php echo esc_html( $row['db_rows_updated'] ); ?></strong>
									<?php else : ?>
										<span class="dawp-webp-muted" title="<?php esc_attr_e( 'Ảnh này được gắn vào bài viết/sản phẩm bằng ID nên không có URL nào trong nội dung cần thay. Đây là trường hợp bình thường, không phải lỗi.', 'duyanhwebpro' ); ?>">—</span>
									<?php endif; ?>
								</td>
								<td>
									<span class="dawp-webp-pill dawp-webp-status-<?php echo esc_attr( $row['status'] ); ?>">
										<?php echo esc_html( $row['status'] ); ?>
									</span>
									<?php if ( ! empty( $row['message'] ) ) : ?>
										<br><small><?php echo esc_html( $row['message'] ); ?></small>
									<?php endif; ?>
								</td>
								<td><?php echo esc_html( mysql2date( 'H:i d/m/Y', $row['created_at'] ) ); ?></td>
							</tr>
						<?php endforeach; ?>
						</tbody>
					</table>

					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="dawp-webp-reset">
						<input type="hidden" name="action" value="dawp_webp_reset_log">
						<?php wp_nonce_field( 'dawp_webp_reset_log' ); ?>
						<button type="submit" class="button button-link-delete">
							<?php esc_html_e( 'Xoá nhật ký', 'duyanhwebpro' ); ?>
						</button>
					</form>
				<?php endif; ?>
			</div>

			<!-- Công cụ sửa lỗi -->
			<div class="dawp-webp-panel">
				<h2><?php esc_html_e( 'Kiểm tra & sửa đường dẫn ảnh', 'duyanhwebpro' ); ?></h2>

				<p class="description" style="max-width:820px">
					<?php esc_html_e( 'Quét toàn bộ thư viện, tìm những mục metadata còn trỏ tới file không tồn tại trên đĩa và sửa lại cho đúng. Công cụ chỉ đọc đĩa và sửa metadata, KHÔNG đụng tới file ảnh, nên chạy lại bao nhiêu lần cũng an toàn. Dùng khi thấy ảnh vỡ ngoài giao diện.', 'duyanhwebpro' ); ?>
				</p>

				<div class="dawp-webp-actions">
					<button type="button" class="button button-secondary" id="dawp-webp-repair">
						<?php esc_html_e( 'Quét và sửa đường dẫn', 'duyanhwebpro' ); ?>
					</button>
					<span id="dawp-webp-repair-status"></span>
				</div>
			</div>

			<!-- Chuẩn bị gỡ plugin an toàn -->
			<div class="dawp-webp-panel">
				<h2><?php esc_html_e( 'Chuẩn bị gỡ plugin an toàn (mọi máy chủ)', 'duyanhwebpro' ); ?></h2>

				<p class="description" style="max-width:820px">
					<?php esc_html_e( 'Quét TOÀN BỘ database (bài viết, meta, options, widget...), tìm mọi tham chiếu .jpg/.png còn sót trỏ tới file đã chuyển sang WebP và sửa lại. Khi kết quả báo 0 tham chiếu còn sót, database hoàn toàn sạch — gỡ plugin không gây lỗi ảnh trên bất kỳ máy chủ nào (Apache, LiteSpeed, OpenLiteSpeed, Nginx). Chỉ đổi khi file cũ không còn và file .webp tồn tại, nên chạy lại bao nhiêu lần cũng an toàn.', 'duyanhwebpro' ); ?>
				</p>

				<div class="dawp-webp-actions">
					<button type="button" class="button button-secondary" id="dawp-webp-sweep">
						<?php esc_html_e( 'Dọn sạch URL cũ trong database', 'duyanhwebpro' ); ?>
					</button>
					<span id="dawp-webp-sweep-status"></span>
				</div>

				<p class="description" style="max-width:820px;margin-top:12px">
					<?php esc_html_e( 'Riêng máy chủ Nginx (không đọc .htaccess): nếu muốn thêm lớp bảo hiểm cho các link .jpg cũ từ bên ngoài (Google, web khác dẫn link), nhờ đơn vị quản trị thêm đoạn sau vào cấu hình server:', 'duyanhwebpro' ); ?>
				</p>
				<pre style="background:#f6f7f7;padding:10px 14px;border-radius:4px;max-width:820px;overflow:auto"><code>location ~* ^(/wp-content/uploads/.+)\.(jpe?g|png)$ {
    try_files $uri $1.webp =404;
}</code></pre>
			</div>

			<!-- Thông tin đơn vị phát triển -->
			<div class="dawp-webp-credit">
				<div class="dawp-webp-credit-main">
					<strong><?php esc_html_e( 'Phát triển bởi Công ty Duy Anh Web', 'duyanhwebpro' ); ?></strong>
					<span><?php esc_html_e( 'Thiết kế website · Tối ưu tốc độ · SEO', 'duyanhwebpro' ); ?></span>
				</div>
				<div class="dawp-webp-credit-contact">
					<a href="https://duyanhweb.com.vn" target="_blank" rel="noopener noreferrer">
						<span class="dashicons dashicons-admin-site-alt3"></span> duyanhweb.com.vn
					</a>
				</div>
			</div>

		</div>
		<?php
	}
}


