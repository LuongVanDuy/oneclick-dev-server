(function($) {
    // Kiểm tra tính năng xuất ảnh WebP từ Canvas và hỗ trợ ES6 (Promise, Object.assign) của trình duyệt
    var supportsWebP = false;
    try {
        supportsWebP = (typeof Promise !== 'undefined') && 
                       (typeof Object.assign !== 'undefined') && 
                       (document.createElement('canvas').toDataURL('image/webp').indexOf('data:image/webp') === 0);
    } catch(e) {}

    // Chuỗi thông báo cảnh báo trình duyệt cũ
    var browserWarningMessage = 'CẢNH BÁO BẢO MẬT & HIỆU NĂNG:\n\n' +
        'Trình duyệt của bạn đã quá cũ và không hỗ trợ công nghệ tối ưu hóa hình ảnh WebP ở máy khách.\n' +
        'Hệ thống đã chặn tuyệt đối việc tải lên hình ảnh để tránh làm nặng và quá tải máy chủ.\n\n' +
        'Vui lòng nâng cấp trình duyệt của bạn lên phiên bản mới nhất (Google Chrome, Microsoft Edge, Firefox, hoặc Safari mới) để tiếp tục tải ảnh!';

    // Hàm hook trực tiếp vào plupload.Uploader (toàn cục) để bao quát tất cả các instance uploader (kể cả trang media-new.php)
    function hookPlupload() {
        if (typeof plupload !== 'undefined' && plupload.Uploader && !plupload.Uploader.isHookedByDawp) {
            plupload.Uploader.isHookedByDawp = true;
            var OriginalUploader = plupload.Uploader;

            plupload.Uploader = function(options) {
                var uploader = new OriginalUploader(options);
                
                if (uploader && !uploader.isHookedByDawp) {
                    uploader.isHookedByDawp = true;
                    
                    if (!supportsWebP) {
                        // Trình duyệt cũ: Chặn tải lên hình ảnh ngay khi thêm tệp tin vào hàng chờ
                        uploader.bind('FilesAdded', function(up, files) {
                        var hasImages = false;
                        plupload.each(files, function(file) {
                            var isImage = file.type === 'image/jpeg' || file.type === 'image/png' || /\.(jpe?g|png)$/i.test(file.name);
                            if (isImage) {
                                up.removeFile(file);
                                hasImages = true;
                            }
                        });
                        if (hasImages) {
                            alert(browserWarningMessage);
                        }
                    });
                } else {
                    // Trình duyệt mới: Tiến hành nén ảnh sang WebP
                    var pendingConversions = 0;

                    uploader.bind('FilesAdded', function(up, files) {
                        var filesToConvert = [];

                        plupload.each(files, function(file) {
                            var isImage = file.type === 'image/jpeg' || file.type === 'image/png' || /\.(jpe?g|png)$/i.test(file.name);
                            if (isImage && !file.isWebpConverted) {
                                filesToConvert.push(file);
                            }
                        });

                        if (filesToConvert.length > 0) {
                            // Tạm dừng upload để thực hiện nén ảnh bất đồng bộ
                            up.stop();
                            pendingConversions += filesToConvert.length;

                            plupload.each(filesToConvert, function(file) {
                                file.status = plupload.UPLOADING; // Thay đổi trạng thái hiển thị trên giao diện UI
                                
                                convertToWebP(file.getNative(), file.name, function(webpFile) {
                                    if (webpFile) {
                                        var webpName = file.name.substring(0, file.name.lastIndexOf('.')) + '.webp';
                                        
                                        // Ghi đè phương thức getSource() trả về tệp tin WebP thay thế tệp tin gốc
                                        var sourceWrapper = file.getSource();
                                        if (sourceWrapper) {
                                            sourceWrapper.getSource = function() {
                                                return webpFile;
                                            };
                                        }

                                        // Cập nhật metadata của Plupload wrapper
                                        file.size = webpFile.size;
                                        file.name = webpName;
                                        file.type = 'image/webp';
                                        file.isWebpConverted = true;
                                        file.status = plupload.QUEUED;
                                        console.log('DAW Pro: [Plupload] Đã chuyển đổi ' + file.name + ' sang WebP thành công. Kích thước mới: ' + file.size + ' bytes');
                                    } else {
                                        file.isWebpConverted = true;
                                        file.status = plupload.QUEUED;
                                    }

                                    pendingConversions--;
                                    if (pendingConversions <= 0) {
                                        pendingConversions = 0;
                                        // Tiếp tục quá trình upload tệp tin đã được thay đổi
                                        up.start();
                                    }
                                });
                            });
                        }
                    });
                }
                } // Kết thúc kiểm tra !uploader.isHookedByDawp
 
                return uploader;
            };

            // Sao chép prototype từ constructor cũ sang mới
            plupload.Uploader.prototype = OriginalUploader.prototype;
            // Sao chép toàn bộ thuộc tính tĩnh
            Object.assign(plupload.Uploader, OriginalUploader);
            console.log('DAW Pro: Đã hook thành công vào plupload.Uploader.');
        }
    }

    // Hàm hook vào wp.Uploader (sử dụng Plupload cho thư viện media cổ điển và Customizer)
    function hookWpUploader() {
        if (typeof wp !== 'undefined' && wp.Uploader && !wp.Uploader.isHookedByDawp) {
            wp.Uploader.isHookedByDawp = true;
            var OriginalUploader = wp.Uploader;

            wp.Uploader = function(options) {
                var self = this;
                
                // Gọi constructor gốc và lấy kết quả trả về
                var result = OriginalUploader.apply(self, arguments);
                
                // Nếu constructor gốc trả về đối tượng khác, ta sử dụng đối tượng đó
                var instance = (result && typeof result === 'object') ? result : self;

                var uploader = instance.uploader;
                if (uploader && !uploader.isHookedByDawp) {
                    uploader.isHookedByDawp = true;
                    
                    if (!supportsWebP) {
                        // Trình duyệt cũ: Chặn tải lên hình ảnh ngay khi thêm tệp tin vào hàng chờ
                        uploader.bind('FilesAdded', function(up, files) {
                            var hasImages = false;
                            plupload.each(files, function(file) {
                                var isImage = file.type === 'image/jpeg' || file.type === 'image/png' || /\.(jpe?g|png)$/i.test(file.name);
                                if (isImage) {
                                    up.removeFile(file);
                                    hasImages = true;
                                }
                            });
                            if (hasImages) {
                                alert(browserWarningMessage);
                            }
                        });
                    } else {
                        // Trình duyệt mới: Tiến hành nén ảnh sang WebP
                        var pendingConversions = 0;

                        uploader.bind('FilesAdded', function(up, files) {
                            var filesToConvert = [];

                            plupload.each(files, function(file) {
                                var isImage = file.type === 'image/jpeg' || file.type === 'image/png' || /\.(jpe?g|png)$/i.test(file.name);
                                if (isImage && !file.isWebpConverted) {
                                    filesToConvert.push(file);
                                }
                            });

                            if (filesToConvert.length > 0) {
                                // Tạm dừng upload để thực hiện nén ảnh bất đồng bộ
                                up.stop();
                                pendingConversions += filesToConvert.length;

                                plupload.each(filesToConvert, function(file) {
                                    file.status = plupload.UPLOADING; // Thay đổi trạng thái hiển thị trên giao diện UI
                                    
                                    convertToWebP(file.getNative(), file.name, function(webpFile) {
                                        if (webpFile) {
                                            var webpName = file.name.substring(0, file.name.lastIndexOf('.')) + '.webp';
                                            
                                            // Ghi đè phương thức getSource() trả về tệp tin WebP thay thế tệp tin gốc
                                            var sourceWrapper = file.getSource();
                                            if (sourceWrapper) {
                                                sourceWrapper.getSource = function() {
                                                    return webpFile;
                                                };
                                            }

                                            // Cập nhật metadata của Plupload wrapper
                                            file.size = webpFile.size;
                                            file.name = webpName;
                                            file.type = 'image/webp';
                                            file.isWebpConverted = true;
                                            file.status = plupload.QUEUED;
                                            console.log('DAW Pro: Đã chuyển đổi ' + file.name + ' sang WebP tại máy khách thành công.');
                                        } else {
                                            file.isWebpConverted = true;
                                            file.status = plupload.QUEUED;
                                        }

                                        pendingConversions--;
                                        if (pendingConversions <= 0) {
                                            pendingConversions = 0;
                                            // Tiếp tục quá trình upload tệp tin đã được thay đổi
                                            up.start();
                                        }
                                    });
                                });
                            }
                        });
                    }
                } // Kết thúc kiểm tra !uploader.isHookedByDawp
 
                // QUAN TRỌNG: Luôn hoàn trả đối tượng instance
                return instance;
            };

            // Sao chép prototype từ constructor cũ sang mới
            wp.Uploader.prototype = OriginalUploader.prototype;
            
            // QUAN TRỌNG: Sao chép toàn bộ thuộc tính tĩnh (static properties) như queue, defaults, errors...
            // Tránh việc làm mất wp.Uploader.queue phá hỏng luồng hoạt động của Media Library
            Object.assign(wp.Uploader, OriginalUploader);
        }
    }

    // Hàm hook vào trình soạn thảo Gutenberg Block Editor
    function hookGutenbergUpload() {
        if (typeof wp !== 'undefined' && wp.mediaUtils && wp.mediaUtils.uploadMedia && !wp.mediaUtils.uploadMedia.isHookedByDawp) {
            wp.mediaUtils.uploadMedia.isHookedByDawp = true;
            var originalUploadMedia = wp.mediaUtils.uploadMedia;

            wp.mediaUtils.uploadMedia = function(options) {
                var self = this;
                var args = arguments;

                if (options && options.filesList && options.filesList.length > 0) {
                    var files = Array.from(options.filesList);
                    
                    // Trình duyệt cũ: Chặn hoàn toàn và cảnh báo nếu phát hiện tải lên tệp ảnh
                    if (!supportsWebP) {
                        var hasImages = false;
                        files.forEach(function(file) {
                            var isImage = file.type === 'image/jpeg' || file.type === 'image/png' || /\.(jpe?g|png)$/i.test(file.name);
                            if (isImage) {
                                hasImages = true;
                            }
                        });
                        if (hasImages) {
                            alert(browserWarningMessage);
                            return Promise.reject('Browser outdated'); // Trả về Promise Reject cho Gutenberg
                        }
                        return originalUploadMedia.apply(self, args);
                    }

                    // Trình duyệt mới: Thực hiện chuyển đổi sang WebP bất đồng bộ và trả về Promise
                    return new Promise(function(resolve, reject) {
                        var pending = files.length;
                        var convertedFiles = [];

                        var checkAndProceed = function() {
                            if (pending === 0) {
                                options.filesList = convertedFiles;
                                try {
                                    var resultPromise = originalUploadMedia.apply(self, args);
                                    resolve(resultPromise);
                                } catch (e) {
                                    reject(e);
                                }
                            }
                        };

                        files.forEach(function(file, index) {
                            var isImage = file.type === 'image/jpeg' || file.type === 'image/png' || /\.(jpe?g|png)$/i.test(file.name);
                            if (isImage) {
                                convertToWebP(file, file.name, function(webpFile) {
                                    if (webpFile) {
                                        convertedFiles[index] = webpFile;
                                    } else {
                                        convertedFiles[index] = file;
                                    }
                                    pending--;
                                    checkAndProceed();
                                });
                            } else {
                                convertedFiles[index] = file;
                                pending--;
                                checkAndProceed();
                            }
                        });
                    });
                } else {
                    return originalUploadMedia.apply(self, args);
                }
            };
        }
    }

    // Hàm phụ trợ nén và xuất tệp ảnh WebP bằng HTML5 Canvas API với thuật toán nén thông minh (Sharp & Ultra-Light)
    function convertToWebP(nativeFile, originalName, callback, customConfig) {
        if (!nativeFile) {
            callback(null);
            return;
        }

        var objectUrl = URL.createObjectURL(nativeFile);
        var img = new Image();
        img.crossOrigin = 'anonymous';

        img.onload = function() {
            // 1. Tự động chuẩn hóa kích thước về tiêu chuẩn màn hình sắc nét nhất cho web (1600px cho ảnh ngang, 1000px cho ảnh đứng)
            // Giữ nguyên hoàn toàn tỷ lệ ảnh gốc (không vỡ hình, không méo hình)
            var width = img.width;
            var height = img.height;
            var targetWidth = width;
            var targetHeight = height;

            var maxW = (customConfig && customConfig.maxW) ? customConfig.maxW : 1600; 
            var maxH = (customConfig && customConfig.maxH) ? customConfig.maxH : 1000;

            if (width > height) {
                if (width > maxW) {
                    targetWidth = maxW;
                    targetHeight = Math.round((height * maxW) / width);
                }
            } else {
                if (height > maxH) {
                    targetHeight = maxH;
                    targetWidth = Math.round((width * maxH) / height);
                }
            }

            var canvas = document.createElement('canvas');
            canvas.width = targetWidth;
            canvas.height = targetHeight;
            var ctx = canvas.getContext('2d');

            // 2. Thuật toán hạ kích thước nhiều bước (Multi-step Downscaling) giúp ảnh không bị nhòe và răng cưa
            // Thay vì vẽ trực tiếp từ ảnh gốc khổng lồ xuống kích thước đích, ta chia nhỏ từng bước (giảm 50% mỗi lần)
            var tempCanvas = document.createElement('canvas');
            var tempCtx = tempCanvas.getContext('2d');

            var currentWidth = img.width;
            var currentHeight = img.height;

            // Bắt đầu từ ảnh gốc
            tempCanvas.width = currentWidth;
            tempCanvas.height = currentHeight;
            tempCtx.drawImage(img, 0, 0);

            // Thu nhỏ từng bước 50% để tránh mất chi tiết và chống răng cưa
            while (currentWidth * 0.5 > targetWidth && currentHeight * 0.5 > targetHeight) {
                currentWidth = Math.round(currentWidth * 0.5);
                currentHeight = Math.round(currentHeight * 0.5);
                
                var nextCanvas = document.createElement('canvas');
                nextCanvas.width = currentWidth;
                nextCanvas.height = currentHeight;
                var nextCtx = nextCanvas.getContext('2d');
                
                nextCtx.imageSmoothingEnabled = true;
                nextCtx.imageSmoothingQuality = 'high';
                nextCtx.drawImage(tempCanvas, 0, 0, tempCanvas.width, tempCanvas.height, 0, 0, currentWidth, currentHeight);
                
                tempCanvas = nextCanvas;
                tempCtx = nextCtx;
            }

            // Bước vẽ cuối cùng lên canvas đích
            ctx.imageSmoothingEnabled = true;
            ctx.imageSmoothingQuality = 'high';
            ctx.drawImage(tempCanvas, 0, 0, tempCanvas.width, tempCanvas.height, 0, 0, targetWidth, targetHeight);

            // 0. Bản đồ cấu hình chất lượng nén ảnh
            var qualitySettings = {
                'high': {
                    targetSize: 250 * 1024,   // 250 KB
                    initialQuality: 0.85,
                    sharpenAmount: 0.15,
                    minQuality: 0.60
                },
                'ultra': {
                    targetSize: 400 * 1024,   // 400 KB
                    initialQuality: 0.95,
                    sharpenAmount: 0.22,
                    minQuality: 0.70
                },
                'super': {
                    targetSize: 800 * 1024,   // 800 KB
                    initialQuality: 0.98,
                    sharpenAmount: 0.28,
                    minQuality: 0.85
                }
            };

            var level = (window.dawpWebpSettings && window.dawpWebpSettings.quality_level) || 'high';
            var config = qualitySettings[level] || qualitySettings['high'];

            // 3. Thuật toán làm sắc nét thông minh (Smart Sharpen Filter)
            // Nhằm giữ lại độ tương phản ở các cạnh chi tiết giúp ảnh trông cực kỳ sắc nét ("nét căng")
            // Sử dụng lượng sharpen dựa trên cấu hình chất lượng nén.
            try {
                sharpenCanvas(ctx, targetWidth, targetHeight, config.sharpenAmount); 
            } catch (e) {
                console.warn("DAW Pro: Sharpen filter skipped due to error", e);
            }

            // 4. Thuật toán nén thích ứng động (Adaptive WebP Quality Compression)
            // Đảm bảo dung lượng mục tiêu đưa về dưới mức cấu hình nhưng vẫn giữ lại độ sắc nét tốt nhất
            var targetSize = config.targetSize;
            var initialQuality = config.initialQuality;
            
            function compressAdaptive(quality) {
                canvas.toBlob(function(blob) {
                    if (blob) {
                        // Nếu dung lượng vượt quá giới hạn và chất lượng vẫn giảm thêm được (giới hạn tối thiểu theo cấu hình để giữ nét)
                        if (blob.size > targetSize && quality > config.minQuality) {
                            compressAdaptive(quality - 0.08); // Giảm chất lượng đi 8% và nén lại
                        } else {
                            URL.revokeObjectURL(objectUrl);
                            var lastDot = originalName.lastIndexOf('.');
                            var webpName = (lastDot !== -1 ? originalName.substring(0, lastDot) : originalName) + '.webp';
                            var webpFile = new File([blob], webpName, { type: 'image/webp' });
                            console.log('DAW Pro: Nén thích ứng hoàn tất [' + level + ']. Tên:', webpName, 'Chất lượng xuất:', quality.toFixed(2), 'Dung lượng:', (blob.size / 1024).toFixed(1) + ' KB');
                            callback(webpFile);
                        }
                    } else {
                        URL.revokeObjectURL(objectUrl);
                        callback(null);
                    }
                }, 'image/webp', quality);
            }

            compressAdaptive(initialQuality);
        };

        img.onerror = function() {
            URL.revokeObjectURL(objectUrl);
            callback(null);
        };

        img.src = objectUrl;
    }

    // Hàm làm sắc nét sử dụng ma trận Convolution (nhanh và tối ưu)
    function sharpenCanvas(ctx, width, height, amount) {
        var imageData = ctx.getImageData(0, 0, width, height);
        var data = imageData.data;
        
        // Tạo bản sao dữ liệu pixel
        var buffer = new Uint8ClampedArray(data);
        
        // Ma trận 3x3 Laplacian tăng cường độ sắc nét
        var w = amount;
        var centerWeight = 1 + 4 * w;
        var edgeWeight = -w;

        // Bỏ qua các pixel ở viền ngoài cùng 1px để tăng tốc độ và tránh lỗi tràn biên
        for (var y = 1; y < height - 1; y++) {
            for (var x = 1; x < width - 1; x++) {
                var idx = (y * width + x) * 4;
                
                // Vị trí các pixel xung quanh: Trên, Dưới, Trái, Phải
                var topIdx   = ((y - 1) * width + x) * 4;
                var bottomIdx= ((y + 1) * width + x) * 4;
                var leftIdx  = (y * width + (x - 1)) * 4;
                var rightIdx = (y * width + (x + 1)) * 4;

                // Tính toán màu đỏ (Red)
                var r = buffer[idx] * centerWeight + 
                        (buffer[topIdx] + buffer[bottomIdx] + buffer[leftIdx] + buffer[rightIdx]) * edgeWeight;
                
                // Tính toán màu xanh lá (Green)
                var g = buffer[idx + 1] * centerWeight + 
                        (buffer[topIdx + 1] + buffer[bottomIdx + 1] + buffer[leftIdx + 1] + buffer[rightIdx + 1]) * edgeWeight;
                        
                // Tính toán màu xanh dương (Blue)
                var b = buffer[idx + 2] * centerWeight + 
                        (buffer[topIdx + 2] + buffer[bottomIdx + 2] + buffer[leftIdx + 2] + buffer[rightIdx + 2]) * edgeWeight;

                // Ghi đè lại ảnh gốc sau khi giới hạn khoảng màu từ 0 đến 255
                data[idx]     = r < 0 ? 0 : (r > 255 ? 255 : r);
                data[idx + 1] = g < 0 ? 0 : (g > 255 ? 255 : g);
                data[idx + 2] = b < 0 ? 0 : (b > 255 ? 255 : b);
                // Giữ nguyên độ trong suốt (Alpha - index + 3)
            }
        }
        
        ctx.putImageData(imageData, 0, 0);
    }

    // Khởi chạy hook ngay lập tức và khi DOM sẵn sàng
    hookPlupload();
    hookWpUploader();
    hookGutenbergUpload();

    $(document).ready(function() {
        hookPlupload();
        hookWpUploader();
        hookGutenbergUpload();
    });

    // Lặp kiểm tra định kỳ (đề phòng trường hợp thư viện WP được load động bằng Ajax)
    var checkInterval = setInterval(function() {
        hookPlupload();
        hookWpUploader();
        hookGutenbergUpload();
    }, 1000);

    // Tự động giải phóng bộ nhớ sau 15 giây
    setTimeout(function() {
        clearInterval(checkInterval);
    }, 15000);

    window.dawpConvertToWebP = convertToWebP;

})(jQuery);
