<?php
defined( 'ABSPATH' ) || exit;

class DAWP_Helpers {


    /**
     * Lấy giá trị cài đặt từ CSDL (Hỗ trợ chuẩn tương thích LTS 10 năm)
     */
    public static function get_setting( string $key, $default = false ) {
        $options = get_option( 'dawp_settings', [] );
        return isset( $options[ $key ] ) ? $options[ $key ] : $default;
    }

    /**
     * Kiểm tra module có đang được kích hoạt hay không
     */
    public static function is_module_active( string $module_key ) : bool {
        $options = get_option( 'dawp_settings', [] );

        // Cấu hình mặc định cho các module quan trọng.
        // LƯU Ý: khi site chưa lưu cài đặt lần nào ($options rỗng), TRƯỚC ĐÂY hàm
        // này trả true cho MỌI module — làm các module đáng lẽ tắt (Dịch tay,
        // Dịch tự động, Đánh giá sản phẩm) tự chạy trên site mới cài: cột "Dịch
        // thuật" hiện trong danh sách bài viết dù chưa ai bật gì. Nay option rỗng
        // đi cùng đường với option có dữ liệu: tra bảng mặc định dưới đây.
        $defaults = [
            'admin_style_active'      => 1,
            'classic_editor_active'   => 1,
            'optimization_active'     => 1,
            'security_active'         => 1,
            'pagespeed_active'        => 1,
            'contact_form_active'     => 1,
            'contact_buttons_active'  => 1,
            'woo_reviews_active'      => 0,
            'font_awesome_active'     => 1,
            'social_share_active'     => 1,
            'webp_converter_active'   => 1,
            // Giữ khớp với trạng thái mặc định của các ô tick trong trang cài đặt
            'seo_active'              => 1,
            'smtp_active'             => 0,
            'maintenance_active'      => 0,
            'multilingual_active'     => 0,
            'google_translate_active' => 0,
        ];

        if ( ! isset( $options[ $module_key ] ) ) {
            return isset( $defaults[ $module_key ] ) ? (bool)$defaults[ $module_key ] : false;
        }
        return ! empty( $options[ $module_key ] );
    }


    /**
     * Xóa sạch bộ nhớ đệm tĩnh (Static HTML Cache) và phát tín hiệu LiteSpeed Purge
     */
    public static function purge_static_cache() {
        $cache_dir = WP_CONTENT_DIR . '/cache/dawp-cache/';
        if ( file_exists( $cache_dir ) ) {
            $files = glob( $cache_dir . '*' );
            if ( is_array( $files ) ) {
                foreach ( $files as $file ) {
                    if ( is_file( $file ) ) {
                        @unlink( $file );
                    }
                }
            }
        }
        if ( ! headers_sent() ) {
            header( 'X-LiteSpeed-Purge: *' );
        }
    }

    /**
     * Mồi cache tự động cho một URL cụ thể (cả Desktop và Mobile/Tablet)
     */
    public static function preload_url( $url, $only_default = false ) {
        if ( empty( $url ) ) {
            return;
        }

        $default_lang = '';
        if ( class_exists( 'DAWP_Multilingual' ) ) {
            $default_lang = DAWP_Multilingual::get_default_language();
        }

        if ( $only_default ) {
            $langs = [ $default_lang ];
        } else {
            $langs = [];
            if ( class_exists( 'DAWP_Multilingual' ) ) {
                $langs = array_keys( DAWP_Multilingual::get_active_languages() );
            }
            if ( empty( $langs ) ) {
                $langs = [ '' ];
            }
        }

        foreach ( $langs as $code ) {
            $headers_desktop = [
                'User-Agent' => 'DAWP-Auto-Preloader/1.0 (Desktop)'
            ];
            $headers_mobile = [
                'User-Agent' => 'DAWP-Auto-Preloader/1.0 (Mobile; Android)'
            ];

            // Nếu không phải là ngôn ngữ mặc định và code không rỗng, thêm Cookie
            if ( ! empty( $code ) && $code !== $default_lang ) {
                $headers_desktop['Cookie'] = 'dawp_lang=' . $code;
                $headers_mobile['Cookie']  = 'dawp_lang=' . $code;
            }

            // Mồi cache cho Desktop
            wp_remote_get( $url, [
                'timeout'     => 0.1,
                'blocking'    => false,
                'sslverify'   => false,
                'headers'     => $headers_desktop
            ] );

            // Mồi cache cho Mobile/Tablet
            wp_remote_get( $url, [
                'timeout'     => 0.1,
                'blocking'    => false,
                'sslverify'   => false,
                'headers'     => $headers_mobile
            ] );
        }
    }

    /**
     * Minify inline CSS by removing comments, tabs, line breaks and multiple spaces
     */
    public static function minify_css( $css ) {
        if ( empty( $css ) ) {
            return '';
        }
        // Remove comments
        $css = preg_replace( '!/\*[^*]*\*+([^/*][^*]*\*+)*/!', '', $css );
        // Remove spacing, tabs, line breaks
        $css = str_replace( [ "\r\n", "\r", "\n", "\t", '  ', '    ' ], '', $css );
        $css = preg_replace( '/\s*([\{\}:;])\s*/', '$1', $css );
        return trim( $css );
    }
}
