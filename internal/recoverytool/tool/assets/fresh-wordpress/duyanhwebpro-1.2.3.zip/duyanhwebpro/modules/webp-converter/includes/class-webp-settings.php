<?php
/**
 * Quản lý cấu hình plugin.
 *
 * @package duyanhweb
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DAWP_WebP_Settings {

	/**
	 * Giá trị mặc định.
	 *
	 * @return array
	 */
	public static function defaults() {
		return array(
			// Chất lượng WebP 0.10 - 1.00. 0.82 là điểm cân bằng tốt giữa chất lượng và dung lượng.
			'quality'             => 0.82,
			// Giới hạn CẠNH DÀI NHẤT của ảnh gốc (0 = không giới hạn).
			// 1920px = chuẩn màn hình Full HD: hiển thị tràn màn hình vẫn nét,
			// dư ~1.6x cho màn Retina với khung nội dung web thông thường,
			// nhẹ gần một nửa so với 2560. Áp cho cả ảnh ngang lẫn ảnh dọc.
			'max_width'           => 1920,
			// Số ảnh xử lý song song trong trình duyệt. 1 = tuần tự, an toàn nhất.
			'concurrency'         => 1,
			// Giữ lại ảnh gốc bên cạnh bản WebP.
			// Mặc định TẮT: mục tiêu chính là giảm dung lượng. URL cũ đã có ba
			// lớp bảo vệ: metadata + search-replace DB + rule .htaccess trả về
			// bản .webp khi file gốc không còn.
			'keep_original'       => 0,
			// Cập nhật URL trong database sau mỗi ảnh.
			'update_database'     => 1,
			// Lọc HTML đầu ra đổi .jpg/.png sang .webp.
			'enable_rewrite'      => 1,
			// Ghi rule .htaccess để URL cũ vẫn trả về WebP.
			'enable_server_rules' => 1,
			// Định dạng được phép chuyển đổi.
			'convert_jpeg'        => 1,
			'convert_png'         => 1,
		);
	}

	/**
	 * Lấy toàn bộ settings đã merge với mặc định.
	 *
	 * @return array
	 */
	public static function all() {
		$saved = get_option( DAWP_WebP_OPTION, array() );
		if ( ! is_array( $saved ) ) {
			$saved = array();
		}
		return wp_parse_args( $saved, self::defaults() );
	}

	/**
	 * Lấy một giá trị cấu hình.
	 *
	 * @param string $key Khoá.
	 * @return mixed
	 */
	public static function get( $key ) {
		$all = self::all();
		return isset( $all[ $key ] ) ? $all[ $key ] : null;
	}

	/**
	 * Lưu settings sau khi làm sạch dữ liệu.
	 *
	 * @param array $input Dữ liệu thô.
	 * @return array
	 */
	public static function save( $input ) {
		$clean = array();

		$quality          = isset( $input['quality'] ) ? (float) $input['quality'] : 0.82;
		$clean['quality'] = max( 0.10, min( 1.00, $quality ) );

		$clean['max_width']           = isset( $input['max_width'] ) ? max( 0, absint( $input['max_width'] ) ) : 1920;
		$clean['concurrency']         = isset( $input['concurrency'] ) ? max( 1, min( 6, absint( $input['concurrency'] ) ) ) : 1;
		$clean['keep_original']       = empty( $input['keep_original'] ) ? 0 : 1;
		$clean['update_database']     = empty( $input['update_database'] ) ? 0 : 1;
		$clean['enable_rewrite']      = empty( $input['enable_rewrite'] ) ? 0 : 1;
		$clean['enable_server_rules'] = empty( $input['enable_server_rules'] ) ? 0 : 1;
		$clean['convert_jpeg']        = empty( $input['convert_jpeg'] ) ? 0 : 1;
		$clean['convert_png']         = empty( $input['convert_png'] ) ? 0 : 1;

		update_option( DAWP_WebP_OPTION, $clean, false );

		// Đồng bộ rule server theo cấu hình mới.
		if ( $clean['enable_server_rules'] ) {
			DAWP_WebP_Server_Rules::write();
		} else {
			DAWP_WebP_Server_Rules::remove();
		}

		return $clean;
	}

	/**
	 * Cài mặc định lần đầu (không ghi đè cấu hình đã có).
	 */
	public static function install_defaults() {
		if ( false === get_option( DAWP_WebP_OPTION, false ) ) {
			add_option( DAWP_WebP_OPTION, self::defaults(), '', false );
		}
	}

	/**
	 * Danh sách MIME được phép chuyển đổi theo cấu hình.
	 *
	 * @return array
	 */
	public static function enabled_mimes() {
		$mimes = array();
		if ( self::get( 'convert_jpeg' ) ) {
			$mimes[] = 'image/jpeg';
		}
		if ( self::get( 'convert_png' ) ) {
			$mimes[] = 'image/png';
		}
		return $mimes;
	}

	/**
	 * Phần mở rộng file được phép chuyển đổi, theo cấu hình.
	 *
	 * Dùng để lọc từng file kích thước con, vì WordPress chỉ lưu MIME ở cấp
	 * attachment chứ không lưu riêng cho mỗi thumbnail.
	 *
	 * @return string[]
	 */
	public static function enabled_extensions() {
		$extensions = array();
		if ( self::get( 'convert_jpeg' ) ) {
			$extensions[] = 'jpg';
			$extensions[] = 'jpeg';
		}
		if ( self::get( 'convert_png' ) ) {
			$extensions[] = 'png';
		}
		return $extensions;
	}

	/**
	 * File này có thuộc diện cần nén không.
	 *
	 * @param string $filename Tên file.
	 * @return bool
	 */
	public static function is_convertible_file( $filename ) {
		$extension = strtolower( (string) pathinfo( $filename, PATHINFO_EXTENSION ) );
		return in_array( $extension, self::enabled_extensions(), true );
	}
}

