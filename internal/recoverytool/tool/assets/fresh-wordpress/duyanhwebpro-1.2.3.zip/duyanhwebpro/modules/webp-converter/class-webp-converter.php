<?php
defined( 'ABSPATH' ) || exit;

define( 'DAWP_WebP_VERSION', DAWP_VERSION );
define( 'DAWP_WebP_DIR', DAWP_MODULES_DIR . 'webp-converter/' );
define( 'DAWP_WebP_URL', DAWP_URL . 'modules/webp-converter/' );
define( 'DAWP_WebP_REST_NS', 'dawp-webp/v1' );
define( 'DAWP_WebP_OPTION', 'DAWP_WebP_settings' );
define( 'DAWP_WebP_META_DONE', '_DAWP_WebP_optimized' );
define( 'DAWP_WebP_META_SKIP', '_DAWP_WebP_skipped' );
define( 'DAWP_WebP_META_ERROR', '_DAWP_WebP_error' );
define( 'DAWP_WebP_META_PARTIAL', '_DAWP_WebP_partial' );

require_once DAWP_WebP_DIR . 'includes/class-webp-settings.php';
require_once DAWP_WebP_DIR . 'includes/class-webp-db.php';
require_once DAWP_WebP_DIR . 'includes/class-webp-replacer.php';
require_once DAWP_WebP_DIR . 'includes/class-webp-scanner.php';
require_once DAWP_WebP_DIR . 'includes/class-webp-converter.php';
require_once DAWP_WebP_DIR . 'includes/class-webp-repair.php';
require_once DAWP_WebP_DIR . 'includes/class-webp-rest.php';
require_once DAWP_WebP_DIR . 'includes/class-webp-rewriter.php';
require_once DAWP_WebP_DIR . 'includes/class-webp-server-rules.php';
require_once DAWP_WebP_DIR . 'includes/class-webp-admin.php';

class DAWP_WebP_Converter {
	public function __construct() {
		// Nâng cấp cấu hình một lần khi cập nhật version
		if ( DAWP_WebP_VERSION !== get_option( 'DAWP_WebP_version' ) ) {
			// Đảm bảo bảng log + cấu hình mặc định được tạo ngay lần đầu module nạp
			self::create_db_table();

			$saved = get_option( DAWP_WebP_OPTION, array() );
			if ( is_array( $saved ) && isset( $saved['max_width'] ) && 2560 === (int) $saved['max_width'] ) {
				$saved['max_width'] = 1920;
				update_option( DAWP_WebP_OPTION, $saved, false );
			}
			update_option( 'DAWP_WebP_version', DAWP_WebP_VERSION, false );
		}

		new DAWP_WebP_REST();
		new DAWP_WebP_Rewriter();

		if ( is_admin() ) {
			new DAWP_WebP_Admin();
		}
	}

	public static function create_db_table() {
		DAWP_WebP_DB::create_table();
		DAWP_WebP_Settings::install_defaults();
		if ( DAWP_WebP_Settings::get( 'enable_server_rules' ) ) {
			DAWP_WebP_Server_Rules::write();
		}
		update_option( 'DAWP_WebP_version', DAWP_WebP_VERSION, false );
	}
}

