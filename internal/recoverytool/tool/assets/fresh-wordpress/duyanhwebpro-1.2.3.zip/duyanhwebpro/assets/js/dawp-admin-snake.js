document.addEventListener('DOMContentLoaded', function() {
    const cards = document.querySelectorAll('.dawp-app-card');
    if (cards.length === 0) return;

    const canvas = document.createElement('canvas');
    canvas.id = 'dawp-snake-canvas';
    canvas.style.position = 'fixed';
    canvas.style.top = '0';
    canvas.style.left = '0';
    canvas.style.width = '100vw';
    canvas.style.height = '100vh';
    canvas.style.pointerEvents = 'none';
    canvas.style.zIndex = '9999';
    document.body.appendChild(canvas);

    const ctx = canvas.getContext('2d');

    let width = canvas.width = window.innerWidth;
    let height = canvas.height = window.innerHeight;

    window.addEventListener('resize', () => {
        width = canvas.width = window.innerWidth;
        height = canvas.height = window.innerHeight;
        updateTargetPosition();
    });

    let snake = {
        segments: [],
        length: 20, // Độ dài ban đầu
        maxLength: 120, // Giới hạn chiều dài, tới đây sẽ nổ tung chết
        x: width / 2,
        y: height / 2,
        vx: 0,
        vy: 0,
        speed: 4, 
        size: 4, 
        targetCard: null,
        targetX: 0,
        targetY: 0,
        state: 'alive' // 'alive' hoặc 'dying'
    };

    function pickTarget() {
        const randomCard = cards[Math.floor(Math.random() * cards.length)];
        snake.targetCard = randomCard;
        updateTargetPosition();
    }

    function updateTargetPosition() {
        if (!snake.targetCard) return;
        const icon = snake.targetCard.querySelector('.dawp-app-icon');
        if (icon) {
            const iconRect = icon.getBoundingClientRect();
            snake.targetX = iconRect.left + iconRect.width / 2;
            snake.targetY = iconRect.top + iconRect.height / 2;
        }
    }

    pickTarget();

    window.addEventListener('scroll', updateTargetPosition);

    function update() {
        if (snake.state === 'dying') {
            // Hiệu ứng rắn chết: thu mình lại cực nhanh
            for(let i=0; i<6; i++) {
                if (snake.segments.length > 0) snake.segments.pop();
            }
            if (snake.segments.length === 0) {
                // Hồi sinh từ đầu
                snake.state = 'alive';
                snake.length = 20;
                snake.speed = 4;
                snake.x = width / 2;
                snake.y = height / 2;
                snake.vx = 0;
                snake.vy = 0;
                pickTarget();
            }
            return;
        }

        const dx = snake.targetX - snake.x;
        const dy = snake.targetY - snake.y;
        const dist = Math.sqrt(dx * dx + dy * dy);

        if (dist < 15) {
            if (snake.length >= snake.maxLength) {
                // Rắn ăn quá nhiều -> Chết (Nổ tung)
                snake.state = 'dying';
                if(snake.targetCard) {
                    snake.targetCard.classList.add('dawp-card-explode');
                    setTimeout(() => snake.targetCard.classList.remove('dawp-card-explode'), 600);
                }
            } else {
                // Ăn mồi bình thường, dài thêm
                snake.length += 10;
                snake.speed += 0.15; // Càng dài bò càng nhanh
                
                // Hiệu ứng cắn gọi từ CSS Class
                if(snake.targetCard) {
                    snake.targetCard.classList.add('dawp-card-bitten');
                    setTimeout(() => snake.targetCard.classList.remove('dawp-card-bitten'), 400);
                }
                pickTarget();
            }
        } else {
            // Uốn lượn mượt mà
            const angle = Math.atan2(dy, dx);
            const desiredVx = Math.cos(angle) * snake.speed;
            const desiredVy = Math.sin(angle) * snake.speed;
            
            snake.vx += (desiredVx - snake.vx) * 0.05;
            snake.vy += (desiredVy - snake.vy) * 0.05;

            snake.x += snake.vx;
            snake.y += snake.vy;
        }

        snake.segments.unshift({x: snake.x, y: snake.y});
        if (snake.segments.length > snake.length) {
            snake.segments.pop();
        }
    }

    function draw() {
        ctx.clearRect(0, 0, width, height);

        if (snake.state === 'alive') {
            ctx.beginPath();
            ctx.arc(snake.targetX, snake.targetY, 4, 0, Math.PI * 2);
            ctx.fillStyle = '#0d63f3'; 
            ctx.shadowBlur = 10;
            ctx.shadowColor = '#0d63f3';
            ctx.fill();
            ctx.closePath();
            ctx.shadowBlur = 0; 
        }

        if (snake.segments.length > 0) {
            ctx.beginPath();
            ctx.moveTo(snake.segments[0].x, snake.segments[0].y);
            for (let i = 1; i < snake.segments.length; i++) {
                ctx.lineTo(snake.segments[i].x, snake.segments[i].y);
            }
            
            ctx.lineCap = 'round';
            ctx.lineJoin = 'round';
            ctx.lineWidth = snake.size;
            
            let colorStart = '#1d9af2';
            let colorShadow = '#1d9af2';
            if (snake.state === 'dying') {
                colorStart = '#ff3333'; // Hóa đỏ khi chết
                colorShadow = '#ff3333';
            }

            const gradient = ctx.createLinearGradient(
                snake.segments[0].x, snake.segments[0].y, 
                snake.segments[snake.segments.length-1].x, snake.segments[snake.segments.length-1].y
            );
            gradient.addColorStop(0, colorStart); 
            gradient.addColorStop(1, 'rgba(29, 154, 242, 0)'); 
            if (snake.state === 'dying') gradient.addColorStop(1, 'rgba(255, 51, 51, 0)');

            ctx.strokeStyle = gradient;
            ctx.shadowBlur = 8;
            ctx.shadowColor = colorShadow;
            ctx.stroke();
            ctx.shadowBlur = 0;

            ctx.beginPath();
            ctx.arc(snake.segments[0].x, snake.segments[0].y, snake.size / 1.2, 0, Math.PI * 2);
            ctx.fillStyle = '#ffffff'; 
            ctx.shadowBlur = 12;
            ctx.shadowColor = '#ffffff';
            ctx.fill();
            ctx.shadowBlur = 0;
        }
    }

    function loop() {
        update();
        draw();
        requestAnimationFrame(loop);
    }

    loop();
});
