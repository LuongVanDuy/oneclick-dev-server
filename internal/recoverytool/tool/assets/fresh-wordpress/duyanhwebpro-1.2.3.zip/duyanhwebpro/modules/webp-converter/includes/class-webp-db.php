<?php
/**
 * Bảng nhật ký nén ảnh.
 *
 * @package duyanhweb
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DAWP_WebP_DB {

	/**
	 * Tên bảng đầy đủ kèm prefix.
	 *
	 * @return string
	 */
	public static function table() {
		global $wpdb;
		return $wpdb->prefix . 'dawp_webp_log';
	}

	/**
	 * Tạo bảng log khi kích hoạt plugin.
	 */
	public static function create_table() {
		global $wpdb;

		$table   = self::table();
		$collate = $wpdb->get_charset_collate();

		$sql = "CREATE TABLE {$table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			attachment_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			orig_file VARCHAR(500) NOT NULL DEFAULT '',
			webp_file VARCHAR(500) NOT NULL DEFAULT '',
			size_before BIGINT UNSIGNED NOT NULL DEFAULT 0,
			size_after BIGINT UNSIGNED NOT NULL DEFAULT 0,
			files_count INT UNSIGNED NOT NULL DEFAULT 0,
			db_rows_updated INT UNSIGNED NOT NULL DEFAULT 0,
			status VARCHAR(20) NOT NULL DEFAULT 'done',
			message TEXT NULL,
			created_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			PRIMARY KEY  (id),
			KEY attachment_id (attachment_id),
			KEY status (status),
			KEY created_at (created_at)
		) {$collate};";

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta( $sql );
	}

	/**
	 * Ghi một bản ghi nhật ký.
	 *
	 * @param array $data Dữ liệu.
	 * @return int|false
	 */
	public static function log( $data ) {
		global $wpdb;

		$row = wp_parse_args(
			$data,
			array(
				'attachment_id'   => 0,
				'orig_file'       => '',
				'webp_file'       => '',
				'size_before'     => 0,
				'size_after'      => 0,
				'files_count'     => 0,
				'db_rows_updated' => 0,
				'status'          => 'done',
				'message'         => '',
				'created_at'      => current_time( 'mysql' ),
			)
		);

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$ok = $wpdb->insert( self::table(), $row );

		return $ok ? (int) $wpdb->insert_id : false;
	}

	/**
	 * Tổng hợp số liệu để hiển thị dashboard.
	 *
	 * @return array
	 */
	public static function stats() {
		global $wpdb;
		$table = self::table();

		// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL
		$row = $wpdb->get_row(
			"SELECT
				COUNT(*) AS total,
				COALESCE(SUM(size_before),0) AS before_bytes,
				COALESCE(SUM(size_after),0) AS after_bytes,
				COALESCE(SUM(files_count),0) AS files,
				COALESCE(SUM(db_rows_updated),0) AS db_rows
			FROM {$table} WHERE status = 'done'",
			ARRAY_A
		);
		// phpcs:enable

		if ( ! $row ) {
			$row = array(
				'total'        => 0,
				'before_bytes' => 0,
				'after_bytes'  => 0,
				'files'        => 0,
				'db_rows'      => 0,
			);
		}

		$before = (int) $row['before_bytes'];
		$after  = (int) $row['after_bytes'];

		return array(
			'optimized_count' => (int) $row['total'],
			'files_converted' => (int) $row['files'],
			'db_rows_updated' => (int) $row['db_rows'],
			'bytes_before'    => $before,
			'bytes_after'     => $after,
			'bytes_saved'     => max( 0, $before - $after ),
			'percent_saved'   => $before > 0 ? round( ( $before - $after ) / $before * 100, 1 ) : 0.0,
		);
	}

	/**
	 * Lấy các bản ghi gần nhất.
	 *
	 * @param int $limit Số dòng.
	 * @return array
	 */
	public static function recent( $limit = 50 ) {
		global $wpdb;
		$table = self::table();
		$limit = max( 1, min( 500, absint( $limit ) ) );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL
		return $wpdb->get_results(
			$wpdb->prepare( "SELECT * FROM {$table} ORDER BY id DESC LIMIT %d", $limit ),
			ARRAY_A
		);
	}

	/**
	 * Xoá toàn bộ nhật ký.
	 */
	public static function truncate() {
		global $wpdb;
		$table = self::table();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL
		$wpdb->query( "TRUNCATE TABLE {$table}" );
	}

}


