<?php
defined( 'ABSPATH' ) || exit;

class DAWP_Multilingual {
    private static $current_lang = null;
    private static $active_languages = null;
    private static $default_lang = null;
    private static $google_call_count = 0;

    public function __construct() {
        // Mồi cache chắc: ignore_user_abort cho preloader
        if ( isset( $_SERVER['HTTP_USER_AGENT'] ) && strpos( $_SERVER['HTTP_USER_AGENT'], 'DAWP-Auto-Preloader' ) !== false ) {
            ignore_user_abort( true );
            set_time_limit( 180 );
        }

        // Khởi động các class phụ thuộc
        $this->includes();



        // Đăng ký bộ lọc locale của WordPress để nạp tệp dịch .mo gốc cho plugins/themes
        add_filter( 'locale', [ $this, 'filter_locale' ], 1 );
        add_filter( 'theme_locale', [ $this, 'filter_locale' ], 1 );
        
        // Đăng ký vị trí menu đa ngôn ngữ (cần chạy ở cả admin và frontend)
        add_action( 'init', [ $this, 'register_multilingual_nav_menus' ], 99 );
        
        // Đăng ký Shortcode hiển thị bộ chuyển đổi ngôn ngữ ngoài frontend
        add_shortcode( 'dawp_languages', [ $this, 'render_language_switcher' ] );
        
        // Chỉ chạy các bộ lọc frontend nếu phân hệ được kích hoạt
        if ( ! is_admin() || self::is_frontend_ajax() ) {
            add_filter( 'theme_mod_nav_menu_locations', [ $this, 'filter_nav_menu_locations' ] );

            // Lọc logo và link logo theo ngôn ngữ
            add_filter( 'theme_mod_custom_logo', [ $this, 'filter_theme_logo' ] );
            add_filter( 'theme_mod_site_logo', [ $this, 'filter_theme_logo' ] );
            add_filter( 'theme_mod_logo', [ $this, 'filter_theme_logo' ] );
            add_filter( 'theme_mod_logo_image', [ $this, 'filter_theme_logo' ] );
            add_filter( 'theme_mod_ocean_logo', [ $this, 'filter_theme_logo' ] );
            add_filter( 'theme_mod_site_logo_sticky', [ $this, 'filter_theme_logo_sticky' ] );
            add_filter( 'theme_mod_site_logo_dark', [ $this, 'filter_theme_logo_dark' ] );
            add_filter( 'theme_mod_logo_link', [ $this, 'filter_theme_logo_link' ] );

            // Dịch các bài viết, trang, sản phẩm on-the-fly qua filter
            add_filter( 'the_title', [ $this, 'translate_post_title' ], 99, 2 );
            add_filter( 'the_content', [ $this, 'translate_post_content' ], 10 );
            add_filter( 'the_excerpt', [ $this, 'translate_post_excerpt' ], 10 );
            add_filter( 'woocommerce_short_description', [ $this, 'translate_post_excerpt' ], 10 );

            // Dịch danh mục (terms) on-the-fly qua filter
            add_filter( 'get_term', [ $this, 'translate_term' ], 10, 1 );
            add_filter( 'get_the_terms', [ $this, 'translate_the_terms' ], 10, 3 );
            add_filter( 'single_term_title', [ $this, 'translate_single_term_title' ], 10, 1 );

            // Dịch SEO (Yoast SEO)
            add_filter( 'wpseo_title', [ $this, 'translate_seo_title' ] );
            add_filter( 'wpseo_metadesc', [ $this, 'translate_seo_desc' ] );
            add_filter( 'wpseo_opengraph_title', [ $this, 'translate_seo_og_title' ] );
            add_filter( 'wpseo_opengraph_desc', [ $this, 'translate_seo_og_desc' ] );
            add_filter( 'wpseo_opengraph_image', [ $this, 'translate_seo_og_image' ] );
            
            // Dịch SEO (Rank Math)
            add_filter( 'rank_math/frontend/title', [ $this, 'translate_seo_title' ] );
            add_filter( 'rank_math/frontend/description', [ $this, 'translate_seo_desc' ] );
            add_filter( 'rank_math/opengraph/facebook/title', [ $this, 'translate_seo_og_title' ] );
            add_filter( 'rank_math/opengraph/facebook/description', [ $this, 'translate_seo_og_desc' ] );
            add_filter( 'rank_math/opengraph/facebook/image', [ $this, 'translate_seo_og_image' ] );

            // Lọc dịch tên các mục Menu động bằng String Translation
            add_filter( 'wp_nav_menu_objects', [ $this, 'filter_menu_items_by_string_translation' ] );
            add_filter( 'wp_get_nav_menu_items', [ $this, 'filter_menu_items_by_string_translation' ] );

            // Dịch Flatsome UX blocks
            add_filter( 'shortcode_atts_block', [ $this, 'filter_flatsome_block_shortcode_atts' ], 10, 4 );

            // Dịch Flatsome Theme Mods (Header Buttons, v.v.)
            $theme_slug = get_option( 'stylesheet' );
            add_filter( "option_theme_mods_{$theme_slug}", [ $this, 'filter_theme_mods_by_string_translation' ] );
            if ( $theme_slug !== 'flatsome' ) {
                add_filter( "option_theme_mods_flatsome", [ $this, 'filter_theme_mods_by_string_translation' ] );
            }

            // Dịch nội dung Widgets (Tiêu đề và nội dung văn bản)
            add_filter( 'widget_title', [ $this, 'filter_widget_text' ] );
            add_filter( 'widget_text', [ $this, 'filter_widget_text' ] );
            add_filter( 'widget_block_content', [ $this, 'filter_widget_text' ] );
            add_filter( 'widget_custom_html_content', [ $this, 'filter_widget_text' ] );

            // Các action chỉ chạy ở page-load thật (không chạy trong AJAX)
            if ( ! is_admin() ) {
                // Render bộ chuyển đổi ngôn ngữ dạng nổi ở footer
                add_action( 'wp_footer', [ $this, 'render_floating_switcher' ] );

                // Thay thế dịch gettext bằng cơ chế Output Buffering toàn trang siêu tốc
                add_action( 'template_redirect', [ $this, 'start_html_buffer' ], 0 );
            }
        }

        // Clear all transients when settings are updated
        add_action( 'update_option_dawp_settings', [ __CLASS__, 'clear_transients' ] );
    }

    private function includes() {
        if ( is_admin() ) {
            require_once plugin_dir_path( __FILE__ ) . 'class-multilingual-admin.php';
            new DAWP_Multilingual_Admin();
        }
    }

    public static function get_supported_languages() {
        return [
            'vi' => [ 'name' => 'Tiếng Việt', 'locale' => 'vi', 'flag' => 'vn' ],
            'en' => [ 'name' => 'English', 'locale' => 'en_US', 'flag' => 'us' ],
            'zh' => [ 'name' => '简体中文 (Chinese)', 'locale' => 'zh_CN', 'flag' => 'cn' ],
            'ja' => [ 'name' => '日本語 (Japanese)', 'locale' => 'ja', 'flag' => 'jp' ],
            'ko' => [ 'name' => '한국어 (Korean)', 'locale' => 'ko_KR', 'flag' => 'kr' ],
            'fr' => [ 'name' => 'Français (French)', 'locale' => 'fr_FR', 'flag' => 'fr' ],
            'de' => [ 'name' => 'Deutsch (German)', 'locale' => 'de_DE', 'flag' => 'de' ],
            'ru' => [ 'name' => 'Русский (Russian)', 'locale' => 'ru_RU', 'flag' => 'ru' ],
            'es' => [ 'name' => 'Español (Spanish)', 'locale' => 'es_ES', 'flag' => 'es' ],
            'it' => [ 'name' => 'Italiano (Italian)', 'locale' => 'it_IT', 'flag' => 'it' ],
            'pt' => [ 'name' => 'Português (Portuguese)', 'locale' => 'pt_PT', 'flag' => 'pt' ],
            'th' => [ 'name' => 'ไทย (Thai)', 'locale' => 'th', 'flag' => 'th' ],
            'lo' => [ 'name' => 'ລາວ (Lao)', 'locale' => 'lo', 'flag' => 'la' ],
            'km' => [ 'name' => 'ភាសាខ្មែរ (Khmer)', 'locale' => 'km', 'flag' => 'kh' ],
            'my' => [ 'name' => 'မြန်မာဘာသာ (Burmese)', 'locale' => 'my', 'flag' => 'mm' ],
            'id' => [ 'name' => 'Bahasa Indonesia (Indonesian)', 'locale' => 'id_ID', 'flag' => 'id' ],
            'ms' => [ 'name' => 'Bahasa Melayu (Malay)', 'locale' => 'ms_MY', 'flag' => 'my' ],
            'ar' => [ 'name' => 'العربية (Arabic)', 'locale' => 'ar', 'flag' => 'sa' ],
            'hi' => [ 'name' => 'हिन्दी (Hindi)', 'locale' => 'hi_IN', 'flag' => 'in' ],
            'bn' => [ 'name' => 'বাংলা (Bengali)', 'locale' => 'bn_BD', 'flag' => 'bd' ],
            'tr' => [ 'name' => 'Türkçe (Turkish)', 'locale' => 'tr_TR', 'flag' => 'tr' ],
            'nl' => [ 'name' => 'Nederlands (Dutch)', 'locale' => 'nl_NL', 'flag' => 'nl' ],
            'pl' => [ 'name' => 'Polski (Polish)', 'locale' => 'pl_PL', 'flag' => 'pl' ],
            'sv' => [ 'name' => 'Svenska (Swedish)', 'locale' => 'sv_SE', 'flag' => 'se' ],
            'da' => [ 'name' => 'Dansk (Danish)', 'locale' => 'da_DK', 'flag' => 'dk' ],
            'fi' => [ 'name' => 'Suomi (Finnish)', 'locale' => 'fi_FI', 'flag' => 'fi' ],
            'no' => [ 'name' => 'Norsk (Norwegian)', 'locale' => 'nb_NO', 'flag' => 'no' ],
            'el' => [ 'name' => 'Ελληνικά (Greek)', 'locale' => 'el_GR', 'flag' => 'gr' ],
            'he' => [ 'name' => 'עברית (Hebrew)', 'locale' => 'he_IL', 'flag' => 'il' ],
            'cs' => [ 'name' => 'Čeština (Czech)', 'locale' => 'cs_CZ', 'flag' => 'cz' ],
            'hu' => [ 'name' => 'Magyar (Hungarian)', 'locale' => 'hu_HU', 'flag' => 'hu' ],
            'ro' => [ 'name' => 'Română (Romanian)', 'locale' => 'ro_RO', 'flag' => 'ro' ],
            'uk' => [ 'name' => 'Українська (Ukrainian)', 'locale' => 'uk_UA', 'flag' => 'ua' ],
            'sk' => [ 'name' => 'Slovenčina (Slovak)', 'locale' => 'sk_SK', 'flag' => 'sk' ],
            'bg' => [ 'name' => 'Български (Bulgarian)', 'locale' => 'bg_BG', 'flag' => 'bg' ],
            'hr' => [ 'name' => 'Hrvatski (Croatian)', 'locale' => 'hr_HR', 'flag' => 'hr' ],
            'sr' => [ 'name' => 'Српски (Serbian)', 'locale' => 'sr_RS', 'flag' => 'rs' ],
            'sl' => [ 'name' => 'Slovenščina (Slovenian)', 'locale' => 'sl_SI', 'flag' => 'si' ],
            'et' => [ 'name' => 'Eesti (Estonian)', 'locale' => 'et_EE', 'flag' => 'ee' ],
            'lv' => [ 'name' => 'Latviešu (Latvian)', 'locale' => 'lv_LV', 'flag' => 'lv' ],
            'lt' => [ 'name' => 'Lietuvių (Lithuanian)', 'locale' => 'lt_LT', 'flag' => 'lt' ],
            'fa' => [ 'name' => 'فارسی (Persian)', 'locale' => 'fa_IR', 'flag' => 'ir' ],
            'ur' => [ 'name' => 'اردو (Urdu)', 'locale' => 'ur', 'flag' => 'pk' ],
            'sw' => [ 'name' => 'Kiswahili (Swahili)', 'locale' => 'sw', 'flag' => 'tz' ],
            'tl' => [ 'name' => 'Tagalog (Filipino)', 'locale' => 'tl', 'flag' => 'ph' ],
        ];
    }

    public static function get_active_languages() {
        if ( self::$active_languages !== null ) {
            return self::$active_languages;
        }
        $options = get_option( 'dawp_settings', [] );
        $active_codes = isset( $options['multilingual_langs'] ) ? (array)$options['multilingual_langs'] : [];
        if ( empty( $active_codes ) ) {
            $active_codes = [ 'vi', 'en', 'zh' ];
        }
        $supported = self::get_supported_languages();
        $active = [];

        // Luôn đưa ngôn ngữ mặc định (ví dụ: vi) vào đầu tiên
        $default = self::get_default_language();
        if ( isset( $supported[ $default ] ) ) {
            $active[ $default ] = $supported[ $default ];
        }

        foreach ( $active_codes as $code ) {
            if ( $code !== $default && isset( $supported[ $code ] ) ) {
                $active[ $code ] = $supported[ $code ];
            }
        }
        self::$active_languages = $active;
        return $active;
    }

    public static function get_default_language() {
        if ( self::$default_lang !== null ) {
            return self::$default_lang;
        }
        $options = get_option( 'dawp_settings', [] );
        $default = isset( $options['multilingual_default'] ) ? $options['multilingual_default'] : 'vi';
        self::$default_lang = $default;
        return $default;
    }

    public static function get_admin_language() {
        $cookie = isset( $_COOKIE['dawp_admin_lang'] ) ? sanitize_text_field( $_COOKIE['dawp_admin_lang'] ) : '';
        $active = self::get_active_languages();
        if ( ! empty( $cookie ) && array_key_exists( $cookie, $active ) ) {
            return $cookie;
        }
        return self::get_default_language();
    }

    public static function is_builder_context() {
        static $is_builder = null;
        if ( $is_builder !== null ) {
            return $is_builder;
        }

        $is_builder = false;

        // 1. Kiểm tra $_GET['app'] === 'uxbuilder'
        if ( isset( $_GET['app'] ) && $_GET['app'] === 'uxbuilder' ) {
            $is_builder = true;
        }
        // 2. Kiểm tra hằng số IFRAME_REQUEST
        elseif ( defined( 'IFRAME_REQUEST' ) && IFRAME_REQUEST ) {
            $is_builder = true;
        }
        // 3. Kiểm tra $_REQUEST['action'] chứa uxbuilder hoặc liên quan
        elseif ( isset( $_REQUEST['action'] ) ) {
            $action = $_REQUEST['action'];
            if ( strpos( $action, 'ux_builder' ) !== false || strpos( $action, 'uxbuilder' ) !== false || strpos( $action, 'refresh_shortcode' ) !== false ) {
                $is_builder = true;
            }
        }

        // 4. Kiểm tra các key uxb_ trong $_REQUEST
        if ( ! $is_builder && ! empty( $_REQUEST ) ) {
            foreach ( $_REQUEST as $key => $val ) {
                if ( strpos( $key, 'uxb_' ) === 0 ) {
                    $is_builder = true;
                    break;
                }
            }
        }

        return $is_builder;
    }

    public static function is_frontend_ajax() {
        static $is_fe_ajax = null;
        if ( $is_fe_ajax !== null ) {
            return $is_fe_ajax;
        }

        if ( self::is_builder_context() ) {
            $is_fe_ajax = false;
            return $is_fe_ajax;
        }

        $is_ajax = false;
        if ( function_exists( 'wp_doing_ajax' ) ) {
            $is_ajax = wp_doing_ajax();
        } elseif ( defined( 'DOING_AJAX' ) && DOING_AJAX ) {
            $is_ajax = true;
        }

        if ( $is_ajax ) {
            $referer = $_SERVER['HTTP_REFERER'] ?? '';
            if ( empty( $referer ) || strpos( $referer, '/wp-admin/' ) === false ) {
                $is_ajax = true;
            } else {
                $is_ajax = false;
            }
        }

        $is_fe_ajax = $is_ajax;
        return $is_fe_ajax;
    }

    public static function get_current_language() {
        if ( self::is_builder_context() ) {
            self::$current_lang = self::get_default_language();
            return self::$current_lang;
        }

        if ( self::$current_lang !== null ) {
            return self::$current_lang;
        }

        if ( is_admin() && ! self::is_frontend_ajax() ) {
            self::$current_lang = self::get_admin_language();
            return self::$current_lang;
        }

        // Lấy từ Cookie
        $cookie_lang = isset( $_COOKIE['dawp_lang'] ) ? sanitize_text_field( $_COOKIE['dawp_lang'] ) : '';
        $active_langs = self::get_active_languages();
        if ( ! empty( $cookie_lang ) && array_key_exists( $cookie_lang, $active_langs ) ) {
            self::$current_lang = $cookie_lang;
            return self::$current_lang;
        }

        self::$current_lang = self::get_default_language();
        return self::$current_lang;
    }

    public static function get_translation_url( $lang_code ) {
        // Đường dẫn giữ nguyên nên trả về URL hiện tại
        return esc_url_raw( ( is_ssl() ? 'https://' : 'http://' ) . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'] );
    }

    public function register_multilingual_nav_menus() {
        global $_wp_registered_nav_menus;
        if ( empty( $_wp_registered_nav_menus ) ) {
            return;
        }

        $active_langs = self::get_active_languages();
        $default_lang = self::get_default_language();
        $current_lang = self::get_current_language();

        $all_possible_menus = $_wp_registered_nav_menus;
        $new_menus = [];
        foreach ( $_wp_registered_nav_menus as $location => $description ) {
            $is_already_lang = false;
            foreach ( array_keys( $active_langs ) as $code ) {
                $suffix = '_' . $code;
                if ( substr( $location, -strlen( $suffix ) ) === $suffix ) {
                    $is_already_lang = true;
                    break;
                }
            }
            if ( $is_already_lang ) {
                continue;
            }

            foreach ( $active_langs as $lang_code => $lang_info ) {
                if ( $lang_code === $default_lang ) {
                    continue;
                }
                $lang_suffix = '_' . $lang_code;
                $new_location = $location . $lang_suffix;
                $new_description = $description . ' [' . $lang_info['name'] . ']';
                $new_menus[ $new_location ] = $new_description;
            }
        }
        $all_possible_menus = array_merge( $all_possible_menus, $new_menus );

        $filtered_menus = [];
        if ( $current_lang === $default_lang ) {
            foreach ( $all_possible_menus as $location => $description ) {
                $has_lang_suffix = false;
                foreach ( array_keys( $active_langs ) as $code ) {
                    $suffix = '_' . $code;
                    if ( substr( $location, -strlen( $suffix ) ) === $suffix ) {
                        $has_lang_suffix = true;
                        break;
                    }
                }
                if ( ! $has_lang_suffix ) {
                    $filtered_menus[ $location ] = $description;
                }
            }
        } else {
            foreach ( $all_possible_menus as $location => $description ) {
                if ( substr( $location, -strlen( '_' . $current_lang ) ) === '_' . $current_lang ) {
                    $clean_desc = preg_replace( '/\s*\[.*?\]$/', '', $description );
                    $filtered_menus[ $location ] = $clean_desc;
                }
            }
        }

        if ( ! is_admin() ) {
            $_wp_registered_nav_menus = $all_possible_menus;
        } else {
            $_wp_registered_nav_menus = $filtered_menus;
        }
    }

    public function filter_nav_menu_locations( $locations ) {
        if ( ( is_admin() && ! self::is_frontend_ajax() ) || empty( $locations ) ) {
            return $locations;
        }

        $lang = self::get_current_language();
        $default_lang = self::get_default_language();

        if ( $lang !== $default_lang ) {
            foreach ( $locations as $location => $menu_id ) {
                if ( strpos( $location, '_' . $lang ) === false ) {
                    $lang_location = $location . '_' . $lang;
                    if ( isset( $locations[ $lang_location ] ) && ! empty( $locations[ $lang_location ] ) ) {
                        $locations[ $location ] = $locations[ $lang_location ];
                    }
                }
            }
        }

        return $locations;
    }

    public function render_language_switcher( $atts ) {
        $options = get_option( 'dawp_settings', [] );
        $active = isset($options['multilingual_active']) ? (bool)$options['multilingual_active'] : false;
        if ( ! $active ) {
            return '';
        }

        $default_style = isset($options['multilingual_inline_style']) ? $options['multilingual_inline_style'] : 'dropdown-pill';
        $atts = shortcode_atts( [
            'style' => $default_style
        ], $atts, 'dawp_languages' );

        if ( $atts['style'] === 'dropdown' ) {
            $atts['style'] = 'dropdown-pill';
        }

        return $this->generate_html( $options, 'inline', $atts['style'] );
    }

    public function render_floating_switcher() {
        $options = get_option( 'dawp_settings', [] );
        $active = isset($options['multilingual_active']) ? (bool)$options['multilingual_active'] : false;
        if ( ! $active ) {
            return;
        }

        $layout = isset($options['multilingual_layout']) ? $options['multilingual_layout'] : 'floating';
        if ( $layout !== 'floating' ) {
            return;
        }

        echo $this->generate_html( $options, 'floating' );
    }

    private function generate_html( $options, $type = 'floating', $inline_style = 'dropdown-pill' ) {
        $position = isset($options['multilingual_position']) ? $options['multilingual_position'] : 'right';
        $active_langs = self::get_active_languages();
        $current_lang = self::get_current_language();

        if ( count( $active_langs ) <= 1 ) {
            return '';
        }

        $curr_info = isset($active_langs[ $current_lang ]) ? $active_langs[ $current_lang ] : reset($active_langs);
        $flag_code = $curr_info['flag'];
        $local_flag_path = DAWP_DIR . 'assets/flags/' . $flag_code . '.png';
        if ( file_exists( $local_flag_path ) ) {
            $curr_flag_url = DAWP_URL . 'assets/flags/' . $flag_code . '.png';
        } else {
            $curr_flag_url = 'https://flagcdn.com/w40/' . $flag_code . '.png';
        }

        ob_start();
        ?>
        <style>
            .dawp-lang-container {
                font-family: system-ui, -apple-system, sans-serif;
                z-index: 99998;
                box-sizing: border-box;
            }
            .dawp-lang-container * {
                box-sizing: border-box;
            }
            .dawp-lang-container.floating {
                position: fixed;
                bottom: 110px;
                <?php echo $position === 'right' ? 'right: 30px;' : 'left: 30px;'; ?>
            }
            .dawp-lang-btn {
                position: relative;
                width: 56px;
                height: 56px;
                border-radius: 50%;
                background: linear-gradient(135deg, #0068ff, #0056b3);
                color: #ffffff;
                display: flex;
                align-items: center;
                justify-content: center;
                cursor: pointer;
                box-shadow: 0 8px 20px rgba(0, 104, 255, 0.35);
                transition: transform 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275), box-shadow 0.4s;
                border: none;
                outline: none;
            }
            .dawp-lang-btn:hover {
                transform: scale(1.12) translateY(-5px);
                box-shadow: 0 12px 28px rgba(0, 104, 255, 0.5);
            }
            .dawp-lang-btn svg {
                width: 26px;
                height: 26px;
                fill: #ffffff;
                transition: transform 0.4s ease;
            }
            .dawp-lang-btn:hover svg {
                transform: rotate(30deg);
            }
            .dawp-lang-btn::before,
            .dawp-lang-btn::after {
                content: "" !important;
                position: absolute !important;
                top: 0 !important;
                left: 0 !important;
                right: 0 !important;
                bottom: 0 !important;
                border-radius: inherit !important;
                background: inherit !important;
                z-index: -1 !important;
                opacity: 0 !important;
                transform: scale(1) !important;
                pointer-events: none !important;
            }
            .dawp-lang-btn::before {
                animation: dawp-lang-ripple 2.4s infinite cubic-bezier(0.25, 0, 0, 1) !important;
            }
            .dawp-lang-btn::after {
                animation: dawp-lang-ripple 2.4s infinite cubic-bezier(0.25, 0, 0, 1) !important;
                animation-delay: 1.2s !important;
            }
            @keyframes dawp-lang-ripple {
                0% { transform: scale(1); opacity: 0.6; }
                100% { transform: scale(1.5); opacity: 0; }
            }
            .dawp-lang-menu {
                position: absolute;
                bottom: 70px;
                <?php echo $position === 'right' ? 'right: 0;' : 'left: 0;'; ?>
                background: rgba(255, 255, 255, 0.95);
                backdrop-filter: blur(10px);
                -webkit-backdrop-filter: blur(10px);
                border-radius: 12px;
                box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
                padding: 8px 0;
                min-width: 170px;
                display: none;
                opacity: 0;
                transform: translateY(15px);
                transition: opacity 0.3s, transform 0.3s, display 0.3s allow-discrete;
                border: 1px solid rgba(255,255,255,0.4);
            }
            .dawp-lang-menu.open {
                display: block;
                opacity: 1;
                transform: translateY(0);
            }
            .dawp-lang-item {
                display: flex;
                align-items: center;
                padding: 10px 18px;
                color: #2c3e50;
                text-decoration: none !important;
                font-size: 14px;
                font-weight: 600;
                cursor: pointer;
                transition: background 0.25s, color 0.25s;
            }
            .dawp-lang-item:hover {
                background: rgba(0, 104, 255, 0.08);
                color: #0068ff !important;
            }
            .dawp-lang-item:first-child {
                border-top-left-radius: 12px;
                border-top-right-radius: 12px;
            }
            .dawp-lang-item:last-child {
                border-bottom-left-radius: 12px;
                border-bottom-right-radius: 12px;
            }
            .dawp-lang-flag {
                margin-right: 12px;
                line-height: 1;
                display: inline-flex;
                align-items: center;
            }
            .dawp-lang-container.inline {
                position: relative;
                display: inline-flex !important;
                align-items: center;
                vertical-align: middle;
                white-space: nowrap !important;
                flex-wrap: nowrap !important;
            }
            .dawp-lang-container.inline .dawp-lang-btn {
                background: transparent;
                color: inherit;
                width: auto;
                height: 38px;
                padding: 0 14px;
                font-size: 13px;
                font-weight: 600;
                display: inline-flex !important;
                align-items: center;
                gap: 8px;
                box-shadow: none;
                transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
                white-space: nowrap !important;
                flex-wrap: nowrap !important;
                border: none;
                outline: none;
            }
            <?php if ($inline_style === 'dropdown-pill'): ?>
            .dawp-lang-container.inline .dawp-lang-btn {
                border: 1px solid rgba(120, 120, 120, 0.25);
                border-radius: 50px;
            }
            .dawp-lang-container.inline .dawp-lang-btn:hover {
                transform: translateY(-1px);
                background-color: rgba(120, 120, 120, 0.08);
                border-color: rgba(120, 120, 120, 0.4);
                box-shadow: 0 4px 12px rgba(0,0,0,0.03);
            }
            <?php elseif ($inline_style === 'dropdown-flat'): ?>
            .dawp-lang-container.inline .dawp-lang-btn {
                border: 1px solid transparent;
                border-radius: 4px;
                padding: 0 8px;
            }
            .dawp-lang-container.inline .dawp-lang-btn:hover {
                background-color: rgba(120, 120, 120, 0.08);
            }
            <?php endif; ?>
            .dawp-lang-container.inline .dawp-lang-btn::before,
            .dawp-lang-container.inline .dawp-lang-btn::after {
                display: none !important;
                content: none !important;
                animation: none !important;
            }
            .dawp-lang-flag-img {
                width: 20px;
                height: 20px;
                border-radius: 50% !important;
                object-fit: cover !important;
                box-shadow: 0 1px 4px rgba(0,0,0,0.15);
                display: inline-block;
                vertical-align: middle;
                border: 1px solid rgba(0,0,0,0.08);
            }
            .dawp-lang-current-flag {
                display: inline-flex;
                align-items: center;
                line-height: 1;
            }
            .dawp-lang-current-name {
                font-size: 13px;
                font-weight: 600;
            }
            .dawp-lang-chevron {
                display: inline-flex;
                align-items: center;
                transition: transform 0.3s ease;
                opacity: 0.7;
            }
            .dawp-lang-container.inline.open .dawp-lang-chevron {
                transform: rotate(180deg);
            }
            .dawp-lang-container.inline .dawp-lang-menu {
                bottom: auto;
                top: calc(100% + 8px);
                <?php echo $position === 'right' ? 'right: 0; left: auto;' : 'left: 0; right: auto;'; ?>
                background: rgba(255, 255, 255, 0.9);
                backdrop-filter: blur(20px);
                -webkit-backdrop-filter: blur(20px);
                border-radius: 12px;
                border: 1px solid rgba(0, 0, 0, 0.08);
                box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08), 0 3px 10px rgba(0, 0, 0, 0.03);
                padding: 6px 0;
                min-width: 160px;
                opacity: 0;
                transform: translateY(10px);
                pointer-events: none;
                display: block !important;
                transition: opacity 0.25s cubic-bezier(0.4, 0, 0.2, 1), transform 0.25s cubic-bezier(0.4, 0, 0.2, 1);
                z-index: 99999;
            }
            .dawp-lang-container.inline.open .dawp-lang-menu {
                opacity: 1;
                transform: translateY(0);
                pointer-events: auto;
            }
            .dawp-lang-container.inline .dawp-lang-item {
                display: flex;
                align-items: center;
                padding: 8px 16px;
                color: #2c3e50;
                font-size: 13px;
                font-weight: 550;
                transition: background-color 0.2s, color 0.2s;
                gap: 10px;
                border-radius: 0;
            }
            .dawp-lang-container.inline .dawp-lang-item:hover {
                background-color: rgba(0, 104, 255, 0.06);
                color: #0068ff !important;
            }
            .dawp-lang-container.inline .dawp-lang-item.active {
                background-color: rgba(0, 104, 255, 0.08);
                color: #0068ff !important;
                font-weight: 700;
            }
            .dawp-lang-container.inline .dawp-lang-flag {
                margin-right: 0;
                display: inline-flex;
                align-items: center;
            }
            .dawp-lang-flags-list {
                display: inline-flex !important;
                align-items: center;
                gap: 10px;
                flex-wrap: nowrap !important;
                white-space: nowrap !important;
                vertical-align: middle;
            }
            .dawp-lang-flag-item {
                cursor: pointer;
                transition: transform 0.2s cubic-bezier(0.175, 0.885, 0.32, 1.275), filter 0.2s;
                display: inline-flex;
                align-items: center;
                justify-content: center;
                filter: grayscale(0.2) opacity(0.8);
                padding: 2px;
                border-bottom: 2px solid transparent;
                text-decoration: none !important;
            }
            .dawp-lang-flag-item:hover {
                transform: scale(1.2) translateY(-2px);
                filter: grayscale(0) opacity(1);
            }
            .dawp-lang-flag-item.active {
                transform: scale(1.1);
                filter: grayscale(0) opacity(1);
            }
            .dawp-lang-flag-item.active .dawp-lang-flag-img {
                border: 2px solid #0068ff !important;
            }
        </style>

        <div class="dawp-lang-container <?php echo $type; ?> <?php echo esc_attr($inline_style); ?>">
            <?php if ( $type === 'inline' && $inline_style === 'flags' ): ?>
                <div class="dawp-lang-flags-list">
                    <?php foreach ( $active_langs as $code => $lang ): 
                        $is_active = ( $code === $current_lang );
                        $flag_code = $lang['flag'];
                        $local_flag_path = DAWP_DIR . 'assets/flags/' . $flag_code . '.png';
                        $flag_url = file_exists( $local_flag_path ) ? DAWP_URL . 'assets/flags/' . $flag_code . '.png' : 'https://flagcdn.com/w40/' . $flag_code . '.png';
                        $url = self::get_translation_url( $code );
                    ?>
                        <a href="<?php echo esc_url($url); ?>" data-lang="<?php echo esc_attr($code); ?>" class="dawp-lang-flag-item <?php echo $is_active ? 'active' : ''; ?>" title="<?php echo esc_attr($lang['name']); ?>">
                            <img src="<?php echo esc_url($flag_url); ?>" width="20" height="20" alt="<?php echo esc_attr($lang['name']); ?>" class="dawp-lang-flag-img" />
                        </a>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <button class="dawp-lang-btn" aria-label="Switch Language" title="Đổi ngôn ngữ">
                    <?php if ( $type === 'inline' ): ?>
                        <span class="dawp-lang-current-flag">
                            <img src="<?php echo esc_url($curr_flag_url); ?>" width="20" height="20" alt="<?php echo esc_attr($curr_info['name']); ?>" class="dawp-lang-flag-img" />
                        </span>
                        <span class="dawp-lang-current-name" style="margin-left: 8px; margin-right: 2px;"><?php echo esc_html($curr_info['name']); ?></span>
                        <span class="dawp-lang-chevron">
                            <svg viewBox="0 0 24 24" width="14" height="14" fill="currentColor">
                                <path d="M7 10l5 5 5-5z"/>
                            </svg>
                        </span>
                    <?php else: ?>
                        <svg viewBox="0 0 24 24">
                            <path d="M12.87 15.07l-2.54-2.51.03-.03c1.74-1.94 2.98-4.17 3.71-6.53H17V4h-7V2H8v2H1v2h11.17C11.5 7.92 10.44 9.75 9 11.35 8.07 10.32 7.3 9.19 6.69 8h-2c.73 1.63 1.73 3.17 2.98 4.56l-5.09 5.02L4 19l5-5 3.11 3.11.76-2.04zM18.5 10h-2L12 22h2l1.12-3h4.75L21 22h2l-4.5-12zm-2.62 7l1.62-4.33L19.12 17h-3.24z"/>
                        </svg>
                    <?php endif; ?>
                </button>
                <div class="dawp-lang-menu">
                    <?php foreach ( $active_langs as $code => $lang ): 
                        $is_active = ( $code === $current_lang );
                        $flag_code = $lang['flag'];
                        $local_flag_path = DAWP_DIR . 'assets/flags/' . $flag_code . '.png';
                        $flag_url = file_exists( $local_flag_path ) ? DAWP_URL . 'assets/flags/' . $flag_code . '.png' : 'https://flagcdn.com/w40/' . $flag_code . '.png';
                        $url = self::get_translation_url( $code );
                    ?>
                        <a href="<?php echo esc_url($url); ?>" data-lang="<?php echo esc_attr($code); ?>" class="dawp-lang-item <?php echo $is_active ? 'active' : ''; ?>">
                            <span class="dawp-lang-flag">
                                <img src="<?php echo esc_url($flag_url); ?>" width="20" height="20" alt="<?php echo esc_attr($lang['name']); ?>" class="dawp-lang-flag-img" />
                            </span>
                            <span class="dawp-lang-name"><?php echo esc_html($lang['name']); ?></span>
                        </a>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

        <?php if ( ! defined( 'DAWP_LANG_JS_LOADED' ) ): define( 'DAWP_LANG_JS_LOADED', true ); ?>
            <script>
                (function() {
                    document.addEventListener('click', function(e) {
                        var target = e.target.closest('.dawp-lang-item, .dawp-lang-flag-item');
                        if (target) {
                            e.preventDefault();
                            if (target.classList.contains('active')) {
                                return;
                            }
                            var lang = target.getAttribute('data-lang');
                            var href = target.getAttribute('href');
                            if (lang) {
                                var d = new Date();
                                d.setTime(d.getTime() + (30*24*60*60*1000));
                                var expires = "expires="+ d.toUTCString();
                                var hostname = window.location.hostname;
                                var domainParts = hostname.split('.');
                                var wildCardDomain = domainParts.length > 1 ? '.' + domainParts.slice(-2).join('.') : '';

                                // Xóa sạch tất cả các phiên bản cookie cũ có thể tồn tại ở các path và domain khác nhau để tránh trùng lặp
                                var cleanPaths = ['/', '/02', '/02/'];
                                cleanPaths.forEach(function(p) {
                                    document.cookie = "dawp_lang=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=" + p;
                                    document.cookie = "dawp_lang=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=" + p + "; domain=" + hostname;
                                    if (wildCardDomain) {
                                        document.cookie = "dawp_lang=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=" + p + "; domain=" + wildCardDomain;
                                    }
                                });

                                 // Thiết lập duy nhất 1 cookie sạch sẽ cho domain hiện tại ở path / (không chỉ định domain để tránh trùng lặp domain wildcard)
                                 document.cookie = "dawp_lang=" + lang + ";" + expires + ";path=/";
                            }
                            if (href) {
                                var cleanHref = href.split('#')[0].split('?')[0];
                                var cleanCurrent = window.location.href.split('#')[0].split('?')[0];
                                if (cleanHref === cleanCurrent) {
                                    window.location.reload();
                                } else {
                                    window.location.href = href;
                                }
                            }
                        }
                    });

                    document.addEventListener('click', function(e) {
                        var allContainers = document.querySelectorAll('.dawp-lang-container');
                        allContainers.forEach(function(container) {
                            var trigger = container.querySelector('.dawp-lang-btn');
                            var menu = container.querySelector('.dawp-lang-menu');
                            if (trigger && menu) {
                                if (!container.contains(e.target)) {
                                    container.classList.remove('open');
                                    menu.classList.remove('open');
                                }
                            }
                        });
                    });

                    var triggers = document.querySelectorAll('.dawp-lang-btn');
                    triggers.forEach(function(trigger) {
                        trigger.addEventListener('click', function(e) {
                            e.stopPropagation();
                            var container = this.closest('.dawp-lang-container');
                            if (!container) return;
                            var menu = container.querySelector('.dawp-lang-menu');
                            if (!menu) return;
                            
                            document.querySelectorAll('.dawp-lang-container').forEach(function(c) {
                                if (c !== container) {
                                    c.classList.remove('open');
                                    var m = c.querySelector('.dawp-lang-menu');
                                    if (m) m.classList.remove('open');
                                }
                            });

                            container.classList.toggle('open');
                            menu.classList.toggle('open');
                        });
                    });
                })();
            </script>
        <?php endif; ?>
        <?php
        return ob_get_clean();
    }

    public function filter_theme_logo( $value ) {
        $lang = self::get_current_language();
        $default_lang = self::get_default_language();
        if ( $lang !== $default_lang ) {
            $options = get_option( 'dawp_settings', [] );
            $trans_logo = isset( $options['trans_site_logo_' . $lang] ) ? $options['trans_site_logo_' . $lang] : '';
            if ( ! empty( $trans_logo ) ) {
                if ( is_numeric( $value ) && (int) $value > 0 ) {
                    $attachment_id = attachment_url_to_postid( $trans_logo );
                    if ( $attachment_id ) {
                        return (int) $attachment_id;
                    }
                }
                return $trans_logo;
            }
        }
        return $value;
    }

    public function filter_theme_logo_sticky( $value ) {
        $lang = self::get_current_language();
        $default_lang = self::get_default_language();
        if ( $lang !== $default_lang ) {
            $options = get_option( 'dawp_settings', [] );
            $trans_logo_sticky = isset( $options['trans_site_logo_sticky_' . $lang] ) ? $options['trans_site_logo_sticky_' . $lang] : '';
            if ( ! empty( $trans_logo_sticky ) ) {
                if ( is_numeric( $value ) && (int) $value > 0 ) {
                    $attachment_id = attachment_url_to_postid( $trans_logo_sticky );
                    if ( $attachment_id ) {
                        return (int) $attachment_id;
                    }
                }
                return $trans_logo_sticky;
            }
        }
        return $value;
    }

    public function filter_theme_logo_dark( $value ) {
        $lang = self::get_current_language();
        $default_lang = self::get_default_language();
        if ( $lang !== $default_lang ) {
            $options = get_option( 'dawp_settings', [] );
            $trans_logo_dark = isset( $options['trans_site_logo_dark_' . $lang] ) ? $options['trans_site_logo_dark_' . $lang] : '';
            if ( ! empty( $trans_logo_dark ) ) {
                if ( is_numeric( $value ) && (int) $value > 0 ) {
                    $attachment_id = attachment_url_to_postid( $trans_logo_dark );
                    if ( $attachment_id ) {
                        return (int) $attachment_id;
                    }
                }
                return $trans_logo_dark;
            }
        }
        return $value;
    }

    public function filter_theme_logo_link( $value ) {
        return $value; // Dùng chung 1 URL
    }

    public static function get_auto_translation( $text_or_translation, $current_lang, $exact_only = true ) {
        static $auto_dictionary = [
            'rất tiếc! không tìm thấy trang.' => [ 'en' => 'Oops! Page not found.', 'zh' => '抱歉！找不到该页面。' ],
            'rất tiếc! không tìm thấy trang' => [ 'en' => 'Oops! Page not found', 'zh' => '抱歉！找不到该页面' ],
            'dường như không có gì được tìm thấy tại vị trí này. có thể thử một trong các liên kết bên dưới hoặc tìm kiếm?' => [ 'en' => 'It looks like nothing was found at this location. Maybe try one of the links below or a search?', 'zh' => '在此位置好像找不到任何内容。请尝试使用下方的链接或进行搜索。' ],
            'dường như không có gì được tìm thấy tại vị trí này. có thể thử một trong các liên kết bên dưới hoặc tìm kiếm' => [ 'en' => 'It looks like nothing was found at this location. Maybe try one of the links below or a search', 'zh' => '在此位置好像找不到 any links below or search' ],
            'oops! that page can’t be found.' => [ 'en' => 'Oops! Page not found.', 'zh' => '抱歉！找不到该页面。' ],
            'it looks like nothing was found at this location. maybe try one of the links below or a search?' => [ 'en' => 'It looks like nothing was found at this location. Maybe try one of the links below or a search?', 'zh' => '在此位置好像找不到any content. Try using below links or search.' ],
            // Từ điển này CHỈ chứa chuỗi giao diện chung. Tên doanh nghiệp cụ thể
            // (từng có "nội thất minh khôi", "nội thất duy anh" — rác dự án cũ)
            // không được phép nằm ở đây: plugin bán cho nhiều khách, tên riêng
            // của khách này sẽ bị "dịch" trên site của khách khác.
            'chia sẻ bài viết này:' => [ 'en' => 'Share this post:', 'zh' => '分享此文章:' ],
            'chia sẻ bài viết này' => [ 'en' => 'Share this post', 'zh' => '分享此文章' ],
            'chia sẻ sản phẩm này:' => [ 'en' => 'Share this product:', 'zh' => '分享此商品:' ],
            'chia sẻ sản phẩm này' => [ 'en' => 'Share this product', 'zh' => '分享此商品' ],
            'chia sẻ sản phẩm' => [ 'en' => 'Share this product', 'zh' => '分享此商品' ],
            'chia sẻ bài viết' => [ 'en' => 'Share this post', 'zh' => '分享此文章' ],
            'trang chủ' => [ 'en' => 'Home', 'zh' => '首页' ],
            'danh mục:' => [ 'en' => 'Category:', 'zh' => '分类:' ],
            'danh mục' => [ 'en' => 'Category', 'zh' => '分类' ],
            'chia sẻ:' => [ 'en' => 'Share:', 'zh' => '分享:' ],
            'chia sẻ' => [ 'en' => 'Share', 'zh' => '分享' ],
            'sale!' => [ 'en' => 'Sale!', 'zh' => '促销!' ],
            'giảm giá!' => [ 'en' => 'Sale!', 'zh' => '促销!' ],
            'giảm giá' => [ 'en' => 'Sale', 'zh' => '促销' ],
            'add to cart' => [ 'en' => 'Add to cart', 'zh' => '加入购物车' ],
            'thêm vào giỏ hàng' => [ 'en' => 'Add to cart', 'zh' => '加入购物车' ],
            'thêm vào giỏ' => [ 'en' => 'Add to cart', 'zh' => '加入购物车' ],
            'description' => [ 'en' => 'Description', 'zh' => '描述' ],
            'mô tả' => [ 'en' => 'Description', 'zh' => '描述' ],
            'reviews (0)' => [ 'en' => 'Reviews (0)', 'zh' => '评价 (0)' ],
            'reviews' => [ 'en' => 'Reviews', 'zh' => '评价' ],
            'đánh giá (0)' => [ 'en' => 'Reviews (0)', 'zh' => '评价 (0)' ],
            'đánh giá' => [ 'en' => 'Reviews', 'zh' => '评价' ],
            'categories:' => [ 'en' => 'Categories:', 'zh' => '分类:' ],
            'categories' => [ 'en' => 'Categories', 'zh' => '分类' ],
            'home' => [ 'en' => 'Home', 'zh' => '首页' ],
            'related products' => [ 'en' => 'Related Products', 'zh' => '相关产品' ],
            'sản phẩm tương tự' => [ 'en' => 'Related Products', 'zh' => '相关产品' ],
            'sản phẩm liên quan' => [ 'en' => 'Related Products', 'zh' => '相关产品' ],
            'there are no reviews yet.' => [ 'en' => 'There are no reviews yet.', 'zh' => '暂无评价。' ],
            'chưa có đánh giá nào.' => [ 'en' => 'There are no reviews yet.', 'zh' => '暂无评价。' ],
            'be the first to review' => [ 'en' => 'Be the first to review', 'zh' => '成为第一个评价的人' ],
            'hãy là người đầu tiên nhận xét' => [ 'en' => 'Be the first to review', 'zh' => '成为第一个评价的人' ],
            'your email address will not be published.' => [ 'en' => 'Your email address will not be published.', 'zh' => '您的电子邮箱地址不会被公开。' ],
            'địa chỉ email của bạn sẽ không được công bố.' => [ 'en' => 'Your email address will not be published.', 'zh' => '您的电子邮箱地址不会被公开。' ],
            'required fields are marked *' => [ 'en' => 'Required fields are marked *', 'zh' => '必填项已用 * 标注' ],
            'các trường bắt buộc được đánh dấu *' => [ 'en' => 'Required fields are marked *', 'zh' => '必填项已用 * 标注' ],
            'submit' => [ 'en' => 'Submit', 'zh' => '提交' ],
            'gửi đi' => [ 'en' => 'Submit', 'zh' => '提交' ],
            'gửi' => [ 'en' => 'Submit', 'zh' => '提交' ],
            'your rating' => [ 'en' => 'Your rating', 'zh' => '您的评分' ],
            'đánh giá của bạn' => [ 'en' => 'Your rating', 'zh' => '您的评分' ],
            'your review' => [ 'en' => 'Your review', 'zh' => '您的评价' ],
            'nhận xét của bạn' => [ 'en' => 'Your review', 'zh' => '您的评价' ],
            'name' => [ 'en' => 'Name', 'zh' => '姓名' ],
            'tên' => [ 'en' => 'Name', 'zh' => '姓名' ],
            'email' => [ 'en' => 'Email', 'zh' => '电子邮箱' ],
            'save my name, email, and website in this browser for the next time I comment.' => [ 'en' => 'Save my name, email, and website in this browser for the next time I comment.', 'zh' => '在此浏览器中保存我的姓名、电邮和网站以备下次评论时使用。' ],
            'lưu tên của tôi, email, và trang web trong trình duyệt này cho lần bình luận tiếp theo của tôi.' => [ 'en' => 'Save my name, email, and website in this browser for the next time I comment.', 'zh' => '在此浏览器中保存我的姓名、电邮和网站以备下次评论时 sử dụng。' ],
            'product' => [ 'en' => 'Product', 'zh' => '商品' ],
            'sản phẩm' => [ 'en' => 'Product', 'zh' => '商品' ],
            'price' => [ 'en' => 'Price', 'zh' => '价格' ],
            'giá' => [ 'en' => 'Price', 'zh' => '价格' ],
            'quantity' => [ 'en' => 'Quantity', 'zh' => '数量' ],
            'số lượng' => [ 'en' => 'Quantity', 'zh' => '数量' ],
            'subtotal' => [ 'en' => 'Subtotal', 'zh' => '小计' ],
            'tạm tính' => [ 'en' => 'Subtotal', 'zh' => '小计' ],
            'cart totals' => [ 'en' => 'Cart totals', 'zh' => '购物车总计' ],
            'cộng giỏ hàng' => [ 'en' => 'Cart totals', 'zh' => '购物车总计' ],
            'total' => [ 'en' => 'Total', 'zh' => '总计' ],
            'tổng cộng' => [ 'en' => 'Total', 'zh' => '总计' ],
            'tổng' => [ 'en' => 'Total', 'zh' => '总计' ],
            'proceed to checkout' => [ 'en' => 'Proceed to checkout', 'zh' => '前往结账' ],
            'tiến hành thanh toán' => [ 'en' => 'Proceed to checkout', 'zh' => '前往结账' ],
            'coupon code' => [ 'en' => 'Coupon code', 'zh' => '优惠券代码' ],
            'mã ưu đãi' => [ 'en' => 'Coupon code', 'zh' => '优惠券代码' ],
            'mã giảm giá' => [ 'en' => 'Coupon code', 'zh' => '优惠券代码' ],
            'apply coupon' => [ 'en' => 'Apply coupon', 'zh' => '使用优惠券' ],
            'áp dụng ưu đãi' => [ 'en' => 'Apply coupon', 'zh' => '使用优惠券' ],
            'áp dụng' => [ 'en' => 'Apply coupon', 'zh' => '使用优惠券' ],
            'update cart' => [ 'en' => 'Update cart', 'zh' => '更新购物车' ],
            'cập nhật giỏ hàng' => [ 'en' => 'Update cart', 'zh' => '更新购物车' ],
            'cart' => [ 'en' => 'Cart', 'zh' => '购物车' ],
            'giỏ hàng' => [ 'en' => 'Cart', 'zh' => '购物车' ],
            'checkout' => [ 'en' => 'Checkout', 'zh' => '结账' ],
            'thanh toán' => [ 'en' => 'Checkout', 'zh' => '结账' ],
            'billing details' => [ 'en' => 'Billing details', 'zh' => '账单明细' ],
            'thông tin thanh toán' => [ 'en' => 'Billing details', 'zh' => '账单明细' ],
            'first name' => [ 'en' => 'First name', 'zh' => '名字' ],
            'last name' => [ 'en' => 'Last name', 'zh' => '姓氏' ],
            'company name (optional)' => [ 'en' => 'Company name (optional)', 'zh' => '公司名称 (可选)' ],
            'tên công ty (tùy chọn)' => [ 'en' => 'Company name (optional)', 'zh' => '公司名称 (可选)' ],
            'country / region' => [ 'en' => 'Country / Region', 'zh' => '国家/地区' ],
            'quốc gia / khu vực' => [ 'en' => 'Country / Region', 'zh' => '国家/地区' ],
            'street address' => [ 'en' => 'Street address', 'zh' => '街道地址' ],
            'địa chỉ' => [ 'en' => 'Street address', 'zh' => '街道地址' ],
            'town / city' => [ 'en' => 'Town / City', 'zh' => '城镇/城市' ],
            'tỉnh / thành phố' => [ 'en' => 'Town / City', 'zh' => '城镇/城市' ],
            'state / county' => [ 'en' => 'State / County', 'zh' => '省份' ],
            'quận / huyện' => [ 'en' => 'State / County', 'zh' => '省份' ],
            'postcode / zip' => [ 'en' => 'Postcode / ZIP', 'zh' => '邮政编码' ],
            'mã bưu điện' => [ 'en' => 'Postcode / ZIP', 'zh' => '邮政编码' ],
            'phone' => [ 'en' => 'Phone', 'zh' => '电话' ],
            'số điện thoại' => [ 'en' => 'Phone', 'zh' => '电话' ],
            'điện thoại' => [ 'en' => 'Phone', 'zh' => '电话' ],
            'email address' => [ 'en' => 'Email address', 'zh' => '电子邮箱地址' ],
            'địa chỉ email' => [ 'en' => 'Email address', 'zh' => '电子邮箱地址' ],
            'order notes (optional)' => [ 'en' => 'Order notes (optional)', 'zh' => '订单备注 (可选)' ],
            'ghi chú đơn hàng (tùy chọn)' => [ 'en' => 'Order notes (optional)', 'zh' => '订单备注 (可选)' ],
            'your order' => [ 'en' => 'Your order', 'zh' => '您的订单' ],
            'đơn hàng của bạn' => [ 'en' => 'Your order', 'zh' => '您的订单' ],
            'place order' => [ 'en' => 'Place order', 'zh' => '下单' ],
            'đặt hàng' => [ 'en' => 'Place order', 'zh' => '下单' ],
        ];

        $key = mb_strtolower( trim( $text_or_translation ) );
        if ( isset( $auto_dictionary[ $key ][ $current_lang ] ) ) {
            return $auto_dictionary[ $key ][ $current_lang ];
        }
        // Rơi thẳng về dịch tự động Google. Nguồn dùng 'auto' THỐNG NHẤT với
        // auto_translate_batch: source nằm trong khóa transient, trước đây chỗ này
        // truyền default_lang nên khóa lệch với batch pre-warm ('_vi_' vs '_auto_')
        // → kết quả batch không bao giờ được đọc lại, ngân sách request bị đốt kép
        return self::auto_translate_via_google( $text_or_translation, $current_lang, 'auto' );
    }

    public function start_html_buffer() {
        if ( is_admin() ) {
            return;
        }

        // Mồi cache cho bài viết hiện tại và các taxonomy terms liên quan
        $current_lang = self::get_current_language();
        $default_lang = self::get_default_language();
        
        if ( $current_lang !== $default_lang ) {
            $pre_warm_texts = [];
            
            if ( is_singular() ) {
                $post = get_queried_object();
                if ( $post instanceof WP_Post ) {
                    $pre_warm_texts[] = $post->post_title;
                    $pre_warm_texts[] = $post->post_content;
                    $pre_warm_texts[] = $post->post_excerpt;
                    
                    // Lấy các trường SEO
                    $seo_title = get_post_meta( $post->ID, '_yoast_wpseo_title', true );
                    if ( ! empty( $seo_title ) ) $pre_warm_texts[] = $seo_title;
                    $seo_desc = get_post_meta( $post->ID, '_yoast_wpseo_metadesc', true );
                    if ( ! empty( $seo_desc ) ) $pre_warm_texts[] = $seo_desc;
                    
                    $rm_title = get_post_meta( $post->ID, 'rank_math_title', true );
                    if ( ! empty( $rm_title ) ) $pre_warm_texts[] = $rm_title;
                    $rm_desc = get_post_meta( $post->ID, 'rank_math_description', true );
                    if ( ! empty( $rm_desc ) ) $pre_warm_texts[] = $rm_desc;

                    // Lấy các terms của bài viết
                    $taxonomies = get_object_taxonomies( $post->post_type );
                    if ( ! empty( $taxonomies ) ) {
                        $terms = wp_get_post_terms( $post->ID, $taxonomies );
                        if ( ! is_wp_error( $terms ) && ! empty( $terms ) ) {
                            foreach ( $terms as $term ) {
                                $pre_warm_texts[] = $term->name;
                                $pre_warm_texts[] = $term->description;
                            }
                        }
                    }
                }
            } elseif ( is_tax() || is_category() || is_tag() ) {
                $term = get_queried_object();
                if ( $term instanceof WP_Term ) {
                    $pre_warm_texts[] = $term->name;
                    $pre_warm_texts[] = $term->description;
                }
            }

            if ( ! empty( $pre_warm_texts ) ) {
                self::auto_translate_batch( $pre_warm_texts, $current_lang, 'auto' );
            }
        }

        ob_start( [ $this, 'filter_html_translation' ] );
    }

    public function filter_html_translation( $html ) {
        if ( empty( $html ) ) {
            return $html;
        }

        $current_lang = self::get_current_language();
        $default_lang = self::get_default_language();
        if ( $current_lang === $default_lang ) {
            return $html;
        }

        $cache_key = 'dawp_replace_map_' . $current_lang;
        $replace_map = get_transient( $cache_key );
        
        if ( ! is_array( $replace_map ) ) {
            $replace_map = [];
            
            // 1. Tự động thêm từ điển hệ thống theo ngôn ngữ gốc động
            $ui_seeds = [
                'vi' => [
                    'rất tiếc! không tìm thấy trang.', 'rất tiếc! không tìm thấy trang',
                    'dường như không có gì được tìm thấy tại vị trí này. có thể thử một trong các liên kết bên dưới hoặc tìm kiếm?',
                    'dường như không có gì được tìm thấy tại vị trí này. có thể thử một trong các liên kết bên dưới hoặc tìm kiếm',
                    'trang chủ', 'danh mục:', 'danh mục', 'chia sẻ:', 'chia sẻ',
                    'chia sẻ bài viết này:', 'chia sẻ bài viết này', 'chia sẻ sản phẩm này:', 'chia sẻ sản phẩm này',
                    'chia sẻ sản phẩm', 'chia sẻ bài viết',
                    'sale!', 'giảm giá!', 'giảm giá',
                    'thêm vào giỏ hàng', 'thêm vào giỏ',
                    'mô tả',
                    'reviews (0)', 'reviews', 'đánh giá (0)', 'đánh giá',
                    'categories:', 'categories',
                    'sản phẩm tương tự', 'sản phẩm liên quan',
                    'chưa có đánh giá nào.',
                    'hãy là người đầu tiên nhận xét',
                    'địa chỉ email của bạn sẽ không được công bố.',
                    'các trường bắt buộc được đánh dấu *',
                    'gửi đi', 'gửi', 'đánh giá của bạn',
                    'nhận xét của bạn', 'tên', 'email',
                    'lưu tên của tôi, email, và trang web trong trình duyệt này cho lần bình luận tiếp theo của tôi.',
                    'sản phẩm', 'giá', 'số lượng',
                    'tạm tính', 'cộng giỏ hàng', 'tổng cộng', 'tổng',
                    'tiến hành thanh toán', 'mã ưu đãi', 'mã giảm giá',
                    'áp dụng ưu đãi', 'áp dụng', 'cập nhật giỏ hàng',
                    'giỏ hàng', 'thanh toán', 'thông tin thanh toán',
                    'tên công ty (tùy chọn)', 'quốc gia / khu vực', 'địa chỉ',
                    'tỉnh / thành phố', 'quận / huyện', 'mã bưu điện', 'số điện thoại', 'điện thoại',
                    'địa chỉ email', 'ghi chú đơn hàng (tùy chọn)', 'đơn hàng của bạn', 'đặt hàng'
                ],
                'en' => [
                    'oops! that page can’t be found.', 'oops! page not found.', 'oops! page not found',
                    'it looks like nothing was found at this location. maybe try one of the links below or a search?',
                    'it looks like nothing was found at this location. maybe try one of the links below or a search',
                    'home', 'category:', 'category', 'share:', 'share',
                    'share this post:', 'share this post', 'share this product:', 'share this product',
                    'share product', 'share post',
                    'sale!', 'discount',
                    'add to cart', 'add to basket',
                    'description',
                    'reviews (0)', 'reviews', 'rating (0)', 'rating',
                    'categories:', 'categories',
                    'related products', 'similar products',
                    'there are no reviews yet.',
                    'be the first to review',
                    'your email address will not be published.',
                    'required fields are marked *',
                    'submit', 'send', 'your rating',
                    'your review', 'name', 'email',
                    'save my name, email, and website in this browser for the next time I comment.',
                    'product', 'price', 'quantity',
                    'subtotal', 'cart totals', 'total',
                    'proceed to checkout', 'coupon code',
                    'apply coupon', 'apply', 'update cart',
                    'cart', 'checkout', 'billing details',
                    'company name (optional)', 'country / region', 'street address', 'address',
                    'town / city', 'state / county', 'postcode / zip', 'phone', 'telephone',
                    'email address', 'order notes (optional)', 'your order', 'place order'
                ],
                'zh' => [
                    '抱歉！找不到该页面。', '抱歉！找不到该页面',
                    '在此位置好像找不到任何内容。请尝试 sử dụng 下方的链接或进行搜索。',
                    '在此位置好像找不到 any links below or search',
                    '首页', '分类:', '分类', '分享:', '分享',
                    '分享此文章:', '分享此文章', '分享此商品:', '分享此商品',
                    '分享商品', '分享文章',
                    '促销!', '打折',
                    '加入购物车',
                    '描述',
                    '评价 (0)', '评价',
                    '相关产品',
                    '暂无评价。',
                    '成为第一个评价的人',
                    '您的电子邮箱地址不会被公开。',
                    '必填项已用 * 标注',
                    '提交', '发送', '您的评分',
                    '您的评价', '姓名', '电子邮箱',
                    '在此浏览器中保存我的姓名、电邮和网站以备下次评论时使用。',
                    '商品', '价格', '数量',
                    '小计', '购物车总计', '总计',
                    '前往结账', '优惠券代码',
                    '使用优惠券', '使用', '更新购物车',
                    '购物车', '结账', '账单明细',
                    '公司名称 (可选)', '国家/地区', '街道地址', '地址',
                    '城镇/城市', '省份', '邮政编码', '电话',
                    '电子邮箱地址', '订单备注 (可选)', '您的订单', '下单'
                ]
            ];
            
            $sys_phrases = isset( $ui_seeds[ $default_lang ] ) ? $ui_seeds[ $default_lang ] : [];

            // Dịch CẢ LÔ phrase bằng 1-2 request trước, để vòng lặp dưới chỉ đọc cache.
            // Trước đây từng phrase gọi Google riêng lẻ nhưng trần 3 request/pageload
            // → chỉ 3 phrase đầu được dịch, phần còn lại giữ nguyên và bị đóng băng
            // trong replace_map suốt 1 ngày (trang dịch lỗ chỗ kéo dài).
            self::auto_translate_batch( $sys_phrases, $current_lang, 'auto' );

            $unresolved = 0;
            foreach ( $sys_phrases as $phrase ) {
                $trans = self::get_auto_translation( $phrase, $current_lang );

                // Chưa dịch được (hết ngân sách/Google tạm chặn): đếm thiếu và KHÔNG
                // ghi ánh xạ giữ-nguyên vào map — để lượt sau còn dịch bổ sung
                $translated_ok = ! empty( $trans ) && (
                    $trans !== $phrase
                    || false !== get_transient( 'dawp_gt_' . md5( $phrase . '_auto_' . $current_lang ) )
                );
                if ( ! $translated_ok ) {
                    $unresolved++;
                    continue;
                }

                $replace_map[ $phrase ] = $trans;

                $uc_orig = mb_strtoupper( mb_substr( $phrase, 0, 1, 'UTF-8' ), 'UTF-8' ) . mb_substr( $phrase, 1, null, 'UTF-8' );
                $uc_trans = mb_strtoupper( mb_substr( $trans, 0, 1, 'UTF-8' ), 'UTF-8' ) . mb_substr( $trans, 1, null, 'UTF-8' );
                $replace_map[ $uc_orig ] = $uc_trans;

                $replace_map[ mb_strtoupper( $phrase, 'UTF-8' ) ] = mb_strtoupper( $trans, 'UTF-8' );
                $replace_map[ mb_convert_case( $phrase, MB_CASE_TITLE, 'UTF-8' ) ] = mb_convert_case( $trans, MB_CASE_TITLE, 'UTF-8' );
            }
            
            // 2. Lấy từ điển thủ công của người dùng
            $options = get_option( 'dawp_settings', [] );
            $manual_strings = isset( $options['multilingual_strings'] ) ? (array)$options['multilingual_strings'] : [];
            
            foreach ( $manual_strings as $item ) {
                if ( isset( $item['original'] ) && isset( $item['translations'][ $current_lang ] ) && ! empty( $item['translations'][ $current_lang ] ) ) {
                    $orig = trim( $item['original'] );
                    $trans = trim( $item['translations'][ $current_lang ] );
                    
                    $replace_map[ $orig ] = $trans;
                    
                    $uc_orig = mb_strtoupper( mb_substr( $orig, 0, 1, 'UTF-8' ), 'UTF-8' ) . mb_substr( $orig, 1, null, 'UTF-8' );
                    $uc_trans = mb_strtoupper( mb_substr( $trans, 0, 1, 'UTF-8' ), 'UTF-8' ) . mb_substr( $trans, 1, null, 'UTF-8' );
                    $replace_map[ $uc_orig ] = $uc_trans;
                    
                    $replace_map[ mb_strtoupper( $orig, 'UTF-8' ) ] = mb_strtoupper( $trans, 'UTF-8' );
                    $replace_map[ mb_convert_case( $orig, MB_CASE_TITLE, 'UTF-8' ) ] = mb_convert_case( $trans, MB_CASE_TITLE, 'UTF-8' );
                }
            }
            
            if ( ! empty( $replace_map ) ) {
                uksort( $replace_map, function( $a, $b ) {
                    return strlen( $b ) - strlen( $a );
                } );
            }
            
            // Map đủ thì cache 1 ngày; còn phrase chưa dịch được thì chỉ cache 10 phút
            // để lượt xem sau dịch bổ sung thay vì chịu bản thiếu suốt cả ngày
            set_transient( $cache_key, $replace_map, $unresolved > 0 ? 10 * MINUTE_IN_SECONDS : DAY_IN_SECONDS );
        }
        
        if ( ! empty( $replace_map ) ) {
            $parts = preg_split( '/(<script\b[^>]*>.*?<\/script>|<style\b[^>]*>.*?<\/style>|<[^>]+>)/is', $html, -1, PREG_SPLIT_DELIM_CAPTURE );
            if ( is_array( $parts ) ) {
                $texts_to_translate = [];
                $translatable_indices = [];
                
                // 1st Pass: Thu thập các chuỗi cần dịch tự động
                foreach ( $parts as $i => $part ) {
                    if ( empty( $part ) || $part[0] === '<' ) {
                        continue;
                    }
                    $translated_part = strtr( $part, $replace_map );
                    $need_translate = self::should_auto_translate( $translated_part, $current_lang, $translated_part !== $part );
                    if ( $need_translate ) {
                        $texts_to_translate[] = $translated_part;
                        $translatable_indices[$i] = $translated_part;
                    }
                }
                
                // Gọi dịch theo lô (batch) để làm ấm cache
                if ( ! empty( $texts_to_translate ) ) {
                    self::auto_translate_batch( $texts_to_translate, $current_lang, 'auto' );
                }
                
                // 2nd Pass: Áp dụng dịch thực tế (bây giờ tất cả đã có trong transient)
                foreach ( $parts as $i => $part ) {
                    if ( empty( $part ) || $part[0] === '<' ) {
                        continue;
                    }
                    $translated_part = strtr( $part, $replace_map );
                    if ( isset( $translatable_indices[$i] ) ) {
                        $translated_part = self::auto_translate_via_google( $translated_part, $current_lang, 'auto' );
                    }
                    $parts[ $i ] = $translated_part;
                }
                $html = implode( '', $parts );
            } else {
                $translated_html = strtr( $html, $replace_map );
                $need_translate = self::should_auto_translate( $translated_html, $current_lang, $translated_html !== $html );
                if ( $need_translate ) {
                    self::auto_translate_batch( [ $translated_html ], $current_lang, 'auto' );
                    $translated_html = self::auto_translate_via_google( $translated_html, $current_lang, 'auto' );
                }
                $html = $translated_html;
            }
        }
        
        return $html . "\n<!-- DAWP BUFFER PROCESSED " . esc_html($current_lang) . " -->";
    }

    public function translate_string( $translations, $text, $domain ) {
        $current_lang = self::get_current_language();
        $default_lang = self::get_default_language();
        if ( $current_lang === $default_lang ) {
            return $translations;
        }

        if ( empty( $text ) || is_numeric( $text ) || strlen( $text ) <= 1 ) {
            return $translations;
        }
        if ( strlen( $text ) > 300 ) {
            return $translations;
        }
        if ( strpos( $text, 'http' ) === 0 || strpos( $text, '/' ) === 0 || strpos( $text, '#' ) === 0 || strpos( $text, '[' ) === 0 ) {
            return $translations;
        }
        if ( ! preg_match( '/\p{L}/u', $text ) ) {
            return $translations;
        }

        static $runtime_cache = [];
        $cache_key = $current_lang . '|' . $translations . '|' . $text;
        if ( isset( $runtime_cache[ $cache_key ] ) ) {
            return $runtime_cache[ $cache_key ];
        }

        static $indexed_string_cache = null;
        if ( $indexed_string_cache === null ) {
            $options = get_option( 'dawp_settings', [] );
            $raw_cache = isset( $options['multilingual_strings'] ) ? (array)$options['multilingual_strings'] : [];
            $indexed_string_cache = [];
            foreach ( $raw_cache as $item ) {
                if ( isset( $item['original'] ) ) {
                    $key = mb_strtolower( trim( $item['original'] ) );
                    $indexed_string_cache[ $key ] = isset( $item['translations'] ) ? $item['translations'] : [];
                }
            }
        }

        $lower_text = mb_strtolower( trim( $text ) );
        if ( isset( $indexed_string_cache[ $lower_text ][ $current_lang ] ) && ! empty( $indexed_string_cache[ $lower_text ][ $current_lang ] ) ) {
            $runtime_cache[ $cache_key ] = $indexed_string_cache[ $lower_text ][ $current_lang ];
            return $runtime_cache[ $cache_key ];
        }

        $lower_trans = mb_strtolower( trim( $translations ) );
        if ( isset( $indexed_string_cache[ $lower_trans ][ $current_lang ] ) && ! empty( $indexed_string_cache[ $lower_trans ][ $current_lang ] ) ) {
            $runtime_cache[ $cache_key ] = $indexed_string_cache[ $lower_trans ][ $current_lang ];
            return $runtime_cache[ $cache_key ];
        }

        $auto_trans = self::get_auto_translation( $translations, $current_lang );
        if ( ! empty( $auto_trans ) ) {
            $runtime_cache[ $cache_key ] = $auto_trans;
            return $runtime_cache[ $cache_key ];
        }

        $auto_trans_text = self::get_auto_translation( $text, $current_lang );
        if ( ! empty( $auto_trans_text ) ) {
            $runtime_cache[ $cache_key ] = $auto_trans_text;
            return $runtime_cache[ $cache_key ];
        }

        if ( $current_lang === 'en' ) {
            if ( ! preg_match( '/[^\x00-\x7F]/', $text ) ) {
                $runtime_cache[ $cache_key ] = $text;
                return $runtime_cache[ $cache_key ];
            }
            if ( ! preg_match( '/[áàảãạăắằẳẵặâấầẩẫậéèẻẽẹêếềểễệíìỉĩịóòỏõọôốồổỗộơớờởỡợúùủũụưứừửữựýỳỷỹỵđ]/iu', $text ) ) {
                $runtime_cache[ $cache_key ] = $text;
                return $runtime_cache[ $cache_key ];
            }
        }

        $runtime_cache[ $cache_key ] = $translations;
        return $translations;
    }

    public function filter_locale( $locale ) {
        if ( is_admin() && ! self::is_frontend_ajax() ) {
            return $locale;
        }

        $current_lang = self::get_current_language();
        $default_lang = self::get_default_language();

        if ( $current_lang !== $default_lang ) {
            $active_langs = self::get_active_languages();
            if ( isset( $active_langs[ $current_lang ]['locale'] ) && ! empty( $active_langs[ $current_lang ]['locale'] ) ) {
                return $active_langs[ $current_lang ]['locale'];
            }
        }
        return $locale;
    }

    public function filter_menu_items_by_string_translation( $menu_items ) {
        if ( empty( $menu_items ) || ! is_array( $menu_items ) ) {
            return $menu_items;
        }

        $current_lang = self::get_current_language();
        $default_lang = self::get_default_language();
        if ( $current_lang === $default_lang ) {
            return $menu_items;
        }

        static $string_cache = null;
        if ( $string_cache === null ) {
            $options = get_option( 'dawp_settings', [] );
            $string_cache = isset( $options['multilingual_strings'] ) ? (array)$options['multilingual_strings'] : [];
        }

        foreach ( $menu_items as $item ) {
            // Dịch Nhãn điều hướng trực tiếp của menu item nếu có
            $tr_label = get_post_meta( $item->ID, '_dawp_menu_item_label_' . $current_lang, true );
            if ( ! empty( $tr_label ) ) {
                $item->title = $tr_label;
            } else {
                if ( ! empty( $string_cache ) ) {
                    $title = $item->title;
                    foreach ( $string_cache as $item_tr ) {
                        if ( isset( $item_tr['original'] ) && trim( $item_tr['original'] ) === trim( $title ) ) {
                            if ( isset( $item_tr['translations'][ $current_lang ] ) && ! empty( $item_tr['translations'][ $current_lang ] ) ) {
                                $item->title = $item_tr['translations'][ $current_lang ];
                                break;
                            }
                        }
                    }
                }
            }
        }

        return $menu_items;
    }

    public function filter_flatsome_block_shortcode_atts( $out, $pairs, $atts, $shortcode ) {
        return $out; // Dùng chung 1 URL
    }

    public function filter_theme_mods_by_string_translation( $mods ) {
        if ( ( is_admin() && ! self::is_frontend_ajax() ) || empty( $mods ) || ! is_array( $mods ) ) {
            return $mods;
        }

        $current_lang = self::get_current_language();
        $default_lang = self::get_default_language();
        if ( $current_lang === $default_lang ) {
            return $mods;
        }

        static $string_cache = null;
        if ( $string_cache === null ) {
            $options = get_option( 'dawp_settings', [] );
            $string_cache = isset( $options['multilingual_strings'] ) ? (array)$options['multilingual_strings'] : [];
        }

        if ( ! empty( $string_cache ) ) {
            $mods = self::recursive_translate_array( $mods, $string_cache, $current_lang );
        }

        return $mods;
    }

    private static function recursive_translate_array( $array, $string_cache, $current_lang ) {
        // Blocklist dự phòng chung cho các theme
        $ignored_keys = [
            'footer_block', '404_block', 'pages_template', 'nav_menu_locations', 
            'custom_css_post_id', 'custom_logo', 'site_logo', 'logo', 'logo_image', 
            'ocean_logo', 'site_logo_sticky', 'site_logo_dark', 'logo_link', 'logo_width',
            'font-family', 'variant', 'nav_menu', 'menu', 'template', 'stylesheet', 
            'page_on_front', 'page_for_posts'
        ];

        foreach ( $array as $key => $value ) {
            // Kiểm tra key kỹ thuật hoặc nếu key chứa hậu tố đặc biệt
            if ( in_array( $key, $ignored_keys, true ) || preg_match( '/(_id|_url|_class|_block|_logo|template|style)$/i', $key ) ) {
                continue;
            }

            if ( is_array( $value ) ) {
                $array[ $key ] = self::recursive_translate_array( $value, $string_cache, $current_lang );
            } elseif ( is_string( $value ) ) {
                // Sử dụng hàm heuristic để tự động nhận dạng và bỏ qua slug/cấu hình kỹ thuật trên mọi theme
                if ( self::is_technical_slug_or_config( $value ) ) {
                    continue;
                }

                $matched_user = false;
                foreach ( $string_cache as $item_tr ) {
                    if ( isset( $item_tr['original'], $item_tr['translations'][ $current_lang ] ) ) {
                        $orig = $item_tr['original'];
                        $trans = $item_tr['translations'][ $current_lang ];
                        if ( ! empty( $orig ) && ! empty( $trans ) && strpos( $value, $orig ) !== false ) {
                            $array[ $key ] = str_replace( $orig, $trans, $array[ $key ] );
                            $matched_user = true;
                        }
                    }
                }

                if ( ! $matched_user ) {
                    $auto_val = self::get_auto_translation( $value, $current_lang, false );
                    if ( ! empty( $auto_val ) ) {
                        $array[ $key ] = $auto_val;
                    } else {
                        // Tiêm dịch tự động Google
                        $array[ $key ] = self::auto_translate_via_google( $value, $current_lang );
                    }
                }
            }
        }
        return $array;
    }

    /**
     * Tự động nhận dạng chuỗi cấu hình hoặc slug kỹ thuật (không phải nội dung dịch) 
     * để tương thích độc lập 100% với mọi loại WordPress theme.
     */
    public static function is_technical_slug_or_config( $value ) {
        if ( ! is_string( $value ) ) {
            return true;
        }
        $value = trim( $value );
        if ( $value === '' ) {
            return true;
        }

        // 1. Chứa ngoặc vuông của shortcode hoặc JSON/CSS rules
        if ( strpos( $value, '[' ) !== false && strpos( $value, ']' ) !== false ) {
            return true;
        }
        if ( strpos( $value, '{' ) !== false && strpos( $value, '}' ) !== false ) {
            return true;
        }
        
        // 2. Định dạng CSS inline hoặc Serialized data của WordPress
        if ( strpos( $value, ';' ) !== false || strpos( $value, ':' ) !== false ) {
            if ( preg_match( '/^[a-zA-Z0-9_-]+:[a-zA-Z0-9_#-]+;?/', $value ) || ( function_exists( 'is_serialized' ) && is_serialized( $value ) ) ) {
                return true;
            }
        }

        // 3. Không có chữ cái nào (chỉ số, ngày tháng hoặc ký tự đặc biệt)
        if ( ! preg_match( '/\p{L}/u', $value ) ) {
            return true;
        }

        // 4. Nếu không có khoảng trắng (từ đơn hoặc slug kỹ thuật)
        if ( strpos( $value, ' ' ) === false ) {
            // Nếu không chứa ký tự Tiếng Việt có dấu, thì 100% là slug kỹ thuật (e.g. 'footer', 'blank', 'flat')
            if ( ! preg_match( '/[áàảãạăắằẳẵặâấầẩẫậéèẻẽẹêếềểễệíìỉĩịóòỏõọôốồổỗộơớờởỡợúùủũụưứừửữựýỳỷỹỵđ]/iu', $value ) ) {
                return true;
            }
        }

        // 5. Định dạng tên file hoặc đường dẫn/URL
        if ( preg_match( '/\.(jpg|jpeg|png|gif|webp|svg|css|js|woff|woff2|ttf|php|html)$/i', $value ) ) {
            return true;
        }
        if ( filter_var( $value, FILTER_VALIDATE_URL ) ) {
            return true;
        }

        return false;
    }

    public function filter_widget_text( $text ) {
        if ( empty( $text ) || ! is_string( $text ) ) {
            return $text;
        }
        return $this->translate_string( $text, $text, 'widget' );
    }

    public static function clear_transients() {
        global $wpdb;
        $wpdb->query( "DELETE FROM $wpdb->options WHERE option_name LIKE '_transient_dawp_replace_map_%'" );
        $wpdb->query( "DELETE FROM $wpdb->options WHERE option_name LIKE '_transient_timeout_dawp_replace_map_%'" );
        $wpdb->query( "DELETE FROM $wpdb->options WHERE option_name LIKE '_transient_dawp_gt_%'" );
        $wpdb->query( "DELETE FROM $wpdb->options WHERE option_name LIKE '_transient_timeout_dawp_gt_%'" );
    }

    public function translate_post_title( $title, $post_id = null ) {
        if ( self::is_builder_context() ) return $title;
        if ( ! $post_id || ( is_admin() && ! self::is_frontend_ajax() ) ) return $title;
        $current_lang = self::get_current_language();
        $default_lang = self::get_default_language();
        if ( $current_lang === $default_lang ) return $title;

        static $title_cache = [];
        $cache_key = $post_id . '_' . $current_lang;
        if ( isset( $title_cache[ $cache_key ] ) ) {
            return $title_cache[ $cache_key ] ? $title_cache[ $cache_key ] : $title;
        }

        $trans_title = get_post_meta( $post_id, "_dawp_trans_{$current_lang}_title", true );
        if ( ! empty( $trans_title ) ) {
            $title_cache[ $cache_key ] = $trans_title;
            return $trans_title;
        }
        
        // Tiêm dịch tự động Google nếu chưa có bản dịch tay
        $auto_title = self::auto_translate_via_google( $title, $current_lang );
        $title_cache[ $cache_key ] = $auto_title;
        return $auto_title;
    }

    public function translate_post_content( $content ) {
        if ( self::is_builder_context() ) return $content;
        if ( is_admin() && ! self::is_frontend_ajax() ) return $content;
        $post_id = get_the_ID();
        if ( ! $post_id ) return $content;
        
        $current_lang = self::get_current_language();
        $default_lang = self::get_default_language();
        if ( $current_lang === $default_lang ) return $content;

        static $content_cache = [];
        $cache_key = $post_id . '_' . $current_lang;
        if ( isset( $content_cache[ $cache_key ] ) ) {
            return $content_cache[ $cache_key ] ? $content_cache[ $cache_key ] : $content;
        }

        $trans_content = get_post_meta( $post_id, "_dawp_trans_{$current_lang}_content", true );
        if ( ! empty( $trans_content ) ) {
            $content_cache[ $cache_key ] = $trans_content;
            return $trans_content;
        }
        
        // Tiêm dịch tự động Google nếu chưa có bản dịch tay
        $auto_content = self::auto_translate_via_google( $content, $current_lang );
        $content_cache[ $cache_key ] = $auto_content;
        return $auto_content;
    }

    public function translate_post_excerpt( $excerpt ) {
        if ( is_admin() && ! self::is_frontend_ajax() ) return $excerpt;
        $post_id = get_the_ID();
        if ( ! $post_id ) return $excerpt;
        
        $current_lang = self::get_current_language();
        $default_lang = self::get_default_language();
        if ( $current_lang === $default_lang ) return $excerpt;

        $trans_excerpt = get_post_meta( $post_id, "_dawp_trans_{$current_lang}_excerpt", true );
        if ( ! empty( $trans_excerpt ) ) {
            return $trans_excerpt;
        }
        
        // Tiêm dịch tự động Google nếu chưa có bản dịch tay
        return self::auto_translate_via_google( $excerpt, $current_lang );
    }

    public function translate_term( $_term ) {
        if ( ! $_term || is_wp_error( $_term ) || ( is_admin() && ! self::is_frontend_ajax() ) ) {
            return $_term;
        }
        if ( isset( $_term->taxonomy ) && in_array( $_term->taxonomy, [ 'product_type', 'product_visibility', 'post_format' ], true ) ) {
            return $_term;
        }
        $current_lang = self::get_current_language();
        $default_lang = self::get_default_language();
        if ( $current_lang === $default_lang ) {
            return $_term;
        }

        $trans_name = get_term_meta( $_term->term_id, "_dawp_trans_{$current_lang}_name", true );
        if ( ! empty( $trans_name ) ) {
            $_term->name = $trans_name;
        } else {
            $_term->name = self::auto_translate_via_google( $_term->name, $current_lang );
        }

        $trans_desc = get_term_meta( $_term->term_id, "_dawp_trans_{$current_lang}_description", true );
        if ( ! empty( $trans_desc ) ) {
            $_term->description = $trans_desc;
        } else {
            $_term->description = self::auto_translate_via_google( $_term->description, $current_lang );
        }

        return $_term;
    }

    public function translate_the_terms( $terms, $post_id, $taxonomy ) {
        if ( empty( $terms ) || is_wp_error( $terms ) || ( is_admin() && ! self::is_frontend_ajax() ) ) {
            return $terms;
        }
        if ( in_array( $taxonomy, [ 'product_type', 'product_visibility', 'post_format' ], true ) ) {
            return $terms;
        }
        $current_lang = self::get_current_language();
        $default_lang = self::get_default_language();
        if ( $current_lang === $default_lang ) {
            return $terms;
        }

        foreach ( $terms as $index => $term ) {
            $trans_name = get_term_meta( $term->term_id, "_dawp_trans_{$current_lang}_name", true );
            if ( ! empty( $trans_name ) ) {
                $terms[ $index ]->name = $trans_name;
            } else {
                $terms[ $index ]->name = self::auto_translate_via_google( $term->name, $current_lang );
            }
            $trans_desc = get_term_meta( $term->term_id, "_dawp_trans_{$current_lang}_description", true );
            if ( ! empty( $trans_desc ) ) {
                $terms[ $index ]->description = $trans_desc;
            } else {
                $terms[ $index ]->description = self::auto_translate_via_google( $term->description, $current_lang );
            }
        }
        return $terms;
    }

    public function translate_single_term_title( $title ) {
        $term = get_queried_object();
        if ( $term && isset( $term->term_id ) ) {
            $current_lang = self::get_current_language();
            $default_lang = self::get_default_language();
            if ( $current_lang !== $default_lang ) {
                $trans_name = get_term_meta( $term->term_id, "_dawp_trans_{$current_lang}_name", true );
                if ( ! empty( $trans_name ) ) {
                    return $trans_name;
                }
                return self::auto_translate_via_google( $title, $current_lang );
            }
        }
        return $title;
    }

    public function translate_seo_title( $title ) {
        if ( is_admin() && ! self::is_frontend_ajax() ) return $title;
        $post_id = get_the_ID();
        if ( ! $post_id ) return $title;
        $current_lang = self::get_current_language();
        $default_lang = self::get_default_language();
        if ( $current_lang === $default_lang ) return $title;

        $trans_seo_title = get_post_meta( $post_id, "_dawp_trans_{$current_lang}_seo_title", true );
        return ! empty( $trans_seo_title ) ? $trans_seo_title : self::auto_translate_via_google( $title, $current_lang );
    }

    public function translate_seo_desc( $desc ) {
        if ( is_admin() && ! self::is_frontend_ajax() ) return $desc;
        $post_id = get_the_ID();
        if ( ! $post_id ) return $desc;
        $current_lang = self::get_current_language();
        $default_lang = self::get_default_language();
        if ( $current_lang === $default_lang ) return $desc;

        $trans_seo_desc = get_post_meta( $post_id, "_dawp_trans_{$current_lang}_seo_desc", true );
        return ! empty( $trans_seo_desc ) ? $trans_seo_desc : self::auto_translate_via_google( $desc, $current_lang );
    }

    public function translate_seo_og_title( $og_title ) {
        if ( is_admin() && ! self::is_frontend_ajax() ) return $og_title;
        $post_id = get_the_ID();
        if ( ! $post_id ) return $og_title;
        $current_lang = self::get_current_language();
        $default_lang = self::get_default_language();
        if ( $current_lang === $default_lang ) return $og_title;

        $trans_og_title = get_post_meta( $post_id, "_dawp_trans_{$current_lang}_og_title", true );
        if ( ! empty( $trans_og_title ) ) {
            return $trans_og_title;
        }
        return $this->translate_seo_title( $og_title );
    }

    public function translate_seo_og_desc( $og_desc ) {
        if ( is_admin() && ! self::is_frontend_ajax() ) return $og_desc;
        $post_id = get_the_ID();
        if ( ! $post_id ) return $og_desc;
        $current_lang = self::get_current_language();
        $default_lang = self::get_default_language();
        if ( $current_lang === $default_lang ) return $og_desc;

        $trans_og_desc = get_post_meta( $post_id, "_dawp_trans_{$current_lang}_og_desc", true );
        if ( ! empty( $trans_og_desc ) ) {
            return $trans_og_desc;
        }
        return $this->translate_seo_desc( $og_desc );
    }

    public function translate_seo_og_image( $og_image ) {
        if ( is_admin() && ! self::is_frontend_ajax() ) return $og_image;
        $post_id = get_the_ID();
        if ( ! $post_id ) return $og_image;
        $current_lang = self::get_current_language();
        $default_lang = self::get_default_language();
        if ( $current_lang === $default_lang ) return $og_image;

        $trans_og_image = get_post_meta( $post_id, "_dawp_trans_{$current_lang}_og_image", true );
        return ! empty( $trans_og_image ) ? $trans_og_image : $og_image;
    }

    /**
     * Cầu dao ngắt mạch: khi Google lỗi/chặn (429), tạm dừng gọi API 10 phút
     * toàn site. Không có nó, mỗi pageview đốt 3 request x 2s timeout = chậm 6s
     * liên tục trong lúc Google vẫn đang chặn, mà không dịch được gì.
     */
    private static function google_backoff_active() {
        return false !== get_transient( 'dawp_gt_backoff' );
    }

    private static function trigger_google_backoff() {
        set_transient( 'dawp_gt_backoff', 1, 10 * MINUTE_IN_SECONDS );
    }

    /**
     * Tự động dịch chuỗi sang ngôn ngữ đích sử dụng API Google Translate miễn phí gtx.
     * Tích hợp lưu Transient Cache trong 30 ngày để tối ưu hiệu năng tối đa.
     */
    public static function auto_translate_via_google( $text, $target_lang, $source_lang = 'auto' ) {
        if ( ! is_string( $text ) || empty( $text ) || is_numeric( $text ) ) {
            return $text;
        }
        
        if ( ! self::should_auto_translate( $text, $target_lang ) ) {
            return $text;
        }
        
        if ( empty( $source_lang ) ) {
            $source_lang = 'auto';
        }
        
        // Chỉ dịch các chuỗi có chứa chữ cái để tránh dịch thẻ code/JSON/số thuần
        if ( ! preg_match( '/\p{L}/u', $text ) ) {
            return $text;
        }

        $cache_key = 'dawp_gt_' . md5( $text . '_' . $source_lang . '_' . $target_lang );
        $cached = get_transient( $cache_key );
        if ( $cached !== false ) {
            return $cached;
        }

        // Trần ngân sách: tối đa 3 request Google (dùng chung với batch)
        if ( self::$google_call_count >= 3 || self::google_backoff_active() ) {
            return $text;
        }

        $url = 'https://translate.googleapis.com/translate_a/single?client=gtx&sl=' . urlencode( $source_lang ) . '&tl=' . urlencode( $target_lang ) . '&dt=t&q=' . urlencode( $text );

        self::$google_call_count++;

        $response = wp_remote_get( $url, [ 'timeout' => 2 ] ); // Hạ timeout xuống 2 giây
        if ( is_wp_error( $response ) || 200 !== (int) wp_remote_retrieve_response_code( $response ) ) {
            self::trigger_google_backoff();
            return $text;
        }

        $body = wp_remote_retrieve_body( $response );
        $data = json_decode( $body, true );
        
        if ( is_array( $data ) && isset( $data[0] ) ) {
            $translated = '';
            foreach ( $data[0] as $sentence ) {
                if ( isset( $sentence[0] ) ) {
                    $translated .= $sentence[0];
                }
            }
            if ( ! empty( $translated ) ) {
                set_transient( $cache_key, $translated, 30 * DAY_IN_SECONDS );
                return $translated;
            }
        }
        return $text;
    }

    /**
     * Dịch một lô chuỗi văn bản bằng một request duy nhất tới Google Translate.
     * Lưu kết quả vào transient cache của từng chuỗi riêng lẻ.
     */
    public static function auto_translate_batch( array $texts, $target_lang, $source_lang = 'auto' ) {
        if ( empty( $texts ) ) {
            return;
        }

        $source_lang = $source_lang ? $source_lang : 'auto';
        
        // 1. Lọc các chuỗi chưa được cache và có chữ cái
        $uncached_texts = [];
        foreach ( $texts as $text ) {
            if ( ! is_string( $text ) || empty( $text ) || ! self::should_auto_translate( $text, $target_lang ) ) {
                continue;
            }
            $cache_key = 'dawp_gt_' . md5( $text . '_' . $source_lang . '_' . $target_lang );
            $cached = get_transient( $cache_key );
            if ( $cached === false ) {
                $uncached_texts[] = $text;
            }
        }

        if ( empty( $uncached_texts ) ) {
            return;
        }

        // Loại bỏ trùng lặp trong lô hiện tại
        $unique_uncached = array_values( array_unique( $uncached_texts ) );
        
        // 2. Chia lô nhỏ hơn (batches) để không vượt quá chiều dài URL an toàn (~3500 ký tự)
        // và tuân thủ giới hạn tối đa 3 request Google cho mỗi trang load.
        $batch = [];
        $batch_length = 0;
        $batches = [];
        
        foreach ( $unique_uncached as $text ) {
            $text_len = strlen( urlencode( $text ) );
            if ( $batch_length + $text_len > 3500 && ! empty( $batch ) ) {
                $batches[] = $batch;
                $batch = [];
                $batch_length = 0;
            }
            $batch[] = $text;
            $batch_length += $text_len + 3; // +3 cho '&q='
        }
        if ( ! empty( $batch ) ) {
            $batches[] = $batch;
        }

        foreach ( $batches as $current_batch ) {
            if ( self::$google_call_count >= 3 || self::google_backoff_active() ) {
                break; // Vượt trần ngân sách hoặc Google đang tạm chặn
            }

            // Xây dựng URL dịch bằng endpoint /translate_a/t hỗ trợ multiple q
            $url = 'https://translate.googleapis.com/translate_a/t?client=gtx&sl=' . urlencode( $source_lang ) . '&tl=' . urlencode( $target_lang ) . '&v=1.0';
            foreach ( $current_batch as $text ) {
                $url .= '&q=' . urlencode( $text );
            }

            self::$google_call_count++;

            $response = wp_remote_get( $url, [ 'timeout' => 2 ] ); // Timeout 2s
            if ( is_wp_error( $response ) || 200 !== (int) wp_remote_retrieve_response_code( $response ) ) {
                // Google lỗi/chặn: các batch sau cũng sẽ lỗi — kích cầu dao và dừng hẳn
                self::trigger_google_backoff();
                break;
            }

            $body = wp_remote_retrieve_body( $response );
            $data = json_decode( $body, true );
            
            if ( is_array( $data ) && count( $data ) === count( $current_batch ) ) {
                foreach ( $current_batch as $idx => $orig_text ) {
                    $translated = $data[ $idx ];
                    if ( is_array( $translated ) && isset( $translated[0] ) ) {
                        $translated = $translated[0];
                    }
                    if ( ! empty( $translated ) && is_string( $translated ) ) {
                        $c_key = 'dawp_gt_' . md5( $orig_text . '_' . $source_lang . '_' . $target_lang );
                        set_transient( $c_key, $translated, 30 * DAY_IN_SECONDS );
                    }
                }
            }
        }
    }

    /**
     * Kiểm tra xem chuỗi văn bản thô ngoài frontend có cần dịch tự động không.
     * Hỗ trợ nhận diện các bộ ký tự đặc trưng của tiếng Trung, Nhật, Hàn, Nga, Thái, Ả Rập, v.v.
     */
    public static function should_auto_translate( $text, $current_lang, $is_translated = false ) {
        if ( $is_translated ) {
            return false;
        }
        
        if ( ! preg_match( '/\p{L}/u', $text ) ) {
            return false;
        }

        switch ( $current_lang ) {
            case 'zh':
                return ! preg_match( '/[\x{4e00}-\x{9fa5}]/u', $text );
            case 'en':
                $default_lang = self::get_default_language();
                if ( $default_lang === 'vi' ) {
                    return (bool) preg_match( '/[áàảãạăắằẳẵặâấầẩẫậéèẻẽẹêếềểễệíìỉĩịóòỏõọôốồổỗộơớờởỡợúùủũụưứừửữựýỳỷỹỵđ]/iu', $text );
                } elseif ( $default_lang === 'zh' ) {
                    return (bool) preg_match( '/[\x{4e00}-\x{9fa5}]/u', $text );
                } elseif ( $default_lang === 'ja' ) {
                    return (bool) preg_match( '/[\x{3040}-\x{309F}\x{30A0}-\x{30FF}\x{4E00}-\x{9FAF}]/u', $text );
                } elseif ( $default_lang === 'ko' ) {
                    return (bool) preg_match( '/[\x{AC00}-\x{D7A3}]/u', $text );
                } else {
                    return (bool) preg_match( '/[^\x00-\x7F]/u', $text );
                }
            case 'ja':
                return ! preg_match( '/[\x{3040}-\x{309F}\x{30A0}-\x{30FF}\x{4E00}-\x{9FAF}]/u', $text );
            case 'ko':
                return ! preg_match( '/[\x{AC00}-\x{D7A3}]/u', $text );
            case 'ru':
                return ! preg_match( '/[\x{0400}-\x{04FF}]/u', $text );
            case 'th':
                return ! preg_match( '/[\x{0E00}-\x{0E7F}]/u', $text );
            case 'ar':
                return ! preg_match( '/[\x{0600}-\x{06FF}]/u', $text );
            default:
                if ( preg_match( '/[áàảãạăắằẳẵặâấầẩẫậéèẻẽẹêếềểễệíìỉĩịóòỏõọôốồổỗộơớờởỡợúùủũụưứừửữựýỳỷỹỵđ]/iu', $text ) ) {
                    return true;
                }
                return ! preg_match( '/[éèàçœäöüßñíóú]/iu', $text );
        }
    }
}