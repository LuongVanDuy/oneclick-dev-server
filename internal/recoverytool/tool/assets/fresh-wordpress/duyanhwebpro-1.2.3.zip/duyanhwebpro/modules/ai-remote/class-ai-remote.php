<?php
defined( 'ABSPATH' ) || exit;

/**
 * Module: AI sửa web từ xa (AI Remote Edit)
 *
 * Cho phép công cụ AI (Claude Code / Antigravity...) đọc, sửa file và chạy mã PHP
 * trên website ĐANG CHẠY trên hosting thật — để vá giao diện vỡ mà không phải tải
 * cả site về máy local.
 *
 * TRIẾT LÝ AN TOÀN (không phải cửa hậu):
 * - MẶC ĐỊNH TẮT: khi chưa có phiên nào được chủ site tự tay mở, MỌI endpoint đều
 *   trả 401. Không có phiên = không có cửa vào. Cài plugin cho khách không tự mở gì.
 * - CÓ THỜI HẠN: chủ site chọn 15 / 30 / 60 phút. Hết giờ phiên tự chết, token vô
 *   dụng ngay lập tức, khỏi cần nhớ tắt.
 * - TOKEN CHỈ HIỆN 1 LẦN: sinh ngẫu nhiên entropy cao, chỉ lưu bản BĂM (hash) trong
 *   database. Đọc được cả database cũng không dựng lại được token.
 * - CHỐNG DÒ: sai token 10 lần trong 1 giờ là khóa IP đó (429).
 * - GHI NHẬT KÝ: mọi lượt gọi (đọc/ghi/chạy) đều ghi log IP + thời gian + việc làm.
 * - CẢNH BÁO ĐỎ: suốt lúc phiên còn mở, mọi trang admin đều hiện băng đỏ kèm đồng hồ
 *   đếm ngược và nút "Đóng ngay", để chủ site không bao giờ quên là cửa đang mở.
 * - GIỚI HẠN VÙNG: đọc/ghi/liệt kê chỉ trong thư mục WordPress (ABSPATH), chặn ../
 */
class DAWP_Ai_Remote {

	const OPT_SESSION = 'dawp_ai_remote_session';
	const OPT_LOG     = 'dawp_ai_remote_log';
	const LOCK_MAX    = 10;
	const LOG_MAX     = 100;

	public function __construct() {
		add_action( 'rest_api_init', [ $this, 'register_routes' ] );

		// Cầu nối AJAX cho chủ site mở/đóng phiên trong trang cài đặt
		add_action( 'wp_ajax_dawp_ai_remote_open', [ $this, 'ajax_open' ] );
		add_action( 'wp_ajax_dawp_ai_remote_close', [ $this, 'ajax_close' ] );
		add_action( 'wp_ajax_dawp_ai_remote_status', [ $this, 'ajax_status' ] );

		// Băng cảnh báo đỏ khi phiên đang mở
		add_action( 'admin_notices', [ $this, 'active_session_banner' ] );
	}

	/* ===================================================================
	 * REST API
	 * =================================================================== */

	public function register_routes() {
		$args = [
			'methods'             => 'POST',
			'permission_callback' => '__return_true',
		];

		register_rest_route( 'dawp/v1', '/ai-remote/trangthai', array_merge( $args, [
			'methods'  => 'GET',
			'callback' => [ $this, 'handle_status' ],
		] ) );

		register_rest_route( 'dawp/v1', '/ai-remote/doc', array_merge( $args, [
			'callback' => [ $this, 'handle_read' ],
		] ) );

		register_rest_route( 'dawp/v1', '/ai-remote/ghi', array_merge( $args, [
			'callback' => [ $this, 'handle_write' ],
		] ) );

		register_rest_route( 'dawp/v1', '/ai-remote/liet-ke', array_merge( $args, [
			'callback' => [ $this, 'handle_list' ],
		] ) );

		register_rest_route( 'dawp/v1', '/ai-remote/chay-php', array_merge( $args, [
			'callback' => [ $this, 'handle_exec' ],
		] ) );
	}

	/**
	 * Xác thực token phiên + chống dò. Trả về true nếu hợp lệ, WP_Error nếu không.
	 */
	private function verify_token( WP_REST_Request $request ) {
		$ip       = $this->client_ip();
		$lock_key = 'dawp_ai_lock_' . md5( $ip );
		$fails    = (int) get_transient( $lock_key );

		if ( $fails >= self::LOCK_MAX ) {
			return new WP_Error( 'dawp_ai_locked', 'Quá nhiều lần thử sai. IP này bị khóa 1 giờ.', [ 'status' => 429 ] );
		}

		$session = $this->get_session();

		// Không có phiên nào đang mở => cửa đóng hoàn toàn
		if ( ! $session ) {
			return new WP_Error( 'dawp_ai_closed', 'Không có phiên sửa web nào đang mở. Hãy nhờ chủ site mở phiên trong DAW Pro.', [ 'status' => 401 ] );
		}

		if ( time() > (int) $session['expires'] ) {
			$this->close_session( 'het-han' );
			return new WP_Error( 'dawp_ai_expired', 'Phiên sửa web đã hết hạn.', [ 'status' => 401 ] );
		}

		$token = $this->extract_token( $request );

		if ( ! $token || ! hash_equals( (string) $session['token_hash'], hash( 'sha256', $token ) ) ) {
			set_transient( $lock_key, $fails + 1, HOUR_IN_SECONDS );
			$this->log( 'tu-choi', '', 'token sai từ IP ' . $ip );
			return new WP_Error( 'dawp_ai_bad_token', 'Token không hợp lệ hoặc đã bị thu hồi.', [ 'status' => 401 ] );
		}

		delete_transient( $lock_key );
		return true;
	}

	private function extract_token( WP_REST_Request $request ) {
		$token = (string) $request->get_header( 'x-dawp-ai-key' );

		if ( ! $token ) {
			$auth = (string) $request->get_header( 'authorization' );
			if ( stripos( $auth, 'bearer ' ) === 0 ) {
				$token = trim( substr( $auth, 7 ) );
			}
		}

		if ( ! $token ) {
			$token = (string) $request->get_param( 'token' );
		}

		return trim( $token );
	}

	/**
	 * GET trạng thái phiên (cần token) — để công cụ AI tự kiểm tra còn bao lâu.
	 */
	public function handle_status( WP_REST_Request $request ) {
		$ok = $this->verify_token( $request );
		if ( is_wp_error( $ok ) ) {
			return $ok;
		}

		$session = $this->get_session();

		return rest_ensure_response( [
			'ket_qua'    => 'ok',
			'site'       => home_url(),
			'abspath'    => wp_normalize_path( ABSPATH ),
			'con_lai'    => max( 0, (int) $session['expires'] - time() ),
			'het_han_luc' => gmdate( 'Y-m-d H:i:s', (int) $session['expires'] ) . ' UTC',
			'php'        => PHP_VERSION,
			'wp'         => get_bloginfo( 'version' ),
		] );
	}

	/**
	 * POST đọc 1 file trong thư mục WordPress.
	 */
	public function handle_read( WP_REST_Request $request ) {
		$ok = $this->verify_token( $request );
		if ( is_wp_error( $ok ) ) {
			return $ok;
		}

		$path = $this->resolve_path( (string) $request->get_param( 'path' ), true );
		if ( is_wp_error( $path ) ) {
			return $path;
		}

		if ( ! is_readable( $path ) ) {
			return new WP_Error( 'dawp_ai_unreadable', 'Không đọc được file (thiếu quyền).', [ 'status' => 403 ] );
		}

		$content = file_get_contents( $path );
		$this->log( 'doc', $path, strlen( $content ) . ' bytes' );

		return rest_ensure_response( [
			'ket_qua' => 'ok',
			'path'    => $path,
			'size'    => strlen( $content ),
			'sha256'  => hash( 'sha256', $content ),
			'noi_dung' => $content,
		] );
	}

	/**
	 * POST ghi 1 file (tạo mới hoặc đè). Tự sao lưu bản cũ .dawpbak trước khi đè.
	 */
	public function handle_write( WP_REST_Request $request ) {
		$ok = $this->verify_token( $request );
		if ( is_wp_error( $ok ) ) {
			return $ok;
		}

		$path = $this->resolve_path( (string) $request->get_param( 'path' ), false );
		if ( is_wp_error( $path ) ) {
			return $path;
		}

		$content = $request->get_param( 'noi_dung' );
		if ( null === $content ) {
			$content = $request->get_param( 'content' );
		}
		$content = (string) $content;

		$dir = dirname( $path );
		if ( ! is_dir( $dir ) ) {
			if ( ! wp_mkdir_p( $dir ) ) {
				return new WP_Error( 'dawp_ai_mkdir', 'Không tạo được thư mục chứa file.', [ 'status' => 500 ] );
			}
		}

		// Sao lưu bản GỐC — chỉ tạo .dawpbak nếu chưa có, để lần ghi thứ 2 trở đi
		// không đè mất bản gốc bằng bản AI vừa sửa (mất khả năng khôi phục).
		$backup = '';
		if ( file_exists( $path ) ) {
			$backup = $path . '.dawpbak';
			if ( ! file_exists( $backup ) ) {
				@copy( $path, $backup );
			}
		}

		$written = @file_put_contents( $path, $content );
		if ( false === $written ) {
			return new WP_Error( 'dawp_ai_write_failed', 'Ghi file thất bại (thiếu quyền ghi trên hosting).', [ 'status' => 403 ] );
		}

		$this->log( 'ghi', $path, $written . ' bytes' . ( $backup ? ' (đã sao lưu .dawpbak)' : ' (file mới)' ) );

		return rest_ensure_response( [
			'ket_qua'  => 'ok',
			'path'     => $path,
			'size'     => $written,
			'sao_luu'  => $backup,
			'sha256'   => hash( 'sha256', $content ),
		] );
	}

	/**
	 * POST liệt kê nội dung 1 thư mục.
	 */
	public function handle_list( WP_REST_Request $request ) {
		$ok = $this->verify_token( $request );
		if ( is_wp_error( $ok ) ) {
			return $ok;
		}

		$path = $this->resolve_path( (string) $request->get_param( 'path' ), true );
		if ( is_wp_error( $path ) ) {
			return $path;
		}

		if ( ! is_dir( $path ) ) {
			return new WP_Error( 'dawp_ai_not_dir', 'Đường dẫn không phải thư mục.', [ 'status' => 400 ] );
		}

		$items = [];
		foreach ( scandir( $path ) as $name ) {
			if ( $name === '.' || $name === '..' ) {
				continue;
			}
			$full = $path . '/' . $name;
			$items[] = [
				'ten'  => $name,
				'loai' => is_dir( $full ) ? 'thu-muc' : 'file',
				'size' => is_file( $full ) ? filesize( $full ) : 0,
			];
		}

		$this->log( 'liet-ke', $path, count( $items ) . ' mục' );

		return rest_ensure_response( [
			'ket_qua'  => 'ok',
			'path'     => $path,
			'danh_sach' => $items,
		] );
	}

	/**
	 * POST chạy mã PHP tùy ý (chủ site đã đồng ý phạm vi này khi mở phiên).
	 *
	 * Nguy hiểm nhất trong module — nhưng đây chính là mục đích: để AI sửa mọi thứ.
	 * Chỉ chạy được khi có phiên hợp lệ chưa hết hạn. Mọi lượt chạy đều ghi log.
	 */
	public function handle_exec( WP_REST_Request $request ) {
		$ok = $this->verify_token( $request );
		if ( is_wp_error( $ok ) ) {
			return $ok;
		}

		$code = (string) $request->get_param( 'code' );
		if ( '' === trim( $code ) ) {
			return new WP_Error( 'dawp_ai_no_code', 'Thiếu mã PHP để chạy.', [ 'status' => 400 ] );
		}

		// Bỏ thẻ mở <?php nếu công cụ lỡ gửi kèm, để eval không lỗi cú pháp
		$clean = preg_replace( '/^\s*<\?php/', '', $code );

		$this->log( 'chay-php', '', mb_substr( trim( $code ), 0, 120 ) );

		$result   = null;
		$error    = '';
		$captured = '';

		ob_start();
		try {
			$result = eval( $clean );
		} catch ( \Throwable $e ) {
			$error = $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine();
		}
		$captured = ob_get_clean();

		return rest_ensure_response( [
			'ket_qua'  => $error ? 'loi' : 'ok',
			'in_ra'    => $captured,
			'tra_ve'   => $result,
			'loi'      => $error,
		] );
	}

	/* ===================================================================
	 * Giới hạn đường dẫn trong ABSPATH
	 * =================================================================== */

	/**
	 * Chuẩn hóa + kiểm tra đường dẫn phải nằm trong thư mục WordPress.
	 *
	 * @param string $path       Đường dẫn tuyệt đối hoặc tương đối so với ABSPATH.
	 * @param bool   $must_exist File/thư mục bắt buộc phải tồn tại (đọc/liệt kê).
	 * @return string|WP_Error
	 */
	private function resolve_path( $path, $must_exist ) {
		$path = wp_normalize_path( trim( $path ) );
		if ( '' === $path ) {
			return new WP_Error( 'dawp_ai_no_path', 'Thiếu đường dẫn.', [ 'status' => 400 ] );
		}

		$root = wp_normalize_path( realpath( ABSPATH ) ?: ABSPATH );

		// Đường dẫn tương đối => ghép vào ABSPATH
		if ( strpos( $path, $root ) !== 0 && ! preg_match( '#^[A-Za-z]:/#', $path ) && strpos( $path, '/' ) !== 0 ) {
			$path = $root . '/' . ltrim( $path, '/' );
		}

		$path = wp_normalize_path( $path );

		// Chống ../ và mọi mưu thoát ra ngoài ABSPATH
		if ( strpos( $path, '..' ) !== false ) {
			return new WP_Error( 'dawp_ai_traversal', 'Đường dẫn chứa ".." bị chặn.', [ 'status' => 400 ] );
		}

		if ( $must_exist ) {
			$real = realpath( $path );
			if ( false === $real ) {
				return new WP_Error( 'dawp_ai_not_found', 'Không tìm thấy: ' . $path, [ 'status' => 404 ] );
			}
			$real = wp_normalize_path( $real );
		} else {
			// Ghi: kiểm tra thư mục cha đã tồn tại nằm trong ABSPATH
			$parent = realpath( dirname( $path ) );
			$real   = $parent ? wp_normalize_path( $parent ) . '/' . basename( $path ) : $path;
		}

		// So theo BIÊN thư mục, không phải so chuỗi. Nếu chỉ dùng strpos($real,$root)===0
		// thì thư mục anh em cùng tiền tố tên (vd ABSPATH .../public_html còn
		// .../public_html_backup) sẽ lọt vì "public_html" là tiền tố chuỗi của
		// "public_html_backup". Thêm dấu phân tách vào $root để chỉ khớp đúng cây con.
		if ( $real !== $root && strpos( $real, $root . '/' ) !== 0 ) {
			return new WP_Error( 'dawp_ai_outside', 'Chỉ được thao tác trong thư mục WordPress.', [ 'status' => 403 ] );
		}

		return $real;
	}

	/* ===================================================================
	 * Quản lý phiên (chủ site mở/đóng qua AJAX)
	 * =================================================================== */

	private function get_session() {
		$session = get_option( self::OPT_SESSION );
		if ( ! is_array( $session ) || empty( $session['token_hash'] ) ) {
			return false;
		}
		return $session;
	}

	private function close_session( $ly_do = 'dong-tay' ) {
		delete_option( self::OPT_SESSION );
		// Kết thúc phiên là xóa sạch nhật ký cho nhẹ hosting — nhật ký chỉ có
		// ý nghĩa theo dõi trong lúc phiên còn mở.
		delete_option( self::OPT_LOG );
	}

	public function ajax_open() {
		check_ajax_referer( 'dawp_ai_remote_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( [ 'message' => 'Không đủ quyền.' ], 403 );
		}

		$minutes = (int) ( $_POST['minutes'] ?? 0 );
		if ( ! in_array( $minutes, [ 15, 30, 60 ], true ) ) {
			$minutes = 15;
		}

		// Token 48 ký tự hex, entropy 192 bit
		$token = bin2hex( random_bytes( 24 ) );

		$session = [
			'token_hash' => hash( 'sha256', $token ),
			'created'    => time(),
			'expires'    => time() + $minutes * 60,
			'created_by' => get_current_user_id(),
			'created_ip' => $this->client_ip(),
			'minutes'    => $minutes,
		];
		update_option( self::OPT_SESSION, $session, false );
		$this->log( 'mo-phien', '', $minutes . ' phút, bởi user #' . get_current_user_id() );

		wp_send_json_success( [
			'token'    => $token,
			'base'     => rest_url( 'dawp/v1/ai-remote' ),
			'expires'  => $session['expires'],
			'con_lai'  => $minutes * 60,
			'minutes'  => $minutes,
		] );
	}

	public function ajax_close() {
		check_ajax_referer( 'dawp_ai_remote_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( [ 'message' => 'Không đủ quyền.' ], 403 );
		}
		$this->close_session( 'dong-tay' );
		wp_send_json_success( [ 'message' => 'Đã đóng phiên. Token cũ vô hiệu ngay lập tức.' ] );
	}

	public function ajax_status() {
		check_ajax_referer( 'dawp_ai_remote_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( [ 'message' => 'Không đủ quyền.' ], 403 );
		}

		$session = $this->get_session();
		if ( ! $session || time() > (int) $session['expires'] ) {
			if ( $session ) {
				$this->close_session( 'het-han' );
			}
			wp_send_json_success( [ 'dang_mo' => false ] );
		}

		wp_send_json_success( [
			'dang_mo'  => true,
			'con_lai'  => max( 0, (int) $session['expires'] - time() ),
			'nhat_ky'  => $this->log_rows(),
		] );
	}

	/**
	 * Chuẩn bị nhật ký đã định dạng sẵn để hiển thị thời gian thực (tối đa 50 dòng).
	 */
	private function log_rows() {
		$offset = (int) get_option( 'gmt_offset' ) * 3600;
		$rows   = [];
		foreach ( array_slice( self::get_log(), 0, 50 ) as $r ) {
			$rows[] = [
				'time'   => date_i18n( 'H:i:s d/m/Y', (int) $r['time'] + $offset ),
				'action' => $r['action'],
				'ip'     => $r['ip'],
				'detail' => ( $r['path'] ? $r['path'] . ' ' : '' ) . $r['note'],
			];
		}
		return $rows;
	}

	/* ===================================================================
	 * Băng cảnh báo đỏ khi phiên đang mở
	 * =================================================================== */

	public function active_session_banner() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$session = $this->get_session();
		if ( ! $session || time() > (int) $session['expires'] ) {
			return;
		}
		$con_lai = max( 0, (int) $session['expires'] - time() );
		$url     = admin_url( 'admin.php?page=dawp-settings&tab=ai-remote' );
		?>
		<div class="notice notice-error" style="border-left-width:6px;">
			<p style="font-size:14px;">
				🔓 <strong>CẢNH BÁO BẢO MẬT:</strong> Đang có một phiên cho phép AI sửa web từ xa
				(còn <strong id="dawp-ai-banner-countdown"><?php echo esc_html( $this->format_mmss( $con_lai ) ); ?></strong>).
				Nếu không phải bạn đang chủ động dùng, hãy
				<a href="<?php echo esc_url( $url ); ?>"><strong>đóng ngay</strong></a>.
			</p>
		</div>
		<script>
		(function(){
			var el = document.getElementById('dawp-ai-banner-countdown');
			if(!el) return;
			var left = <?php echo (int) $con_lai; ?>;
			setInterval(function(){
				left--; if(left<0){ el.textContent='đã hết hạn'; return; }
				var m=Math.floor(left/60), s=left%60;
				el.textContent=(m<10?'0':'')+m+':'+(s<10?'0':'')+s;
			},1000);
		})();
		</script>
		<?php
	}

	/* ===================================================================
	 * Nhật ký
	 * =================================================================== */

	private function log( $action, $path, $note = '' ) {
		$log = get_option( self::OPT_LOG );
		if ( ! is_array( $log ) ) {
			$log = [];
		}
		array_unshift( $log, [
			'time'   => time(),
			'ip'     => $this->client_ip(),
			'action' => $action,
			'path'   => $path,
			'note'   => $note,
		] );
		$log = array_slice( $log, 0, self::LOG_MAX );
		update_option( self::OPT_LOG, $log, false );
	}

	public static function get_log() {
		$log = get_option( self::OPT_LOG );
		return is_array( $log ) ? $log : [];
	}

	/* ===================================================================
	 * Tiện ích
	 * =================================================================== */

	private function client_ip() {
		return isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : 'unknown';
	}

	private function format_mmss( $sec ) {
		$sec = max( 0, (int) $sec );
		return sprintf( '%02d:%02d', floor( $sec / 60 ), $sec % 60 );
	}
}
