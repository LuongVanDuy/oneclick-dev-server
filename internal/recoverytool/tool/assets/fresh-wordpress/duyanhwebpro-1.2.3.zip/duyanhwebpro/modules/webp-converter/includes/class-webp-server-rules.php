<?php
/**
 * Ghi rule cho web server để URL ảnh cũ (.jpg/.png) vẫn trả về bản .webp.
 *
 * @package duyanhweb
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DAWP_WebP_Server_Rules {

	const MARKER = 'DuyAnhWeb Image Optimizer';

	/**
	 * Đường dẫn tới file .htaccess gốc.
	 *
	 * @return string
	 */
	private static function htaccess_path() {
		if ( ! function_exists( 'get_home_path' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		return get_home_path() . '.htaccess';
	}

	/**
	 * Đường dẫn tương đối của thư mục uploads so với gốc website.
	 *
	 * Ví dụ: "wp-content/uploads".
	 *
	 * @return string
	 */
	private static function uploads_rel_path() {
		$uploads  = wp_get_upload_dir();
		$base_url = $uploads['baseurl'];
		$home_url = home_url();

		if ( 0 === strpos( $base_url, $home_url ) ) {
			$relative = substr( $base_url, strlen( $home_url ) );
		} else {
			$relative = wp_parse_url( $base_url, PHP_URL_PATH );
		}

		return trim( (string) $relative, '/' );
	}

	/**
	 * RewriteBase phù hợp khi WordPress nằm trong thư mục con.
	 *
	 * @return string
	 */
	private static function rewrite_base() {
		$path = wp_parse_url( home_url( '/' ), PHP_URL_PATH );
		return $path ? $path : '/';
	}

	/**
	 * Nội dung rule Apache.
	 *
	 * Ý tưởng: ảnh gốc abc.jpg đã bị thay bằng abc.webp nên file abc.jpg không
	 * còn tồn tại. Khi có request tới abc.jpg, điều kiện `!-f` khớp và server
	 * phục vụ abc.webp thay thế. Rule chỉ áp dụng trong thư mục uploads.
	 *
	 * @return array
	 */
	public static function rules() {
		$uploads = self::uploads_rel_path();
		$base    = self::rewrite_base();

		// Escape dấu chấm và ký tự đặc biệt trong đường dẫn uploads.
		$uploads_pattern = preg_quote( $uploads, '#' );
		$uploads_pattern = str_replace( '#', '\\#', $uploads_pattern );

		return array(
			'<IfModule mod_mime.c>',
			'  AddType image/webp .webp',
			'</IfModule>',
			'<IfModule mod_rewrite.c>',
			'  RewriteEngine On',
			'  RewriteBase ' . $base,
			'  # Anh goc da duoc thay bang ban .webp cung ten -> tra ve .webp',
			'  RewriteCond %{REQUEST_FILENAME} !-f',
			'  RewriteRule ^(' . $uploads_pattern . '/.+)\.(jpe?g|png)$ $1.webp [NC,L,T=image/webp]',
			'</IfModule>',
			'<IfModule mod_expires.c>',
			'  ExpiresActive On',
			'  ExpiresByType image/webp "access plus 1 year"',
			'</IfModule>',
			'<IfModule mod_headers.c>',
			'  <FilesMatch "\.webp$">',
			'    Header set Cache-Control "public, max-age=31536000, immutable"',
			'  </FilesMatch>',
			'</IfModule>',
		);
	}

	/**
	 * Ghi rule vào .htaccess.
	 *
	 * QUAN TRỌNG: block phải nằm TRƯỚC "# BEGIN WordPress", vì block của
	 * WordPress cũng bắt các request tới file không tồn tại và đẩy hết về
	 * index.php. Nếu đặt sau, rule này sẽ không bao giờ được thực thi.
	 *
	 * @return bool|WP_Error
	 */
	public static function write() {
		if ( ! self::is_apache() ) {
			return new WP_Error( 'DAWP_WebP_not_apache', __( 'Máy chủ không dùng Apache. Hãy thêm rule Nginx thủ công.', 'duyanhwebpro' ) );
		}

		require_once ABSPATH . 'wp-admin/includes/misc.php';
		require_once ABSPATH . 'wp-admin/includes/file.php';

		$file = self::htaccess_path();

		if ( ! file_exists( $file ) ) {
			if ( ! is_writable( dirname( $file ) ) ) {
				return new WP_Error( 'DAWP_WebP_htaccess_missing', __( 'Không tạo được file .htaccess.', 'duyanhwebpro' ) );
			}
			// Tạo file rỗng để insert_with_markers hoạt động.
			file_put_contents( $file, '' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		}

		if ( ! is_writable( $file ) ) {
			return new WP_Error( 'DAWP_WebP_htaccess_perm', __( 'File .htaccess không có quyền ghi.', 'duyanhwebpro' ) );
		}

		// Đảm bảo block của plugin nằm trước block WordPress.
		self::ensure_marker_position( $file );

		$ok = insert_with_markers( $file, self::MARKER, self::rules() );

		return $ok ? true : new WP_Error( 'DAWP_WebP_htaccess_write', __( 'Ghi .htaccess thất bại.', 'duyanhwebpro' ) );
	}

	/**
	 * Chèn sẵn cặp marker rỗng ngay trước "# BEGIN WordPress" nếu chưa có,
	 * để insert_with_markers ghi nội dung vào đúng vị trí đó.
	 *
	 * @param string $file Đường dẫn .htaccess.
	 */
	private static function ensure_marker_position( $file ) {
		$content = file_get_contents( $file ); // phpcs:ignore WordPress.WP.AlternativeFunctions

		if ( false === $content ) {
			return;
		}

		$begin = '# BEGIN ' . self::MARKER;

		// Đã có marker rồi -> insert_with_markers sẽ thay tại chỗ, giữ nguyên vị trí.
		if ( false !== strpos( $content, $begin ) ) {
			return;
		}

		$wp_begin = '# BEGIN WordPress';
		$position = strpos( $content, $wp_begin );

		if ( false === $position ) {
			return; // Không có block WordPress, ghi ở cuối file là được.
		}

		$placeholder = $begin . "\n" . '# END ' . self::MARKER . "\n\n";

		$content = substr( $content, 0, $position ) . $placeholder . substr( $content, $position );

		file_put_contents( $file, $content ); // phpcs:ignore WordPress.WP.AlternativeFunctions
	}

	/**
	 * Gỡ rule khỏi .htaccess.
	 *
	 * @return bool
	 */
	public static function remove() {
		if ( ! self::is_apache() ) {
			return false;
		}

		require_once ABSPATH . 'wp-admin/includes/misc.php';
		require_once ABSPATH . 'wp-admin/includes/file.php';

		$file = self::htaccess_path();

		if ( ! file_exists( $file ) || ! is_writable( $file ) ) {
			return false;
		}

		return (bool) insert_with_markers( $file, self::MARKER, array() );
	}

	/**
	 * Kiểm tra rule đã có trong .htaccess chưa.
	 *
	 * @return bool
	 */
	public static function is_active() {
		$file = self::htaccess_path();

		if ( ! file_exists( $file ) || ! is_readable( $file ) ) {
			return false;
		}

		$content = file_get_contents( $file ); // phpcs:ignore WordPress.WP.AlternativeFunctions

		$content = (string) $content;

		// Phải có cả marker lẫn rule thật (marker rỗng không tính là đang hoạt động).
		return false !== strpos( $content, '# BEGIN ' . self::MARKER )
			&& false !== strpos( $content, 'T=image/webp' );
	}

	/**
	 * Máy chủ có phải Apache/LiteSpeed không.
	 *
	 * @return bool
	 */
	public static function is_apache() {
		global $is_apache;
		return ! empty( $is_apache );
	}

	/**
	 * Đoạn cấu hình Nginx để người dùng copy thủ công.
	 *
	 * @return string
	 */
	public static function nginx_snippet() {
		$uploads = self::uploads_rel_path();

		return "# DuyAnhWeb Image Optimizer - them vao server block cua Nginx\n"
			. "location ~* ^/{$uploads}/(.+)\\.(jpe?g|png)$ {\n"
			. "    try_files /{$uploads}/\$1.webp \$uri =404;\n"
			. "    expires 1y;\n"
			. "    add_header Cache-Control \"public, immutable\";\n"
			. "}\n";
	}
}

