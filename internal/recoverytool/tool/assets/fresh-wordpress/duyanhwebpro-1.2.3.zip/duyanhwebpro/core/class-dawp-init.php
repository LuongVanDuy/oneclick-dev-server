<?php
defined( 'ABSPATH' ) || exit;

class DAWP_Init {

    public function __construct() {
        // Constructor rỗng, khởi tạo tại hàm run()
    }

    public function run() {
        $this->check_db_upgrade();
        $this->load_modules();
        $this->setup_settings_page();
        $this->setup_updater();

        // Nạp Font Awesome offline cho toàn bộ website (Frontend & Admin) nếu được kích hoạt
        if ( class_exists( 'DAWP_Helpers' ) && DAWP_Helpers::is_module_active( 'font_awesome_active' ) ) {
            add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_global_assets' ] );
            add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_global_assets' ] );
        }

        // Bỏ qua Rocket Loader của Cloudflare đối với tất cả scripts của DAW Pro
        add_filter( 'script_loader_tag', [ $this, 'add_cfasync_attribute' ], 10, 3 );
    }

    /**
     * Nạp các tài nguyên dùng chung toàn plugin (Font Awesome...)
     */
    public function enqueue_global_assets() {
        wp_enqueue_style( 'dawp-font-awesome', DAWP_URL . 'assets/css/fontawesome.min.css', array(), '7.2.0' );
    }

    /**
     * Bổ sung thuộc tính data-cfasync="false" cho các kịch bản của DAW Pro để tương thích hoàn toàn với Cloudflare Rocket Loader
     */
    public function add_cfasync_attribute( $tag, $handle, $src ) {
        if ( strpos( $handle, 'dawp' ) === 0 ) {
            if ( strpos( $tag, 'data-cfasync' ) === false ) {
                $tag = str_replace( '<script ', '<script data-cfasync="false" ', $tag );
            }
        }
        return $tag;
    }
    /**
     * Kiểm tra nâng cấp cơ sở dữ liệu tập trung (Failsafe)
     */
    private function check_db_upgrade() {
        if ( get_option( 'dawp_db_version' ) !== DAWP_VERSION ) {
            $contact_form_file = DAWP_MODULES_DIR . 'contact-form/class-contact-form.php';
            if ( file_exists( $contact_form_file ) ) {
                require_once $contact_form_file;
                if ( method_exists( 'DAWP_Contact_Form', 'create_db_table' ) ) {
                    DAWP_Contact_Form::create_db_table();
                }
            }

            $seo_file = DAWP_MODULES_DIR . 'seo/class-seo.php';
            if ( file_exists( $seo_file ) ) {
                require_once $seo_file;
                if ( method_exists( 'DAWP_Seo', 'create_db_table' ) ) {
                    DAWP_Seo::create_db_table();
                }
            }

            $woo_reviews_file = DAWP_MODULES_DIR . 'woo-reviews/class-woo-reviews.php';
            if ( file_exists( $woo_reviews_file ) ) {
                require_once $woo_reviews_file;
                if ( method_exists( 'DAWP_Woo_Reviews', 'create_db_table' ) ) {
                    DAWP_Woo_Reviews::create_db_table();
                }
            }

            $webp_converter_file = DAWP_MODULES_DIR . 'webp-converter/class-webp-converter.php';
            if ( file_exists( $webp_converter_file ) ) {
                require_once $webp_converter_file;
                if ( method_exists( 'DAWP_Webp_Converter', 'create_db_table' ) ) {
                    DAWP_Webp_Converter::create_db_table();
                }
            }

            update_option( 'dawp_db_version', DAWP_VERSION );
        }
    }

    /**
     * Tự động nạp các Modules được kích hoạt
     */
    private function load_modules() {
        $modules = [
            'admin-style'      => 'class-admin-style.php',
            'smtp'             => 'class-smtp.php',
            'contact-buttons'  => 'class-contact-buttons.php',
            'contact-form'     => 'class-contact-form.php',
            'classic-editor'   => 'class-classic-editor.php',
            'optimization'     => 'class-optimization.php',
            'security'         => 'class-security.php',
            'maintenance'      => 'class-maintenance.php',
            'pagespeed'        => 'class-pagespeed.php',
            'seo'              => 'class-seo.php',
            'google-translate' => 'class-google-translate.php',
            'multilingual'     => 'class-multilingual.php',
            'woo-reviews'      => 'class-woo-reviews.php',
            'social-share'     => 'class-social-share.php',
            'webp-converter'   => 'class-webp-converter.php',
            'bricks-license'   => 'class-bricks-license.php',
            'ai-remote'        => 'class-ai-remote.php'
        ];

        $modules = apply_filters( 'dawp_registered_modules', $modules );

        foreach ( $modules as $folder => $file ) {
            $setting_key = str_replace( '-', '_', $folder ) . '_active';
            $always_active = ['admin-style', 'optimization', 'security', 'pagespeed', 'webp-converter', 'bricks-license', 'ai-remote'];
            $always_active = apply_filters( 'dawp_always_active_modules', $always_active );
            if ( in_array($folder, $always_active) || DAWP_Helpers::is_module_active( $setting_key ) ) {
                // Hỗ trợ cả tệp tin nội bộ (trong thư mục modules) và tuyệt đối (từ các plugin mở rộng khác)
                $module_path = ( strpos( $file, '/' ) !== false || strpos( $file, '\\' ) !== false ) ? $file : DAWP_MODULES_DIR . trailingslashit( $folder ) . $file;
                if ( file_exists( $module_path ) ) {
                    require_once $module_path;
                    $class_name = 'DAWP_' . str_replace( ' ', '_', ucwords( str_replace( '-', ' ', $folder ) ) );
                    if ( class_exists( $class_name ) ) {
                        new $class_name();
                    }
                }
            }
        }
    }

    /**
     * Nạp giao diện Settings tổng
     */
    private function setup_settings_page() {
        if ( is_admin() ) {
            require_once DAWP_DIR . 'core/class-dawp-settings.php';
            new DAWP_Settings();
        }
    }

    /**
     * Khởi tạo bộ cập nhật từ xa (Chỉ chạy ở trang Admin)
     */
    private function setup_updater() {
        if ( is_admin() && class_exists( 'DAWP_Updater' ) ) {
            new DAWP_Updater();
        }
    }
}
