(function($) {
    // Hàm hook trực tiếp vào plupload.Uploader (toàn cục)
    function hookPlupload() {
        if (typeof plupload !== 'undefined' && plupload.Uploader && !plupload.Uploader.isHookedByDawpPdf) {
            plupload.Uploader.isHookedByDawpPdf = true;
            var OriginalUploader = plupload.Uploader;

            plupload.Uploader = function(options) {
                var uploader = new OriginalUploader(options);
                
                if (uploader && !uploader.isHookedByDawpPdf) {
                    uploader.isHookedByDawpPdf = true;
                    
                    var pendingConversions = 0;

                    uploader.bind('FilesAdded', function(up, files) {
                        var filesToConvert = [];

                        plupload.each(files, function(file) {
                            var isPdf = file.type === 'application/pdf' || /\.pdf$/i.test(file.name);
                            if (isPdf && !file.isPdfCompressed) {
                                filesToConvert.push(file);
                            }
                        });

                        if (filesToConvert.length > 0) {
                            up.stop();
                            pendingConversions += filesToConvert.length;

                            plupload.each(filesToConvert, function(file) {
                                file.status = plupload.UPLOADING;
                                
                                compressPDF(file.getNative(), file.name, function(compressedFile) {
                                    if (compressedFile) {
                                        var sourceWrapper = file.getSource();
                                        if (sourceWrapper) {
                                            sourceWrapper.getSource = function() {
                                                return compressedFile;
                                            };
                                        }

                                        file.size = compressedFile.size;
                                        file.isPdfCompressed = true;
                                        file.status = plupload.QUEUED;
                                        console.log('DAW Pro: [Plupload] Đã nén ' + file.name + ' thành công. Kích thước mới: ' + file.size + ' bytes');
                                    } else {
                                        file.isPdfCompressed = true;
                                        file.status = plupload.QUEUED;
                                    }

                                    pendingConversions--;
                                    if (pendingConversions <= 0) {
                                        pendingConversions = 0;
                                        up.start();
                                    }
                                });
                            });
                        }
                    });
                }
 
                return uploader;
            };

            plupload.Uploader.prototype = OriginalUploader.prototype;
            Object.assign(plupload.Uploader, OriginalUploader);
            console.log('DAW Pro: Đã hook nén PDF thành công vào plupload.Uploader.');
        }
    }

    // Hàm hook vào wp.Uploader
    function hookWpUploader() {
        if (typeof wp !== 'undefined' && wp.Uploader && !wp.Uploader.isHookedByDawpPdf) {
            wp.Uploader.isHookedByDawpPdf = true;
            var OriginalUploader = wp.Uploader;

            wp.Uploader = function(options) {
                var self = this;
                var result = OriginalUploader.apply(self, arguments);
                var instance = (result && typeof result === 'object') ? result : self;

                var uploader = instance.uploader;
                if (uploader && !uploader.isHookedByDawpPdf) {
                    uploader.isHookedByDawpPdf = true;
                    
                    var pendingConversions = 0;

                    uploader.bind('FilesAdded', function(up, files) {
                        var filesToConvert = [];

                        plupload.each(files, function(file) {
                            var isPdf = file.type === 'application/pdf' || /\.pdf$/i.test(file.name);
                            if (isPdf && !file.isPdfCompressed) {
                                filesToConvert.push(file);
                            }
                        });

                        if (filesToConvert.length > 0) {
                            up.stop();
                            pendingConversions += filesToConvert.length;

                            plupload.each(filesToConvert, function(file) {
                                file.status = plupload.UPLOADING;
                                
                                compressPDF(file.getNative(), file.name, function(compressedFile) {
                                    if (compressedFile) {
                                        var sourceWrapper = file.getSource();
                                        if (sourceWrapper) {
                                            sourceWrapper.getSource = function() {
                                                return compressedFile;
                                            };
                                        }
                                        file.size = compressedFile.size;
                                        file.isPdfCompressed = true;
                                        file.status = plupload.QUEUED;
                                        console.log('DAW Pro: [wp.Uploader] Đã nén ' + file.name + ' thành công.');
                                    } else {
                                        file.isPdfCompressed = true;
                                        file.status = plupload.QUEUED;
                                    }

                                    pendingConversions--;
                                    if (pendingConversions <= 0) {
                                        pendingConversions = 0;
                                        up.start();
                                    }
                                });
                            });
                        }
                    });
                }
 
                return instance;
            };

            wp.Uploader.prototype = OriginalUploader.prototype;
            Object.assign(wp.Uploader, OriginalUploader);
        }
    }

    // Hàm hook vào trình soạn thảo Gutenberg Block Editor
    function hookGutenbergUpload() {
        if (typeof wp !== 'undefined' && wp.mediaUtils && wp.mediaUtils.uploadMedia && !wp.mediaUtils.uploadMedia.isHookedByDawpPdf) {
            wp.mediaUtils.uploadMedia.isHookedByDawpPdf = true;
            var originalUploadMedia = wp.mediaUtils.uploadMedia;

            wp.mediaUtils.uploadMedia = function(options) {
                var self = this;
                var args = arguments;

                if (options && options.filesList && options.filesList.length > 0) {
                    var files = Array.from(options.filesList);
                    
                    return new Promise(function(resolve, reject) {
                        var pending = files.length;
                        var convertedFiles = [];

                        var checkAndProceed = function() {
                            if (pending === 0) {
                                options.filesList = convertedFiles;
                                try {
                                    var resultPromise = originalUploadMedia.apply(self, args);
                                    resolve(resultPromise);
                                } catch (e) {
                                    reject(e);
                                }
                            }
                        };

                        files.forEach(function(file, index) {
                            var isPdf = file.type === 'application/pdf' || /\.pdf$/i.test(file.name);
                            if (isPdf) {
                                compressPDF(file, file.name, function(compressedFile) {
                                    if (compressedFile) {
                                        convertedFiles[index] = compressedFile;
                                    } else {
                                        convertedFiles[index] = file;
                                    }
                                    pending--;
                                    checkAndProceed();
                                });
                            } else {
                                convertedFiles[index] = file;
                                pending--;
                                checkAndProceed();
                            }
                        });
                    });
                } else {
                    return originalUploadMedia.apply(self, args);
                }
            };
        }
    }

    // Trích xuất, nén ảnh JPEG và thay thế stream trong PDF
    function compressPDF(nativeFile, originalName, callback) {
        if (!nativeFile) {
            callback(null);
            return;
        }

        if (typeof PDFLib === 'undefined') {
            console.warn('DAW Pro: Thư viện PDFLib chưa được nạp. Không thể nén PDF.');
            callback(null);
            return;
        }

        var level = (window.dawpPdfSettings && window.dawpPdfSettings.quality_level) || 'high';

        // Thiết lập timeout 25s cho toàn bộ file PDF để chống treo hàng đợi
        var timeoutId = setTimeout(function() {
            console.warn('DAW Pro: Nén PDF quá giới hạn 25s. Bỏ qua để tải tệp gốc: ' + originalName);
            done(null);
        }, 25000);

        var isDone = false;
        var done = function(result) {
            if (isDone) return;
            isDone = true;
            clearTimeout(timeoutId);
            callback(result);
        };

        (async function() {
            try {
                const { PDFDocument, PDFName, PDFNumber, PDFRawStream, PDFArray } = PDFLib;
                const fileBuffer = await nativeFile.arrayBuffer();
                const pdfDoc = await PDFDocument.load(fileBuffer);
                const context = pdfDoc.context;
                const indirectObjects = context.enumerateIndirectObjects();
                
                var configSettings = {
                    'high': { maxSize: 1200, quality: 0.82 },
                    'ultra': { maxSize: 1500, quality: 0.85 },
                    'super': { maxSize: 2000, quality: 0.88 }
                };
                var config = configSettings[level] || configSettings['high'];
                var maxSize = config.maxSize;
                var quality = config.quality;

                let compressedCount = 0;

                for (const [ref, obj] of indirectObjects) {
                    if (obj instanceof PDFRawStream) {
                        const dict = obj.dict;
                        const subtypeVal = dict.get(PDFName.of('Subtype'));
                        const subtype = subtypeVal ? context.lookup(subtypeVal) : null;
                        
                        if (subtype === PDFName.of('Image')) {
                            const filterVal = dict.get(PDFName.of('Filter'));
                            const filter = filterVal ? context.lookup(filterVal) : null;
                            
                            const colorSpaceVal = dict.get(PDFName.of('ColorSpace'));
                            const colorSpace = colorSpaceVal ? context.lookup(colorSpaceVal) : null;
                            
                            // 🎨 Bảo vệ CMYK: check colorspace và bỏ qua
                            let isCmyk = false;
                            if (colorSpace) {
                                const csStr = colorSpace.toString();
                                if (csStr.includes('CMYK') || csStr.includes('DeviceCMYK')) {
                                    isCmyk = true;
                                }
                                if (colorSpace instanceof PDFArray) {
                                    const profileRef = colorSpace.get(1);
                                    if (profileRef) {
                                        const profile = context.lookup(profileRef);
                                        if (profile && profile.dict) {
                                            const nVal = profile.dict.get(PDFName.of('N'));
                                            const n = nVal ? context.lookup(nVal) : null;
                                            if (n && n.toString() === '4') {
                                                isCmyk = true;
                                            }
                                        }
                                    }
                                }
                            }
                            
                            if (isCmyk) {
                                console.log('DAW Pro: Bỏ qua ảnh màu CMYK: ' + ref.toString());
                                continue;
                            }

                            // DCTDecode
                            let isDct = false;
                            if (filter === PDFName.of('DCTDecode')) {
                                isDct = true;
                            } else if (filter instanceof PDFArray) {
                                for (let i = 0; i < filter.size(); i++) {
                                    if (context.lookup(filter.get(i)) === PDFName.of('DCTDecode')) {
                                        isDct = true;
                                    }
                                }
                            }

                            if (isDct) {
                                const rawBytes = obj.contents;
                                try {
                                    const compressedBytes = await compressJpegBytes(rawBytes, maxSize, quality);
                                    if (compressedBytes && compressedBytes.length < rawBytes.length) {
                                        obj.contents = compressedBytes;
                                        dict.set(PDFName.of('Length'), PDFNumber.of(compressedBytes.length));
                                        
                                        const img = new Image();
                                        const blob = new Blob([compressedBytes], { type: 'image/jpeg' });
                                        const url = URL.createObjectURL(blob);
                                        img.src = url;
                                        await new Promise((resolve, reject) => {
                                            img.onload = resolve;
                                            img.onerror = reject;
                                            setTimeout(() => reject(new Error("Image load timeout")), 5000);
                                        });
                                        dict.set(PDFName.of('Width'), PDFNumber.of(img.width));
                                        dict.set(PDFName.of('Height'), PDFNumber.of(img.height));
                                        URL.revokeObjectURL(url);
                                        
                                        compressedCount++;
                                    }
                                } catch (e) {
                                    console.error("DAW Pro: Lỗi nén ảnh nhúng DCTDecode:", e);
                                }
                            } else {
                                // check FlateDecode
                                let isFlate = false;
                                if (filter === PDFName.of('FlateDecode')) {
                                    isFlate = true;
                                } else if (filter instanceof PDFArray) {
                                    for (let i = 0; i < filter.size(); i++) {
                                        if (context.lookup(filter.get(i)) === PDFName.of('FlateDecode')) {
                                            isFlate = true;
                                        }
                                    }
                                }

                                if (isFlate) {
                                    const bitsVal = dict.get(PDFName.of('BitsPerComponent'));
                                    const bits = bitsVal ? context.lookup(bitsVal) : null;
                                    
                                    const smaskVal = dict.get(PDFName.of('SMask'));
                                    const smask = smaskVal ? context.lookup(smaskVal) : null;
                                    
                                    const decodeParmsVal = dict.get(PDFName.of('DecodeParms'));
                                    const decodeParms = decodeParmsVal ? context.lookup(decodeParmsVal) : null;
                                    
                                    const is8Bit = bits && bits.toString() === '8';
                                    let isSafeCS = false;
                                    let channels = 3;
                                    if (colorSpace) {
                                        const csStr = colorSpace.toString();
                                        if (csStr === '/DeviceRGB' || csStr === 'DeviceRGB') {
                                            isSafeCS = true;
                                            channels = 3;
                                        } else if (csStr === '/DeviceGray' || csStr === 'DeviceGray') {
                                            isSafeCS = true;
                                            channels = 1;
                                        }
                                    }
                                    
                                    const hasSmask = !!smask;
                                    let hasPredictor = false;
                                    if (decodeParms) {
                                        const predictorVal = decodeParms.get(PDFName.of('Predictor'));
                                        const predictor = predictorVal ? context.lookup(predictorVal) : null;
                                        if (predictor && parseInt(predictor.toString(), 10) > 1) {
                                            hasPredictor = true;
                                        }
                                    }
                                    
                                    if (is8Bit && isSafeCS && !hasSmask && !hasPredictor && typeof pako !== 'undefined') {
                                        const rawBytes = obj.contents;
                                        try {
                                            const decompressedBytes = pako.inflate(rawBytes);
                                            const widthVal = dict.get(PDFName.of('Width'));
                                            const heightVal = dict.get(PDFName.of('Height'));
                                            const width = Number(context.lookup(widthVal).toString());
                                            const height = Number(context.lookup(heightVal).toString());
                                            
                                            const compressedBytes = await compressRawBytes(decompressedBytes, width, height, channels, maxSize, quality);
                                            if (compressedBytes && compressedBytes.length < rawBytes.length) {
                                                obj.contents = compressedBytes;
                                                dict.set(PDFName.of('Length'), PDFNumber.of(compressedBytes.length));
                                                dict.set(PDFName.of('Filter'), PDFName.of('DCTDecode'));
                                                dict.delete(PDFName.of('DecodeParms'));
                                                
                                                const img = new Image();
                                                const blob = new Blob([compressedBytes], { type: 'image/jpeg' });
                                                const url = URL.createObjectURL(blob);
                                                img.src = url;
                                                await new Promise((resolve, reject) => {
                                                    img.onload = resolve;
                                                    img.onerror = reject;
                                                    setTimeout(() => reject(new Error("Image load timeout")), 5000);
                                                });
                                                dict.set(PDFName.of('Width'), PDFNumber.of(img.width));
                                                dict.set(PDFName.of('Height'), PDFNumber.of(img.height));
                                                URL.revokeObjectURL(url);
                                                
                                                compressedCount++;
                                            }
                                        } catch (e) {
                                            console.error("DAW Pro: Lỗi giải nén/nén ảnh FlateDecode:", e);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                if (compressedCount > 0) {
                    const newPdfBytes = await pdfDoc.save();
                    const compressedFile = new File([newPdfBytes], originalName, { type: 'application/pdf' });
                    console.log('DAW Pro: Nén PDF hoàn tất. Đã nén ' + compressedCount + ' ảnh.');
                    done(compressedFile);
                } else {
                    console.log('DAW Pro: Tệp PDF không chứa ảnh JPEG/Flate phù hợp hoặc đã tối ưu.');
                    done(null);
                }
            } catch (err) {
                console.error("DAW Pro: Lỗi xử lý tệp PDF nhị phân:", err);
                done(null);
            }
        })();
    }

    // Nén canvas của ảnh JPEG nhị phân (Downsample-first)
    async function compressJpegBytes(bytes, maxSize, quality) {
        const blob = new Blob([bytes], { type: 'image/jpeg' });
        const imgUrl = URL.createObjectURL(blob);
        const img = new Image();
        img.src = imgUrl;
        
        await new Promise((resolve, reject) => {
            img.onload = resolve;
            img.onerror = reject;
            setTimeout(() => reject(new Error("Image load timeout")), 5000);
        });

        let width = img.width;
        let height = img.height;
        
        if (width > maxSize || height > maxSize) {
            if (width > height) {
                height = Math.round((height * maxSize) / width);
                width = maxSize;
            } else {
                width = Math.round((width * maxSize) / height);
                height = maxSize;
            }
        }

        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0, width, height);

        URL.revokeObjectURL(imgUrl);

        const newBlob = await new Promise(resolve => canvas.toBlob(resolve, 'image/jpeg', quality));
        const newBuffer = await newBlob.arrayBuffer();
        return new Uint8Array(newBuffer);
    }

    // Tái cấu trúc raw pixels từ FlateDecode sang JPEG
    async function compressRawBytes(pixels, width, height, channels, maxSize, quality) {
        if (!pixels) {
            return null;
        }

        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        const imgData = ctx.createImageData(width, height);
        
        if (channels === 3) {
            let srcIdx = 0;
            let dstIdx = 0;
            const len = width * height;
            for (let i = 0; i < len; i++) {
                imgData.data[dstIdx] = (pixels[srcIdx] !== undefined) ? pixels[srcIdx] : 0;
                imgData.data[dstIdx+1] = (pixels[srcIdx+1] !== undefined) ? pixels[srcIdx+1] : 0;
                imgData.data[dstIdx+2] = (pixels[srcIdx+2] !== undefined) ? pixels[srcIdx+2] : 0;
                imgData.data[dstIdx+3] = 255;
                srcIdx += 3;
                dstIdx += 4;
            }
        } else if (channels === 1) {
            let srcIdx = 0;
            let dstIdx = 0;
            const len = width * height;
            for (let i = 0; i < len; i++) {
                const g = (pixels[srcIdx] !== undefined) ? pixels[srcIdx] : 0;
                imgData.data[dstIdx] = g;
                imgData.data[dstIdx+1] = g;
                imgData.data[dstIdx+2] = g;
                imgData.data[dstIdx+3] = 255;
                srcIdx += 1;
                dstIdx += 4;
            }
        }
        ctx.putImageData(imgData, 0, 0);

        let newW = width;
        let newH = height;
        if (newW > maxSize || newH > maxSize) {
            if (newW > newH) {
                newH = Math.round((newH * maxSize) / newW);
                newW = maxSize;
            } else {
                newW = Math.round((newW * maxSize) / newH);
                newH = maxSize;
            }
            const downscaledCanvas = document.createElement('canvas');
            downscaledCanvas.width = newW;
            downscaledCanvas.height = newH;
            const downscaledCtx = downscaledCanvas.getContext('2d');
            downscaledCtx.drawImage(canvas, 0, 0, newW, newH);
            const newBlob = await new Promise(resolve => downscaledCanvas.toBlob(resolve, 'image/jpeg', quality));
            const newBuffer = await newBlob.arrayBuffer();
            return new Uint8Array(newBuffer);
        } else {
            const newBlob = await new Promise(resolve => canvas.toBlob(resolve, 'image/jpeg', quality));
            const newBuffer = await newBlob.arrayBuffer();
            return new Uint8Array(newBuffer);
        }
    }

    // Expose cho testing
    window.compressPDF = compressPDF;

    // Khởi chạy hook
    hookPlupload();
    hookWpUploader();
    hookGutenbergUpload();

    $(document).ready(function() {
        hookPlupload();
        hookWpUploader();
        hookGutenbergUpload();
    });

    var checkInterval = setInterval(function() {
        hookPlupload();
        hookWpUploader();
        hookGutenbergUpload();
    }, 1000);

    setTimeout(function() {
        clearInterval(checkInterval);
    }, 15000);

})(jQuery);
