<?php
/**
 * Gọn CSS + Critical CSS (CSS Slim).
 *
 * Nguyên tắc: TỐI ƯU THẬT, KHÔNG GIAN LẬN ĐIỂM SỐ.
 * - Không nhận diện bot đo điểm (Lighthouse/PageSpeed) để đưa nội dung riêng —
 *   trang mà Google đo chính là trang người dùng nhìn thấy.
 * - Chỉ loại các luật CSS mà trang đó THẬT SỰ không dùng, dựa trên HTML thật
 *   của chính trang (kèm danh sách an toàn cho các class động: menu mở,
 *   slider, hover, popup...). Hướng bảo thủ: nghi ngờ thì GIỮ LẠI.
 * - CSS gốc vẫn được nạp lại đầy đủ ngay khi người dùng tương tác (lưới an
 *   toàn tự vá), và có <noscript> dự phòng cho trình duyệt tắt JavaScript.
 * - Việc phân tích chạy ngầm qua WP-Cron, KHÔNG làm chậm khách truy cập:
 *   khi chưa có kết quả thì trang được trả về nguyên trạng.
 *
 * Cách hoạt động:
 * 1. Lượt xem đầu tiên của một URL: trả nguyên trạng + đặt lịch phân tích ngầm.
 * 2. Cron tự tải HTML của URL đó (kèm ?dawp_cssgen=1 để không bị chính bộ lọc
 *    này can thiệp), gom toàn bộ class/id/thẻ xuất hiện trong HTML (kể cả
 *    trong mã JavaScript inline — nhờ vậy class do JS thêm vào cũng được giữ).
 * 3. Đọc từng tệp CSS nội bộ, giữ đúng các luật trang dùng, viết lại đường dẫn
 *    url() thành tuyệt đối, nén gọn, lưu vào uploads/dawp-css-slim/.
 * 4. Các lượt xem sau: thay toàn bộ thẻ <link> CSS nội bộ bằng một khối duy
 *    nhất — nhúng thẳng vào <head> nếu đủ nhỏ (dưới 60KB), hết render-blocking.
 */

defined( 'ABSPATH' ) || exit;

class DAWP_CSS_Slim {

    const CRON_HOOK  = 'dawp_slim_css_generate';
    const INLINE_MAX = 61440;  // 60KB: dưới ngưỡng này thì nhúng thẳng vào <head>
    const MAX_FILES  = 300;    // trần số URL được lưu cache, quá thì dọn bản cũ nhất
    const META_REV   = 4;      // tăng số này khi đổi thuật toán để cache cũ tự hết hạn
    const CRITICAL_HTML_MIN   = 16384; // ít nhất 16KB HTML đầu coi là "màn hình đầu"
    const CRITICAL_HTML_MAX   = 65536; // nhưng không quá 64KB
    const CRITICAL_MAX        = 81920; // critical CSS quá 80KB thì thôi, không inline (gzip còn ~12KB)

    /** Tùy chọn dawp_settings được truyền vào từ DAWP_Pagespeed */
    private static $options = [];

    /** Lý do lượt này chưa áp dụng được (cho marker chẩn đoán) */
    public static $last_reason = '';

    /** Có cần in JS bật lại hoạt ảnh không (đặt trong rewrite_html) */
    private static $need_anim_ready_js = false;

    /**
     * Danh sách an toàn mặc định: các class thường được JavaScript thêm vào
     * SAU khi trang tải (trạng thái mở/đóng, thư viện slider, popup...) nên
     * không xuất hiện trong HTML ban đầu — luật CSS chứa chúng luôn được giữ.
     */
    private static $default_safelist = [
        'active', 'open', 'show', 'visible', 'invisible', 'hover', 'focus',
        'current', 'sticky', 'stuck', 'fixed', 'scrolled', 'scrolling',
        'loaded', 'loading', 'toggle', 'expand', 'collaps', 'selected',
        'checked', 'disabled', 'error', 'valid', 'invalid', 'success',
        'required', 'hidden', 'hide', 'fade', 'in-view', 'inview',
        'animated', 'animate', 'aos', 'wow', 'slick', 'swiper', 'flickity',
        'owl-', 'glide', 'splide', 'tns-', 'lightbox', 'mfp-', 'pswp',
        'fancybox', 'modal', 'popup', 'tooltip', 'dropdown', 'sub-menu',
        'submenu', 'mega-menu', 'megamenu', 'menu-open', 'nav-open',
        'off-canvas', 'offcanvas', 'mobile-menu', 'mobile-nav', 'sidebar',
        'overlay', 'sr-only', 'screen-reader', 'skip-link', 'select2',
        'blockui', 'processing', 'added', 'cart-open', 'mini-cart',
        'woocommerce-message', 'woocommerce-error', 'woocommerce-info',
        'grecaptcha', 'wpcf7', 'dawp', 'lazyload', 'no-js', 'js-',
    ];

    public static function init( $options ) {
        self::$options = is_array( $options ) ? $options : [];

        // Cron phân tích ngầm — luôn đăng ký để sự kiện đã đặt lịch không lỗi
        add_action( self::CRON_HOOK, [ __CLASS__, 'generate_for_url' ] );

        if ( is_admin() ) {
            add_action( 'wp_ajax_dawp_slim_css_clear', [ __CLASS__, 'ajax_clear' ] );
        }
    }

    /* =====================================================================
     * PHẦN 1: ÁP DỤNG CHO TRANG (chạy trong output buffer của DAWP_Pagespeed)
     * ===================================================================== */

    public static function maybe_apply( $html ) {
        if ( empty( self::$options['ps_slim_css'] ) ) {
            return $html;
        }
        $html = self::apply_inner( $html );
        // CSS ngoài host (Font Awesome/Google Fonts từ CDN...): không đọc được tệp
        // để gọn, nhưng vẫn chặn render + tốn 1 kết nối DNS/TLS mới (~0,5s trên
        // 4G). Chuyển sang nạp không chặn — icon/font hiện trễ vài trăm ms không
        // ai nhận ra, còn chữ và ảnh thì hiện ngay. Bỏ luôn bản nạp trùng.
        if ( ! isset( $_GET['dawp_cssgen'] ) && ! is_user_logged_in() ) {
            $html = self::defer_external_css( $html );
        }
        return $html;
    }

    private static function apply_inner( $html ) {
        // Lượt tải của chính bộ phân tích ngầm: trả nguyên trạng
        if ( isset( $_GET['dawp_cssgen'] ) ) {
            return $html;
        }
        // Chỉ áp dụng cho khách vãng lai, trang tĩnh, không query string
        if ( is_user_logged_in() || is_404() || is_search() || is_customize_preview() ) {
            return $html;
        }
        if ( ! empty( $_GET ) ) {
            return $html;
        }
        if ( isset( $_SERVER['REQUEST_METHOD'] ) && 'GET' !== $_SERVER['REQUEST_METHOD'] ) {
            return $html;
        }
        if ( is_singular() && post_password_required() ) {
            return $html;
        }

        $url = self::current_url();
        if ( ! $url ) {
            return $html;
        }

        $links = self::extract_links( $html );
        if ( empty( $links ) ) {
            return $html;
        }

        $sig  = self::signature( $links );
        $meta = self::load_meta( $url );

        // Chưa phân tích, hoặc bộ CSS của trang đã thay đổi (đổi theme, cập nhật
        // plugin...): đặt lịch phân tích lại và tạm trả trang NGUYÊN TRẠNG —
        // thà chậm một nhịp còn hơn đưa CSS lệch phiên bản.
        if ( ! $meta || $meta['sig'] !== $sig || ! is_readable( self::css_path( $url ) ) ) {
            // Lý do để chẩn đoán từ xa (đọc được trong marker cuối trang)
            self::$last_reason = ! $meta ? 'no-meta' : ( $meta['sig'] !== $sig ? 'sig-mismatch' : 'css-unreadable' );
            self::schedule( $url );

            // Dự phòng khi hosting chặn WP-Cron/loopback (rất hay gặp trên hosting
            // chia sẻ): sau vài lượt xem mà vẫn chưa có kết quả thì phân tích NGAY
            // bằng chính HTML của lượt này — chậm ~1s đúng một lần, các lượt sau
            // đều nhanh. Không có bước này thì trên hosting như vậy tính năng im
            // lặng mãi mãi.
            $miss_key = 'dawp_slimcss_miss_' . md5( $url );
            $misses   = (int) get_transient( $miss_key );
            if ( $misses >= 2 ) {
                delete_transient( $miss_key );
                if ( self::generate_from_html( $url, $html ) ) {
                    $meta = self::load_meta( $url );
                    if ( $meta && $meta['sig'] === $sig ) {
                        self::$last_reason = '';
                        return self::rewrite_html( $html, $links, $meta, $url );
                    }
                    self::$last_reason .= '+regen-sig-still-differs';
                } else {
                    self::$last_reason .= '+regen-failed';
                }
            } else {
                set_transient( $miss_key, $misses + 1, HOUR_IN_SECONDS );
            }
            return $html;
        }

        return self::rewrite_html( $html, $links, $meta, $url );
    }

    /**
     * Chuyển CSS ngoài host sang nạp không chặn render, bỏ bản trùng.
     * Chỉ đụng link chặn render (media all/screen/trống), chưa có onload.
     */
    private static function defer_external_css( $html ) {
        if ( ! preg_match_all( '/<link\b[^>]*>/i', $html, $m ) ) {
            return $html;
        }
        $home_host = strtolower( (string) wp_parse_url( home_url(), PHP_URL_HOST ) );
        $seen      = [];
        $noscript  = '';
        foreach ( $m[0] as $tag ) {
            if ( ! preg_match( '/\brel=["\']?[^"\'>]*stylesheet/i', $tag ) ) {
                continue;
            }
            if ( ! preg_match( '/\bhref=["\']([^"\']+)["\']/i', $tag, $hm ) ) {
                continue;
            }
            $href = html_entity_decode( $hm[1] );
            $host = strtolower( (string) wp_parse_url( $href, PHP_URL_HOST ) );
            if ( '' === $host || $host === $home_host ) {
                continue;
            }
            if ( false !== stripos( $tag, 'onload=' ) ) {
                continue;
            }
            if ( preg_match( '/\bmedia=["\']([^"\']+)["\']/i', $tag, $mm ) ) {
                $media = strtolower( trim( $mm[1] ) );
                if ( '' !== $media && 'all' !== $media && 'screen' !== $media ) {
                    continue;
                }
            }
            $pos = strpos( $html, $tag );
            if ( false === $pos ) {
                continue;
            }
            $key = strtolower( preg_replace( '/[?#].*$/', '', $href ) );
            if ( isset( $seen[ $key ] ) ) {
                // Bản trùng (cùng tệp, khác ?ver hoặc plugin khác nạp lại): bỏ hẳn
                $html = substr_replace( $html, '', $pos, strlen( $tag ) );
                continue;
            }
            $seen[ $key ] = 1;
            $new = preg_replace( '/\bmedia=["\'][^"\']*["\']/i', '', $tag );
            $new = preg_replace( '/\s*\/?>$/', '', $new ) . ' media="print" onload="this.media=&#39;all&#39;">';
            $html = substr_replace( $html, $new, $pos, strlen( $tag ) );
            $noscript .= $tag;
        }
        if ( '' !== $noscript ) {
            $body_pos = strripos( $html, '</body>' );
            $ns = '<noscript>' . $noscript . '</noscript>';
            $html = ( false !== $body_pos ) ? substr_replace( $html, $ns, $body_pos, 0 ) : $html . $ns;
        }
        return $html;
    }

    /**
     * Thay các thẻ <link> CSS đã xử lý bằng khối CSS gọn + lưới an toàn.
     */
    private static function rewrite_html( $html, $links, $meta, $url ) {
        $handled = isset( $meta['handled'] ) ? (array) $meta['handled'] : [];
        if ( empty( $handled ) ) {
            return $html;
        }

        $css_file  = self::css_path( $url );
        // Critical riêng theo thiết bị (cache tĩnh của plugin đã tách mobile/desktop)
        $crit_file = substr( $css_file, 0, -4 ) . ( wp_is_mobile() ? '.crit-m.css' : '.crit.css' );
        if ( ! is_readable( $crit_file ) ) {
            $crit_file = substr( $css_file, 0, -4 ) . '.crit.css';
        }
        $inline    = ( filesize( $css_file ) <= self::INLINE_MAX );

        if ( $inline ) {
            // Đủ nhỏ: nhúng thẳng toàn bộ, không cần tách critical
            $css = file_get_contents( $css_file );
            if ( false === $css || '' === trim( $css ) ) {
                return $html;
            }
            $slim_block = '<style id="dawp-slim-css">' . $css . '</style>';
        } else {
            $upload   = wp_upload_dir();
            $ver      = substr( (string) $meta['sig'], 0, 10 );
            $full_url = esc_url( $upload['baseurl'] . '/dawp-css-slim/' . self::url_key( $url ) . '.css?v=' . $ver );
            $crit     = is_readable( $crit_file ) ? file_get_contents( $crit_file ) : '';

            $anim_file = substr( $css_file, 0, -4 ) . '.anim.css';
            $anim_css  = is_readable( $anim_file ) ? trim( (string) file_get_contents( $anim_file ) ) : '';
            if ( '' !== $anim_css ) {
                $crit .= $anim_css;
                self::$need_anim_ready_js = true;
            }

            if ( '' !== trim( (string) $crit ) ) {
                // Critical inline + tệp đầy đủ nạp KHÔNG chặn (kỹ thuật media=print
                // → onload đổi về all, được mọi trình duyệt hỗ trợ). Có <noscript>
                // riêng để trình duyệt tắt JS vẫn nạp được tệp đầy đủ.
                $slim_block = '<style id="dawp-slim-css">' . $crit . '</style>'
                    . '<link rel="stylesheet" id="dawp-slim-css-full" href="' . $full_url . '" media="print" onload="this.media=&#39;all&#39;">'
                    . '<noscript><link rel="stylesheet" href="' . $full_url . '"></noscript>';
            } else {
                $slim_block = '<link rel="stylesheet" id="dawp-slim-css" href="' . $full_url . '">';
            }
        }

        $original_tags  = [];
        $original_hrefs = [];
        $first_done     = false;

        foreach ( $links as $link ) {
            if ( ! in_array( $link['href'], $handled, true ) ) {
                continue; // tệp không đọc được lúc phân tích: để nguyên, không đụng
            }
            $pos = strpos( $html, $link['tag'] );
            if ( false === $pos ) {
                continue;
            }
            $replacement = $first_done ? '' : $slim_block;
            $html        = substr_replace( $html, $replacement, $pos, strlen( $link['tag'] ) );
            $first_done  = true;
            $original_tags[]  = $link['tag'];
            $original_hrefs[] = $link['href'];
        }

        if ( ! $first_done ) {
            return $html;
        }

        // Lưới an toàn 1: <noscript> nạp CSS gốc cho trình duyệt tắt JavaScript
        $tail = '<noscript>' . implode( '', $original_tags ) . '</noscript>';

        // Bật lại hoạt ảnh vô hạn sau khi trang yên (nếu nút liên hệ của plugin
        // đã in đoạn này rồi thì chạy hai lần cũng vô hại — chỉ thêm 1 class)
        if ( self::$need_anim_ready_js && false === strpos( $html, 'dawp-anim-ready' ) ) {
            $tail .= '<script data-dawp-keep="1">(function(){function go(){document.documentElement.classList.add("dawp-anim-ready");}var t=function(){setTimeout(go,3000);};if(document.readyState==="complete"){t();}else{window.addEventListener("load",t);}var e=["pointerdown","touchstart","keydown","wheel"];function h(){e.forEach(function(x){window.removeEventListener(x,h,{passive:true});});go();}e.forEach(function(x){window.addEventListener(x,h,{passive:true});});})();</script>';
        }

        // Lưới an toàn 2: nạp lại toàn bộ CSS gốc ngay khi người dùng tương tác.
        // CSS gốc chèn SAU khối gọn nên thắng khi hòa độ ưu tiên → giao diện
        // trở về đúng 100% bản gốc, tự vá mọi luật lỡ bị loại nhầm.
        if ( ! isset( self::$options['ps_slim_css_fallback'] ) || ! empty( self::$options['ps_slim_css_fallback'] ) ) {
            $tail .= '<script id="dawp-slim-css-restore" data-dawp-keep="1">'
                . '(function(){var u=' . wp_json_encode( array_values( $original_hrefs ) ) . ',d=false;'
                . 'function go(){if(d)return;d=true;u.forEach(function(h){'
                . 'var l=document.createElement("link");l.rel="stylesheet";l.href=h;document.head.appendChild(l);});}'
                . 'var e=["pointerdown","keydown","touchstart","wheel","mouseover"];'
                . 'function h(){e.forEach(function(x){window.removeEventListener(x,h,{passive:true});});go();}'
                . 'e.forEach(function(x){window.addEventListener(x,h,{passive:true});});'
                . '})();</script>';
        }

        $body_pos = strripos( $html, '</body>' );
        if ( false !== $body_pos ) {
            $html = substr_replace( $html, $tail, $body_pos, 0 );
        } else {
            $html .= $tail;
        }

        return $html;
    }

    /* =====================================================================
     * PHẦN 2: PHÂN TÍCH NGẦM (chạy trong WP-Cron)
     * ===================================================================== */

    private static function schedule( $url ) {
        $lock = 'dawp_slimcss_lock_' . md5( $url );
        if ( get_transient( $lock ) ) {
            return;
        }
        set_transient( $lock, 1, 15 * MINUTE_IN_SECONDS );

        if ( ! wp_next_scheduled( self::CRON_HOOK, [ $url ] ) ) {
            wp_schedule_single_event( time() + 5, self::CRON_HOOK, [ $url ] );
            if ( function_exists( 'spawn_cron' ) ) {
                spawn_cron();
            }
        }
    }

    /**
     * Phân tích một URL: tải HTML thật, đối chiếu CSS, lưu kết quả.
     */
    public static function generate_for_url( $url ) {
        $options = get_option( 'dawp_settings', [] );
        if ( empty( $options['ps_slim_css'] ) ) {
            return;
        }
        // Cron chạy ngoài ngữ cảnh DAWP_Pagespeed nên tự nạp lại tùy chọn
        self::$options = array_merge( self::$options, is_array( $options ) ? $options : [] );

        $dir = self::storage_dir();
        if ( ! $dir ) {
            return;
        }
        self::enforce_cap( $dir );

        // Tải HTML thật của trang (kèm cờ để bộ lọc không tự can thiệp chính nó)
        $resp = wp_remote_get( add_query_arg( 'dawp_cssgen', '1', $url ), [
            'timeout'    => 30,
            'sslverify'  => false, // loopback về chính máy chủ này
            'user-agent' => 'DAWP-CSS-Slim/' . DAWP_VERSION . '; ' . home_url( '/' ),
        ] );
        if ( is_wp_error( $resp ) || 200 !== wp_remote_retrieve_response_code( $resp ) ) {
            return;
        }
        $html = wp_remote_retrieve_body( $resp );
        if ( '' === $html ) {
            return;
        }

        self::generate_from_html( $url, $html );
    }

    /**
     * Phân tích từ HTML đã có sẵn (dùng chung cho cron và đường dự phòng).
     * Trả về true nếu đã ghi được kết quả.
     */
    public static function generate_from_html( $url, $html ) {
        $options = get_option( 'dawp_settings', [] );
        if ( empty( $options['ps_slim_css'] ) ) {
            return false;
        }
        self::$options = array_merge( self::$options, is_array( $options ) ? $options : [] );

        $dir = self::storage_dir();
        if ( ! $dir ) {
            return false;
        }
        self::enforce_cap( $dir );

        $links = self::extract_links( $html );
        if ( empty( $links ) ) {
            return false;
        }

        // Gom mọi "từ" xuất hiện trong HTML (kể cả trong JS inline) làm bộ dấu
        // hiệu: class/id nào có mặt thì luật CSS tương ứng được giữ. Quét cả JS
        // để class do JS thêm vào (addClass, classList.add) cũng được nhận diện.
        $used     = self::collect_tokens( $html );
        $safelist = self::build_safelist( $options );

        $css_out = '';
        $handled = [];

        foreach ( $links as $link ) {
            $path = self::url_to_path( $link['href'] );
            if ( ! $path || ! is_readable( $path ) ) {
                continue; // không đọc được: để nguyên thẻ link gốc trên trang
            }
            $css = file_get_contents( $path );
            if ( false === $css ) {
                continue;
            }
            $css      = self::strip_bom( $css );
            $css      = self::rewrite_urls( $css, $link['href'] );
            $kept     = self::filter_block( $css, $used, $safelist );
            $css_out .= "\n/* nguồn: " . basename( (string) wp_parse_url( $link['href'], PHP_URL_PATH ) ) . " */\n" . $kept;
            $handled[] = $link['href'];
        }

        if ( empty( $handled ) ) {
            return false;
        }

        $css_out = DAWP_Helpers::minify_css( $css_out );

        // Critical CSS (màn hình đầu): lọc CSS gọn thêm một lần nữa, lần này chỉ
        // với các dấu hiệu xuất hiện trong phần HTML ĐẦU (header + hero) — xấp xỉ
        // đủ tốt của "những gì hiện trong màn hình đầu tiên" mà không cần chạy
        // trình duyệt. Khối này nhỏ nên nhúng thẳng vào <head>; phần đầy đủ nạp
        // KHÔNG chặn render phía sau. Trang hiện chữ/ảnh sớm hơn 1-2 giây trên 4G.
        $top_html = self::above_fold_html( $html );
        // Cộng thêm thẻ <html>/<body> mở (class trên body quyết định nhiều luật)
        if ( preg_match( '/<html\b[^>]*>/i', $html, $hm ) ) { $top_html .= ' ' . $hm[0]; }
        if ( preg_match( '/<body\b[^>]*>/i', $html, $bm ) ) { $top_html .= ' ' . $bm[0]; }
        $used_top = self::collect_tokens( $top_html );
        // Critical dùng safelist RỖNG có chủ ý: class trạng thái (open, active...)
        // là của tương tác về sau, không thuộc màn hình đầu. Chúng vẫn nằm đủ
        // trong tệp đầy đủ nạp ngay sau.
        // Hai bản critical riêng: mobile bỏ @media min-width>=768, desktop bỏ
        // max-width<=767; cả hai bỏ luật :hover/:focus. Trên Flatsome/Bricks
        // điều này cắt critical mobile từ ~41KB xuống còn khoảng một nửa — mà
        // 41KB inline nằm ngay trước ảnh hero là thứ kéo FCP/LCP thêm ~1 giây.
        $crit_m = self::filter_block( $css_out, $used_top, [ 'dawp' ], 'mobile' );
        $crit_d = self::filter_block( $css_out, $used_top, [ 'dawp' ], 'desktop' );
        if ( strlen( $crit_m ) > self::CRITICAL_MAX ) { $crit_m = ''; }
        if ( strlen( $crit_d ) > self::CRITICAL_MAX ) { $crit_d = ''; }

        // Hoạt ảnh CHẠY MÃI (infinite) trong màn hình đầu — "nút gọi nhấp nháy",
        // vòng pulse, rung chuông... Đo trên PageSpeed: chúng ép trình duyệt
        // style/layout/paint mỗi khung hình từ byte đầu tiên, main thread bận
        // suốt nên ảnh hero đã tải về vẫn bị hoãn vẽ (LCP 5-6s dù mạng sạch).
        // Cách xử lý: tạm dừng chúng cho tới khi trang yên (html.dawp-anim-ready
        // — cùng cơ chế với nút liên hệ của plugin), rồi chạy đầy đủ như cũ.
        // Bỏ qua spinner/loading vì chúng chỉ hiện khi đang xử lý.
        $anim_sel = self::collect_infinite_animation_selectors( $crit_m . $crit_d );
        $anim_css = '';
        if ( ! empty( $anim_sel ) ) {
            $parts = [];
            foreach ( $anim_sel as $sel ) {
                $parts[] = 'html:not(.dawp-anim-ready) ' . $sel;
            }
            $anim_css = implode( ',', $parts ) . '{animation-play-state:paused!important}';
        }

        $key = self::url_key( $url );
        $ok1 = file_put_contents( $dir . '/' . $key . '.css', $css_out );
        file_put_contents( $dir . '/' . $key . '.anim.css', $anim_css );
        file_put_contents( $dir . '/' . $key . '.crit.css', $crit_d );          // desktop (tên cũ)
        file_put_contents( $dir . '/' . $key . '.crit-m.css', $crit_m );        // mobile
        $ok2 = file_put_contents( $dir . '/' . $key . '.json', wp_json_encode( [
            'rev'     => self::META_REV,
            'url'     => $url,
            'sig'     => self::signature( $links ),
            'handled' => $handled,
            'time'    => time(),
        ] ) );
        return ( false !== $ok1 && false !== $ok2 );
    }

    /* =====================================================================
     * PHẦN 3: BỘ LỌC CSS — hướng bảo thủ, nghi ngờ thì giữ
     * ===================================================================== */

    /**
     * Lọc một khối CSS: giữ luật mà trang có dùng, đệ quy vào @media/@supports.
     */
    /**
     * @param bool|string $critical false = lọc thường; 'mobile'/'desktop' = critical
     *                              cho thiết bị đó (bỏ @media không áp dụng, bỏ :hover...).
     */
    public static function filter_block( $css, $used, $safelist, $critical = false ) {
        $out = '';
        $len = strlen( $css );
        $i   = 0;

        while ( $i < $len ) {
            // Bỏ khoảng trắng đầu
            while ( $i < $len && ctype_space( $css[ $i ] ) ) {
                $i++;
            }
            if ( $i >= $len ) {
                break;
            }
            // Bỏ chú thích
            if ( '/' === $css[ $i ] && $i + 1 < $len && '*' === $css[ $i + 1 ] ) {
                $end = strpos( $css, '*/', $i + 2 );
                $i   = ( false === $end ) ? $len : $end + 2;
                continue;
            }

            // Đọc phần mở đầu (selector hoặc prelude của @rule) tới '{' hoặc ';'
            $start = $i;
            $term  = '';
            while ( $i < $len ) {
                $ch = $css[ $i ];
                if ( '"' === $ch || "'" === $ch ) {
                    $i = self::skip_string( $css, $i, $len );
                    continue;
                }
                if ( '/' === $ch && $i + 1 < $len && '*' === $css[ $i + 1 ] ) {
                    $end = strpos( $css, '*/', $i + 2 );
                    $i   = ( false === $end ) ? $len : $end + 2;
                    continue;
                }
                if ( '{' === $ch || ';' === $ch || '}' === $ch ) {
                    $term = $ch;
                    break;
                }
                $i++;
            }

            $prelude = trim( substr( $css, $start, $i - $start ) );

            if ( '}' === $term ) {
                // '}' lạc dòng: bỏ qua ký tự và đi tiếp
                $i++;
                continue;
            }
            if ( '' === $term ) {
                break; // hết chuỗi
            }

            if ( ';' === $term ) {
                // Câu lệnh at-rule không có khối: @import, @layer a,b; (@charset bỏ)
                $i++;
                if ( '' !== $prelude && '@' === $prelude[0] && 0 !== stripos( $prelude, '@charset' ) ) {
                    if ( ! ( $critical && 0 === stripos( $prelude, '@import' ) ) ) {
                        $out .= $prelude . ';';
                    }
                }
                continue;
            }

            // $term là '{': tìm '}' đóng tương ứng (tôn trọng chuỗi + chú thích)
            $body_start = $i + 1;
            $depth      = 1;
            $j          = $body_start;
            while ( $j < $len && $depth > 0 ) {
                $ch = $css[ $j ];
                if ( '"' === $ch || "'" === $ch ) {
                    $j = self::skip_string( $css, $j, $len );
                    continue;
                }
                if ( '/' === $ch && $j + 1 < $len && '*' === $css[ $j + 1 ] ) {
                    $end = strpos( $css, '*/', $j + 2 );
                    $j   = ( false === $end ) ? $len : $end + 2;
                    continue;
                }
                if ( '{' === $ch ) {
                    $depth++;
                } elseif ( '}' === $ch ) {
                    $depth--;
                }
                $j++;
            }
            $body = substr( $css, $body_start, max( 0, $j - $body_start - 1 ) );
            $i    = $j;

            if ( '' !== $prelude && '@' === $prelude[0] ) {
                $name = strtolower( preg_replace( '/^@([a-zA-Z-]+).*/s', '$1', $prelude ) );
                if ( in_array( $name, [ 'media', 'supports', 'layer', 'container' ], true ) ) {
                    // Critical theo thiết bị: @media không bao giờ khớp trên thiết bị đó
                    // thì bỏ hẳn (mobile bỏ min-width>=768, desktop bỏ max-width<=767).
                    if ( $critical && 'media' === $name && self::media_never_matches( $prelude, $critical ) ) {
                        continue;
                    }
                    // Nhóm lồng nhau: lọc đệ quy phần ruột
                    $inner = self::filter_block( $body, $used, $safelist, $critical );
                    if ( '' !== trim( $inner ) ) {
                        $out .= $prelude . '{' . $inner . '}';
                    }
                } elseif ( $critical && in_array( $name, [ 'keyframes', '-webkit-keyframes', '-moz-keyframes' ], true ) ) {
                    // Critical CSS (màn hình đầu) không cần hoạt ảnh — đã có trong
                    // tệp đầy đủ nạp ngay sau; giữ lại chỉ làm khối inline phình lên
                    // (animate.css có ~250 keyframes). @font-face thì PHẢI giữ: thiếu
                    // nó chữ vẽ bằng phông dự phòng có chiều cao dòng khác, khi phông
                    // thật về cả trang nhảy vài chục px (CLS) — đã đo được trên Bricks.
                } else {
                    // @font-face, @keyframes, @page, @property...: giữ nguyên
                    $out .= $prelude . '{' . $body . '}';
                }
                continue;
            }

            // Luật thường: giữ NGUYÊN cả luật nếu BẤT KỲ selector nào có thể khớp
            if ( '' !== $prelude && self::selector_list_may_match( $prelude, $used, $safelist ) ) {
                // Critical: luật chỉ dành cho tương tác (:hover/:focus/:active/:focus-within)
                // không cần cho khung hình đầu — tệp đầy đủ về ngay sau đó lo.
                if ( $critical && self::selector_list_only_interactive( $prelude ) ) {
                    continue;
                }
                $out .= $prelude . '{' . $body . '}';
            }
        }

        return $out;
    }

    /**
     * @media có chắc chắn KHÔNG khớp trên thiết bị này không? Chỉ kết luận khi
     * rõ ràng: mobile ↔ (min-width: >=768px); desktop ↔ (max-width: <=767px).
     * print luôn bỏ. Mọi trường hợp mơ hồ → giữ.
     */
    private static function media_never_matches( $prelude, $device ) {
        $q = strtolower( $prelude );
        if ( preg_match( '/^\s*@media\s+print\s*$/', $q ) ) {
            return true;
        }
        if ( 'mobile' === $device && preg_match( '/min-width\s*:\s*(\d+(?:\.\d+)?)\s*(px|em|rem)/', $q, $m ) ) {
            $px = (float) $m[1] * ( 'px' === $m[2] ? 1 : 16 );
            if ( $px >= 768 && false === strpos( $q, 'max-width' ) ) {
                return true;
            }
        }
        if ( 'desktop' === $device && preg_match( '/max-width\s*:\s*(\d+(?:\.\d+)?)\s*(px|em|rem)/', $q, $m ) ) {
            $px = (float) $m[1] * ( 'px' === $m[2] ? 1 : 16 );
            if ( $px <= 767 && false === strpos( $q, 'min-width' ) ) {
                return true;
            }
        }
        return false;
    }

    /** Toàn bộ selector trong danh sách đều có :hover/:focus/:active/:focus-within/:focus-visible? */
    private static function selector_list_only_interactive( $selector_list ) {
        foreach ( explode( ',', $selector_list ) as $sel ) {
            if ( ! preg_match( '/:(hover|focus|active|focus-within|focus-visible)\b/i', $sel ) ) {
                return false;
            }
        }
        return true;
    }

    /**
     * Thu các selector có `animation ... infinite` (không phải spinner/loading).
     * Trả về danh sách selector đơn (đã tách dấu phẩy), tối đa 60.
     */
    public static function collect_infinite_animation_selectors( $css ) {
        $out = [];
        if ( ! preg_match_all( '/([^{}]+)\{([^{}]*\banimation(?:-name)?\s*:[^;}]*\binfinite\b[^{}]*)\}/i', $css, $m, PREG_SET_ORDER ) ) {
            return $out;
        }
        foreach ( $m as $rule ) {
            $sel_list = trim( $rule[1] );
            // Bỏ phần prelude @media dính trước selector (do regex không hiểu lồng)
            $sel_list = preg_replace( '/^.*\}/s', '', $sel_list );
            $sel_list = preg_replace( '/^@[^{]*\{/s', '', $sel_list );
            if ( '' === $sel_list || '@' === $sel_list[0] ) {
                continue;
            }
            foreach ( explode( ',', $sel_list ) as $sel ) {
                $sel = trim( $sel );
                if ( '' === $sel || strlen( $sel ) > 200 ) {
                    continue;
                }
                // Spinner/đang xử lý: để nguyên
                if ( preg_match( '/loading|spinner|processing|blockui|blockoverlay|progress|preloader|skeleton|placeholder|dawp-/i', $sel ) ) {
                    continue;
                }
                $out[ $sel ] = 1;
                if ( count( $out ) >= 60 ) {
                    break 2;
                }
            }
        }
        return array_keys( $out );
    }

    /** Nhảy qua một chuỗi trong CSS, trả về vị trí sau dấu nháy đóng. */
    private static function skip_string( $css, $i, $len ) {
        $quote = $css[ $i ];
        $i++;
        while ( $i < $len ) {
            if ( '\\' === $css[ $i ] ) {
                $i += 2;
                continue;
            }
            if ( $css[ $i ] === $quote ) {
                return $i + 1;
            }
            $i++;
        }
        return $len;
    }

    /**
     * Danh sách selector (tách bởi dấu phẩy): chỉ cần MỘT selector có khả năng
     * khớp là giữ nguyên cả luật.
     */
    private static function selector_list_may_match( $selector_list, $used, $safelist ) {
        foreach ( explode( ',', $selector_list ) as $sel ) {
            if ( self::selector_may_match( $sel, $used, $safelist ) ) {
                return true;
            }
        }
        return false;
    }

    /**
     * Một selector bị loại CHỈ KHI chứa class/id chắc chắn vắng mặt trên trang
     * và không thuộc danh sách an toàn. Mọi trường hợp mơ hồ đều GIỮ.
     */
    private static function selector_may_match( $sel, $used, $safelist ) {
        // Selector thuộc tính [data-x="y"] → coi như khớp được (không kiểm tra)
        $sel = preg_replace( '/\[[^\]]*\]/', ' ', $sel );
        // Ruột của :not(...), :is(...), :where(...)... → bỏ, không bắt buộc
        $sel = preg_replace( '/\([^()]*\)/', ' ', $sel );
        // Tên pseudo-class / pseudo-element
        $sel = preg_replace( '/::?[a-zA-Z-]+/', ' ', $sel );

        if ( ! preg_match_all( '/([.#])([A-Za-z0-9_\\\\-]+)/', $sel, $m, PREG_SET_ORDER ) ) {
            return true; // chỉ có thẻ/universal: luôn giữ
        }

        // Chỉ cần MỘT token thuộc danh sách an toàn là giữ cả selector: class
        // trạng thái (active, open...) thường do JS bên ngoài thêm cùng lúc với
        // các class khác, nên không thể kết luận vắng mặt cho phần còn lại.
        foreach ( $m as $token ) {
            if ( self::in_safelist( $token[2], $safelist ) ) {
                return true;
            }
        }

        foreach ( $m as $token ) {
            $name = $token[2];
            if ( false !== strpos( $name, '\\' ) ) {
                continue; // class có ký tự escape: không đánh giá được → giữ
            }
            if ( isset( $used[ $name ] ) || isset( $used[ strtolower( $name ) ] ) ) {
                continue;
            }
            return false; // chắc chắn vắng mặt → selector này không thể khớp
        }
        return true;
    }

    private static function in_safelist( $name, $safelist ) {
        $name = strtolower( $name );
        foreach ( $safelist as $word ) {
            if ( '' !== $word && false !== strpos( $name, $word ) ) {
                return true;
            }
        }
        return false;
    }

    private static function build_safelist( $options ) {
        $safelist = self::$default_safelist;
        if ( ! empty( $options['ps_slim_css_safelist'] ) ) {
            foreach ( preg_split( '/[\r\n,]+/', (string) $options['ps_slim_css_safelist'] ) as $line ) {
                $line = strtolower( trim( $line ) );
                if ( '' !== $line ) {
                    $safelist[] = $line;
                }
            }
        }
        return $safelist;
    }

    /**
     * Cắt phần HTML "màn hình đầu" để tính critical CSS.
     *
     * Cắt cứng theo byte thì hay đứt giữa section hero (hero cao 1500px không
     * lọt hết 16KB), phần tử phía dưới bị thiếu luật → flex/grid center dồn
     * layout lệch vài chục px rồi "nhảy" khi CSS đầy đủ về (CLS). Nên cắt tại
     * ranh giới phần tử: từ <body> tới hết PHẦN TỬ CẤP CAO THỨ HAI (header +
     * section đầu tiên) — có sàn/trần byte để không quá ngắn hay quá dài.
     */
    private static function above_fold_html( $html ) {
        $body_pos = stripos( $html, '<body' );
        if ( false === $body_pos ) {
            return substr( $html, 0, self::CRITICAL_HTML_MIN );
        }
        $start = strpos( $html, '>', $body_pos );
        $start = ( false === $start ) ? $body_pos : $start + 1;
        $limit = min( strlen( $html ), $start + self::CRITICAL_HTML_MAX );

        // Đếm độ sâu thẻ khối để tìm điểm đóng của phần tử cấp cao thứ 2 trong body
        $depth = 0;
        $top_closed = 0;
        $cut = false;
        if ( preg_match_all( '#<(/?)(header|main|section|div|nav|footer|article|aside)\b[^>]*?(/?)>#i', $html, $m, PREG_OFFSET_CAPTURE, $start ) ) {
            foreach ( $m[0] as $i => $tag ) {
                $pos = $tag[1];
                if ( $pos >= $limit ) {
                    break;
                }
                $closing = ( '/' === $m[1][ $i ][0] );
                $selfclose = ( '/' === $m[3][ $i ][0] );
                if ( $closing ) {
                    $depth = max( 0, $depth - 1 );
                    if ( 0 === $depth ) {
                        $top_closed++;
                        // Bỏ qua các wrapper mỏng (skip-link, overlay...) chỉ vài trăm byte
                        $end = $pos + strlen( $tag[0] );
                        if ( $top_closed >= 2 && $end - $start >= self::CRITICAL_HTML_MIN ) {
                            $cut = $end;
                            break;
                        }
                    }
                } elseif ( ! $selfclose ) {
                    $depth++;
                }
            }
        }
        if ( false === $cut ) {
            $cut = min( $limit, $start + max( self::CRITICAL_HTML_MIN, (int) ( self::CRITICAL_HTML_MAX / 2 ) ) );
        }
        return substr( $html, $start, $cut - $start );
    }

    /**
     * Gom bộ "từ" của trang. Quét toàn bộ HTML — kể cả JS inline — theo đúng
     * cách PurgeCSS làm: mọi chuỗi chữ-số-gạch đều tính là dấu hiệu có mặt.
     * Hướng dư thừa an toàn: giữ nhầm còn hơn bỏ sót.
     */
    private static function collect_tokens( $html ) {
        $used = [];
        if ( preg_match_all( '/[A-Za-z0-9_-]{1,80}/', $html, $m ) ) {
            foreach ( $m[0] as $token ) {
                $used[ $token ] = 1;
                $lower = strtolower( $token );
                if ( $lower !== $token ) {
                    $used[ $lower ] = 1;
                }
            }
        }
        return $used;
    }

    /* =====================================================================
     * PHẦN 4: TIỆN ÍCH — link, đường dẫn, url(), lưu trữ
     * ===================================================================== */

    /**
     * Nhặt các thẻ <link rel="stylesheet"> nội bộ đủ điều kiện xử lý.
     */
    public static function extract_links( $html ) {
        $result = [];
        if ( ! preg_match_all( '/<link\b[^>]*>/i', $html, $m ) ) {
            return $result;
        }

        $home_host = strtolower( (string) wp_parse_url( home_url(), PHP_URL_HOST ) );
        $excludes  = [];
        if ( ! empty( self::$options['ps_slim_css_exclude'] ) ) {
            foreach ( preg_split( '/[\r\n,]+/', (string) self::$options['ps_slim_css_exclude'] ) as $line ) {
                $line = trim( $line );
                if ( '' !== $line ) {
                    $excludes[] = $line;
                }
            }
        }

        foreach ( $m[0] as $tag ) {
            if ( ! preg_match( '/\brel=["\']?[^"\'>]*stylesheet/i', $tag ) ) {
                continue;
            }
            if ( ! preg_match( '/\bhref=["\']([^"\']+)["\']/i', $tag, $href_m ) ) {
                continue;
            }
            $href = html_entity_decode( $href_m[1] );

            // Chỉ nhận media chặn render (all/screen/trống); media="print" để nguyên
            if ( preg_match( '/\bmedia=["\']([^"\']+)["\']/i', $tag, $media_m ) ) {
                $media = strtolower( trim( $media_m[1] ) );
                if ( '' !== $media && 'all' !== $media && 'screen' !== $media ) {
                    continue;
                }
            }
            // Link đã có onload (đã được chuyển async bởi công cụ khác) → không đụng
            if ( false !== stripos( $tag, 'onload=' ) ) {
                continue;
            }

            // Chỉ xử lý CSS cùng host (mới đọc được tệp để phân tích)
            $host = strtolower( (string) wp_parse_url( $href, PHP_URL_HOST ) );
            if ( '' !== $host && $host !== $home_host ) {
                continue;
            }

            $skip = false;
            foreach ( $excludes as $pattern ) {
                if ( false !== stripos( $href, $pattern ) ) {
                    $skip = true;
                    break;
                }
            }
            if ( $skip ) {
                continue;
            }

            $result[] = [ 'tag' => $tag, 'href' => $href ];
        }
        return $result;
    }

    /**
     * Đổi URL tệp CSS nội bộ sang đường dẫn hệ thống, có kiểm tra an toàn.
     */
    private static function url_to_path( $url ) {
        $path = (string) wp_parse_url( $url, PHP_URL_PATH );
        if ( '' === $path || '.css' !== strtolower( substr( $path, -4 ) ) ) {
            return false;
        }

        $maps = [
            [ (string) wp_parse_url( content_url( '/' ), PHP_URL_PATH ), trailingslashit( WP_CONTENT_DIR ) ],
            [ (string) wp_parse_url( includes_url(), PHP_URL_PATH ), trailingslashit( ABSPATH . WPINC ) ],
            [ (string) wp_parse_url( site_url( '/' ), PHP_URL_PATH ), trailingslashit( ABSPATH ) ],
        ];

        foreach ( $maps as $map ) {
            list( $prefix, $base ) = $map;
            if ( '' !== $prefix && 0 === strpos( $path, $prefix ) ) {
                $candidate = $base . ltrim( substr( $path, strlen( $prefix ) ), '/' );
                $real      = realpath( $candidate );
                if ( $real && (
                    0 === strpos( $real, (string) realpath( ABSPATH ) ) ||
                    0 === strpos( $real, (string) realpath( WP_CONTENT_DIR ) )
                ) ) {
                    return $real;
                }
            }
        }
        return false;
    }

    /**
     * Viết lại url(...) và @import tương đối thành tuyệt đối, vì CSS sẽ được
     * chuyển sang vị trí khác (inline trong HTML hoặc tệp gộp).
     */
    public static function rewrite_urls( $css, $stylesheet_url ) {
        $base = preg_replace( '/[?#].*$/', '', $stylesheet_url );
        $base = preg_replace( '#/[^/]*$#', '/', $base );

        $resolve = function ( $ref ) use ( $base ) {
            $ref = trim( $ref );
            if ( '' === $ref || preg_match( '#^(data:|https?://|//|/|\#)#i', $ref ) ) {
                return $ref;
            }
            $abs    = $base . $ref;
            $prefix = '';
            if ( preg_match( '#^(https?://[^/]+)(/.*)$#i', $abs, $pm ) ) {
                $prefix = $pm[1];
                $abs    = $pm[2];
            }
            // Rút gọn các đoạn ../ và ./
            $parts = [];
            foreach ( explode( '/', $abs ) as $seg ) {
                if ( '.' === $seg ) {
                    continue;
                }
                if ( '..' === $seg ) {
                    array_pop( $parts );
                    continue;
                }
                $parts[] = $seg;
            }
            return $prefix . implode( '/', $parts );
        };

        $css = preg_replace_callback( '/url\(\s*([\'"]?)([^\'")]+)\1\s*\)/i', function ( $m ) use ( $resolve ) {
            return 'url(' . $m[1] . $resolve( $m[2] ) . $m[1] . ')';
        }, $css );

        $css = preg_replace_callback( '/@import\s+([\'"])([^\'"]+)\1/i', function ( $m ) use ( $resolve ) {
            return '@import ' . $m[1] . $resolve( $m[2] ) . $m[1];
        }, $css );

        return $css;
    }

    private static function current_url() {
        if ( empty( $_SERVER['REQUEST_URI'] ) ) {
            return false;
        }
        // REQUEST_URI đã chứa cả thư mục con của site (vd /dabricks/), nên phải
        // ghép với GỐC host chứ không phải home_url() — kẻo thành /dabricks/dabricks/.
        $path   = strtok( wp_unslash( $_SERVER['REQUEST_URI'] ), '?' );
        $parts  = wp_parse_url( home_url( '/' ) );
        $origin = $parts['scheme'] . '://' . $parts['host'] . ( ! empty( $parts['port'] ) ? ':' . $parts['port'] : '' );
        return $origin . $path;
    }

    private static function signature( $links ) {
        $hrefs = wp_list_pluck( $links, 'href' );
        sort( $hrefs );
        $extra = [
            self::META_REV,
            DAWP_VERSION,
            isset( self::$options['ps_slim_css_safelist'] ) ? self::$options['ps_slim_css_safelist'] : '',
            isset( self::$options['ps_slim_css_exclude'] ) ? self::$options['ps_slim_css_exclude'] : '',
        ];
        return md5( wp_json_encode( [ $hrefs, $extra ] ) );
    }

    private static function url_key( $url ) {
        return md5( strtolower( untrailingslashit( $url ) ) );
    }

    private static function css_path( $url ) {
        $upload = wp_upload_dir();
        return $upload['basedir'] . '/dawp-css-slim/' . self::url_key( $url ) . '.css';
    }

    private static function load_meta( $url ) {
        $upload = wp_upload_dir();
        $file   = $upload['basedir'] . '/dawp-css-slim/' . self::url_key( $url ) . '.json';
        if ( ! is_readable( $file ) ) {
            return false;
        }
        $meta = json_decode( (string) file_get_contents( $file ), true );
        if ( ! is_array( $meta ) || empty( $meta['sig'] ) || (int) ( isset( $meta['rev'] ) ? $meta['rev'] : 0 ) !== self::META_REV ) {
            return false;
        }
        return $meta;
    }

    private static function storage_dir() {
        $upload = wp_upload_dir();
        $dir    = $upload['basedir'] . '/dawp-css-slim';
        if ( ! is_dir( $dir ) && ! wp_mkdir_p( $dir ) ) {
            return false;
        }
        // Chặn thực thi PHP trong thư mục lưu trữ
        $ht = $dir . '/.htaccess';
        if ( ! file_exists( $ht ) ) {
            file_put_contents( $ht, "<FilesMatch \"\\.(php|phtml|php[0-9])$\">\nRequire all denied\n</FilesMatch>\n" );
        }
        if ( ! file_exists( $dir . '/index.php' ) ) {
            file_put_contents( $dir . '/index.php', "<?php // im lặng là vàng\n" );
        }
        return $dir;
    }

    /** Giữ số tệp cache dưới trần, dọn bản cũ nhất trước. */
    private static function enforce_cap( $dir ) {
        $files = glob( $dir . '/*.json' );
        if ( ! is_array( $files ) || count( $files ) < self::MAX_FILES ) {
            return;
        }
        usort( $files, function ( $a, $b ) {
            return filemtime( $a ) - filemtime( $b );
        } );
        $remove = array_slice( $files, 0, count( $files ) - self::MAX_FILES + 1 );
        foreach ( $remove as $file ) {
            @unlink( $file );
            @unlink( substr( $file, 0, -5 ) . '.css' );
            @unlink( substr( $file, 0, -5 ) . '.crit.css' );
            @unlink( substr( $file, 0, -5 ) . '.crit-m.css' );
            @unlink( substr( $file, 0, -5 ) . '.anim.css' );
        }
    }

    public static function clear_cache() {
        $upload = wp_upload_dir();
        $dir    = $upload['basedir'] . '/dawp-css-slim';
        $count  = 0;
        if ( is_dir( $dir ) ) {
            foreach ( (array) glob( $dir . '/*.{css,json}', GLOB_BRACE ) as $file ) {
                if ( @unlink( $file ) ) {
                    $count++;
                }
            }
        }
        return $count;
    }

    public static function status() {
        $upload = wp_upload_dir();
        $dir    = $upload['basedir'] . '/dawp-css-slim';
        $files  = is_dir( $dir ) ? (array) glob( $dir . '/*.css' ) : [];
        $size   = 0;
        foreach ( $files as $file ) {
            $size += (int) filesize( $file );
        }
        return [ 'count' => count( $files ), 'size' => $size ];
    }

    public static function ajax_clear() {
        check_ajax_referer( 'dawp_slim_css' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( 'Không đủ quyền.' );
        }
        $count = self::clear_cache();
        wp_send_json_success( [ 'deleted' => $count ] );
    }

    private static function strip_bom( $text ) {
        if ( "\xEF\xBB\xBF" === substr( $text, 0, 3 ) ) {
            return substr( $text, 3 );
        }
        return $text;
    }
}
