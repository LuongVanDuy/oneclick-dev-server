/**
 * DAWP WebP Converter - Worker nén ảnh.
 *
 * Toàn bộ công việc nặng (giải mã ảnh, resize, encode WebP) chạy trong Web Worker
 * trên MÁY CỦA QUẢN TRỊ VIÊN. Máy chủ không tham gia vào quá trình này.
 * Chạy trong Worker nên giao diện admin không bao giờ bị treo.
 */

/* global self, createImageBitmap, OffscreenCanvas, fetch */

'use strict';

/**
 * Nén một file ảnh sang WebP.
 *
 * @param {Object} job Thông tin công việc.
 * @return {Promise<Object>} Kết quả.
 */
async function compress( job ) {
	// Tải ảnh với timeout 60s + tự thử lại khi server quá tải (503/429/5xx):
	// firewall chống flood của hosting hay chặn tạm khi tải nhiều ảnh song
	// song — chờ vài giây thử lại là qua, không được tính là ảnh lỗi.
	let response = null;

	for ( let attempt = 0; ; attempt++ ) {
		const controller = new AbortController();
		const timer = setTimeout( function () {
			controller.abort();
		}, 60000 );

		try {
			response = await fetch( job.url, {
				credentials: 'same-origin',
				cache: 'no-store',
				signal: controller.signal
			} );
		} catch ( e ) {
			clearTimeout( timer );

			if ( 2 > attempt ) {
				await new Promise( function ( r ) {
					setTimeout( r, 8000 );
				} );
				continue;
			}

			throw new Error(
				'AbortError' === e.name
					? 'Tải ảnh quá 60 giây không xong.'
					: 'Không tải được ảnh: ' + e.message
			);
		}

		clearTimeout( timer );

		if ( response.ok ) {
			break;
		}

		const transient = 503 === response.status || 429 === response.status || 500 <= response.status;

		if ( transient && 2 > attempt ) {
			await new Promise( function ( r ) {
				setTimeout( r, 8000 );
			} );
			continue;
		}

		throw new Error( 'Không tải được ảnh (HTTP ' + response.status + ')' );
	}

	const sourceBlob = await response.blob();
	const originalSize = sourceBlob.size;

	let bitmap;
	try {
		bitmap = await createImageBitmap( sourceBlob );
	} catch ( e ) {
		throw new Error( 'Không giải mã được ảnh: ' + e.message );
	}

	let width = bitmap.width;
	let height = bitmap.height;

	// Giới hạn CẠNH DÀI NHẤT (mặc định 1920px — chuẩn Full HD, hiển thị
	// tràn màn hình vẫn nét). Áp cho ảnh gốc và bản gốc chưa scale (file
	// nặng nhất), xử lý được cả ảnh ngang lẫn ảnh dọc dài. Thumbnail do
	// WordPress sinh ra đã nhỏ sẵn, không đụng vào.
	const isMainImage = 'full' === job.key || 'original_image' === job.key;

	if ( isMainImage && 0 < job.maxWidth ) {
		const longest = Math.max( width, height );

		if ( longest > job.maxWidth ) {
			const scale = job.maxWidth / longest;
			width = Math.max( 1, Math.round( width * scale ) );
			height = Math.max( 1, Math.round( height * scale ) );
		}
	}

	// ------------------------------------------------------------------
	// THU NHỎ NHIỀU BƯỚC (progressive halving): thu quá nhiều trong một
	// lần vẽ làm ảnh bết và mất chi tiết. Giảm dần từng nửa một rồi mới
	// vẽ bước cuối cho ra ảnh NÉT hơn hẳn so với thu thẳng một phát.
	// ------------------------------------------------------------------
	let source = bitmap;
	let sw = bitmap.width;
	let sh = bitmap.height;

	while ( sw / 2 >= width && 32 < sw ) {
		const hw = Math.max( width, Math.round( sw / 2 ) );
		const hh = Math.max( height, Math.round( sh / 2 ) );

		const step = new OffscreenCanvas( hw, hh );
		const sctx = step.getContext( '2d', { alpha: true } );
		sctx.imageSmoothingEnabled = true;
		sctx.imageSmoothingQuality = 'high';
		sctx.drawImage( source, 0, 0, hw, hh );

		if ( source.close ) {
			source.close();
		}
		source = step;
		sw = hw;
		sh = hh;
	}

	const canvas = new OffscreenCanvas( width, height );
	const ctx = canvas.getContext( '2d', { alpha: true } );
	ctx.imageSmoothingEnabled = true;
	ctx.imageSmoothingQuality = 'high';
	ctx.drawImage( source, 0, 0, width, height );

	if ( source.close ) {
		source.close();
	}

	// ------------------------------------------------------------------
	// CHẤT LƯỢNG THÍCH ỨNG: nén ở chất lượng người dùng chọn trước.
	// Nếu file ra TO HƠN ảnh gốc thì tự hạ từng nấc nhỏ (7%) đến khi nhẹ
	// hơn — mỗi nấc mắt thường gần như không phân biệt được, nhưng đảm
	// bảo kết quả hầu như luôn nhẹ hơn ảnh gốc. Sàn 0.5 để không bao giờ
	// phá nát ảnh vì cố ép dung lượng.
	// ------------------------------------------------------------------
	let quality = job.quality;
	let webpBlob = null;
	let best = null;

	for ( let attempt = 0; 4 > attempt; attempt++ ) {
		webpBlob = await canvas.convertToBlob( {
			type: 'image/webp',
			quality: quality
		} );

		if ( ! webpBlob || 0 === webpBlob.size ) {
			throw new Error( 'Trình duyệt không tạo được file WebP.' );
		}

		if ( ! best || webpBlob.size < best.size ) {
			best = webpBlob;
		}

		// Đã nhẹ hơn ảnh gốc -> đạt yêu cầu, dừng ngay.
		if ( webpBlob.size < originalSize ) {
			break;
		}

		// Chưa nhẹ hơn -> hạ chất lượng một nấc rồi thử lại.
		quality = Math.max( 0.5, quality - 0.07 );

		if ( 0.5 >= quality && 2 <= attempt ) {
			break;
		}
	}

	// Dùng bản nhỏ nhất đạt được. Trường hợp cực hiếm (icon PNG vài trăm
	// byte) có thể vẫn to hơn gốc chút ít — chấp nhận để đồng nhất WebP.
	webpBlob = best;

	// Giải phóng bộ nhớ canvas ngay.
	canvas.width = 0;
	canvas.height = 0;

	return {
		key: job.key,
		blob: webpBlob,
		width: width,
		height: height,
		originalSize: originalSize,
		newSize: webpBlob.size
	};
}

self.onmessage = async function ( event ) {
	const job = event.data;

	try {
		const result = await compress( job );

		self.postMessage( {
			id: job.id,
			ok: true,
			key: result.key,
			blob: result.blob,
			width: result.width,
			height: result.height,
			originalSize: result.originalSize,
			newSize: result.newSize
		} );
	} catch ( error ) {
		self.postMessage( {
			id: job.id,
			ok: false,
			key: job.key,
			error: error && error.message ? error.message : String( error )
		} );
	}
};


