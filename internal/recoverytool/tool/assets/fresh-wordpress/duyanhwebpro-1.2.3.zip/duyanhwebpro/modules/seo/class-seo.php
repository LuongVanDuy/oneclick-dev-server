<?php
defined( 'ABSPATH' ) || exit;

class DAWP_Seo {
    public function __construct() {
        // Tự động kích hoạt các hooks
        add_action( 'init', [ $this, 'init_seo_rules' ] );
        add_action( 'query_vars', [ $this, 'register_query_vars' ] );
        add_action( 'template_redirect', [ $this, 'handle_seo_requests' ], 1 );
        
        // Hooks ghi đè Meta & Header ngoài Frontend
        add_filter( 'document_title_parts', [ $this, 'filter_seo_title' ], 999 );
        add_action( 'wp_head', [ $this, 'output_seo_meta_tags' ], 1 );
        add_filter( 'robots_txt', [ $this, 'filter_robots_txt' ], 999 );
        add_filter( 'the_content', [ $this, 'inject_faq_and_auto_alt' ], 999 );
        add_filter( 'the_content', [ $this, 'auto_nofollow_external_links' ], 1000 );
        add_action( 'wp_footer', [ $this, 'inject_link_prefetch_script' ], 999 );

        // Quản lý Metabox trong Admin bài viết / trang / sản phẩm
        if ( is_admin() ) {
            add_action( 'add_meta_boxes', [ $this, 'add_seo_metabox' ] );
            add_action( 'save_post', [ $this, 'save_seo_meta' ] );
            
            // SEO Meta cho chuyên mục (Taxonomy)
            add_action( 'category_edit_form_fields', [ $this, 'render_taxonomy_seo_fields' ] );
            add_action( 'edited_category', [ $this, 'save_taxonomy_seo_fields' ] );
            add_action( 'post_tag_edit_form_fields', [ $this, 'render_taxonomy_seo_fields' ] );
            add_action( 'edited_post_tag', [ $this, 'save_taxonomy_seo_fields' ] );
            
            // Hỗ trợ WooCommerce Product Cat & Tag
            add_action( 'product_cat_edit_form_fields', [ $this, 'render_taxonomy_seo_fields' ] );
            add_action( 'edited_product_cat', [ $this, 'save_taxonomy_seo_fields' ] );
            add_action( 'product_tag_edit_form_fields', [ $this, 'render_taxonomy_seo_fields' ] );
            add_action( 'edited_product_tag', [ $this, 'save_taxonomy_seo_fields' ] );

            add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_admin_assets' ] );
            add_action( 'wp_ajax_dawp_get_link_suggestions', [ $this, 'get_link_suggestions_callback' ] );

            // Đăng ký cột SEO động cho toàn bộ post type công khai
            add_action( 'init', [ $this, 'register_seo_columns' ], 20 );
            
            // Thêm cột SEO vào thư viện hình ảnh (Media Library)
            add_filter( 'manage_media_columns', [ $this, 'add_seo_column_header' ] );
            add_action( 'manage_media_custom_column', [ $this, 'render_media_column_content' ], 10, 2 );
            
            add_action( 'admin_head', [ $this, 'add_seo_column_styles' ] );
            add_filter( 'request', [ $this, 'sort_views_column_query' ] );

            // Lưu điểm SEO + Dễ đọc vào meta khi lưu bài (phục vụ lọc/đếm ngoài danh sách)
            add_action( 'save_post', [ $this, 'store_scores_on_save' ], 99 );

            // Bộ lọc dropdown "Điểm SEO" & "Điểm Dễ đọc" phía trên danh sách
            add_action( 'restrict_manage_posts', [ $this, 'render_score_filters' ] );
            add_action( 'pre_get_posts', [ $this, 'filter_admin_by_score' ] );

            // AJAX quét lại điểm cho toàn bộ bài viết cũ
            add_action( 'wp_ajax_dawp_rescan_scores', [ $this, 'ajax_rescan_scores' ] );
        }

        // Tự động tạo 301 Redirect khi đổi slug bài viết
        add_action( 'post_updated', [ $this, 'auto_create_301_on_slug_change' ], 10, 3 );
        
        // Đăng ký Shortcode hiển thị Breadcrumbs
        add_shortcode( 'dawp_breadcrumbs', [ $this, 'render_breadcrumbs' ] );

        // Đăng ký Shortcode hiển thị Lượt xem bài viết
        add_shortcode( 'dawp_post_views', [ $this, 'render_post_views' ] );

        // Frontend tracking lượt xem (Cache-safe qua AJAX)
        add_action( 'wp_head', [ $this, 'inject_track_view_script' ] );
        add_action( 'wp_ajax_dawp_inc_pv', [ $this, 'ajax_track_view' ] );
        add_action( 'wp_ajax_nopriv_dawp_inc_pv', [ $this, 'ajax_track_view' ] );
        
        // Đăng ký hook IndexNow khi xuất bản/cập nhật bài viết
        add_action( 'transition_post_status', [ $this, 'ping_indexnow_on_publish' ], 10, 3 );

        // Đăng ký hook chèn mã code snippet (Google Analytics, Facebook Pixel, Ads...)
        add_action( 'wp_head', [ $this, 'inject_header_code' ], 100 );
        add_action( 'wp_body_open', [ $this, 'inject_body_code' ], 1 );
        add_action( 'wp_footer', [ $this, 'inject_footer_code' ], 100 );
    }

    /**
     * Tạo các bảng CSDL phục vụ Redirect 301 và lưu trữ Logs lỗi 404 (Failsafe)
     */
    public static function create_db_table() {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();
        
        // Bảng lưu trữ redirects 301
        $table_redirects = $wpdb->prefix . 'dawp_redirects';
        $sql_redirects = "CREATE TABLE $table_redirects (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            old_url varchar(255) NOT NULL,
            new_url varchar(255) NOT NULL,
            type varchar(10) DEFAULT '301',
            PRIMARY KEY  (id),
            KEY old_url (old_url)
        ) $charset_collate;";

        // Bảng lưu trữ lịch sử lỗi 404
        $table_404 = $wpdb->prefix . 'dawp_404_logs';
        $sql_404 = "CREATE TABLE $table_404 (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            url varchar(255) NOT NULL,
            ip_address varchar(50) DEFAULT '',
            user_agent varchar(255) DEFAULT '',
            access_count int(11) DEFAULT 1,
            last_accessed datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY url (url)
        ) $charset_collate;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta( $sql_redirects );
        dbDelta( $sql_404 );
    }

    public function init_seo_rules() {
        // Tạo đường dẫn /sitemap.xml ảo động
        add_rewrite_rule( 'sitemap\.xml$', 'index.php?dawp_sitemap=1', 'top' );
        add_rewrite_rule( 'sitemap-stylesheet\.xsl$', 'index.php?dawp_sitemap_xsl=1', 'top' );
        // Tạo đường dẫn xác thực key IndexNow ảo dạng {32_hex_chars}.txt
        add_rewrite_rule( '([a-f0-9]{32})\.txt$', 'index.php?dawp_indexnow_verify=$1', 'top' );
    }

    public function register_query_vars( $vars ) {
        $vars[] = 'dawp_sitemap';
        $vars[] = 'dawp_sitemap_xsl';
        $vars[] = 'dawp_indexnow_verify';
        return $vars;
    }

    /**
     * Tự động đăng ký cột SEO cho mọi post type công khai (post, page, product, room, tour...)
     */
    public function register_seo_columns() {
        $post_types = get_post_types( [ 'public' => true ], 'names' );
        
        // Loại bỏ attachment vì đã được xử lý riêng bằng handle_media_columns
        if ( isset( $post_types['attachment'] ) ) {
            unset( $post_types['attachment'] );
        }
        
        foreach ( $post_types as $post_type ) {
            add_filter( "manage_edit-{$post_type}_columns", [ $this, 'add_seo_column_header' ] );
            
            // Đăng ký cột Lượt xem có thể sắp xếp
            add_filter( "manage_edit-{$post_type}_sortable_columns", [ $this, 'register_sortable_views_column' ] );
            
            add_action( "manage_{$post_type}_posts_custom_column", [ $this, 'render_seo_column_content' ], 10, 2 );

            // Link đếm trạng thái điểm SEO ở đầu danh sách (Tốt / Cần cải thiện / Kém)
            add_filter( "views_edit-{$post_type}", [ $this, 'add_score_status_links' ] );
        }
    }

    /**
     * Đăng ký cột Lượt xem là cột có thể sắp xếp (sortable)
     */
    public function register_sortable_views_column( $columns ) {
        $columns['dawp_post_views'] = 'dawp_post_views';
        return $columns;
    }

    /**
     * Xử lý truy vấn sắp xếp theo số lượt xem thực tế
     */
    public function sort_views_column_query( $vars ) {
        if ( isset( $vars['orderby'] ) && 'dawp_post_views' === $vars['orderby'] ) {
            $vars = array_merge( $vars, [
                'meta_key' => '_dawp_post_views',
                'orderby'  => 'meta_value_num'
            ] );
        }
        return $vars;
    }

    /**
     * Điều tuyến requests: Chạy Redirect 301, Ghi nhận 404 logs và Xuất Sitemap XML
     */
    public function handle_seo_requests() {
        global $wpdb;

        // 1. Thực thi Chuyển hướng Redirect 301
        if ( ! is_admin() ) {
            $options = get_option( 'dawp_settings', [] );
            if ( ! empty( $options['sec_demo_mode'] ) ) {
                header( 'X-Robots-Tag: noindex, nofollow, noarchive, nosnippet' );
            }

            $request_uri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
            // Tách query string nếu có
            $clean_uri = strtok($request_uri, '?');
            
            $table_redirects = $wpdb->prefix . 'dawp_redirects';
            // Thử tìm theo URI thô trước, sau đó tìm theo URI kèm query
            $target_redirect = $wpdb->get_var($wpdb->prepare("SELECT new_url FROM $table_redirects WHERE old_url = %s OR old_url = %s LIMIT 1", $clean_uri, $request_uri));
            
            if ( $target_redirect ) {
                // Nếu target redirect bắt đầu bằng / thì tạo link đầy đủ
                if ( strpos($target_redirect, '/') === 0 ) {
                    $target_redirect = home_url( $target_redirect );
                }
                wp_redirect( esc_url_raw($target_redirect), 301 );
                exit;
            }
        }

        // 2. Phục vụ key xác thực IndexNow ảo
        $verify_key = get_query_var( 'dawp_indexnow_verify' );
        if ( ! empty( $verify_key ) ) {
            $stored_key = get_option( 'dawp_indexnow_key' );
            if ( $verify_key === $stored_key ) {
                if ( ob_get_length() ) ob_clean();
                status_header( 200 );
                header( 'Content-Type: text/plain; charset=utf-8' );
                echo esc_html( $verify_key );
                exit;
            }
        }

        // 3. Xuất XSL Stylesheet làm đẹp Sitemap
        if ( get_query_var( 'dawp_sitemap_xsl' ) ) {
            $options = get_option( 'dawp_settings', [] );
            if ( ! empty( $options['sec_demo_mode'] ) ) {
                status_header( 404 );
                nocache_headers();
                include( get_query_template( '404' ) );
                exit;
            }
            $this->output_sitemap_xsl();
            exit;
        }

        // 4. Xuất Sơ đồ trang web Sitemap XML
        if ( get_query_var( 'dawp_sitemap' ) ) {
            $options = get_option( 'dawp_settings', [] );
            if ( ! empty( $options['sec_demo_mode'] ) ) {
                status_header( 404 );
                nocache_headers();
                include( get_query_template( '404' ) );
                exit;
            }
            $this->generate_xml_sitemap();
            exit;
        }

        // 5. Theo dõi và Ghi nhận lỗi 404 (404 Monitor)
        if ( is_404() && ! is_admin() ) {
            $table_404 = $wpdb->prefix . 'dawp_404_logs';
            $bad_url = isset($_SERVER['REQUEST_URI']) ? esc_url_raw($_SERVER['REQUEST_URI']) : '';
            // Bỏ qua các file static rác hay gặp lỗi
            if ( ! empty($bad_url) && ! preg_match('/\.(js|css|png|jpe?g|gif|ico|woff2?|map)$/i', $bad_url) ) {
                $ip = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field($_SERVER['REMOTE_ADDR']) : '';
                $ua = isset($_SERVER['HTTP_USER_AGENT']) ? sanitize_text_field($_SERVER['HTTP_USER_AGENT']) : '';
                
                $existing_id = $wpdb->get_var($wpdb->prepare("SELECT id FROM $table_404 WHERE url = %s LIMIT 1", $bad_url));
                if ( $existing_id ) {
                    $wpdb->query($wpdb->prepare("UPDATE $table_404 SET access_count = access_count + 1, last_accessed = %s, ip_address = %s, user_agent = %s WHERE id = %d", current_time('mysql'), $ip, $ua, $existing_id));
                } else {
                    $wpdb->insert(
                        $table_404,
                        [
                            'url' => $bad_url,
                            'ip_address' => $ip,
                            'user_agent' => $ua,
                            'access_count' => 1,
                            'last_accessed' => current_time('mysql')
                        ],
                        [ '%s', '%s', '%s', '%d', '%s' ]
                    );
                }
            }

            // Tự động chuyển hướng lỗi 404 về trang chủ hoặc bài viết tương tự bằng Levenshtein (Có tối ưu hóa CPU)
            $options = get_option( 'dawp_settings', [] );
            if ( ! empty( $options['seo_404_redirect'] ) ) {
                $requested_uri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';

                // [TỐI ƯU TỐC ĐỘ] Cache đích chuyển hướng theo URL: chỉ dò bài giống 1 lần,
                // các lần 404 sau (kể cả bot spam) sẽ redirect tức thì, không load lâu.
                $dawp_404_cache_key = 'dawp_404rt_' . md5( $requested_uri );
                $dawp_404_cached    = get_transient( $dawp_404_cache_key );
                if ( false !== $dawp_404_cached && ! empty( $dawp_404_cached ) ) {
                    wp_safe_redirect( $dawp_404_cached, 301 );
                    exit;
                }

                $requested_slug = trim(parse_url($requested_uri, PHP_URL_PATH), '/');
                
                if ( ! empty($requested_slug) ) {
                    // Cắt lấy phần slug cuối
                    $slug_parts = explode('/', $requested_slug);
                    $target_slug = end($slug_parts);
                    
                    if ( ! empty($target_slug) && strlen($target_slug) <= 255 ) {
                        global $wpdb;
                        $threshold = 4; // Cho phép sai khác tối đa 4 ký tự gõ nhầm
                        
                        // [TỐI ƯU HÓA CPU] Giới hạn câu lệnh SQL chỉ tải các slug có độ dài chênh lệch không quá 4 ký tự.
                        // Một từ chỉ có thể có khoảng cách Levenshtein <= 4 nếu chênh lệch độ dài của nó <= 4.
                        // Điều này giúp loại bỏ hơn 90% số lượng bài viết không liên quan, giảm tải RAM và CPU cực hạn.
                        $slug_len = mb_strlen( $target_slug );
                        $min_len = max( 1, $slug_len - $threshold );
                        $max_len = $slug_len + $threshold;
                        
                        $allowed_types = get_post_types( [ 'public' => true ], 'names' );
                        if ( isset( $allowed_types['attachment'] ) ) {
                            unset( $allowed_types['attachment'] );
                        }
                        $post_types_in = "'" . implode("', '", array_map('esc_sql', $allowed_types)) . "'";

                        $posts = $wpdb->get_results(
                            $wpdb->prepare(
                                "SELECT ID, post_name FROM {$wpdb->posts}
                                 WHERE post_status = 'publish'
                                   AND post_type IN ($post_types_in)
                                   AND post_name != ''
                                   AND CHAR_LENGTH(post_name) BETWEEN %d AND %d
                                 LIMIT 500",
                                $min_len,
                                $max_len
                            ),
                            ARRAY_A
                        );
                        
                        $best_match = null;
                        $min_distance = 999;
                        
                        if ( ! empty( $posts ) ) {
                            foreach ( $posts as $p ) {
                                if ( strlen($p['post_name']) > 255 ) {
                                    continue;
                                }
                                $distance = levenshtein($target_slug, $p['post_name']);
                                if ( $distance >= 0 && $distance < $min_distance ) {
                                    $min_distance = $distance;
                                    $best_match = $p;
                                }
                            }
                        }
                        
                        // Nếu trùng khớp cao, chuyển hướng 301 về link bài viết đó
                        if ( $best_match && $min_distance <= $threshold ) {
                            $dawp_404_target = get_permalink($best_match['ID']);
                            set_transient( $dawp_404_cache_key, $dawp_404_target, 12 * HOUR_IN_SECONDS );
                            wp_safe_redirect( $dawp_404_target, 301 );
                            exit;
                        }
                    }
                }

                // Không tìm thấy slug tương tự → về trang chủ (và lưu cache để lần sau tức thì)
                set_transient( $dawp_404_cache_key, home_url(), 12 * HOUR_IN_SECONDS );
                wp_safe_redirect( home_url(), 301 );
                exit;
            }
        }
    }

    /**
     * Tự động tạo 301 Redirect khi slug của bài viết/trang/sản phẩm bị thay đổi
     */
    public function auto_create_301_on_slug_change( $post_ID, $post_after, $post_before ) {
        // Chỉ làm việc với các post types được xuất bản công khai
        $allowed_types = get_post_types( [ 'public' => true ], 'names' );
        if ( isset( $allowed_types['attachment'] ) ) {
            unset( $allowed_types['attachment'] );
        }
        if ( ! in_array( $post_after->post_type, $allowed_types ) ) return;
        if ( $post_after->post_status !== 'publish' || $post_before->post_status !== 'publish' ) return;

        // Nếu slug thực sự đổi
        if ( $post_before->post_name !== $post_after->post_name ) {
            $old_link = wp_parse_url( get_permalink( $post_before->ID ), PHP_URL_PATH );
            $new_link = wp_parse_url( get_permalink( $post_after->ID ), PHP_URL_PATH );

            if ( ! empty($old_link) && ! empty($new_link) && $old_link !== $new_link ) {
                global $wpdb;
                $table_name = $wpdb->prefix . 'dawp_redirects';

                // Xóa cấu hình chuyển hướng cũ liên quan đến link đích để tránh lỗi vòng lặp chuyển hướng
                $wpdb->delete( $table_name, [ 'old_url' => $new_link ] );

                // Kiểm tra xem đã tồn tại chuyển hướng từ link cũ này chưa, nếu có thì update
                $exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM $table_name WHERE old_url = %s LIMIT 1", $old_link));
                if ( $exists ) {
                    $wpdb->update($table_name, [ 'new_url' => $new_link ], [ 'id' => $exists ] );
                } else {
                    $wpdb->insert($table_name, [ 'old_url' => $old_link, 'new_url' => $new_link, 'type' => '301' ] );
                }
            }
        }
    }

    /**
     * Tích hợp gửi API IndexNow tự động khi đăng bài viết/sản phẩm mới
     */
    public function ping_indexnow_on_publish( $new_status, $old_status, $post ) {
        $options = get_option( 'dawp_settings', [] );
        if ( ! empty( $options['sec_demo_mode'] ) ) return;

        $allowed_types = get_post_types( [ 'public' => true ], 'names' );
        if ( isset( $allowed_types['attachment'] ) ) {
            unset( $allowed_types['attachment'] );
        }
        if ( ! in_array( $post->post_type, $allowed_types ) ) return;

        // Chỉ trigger khi bài viết chuyển trạng thái sang công khai (Mới đăng hoặc Cập nhật)
        if ( $new_status === 'publish' ) {
            $permalink = get_permalink( $post->ID );
            $host = wp_parse_url( $permalink, PHP_URL_HOST );
            
            // Lấy key IndexNow ngẫu nhiên cho site (Tự sinh nếu chưa có)
            $key = get_option( 'dawp_indexnow_key' );
            if ( empty($key) ) {
                $key = md5( home_url() . time() . 'dawp_indexnow' );
                update_option( 'dawp_indexnow_key', $key );
            }

            // Gửi request tới Bing/IndexNow API bất đồng bộ
            $api_url = 'https://api.indexnow.org/IndexNow';
            wp_remote_post( $api_url, [
                'headers'     => [ 'Content-Type' => 'application/json; charset=utf-8' ],
                'blocking'    => false, // Chạy ngầm để không làm nghẽn quá trình lưu bài của admin
                'sslverify'   => false,
                'body'        => wp_json_encode([
                    'host'        => $host,
                    'key'         => $key,
                    'keyLocation' => home_url( $key . '.txt' ), // Vị trí xác thực key ảo
                    'urlList'     => [ $permalink ]
                ])
            ]);
        }
    }

    /**
     * Ghi đè tiêu đề SEO Title ở đầu trang
     */
    public function filter_seo_title( $title_parts ) {
        if ( is_singular() ) {
            $custom_title = get_post_meta( get_the_ID(), '_dawp_seo_title', true );
            if ( ! empty( $custom_title ) ) {
                $title_parts['title'] = $custom_title;
            }
        } elseif ( is_category() || is_tag() || is_tax() ) {
            $term_id = get_queried_object_id();
            $custom_title = get_term_meta( $term_id, '_dawp_seo_title', true );
            if ( ! empty( $custom_title ) ) {
                $title_parts['title'] = $custom_title;
            }
        }
        return $title_parts;
    }

    /**
     * Đọc và ghi đè nội dung robots.txt từ cấu hình của admin
     */
    public function filter_robots_txt( $output ) {
        $options = get_option( 'dawp_settings', [] );
        if ( ! empty( $options['sec_demo_mode'] ) ) {
            return "User-agent: *\nDisallow: /";
        }
        if ( ! empty( $options['seo_robots_txt'] ) ) {
            return trim( $options['seo_robots_txt'] ) . "\nSitemap: " . home_url('/sitemap.xml');
        }
        return $output;
    }

    /**
     * Tự động xuất các thẻ Meta, Open Graph, Twitter Cards, Canonical và Schema JSON-LD vào wp_head
     */
    public function output_seo_meta_tags() {
        if ( is_admin() ) return;

        $seo_desc = '';
        $seo_robots = 'index, follow';
        $canonical_url = '';
        
        $og_title = '';
        $og_desc = '';
        $og_image = '';
        $og_type = 'website';
        
        $options = get_option( 'dawp_settings', [] );

        // 1. Phân tích Dữ liệu tùy biến SEO cho bài viết/trang/sản phẩm chi tiết
        if ( is_singular() ) {
            $post_id = get_the_ID();
            $seo_desc = get_post_meta( $post_id, '_dawp_seo_desc', true );
            $meta_robots_noindex = get_post_meta( $post_id, '_dawp_seo_noindex', true );
            $meta_robots_nofollow = get_post_meta( $post_id, '_dawp_seo_nofollow', true );
            
            $robots_index = ( ! empty($meta_robots_noindex) ) ? 'noindex' : 'index';
            $robots_follow = ( ! empty($meta_robots_nofollow) ) ? 'nofollow' : 'follow';
            $seo_robots = $robots_index . ', ' . $robots_follow;

            $custom_canonical = get_post_meta( $post_id, '_dawp_seo_canonical', true );
            $canonical_url = ! empty($custom_canonical) ? $custom_canonical : get_permalink( $post_id );

            // Meta Social
            $og_title = get_post_meta( $post_id, '_dawp_seo_og_title', true );
            $og_desc = get_post_meta( $post_id, '_dawp_seo_og_desc', true );
            $og_image = get_post_meta( $post_id, '_dawp_seo_og_image', true );
            $og_type = is_single() ? 'article' : 'website';

            // Fallback nếu description trống (Tự động bóc tách shortcode tránh hiển thị rác ngoài Zalo/FB)
            if ( empty($seo_desc) ) {
                $raw_content = get_post_field('post_content', $post_id);
                // Dọn dẹp cả shortcode đã đăng ký và các dấu ngoặc vuông thô còn sót lại
                $clean_content = strip_shortcodes( $raw_content );
                $clean_content = preg_replace( '/\[[^\]]+\]/', '', $clean_content );
                $seo_desc = wp_strip_all_tags( wp_trim_words( $clean_content, 30 ) );
            }

            // Fallback nếu rỗng
            if ( empty($og_title) ) {
                $custom_title = get_post_meta( $post_id, '_dawp_seo_title', true );
                $og_title = ! empty($custom_title) ? $custom_title : get_the_title( $post_id );
            }
            if ( empty($og_desc) ) {
                $og_desc = $seo_desc;
            }
            if ( empty($og_image) && has_post_thumbnail( $post_id ) ) {
                $og_image = wp_get_attachment_image_url( get_post_thumbnail_id( $post_id ), 'full' );
            }
        } 
        // 2. Tùy biến cho trang lưu trữ (Chuyên mục / Thẻ)
        elseif ( is_category() || is_tag() || is_tax() ) {
            $term_id = get_queried_object_id();
            $seo_desc = get_term_meta( $term_id, '_dawp_seo_desc', true );
            $meta_robots_noindex = get_term_meta( $term_id, '_dawp_seo_noindex', true );
            $meta_robots_nofollow = get_term_meta( $term_id, '_dawp_seo_nofollow', true );
            
            $robots_index = ( ! empty($meta_robots_noindex) ) ? 'noindex' : 'index';
            $robots_follow = ( ! empty($meta_robots_nofollow) ) ? 'nofollow' : 'follow';
            $seo_robots = $robots_index . ', ' . $robots_follow;

            $canonical_url = get_term_link( $term_id );
            
            $og_title = get_term_meta( $term_id, '_dawp_seo_title', true );
            if ( empty($og_title) ) $og_title = single_term_title('', false);
            $og_desc = ! empty($seo_desc) ? $seo_desc : term_description($term_id);
            $og_image = '';
        } 
        // 3. Mặc định trang chủ
        elseif ( is_home() || is_front_page() ) {
            $seo_desc = isset($options['seo_home_desc']) ? $options['seo_home_desc'] : get_bloginfo('description');
            $canonical_url = home_url('/');
            $og_title = get_bloginfo('name');
            $og_desc = $seo_desc;
        }

        // Fallback ảnh Social mặc định
        if ( empty($og_image) && ! empty($options['seo_default_og_image']) ) {
            $og_image = $options['seo_default_og_image'];
        }

        if ( ! empty( $options['sec_demo_mode'] ) ) {
            $seo_robots = 'noindex, nofollow, noarchive, nosnippet';
        }

        // In các thẻ Meta tiêu chuẩn
        if ( ! empty( $seo_desc ) ) {
            echo '<meta name="description" content="' . esc_attr( wp_strip_all_tags( $seo_desc ) ) . '" />' . "\n";
        }
        echo '<meta name="robots" content="' . esc_attr( $seo_robots ) . '" />' . "\n";
        if ( ! empty( $canonical_url ) ) {
            echo '<link rel="canonical" href="' . esc_url( $canonical_url ) . '" />' . "\n";
        }

        // In các thẻ OpenGraph / Facebook / Zalo
        echo '<meta property="og:type" content="' . esc_attr( $og_type ) . '" />' . "\n";
        echo '<meta property="og:title" content="' . esc_attr( $og_title ) . '" />' . "\n";
        echo '<meta property="og:description" content="' . esc_attr( wp_strip_all_tags( $og_desc ) ) . '" />' . "\n";
        echo '<meta property="og:url" content="' . esc_url( $canonical_url ) . '" />' . "\n";
        echo '<meta property="og:site_name" content="' . esc_attr( get_bloginfo('name') ) . '" />' . "\n";
        if ( ! empty( $og_image ) ) {
            echo '<meta property="og:image" content="' . esc_url( $og_image ) . '" />' . "\n";
        }

        // In thẻ Twitter Card
        echo '<meta name="twitter:card" content="summary_large_image" />' . "\n";
        echo '<meta name="twitter:title" content="' . esc_attr( $og_title ) . '" />' . "\n";
        echo '<meta name="twitter:description" content="' . esc_attr( wp_strip_all_tags( $og_desc ) ) . '" />' . "\n";
        if ( ! empty( $og_image ) ) {
            echo '<meta name="twitter:image" content="' . esc_url( $og_image ) . '" />' . "\n";
        }

        // 4. In mã dữ liệu cấu trúc Schema JSON-LD
        $this->output_schema_json_ld();

        // 5. In mã tối ưu hóa dựng hình máy khách (Content Visibility)
        echo '<style id="dawp-client-render-opt">#footer, .site-footer, #colophon, #comments, #respond { content-visibility: auto; contain-intrinsic-size: auto 500px; }</style>' . "\n";
    }

    /**
     * Tự động xuất mã Schema JSON-LD (Breadcrumbs, Article, Product, LocalBusiness, FAQPage)
     */
    private function output_schema_json_ld() {
        $schemas = [];
        $options = get_option( 'dawp_settings', [] );

        // 1. Schema LocalBusiness (Chạy toàn cục nếu được cấu hình trong plugin)
        if ( ! empty($options['seo_local_name']) ) {
            $schemas[] = [
                '@context' => 'https://schema.org',
                '@type'    => 'LocalBusiness',
                'name'     => sanitize_text_field( $options['seo_local_name'] ),
                'image'    => esc_url( isset($options['seo_local_logo']) ? $options['seo_local_logo'] : '' ),
                'telephone'=> sanitize_text_field( isset($options['seo_local_phone']) ? $options['seo_local_phone'] : '' ),
                'address'  => array_filter( [
                    '@type'          => 'PostalAddress',
                    'streetAddress' => sanitize_text_field( isset($options['seo_local_address']) ? $options['seo_local_address'] : '' ),
                    // Không đóng cứng địa danh — plugin dùng cho khách ở mọi tỉnh thành
                    'addressLocality'=> sanitize_text_field( isset($options['seo_local_city']) ? $options['seo_local_city'] : '' ),
                    'addressCountry' => sanitize_text_field( ! empty($options['seo_local_country']) ? $options['seo_local_country'] : 'VN' )
                ] ),
                'url'      => home_url('/')
            ];
        }

        // 2. Schema Breadcrumbs (Chỉ in trên các trang con)
        if ( ! is_home() && ! is_front_page() ) {
            $crumbs = $this->get_breadcrumbs_hierarchy();
            if ( ! empty($crumbs) ) {
                $item_list = [];
                $pos = 1;
                foreach ( $crumbs as $crumb ) {
                    $item_list[] = [
                        '@type'    => 'ListItem',
                        'position' => $pos,
                        'name'     => esc_html( $crumb['title'] ),
                        'item'     => esc_url( $crumb['url'] )
                    ];
                    $pos++;
                }
                $schemas[] = [
                    '@context'        => 'https://schema.org',
                    '@type'           => 'BreadcrumbList',
                    'itemListElement' => $item_list
                ];
            }
        }

        // 3. Schema Article (Bài viết chi tiết)
        if ( is_single() && 'post' === get_post_type() ) {
            $post_id = get_the_ID();
            $schemas[] = [
                '@context'      => 'https://schema.org',
                '@type'         => 'Article',
                'headline'      => get_the_title( $post_id ),
                'datePublished' => get_the_date( 'c', $post_id ),
                'dateModified'  => get_the_modified_date( 'c', $post_id ),
                'author'        => [
                    '@type' => 'Person',
                    'name'  => get_the_author_meta( 'display_name', get_post_field( 'post_author', $post_id ) )
                ],
                'publisher'     => [
                    '@type' => 'Organization',
                    'name'  => get_bloginfo('name'),
                    'logo'  => [
                        '@type' => 'ImageObject',
                        'url'   => esc_url( isset($options['seo_local_logo']) ? $options['seo_local_logo'] : '' )
                    ]
                ],
                'image'         => has_post_thumbnail($post_id) ? wp_get_attachment_image_url(get_post_thumbnail_id($post_id), 'full') : ''
            ];
        }

        // 4. Schema Product (Tích hợp thông tin WooCommerce)
        if ( is_single() && 'product' === get_post_type() && function_exists('wc_get_product') ) {
            $product = wc_get_product( get_the_ID() );
            if ( $product ) {
                // Lấy thông tin Thương hiệu (Brand)
                $brand_name = '';
                $brand_taxonomies = ['product_brand', 'brand', 'yith_product_brand', 'pwb-brand'];
                foreach ( $brand_taxonomies as $taxonomy ) {
                    if ( taxonomy_exists( $taxonomy ) ) {
                        $terms = get_the_terms( $product->get_id(), $taxonomy );
                        if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
                            $brand_name = $terms[0]->name;
                            break;
                        }
                    }
                }
                if ( empty( $brand_name ) ) {
                    $brand_name = ! empty( $options['seo_product_brand'] ) ? sanitize_text_field( $options['seo_product_brand'] ) : '';
                }
                if ( empty( $brand_name ) ) {
                    $brand_name = ! empty( $options['seo_local_name'] ) ? sanitize_text_field( $options['seo_local_name'] ) : '';
                }
                if ( empty( $brand_name ) ) {
                    $brand_name = get_bloginfo( 'name' );
                }

                // Lấy thông tin GTIN / MPN
                $gtin = '';
                $gtin_keys = ['_gtin', '_barcode', '_wccg_gtin', '_mpn', '_isbn', 'gtin', 'barcode'];
                foreach ( $gtin_keys as $key ) {
                    $val = get_post_meta( $product->get_id(), $key, true );
                    if ( ! empty( $val ) ) {
                        $gtin = sanitize_text_field( $val );
                        break;
                    }
                }

                $sku = $product->get_sku();
                $mpn = $sku ? $sku : (string) $product->get_id();

                // Build Offers
                $price = $product->get_price();
                $price_currency = get_woocommerce_currency();
                
                // Cấu hình Vận chuyển (Shipping Details)
                $shipping_cost = isset( $options['seo_product_shipping_cost'] ) ? floatval( $options['seo_product_shipping_cost'] ) : 0.0;
                $shipping_country = ! empty( $options['seo_product_shipping_country'] ) ? sanitize_text_field( $options['seo_product_shipping_country'] ) : 'VN';
                $shipping_handling_min = isset( $options['seo_product_shipping_handling_min'] ) ? intval( $options['seo_product_shipping_handling_min'] ) : 0;
                $shipping_handling_max = isset( $options['seo_product_shipping_handling_max'] ) ? intval( $options['seo_product_shipping_handling_max'] ) : 1;
                $shipping_transit_min = isset( $options['seo_product_shipping_transit_min'] ) ? intval( $options['seo_product_shipping_transit_min'] ) : 1;
                $shipping_transit_max = isset( $options['seo_product_shipping_transit_max'] ) ? intval( $options['seo_product_shipping_transit_max'] ) : 3;

                // Cấu hình Đổi trả (Merchant Return Policy)
                $return_category = ! empty( $options['seo_product_return_category'] ) ? sanitize_text_field( $options['seo_product_return_category'] ) : 'https://schema.org/MerchantReturnFiniteReturnWindow';
                $return_days = isset( $options['seo_product_return_days'] ) ? intval( $options['seo_product_return_days'] ) : 30;
                $return_fees = ! empty( $options['seo_product_return_fees'] ) ? sanitize_text_field( $options['seo_product_return_fees'] ) : 'https://schema.org/FreeReturn';

                $offers = [
                    '@type'         => 'Offer',
                    'price'         => $price ? $price : '0',
                    'priceCurrency' => $price_currency,
                    'availability'  => $product->is_in_stock() ? 'https://schema.org/InStock' : 'https://schema.org/OutOfStock',
                    'url'           => get_permalink( $product->get_id() ),
                    'priceValidUntil'=> date( 'Y-12-31', strtotime( '+1 year' ) ),
                    'shippingDetails' => [
                        '@type' => 'OfferShippingDetails',
                        'shippingRate' => [
                            '@type' => 'MonetaryAmount',
                            'value' => $shipping_cost,
                            'currency' => $price_currency
                        ],
                        'shippingDestination' => [
                            '@type' => 'DefinedRegion',
                            'addressCountry' => $shipping_country
                        ],
                        'deliveryTime' => [
                            '@type' => 'ShippingDeliveryTime',
                            'handlingTime' => [
                                '@type' => 'QuantitativeValue',
                                'minValue' => $shipping_handling_min,
                                'maxValue' => $shipping_handling_max,
                                'unitCode' => 'DAY'
                            ],
                            'transitTime' => [
                                '@type' => 'QuantitativeValue',
                                'minValue' => $shipping_transit_min,
                                'maxValue' => $shipping_transit_max,
                                'unitCode' => 'DAY'
                            ]
                        ]
                    ],
                    'hasMerchantReturnPolicy' => [
                        '@type' => 'MerchantReturnPolicy',
                        'applicableCountry' => $shipping_country,
                        'returnPolicyCategory' => $return_category,
                        'returnMethod' => 'https://schema.org/ReturnByMail',
                        'returnFees' => $return_fees
                    ]
                ];

                if ( $return_category !== 'https://schema.org/MerchantReturnNotPermitted' ) {
                    $offers['hasMerchantReturnPolicy']['merchantReturnDays'] = $return_days;
                }

                // Lấy đánh giá và xếp hạng (aggregateRating và review)
                $review_count = $product->get_review_count();
                $average_rating = $product->get_average_rating();
                
                $aggregate_rating_schema = [];
                if ( $review_count > 0 && $average_rating > 0 ) {
                    $aggregate_rating_schema = [
                        '@type'       => 'AggregateRating',
                        'ratingValue' => $average_rating,
                        'reviewCount' => $review_count,
                        'bestRating'  => '5',
                        'worstRating' => '1'
                    ];
                }

                $reviews_schema = [];
                if ( $review_count > 0 ) {
                    $reviews = get_comments( [
                        'post_id' => $product->get_id(),
                        'status'  => 'approve',
                        'type'    => 'review',
                        'number'  => 5
                    ] );
                    if ( ! empty( $reviews ) ) {
                        foreach ( $reviews as $rev ) {
                            $rating = get_comment_meta( $rev->comment_ID, 'rating', true );
                            $reviews_schema[] = [
                                '@type' => 'Review',
                                'author' => [
                                    '@type' => 'Person',
                                    'name'  => $rev->comment_author
                                ],
                                'datePublished' => mysql2date( 'c', $rev->comment_date_gmt, false ),
                                'reviewBody' => wp_strip_all_tags( $rev->comment_content ),
                                'reviewRating' => [
                                    '@type' => 'Rating',
                                    'bestRating' => '5',
                                    'ratingValue' => $rating ? $rating : '5',
                                    'worstRating' => '1'
                                ]
                            ];
                        }
                    }
                }

                $product_schema = [
                    '@context'    => 'https://schema.org',
                    '@type'       => 'Product',
                    'name'        => $product->get_name(),
                    'description' => wp_strip_all_tags( $product->get_short_description() ? $product->get_short_description() : $product->get_description() ),
                    'image'       => wp_get_attachment_image_url( $product->get_image_id(), 'full' ) ? wp_get_attachment_image_url( $product->get_image_id(), 'full' ) : '',
                    'sku'         => $sku ? $sku : (string) $product->get_id(),
                    'mpn'         => $mpn,
                    'brand'       => [
                        '@type' => 'Brand',
                        'name'  => $brand_name
                    ],
                    'offers'      => $offers
                ];

                if ( ! empty( $aggregate_rating_schema ) ) {
                    $product_schema['aggregateRating'] = $aggregate_rating_schema;
                }
                if ( ! empty( $reviews_schema ) ) {
                    $product_schema['review'] = $reviews_schema;
                }

                if ( ! empty( $gtin ) ) {
                    if ( strlen( $gtin ) === 8 || strlen( $gtin ) === 12 || strlen( $gtin ) === 13 || strlen( $gtin ) === 14 ) {
                        $product_schema['gtin'] = $gtin;
                    } else {
                        $product_schema['gtin13'] = $gtin;
                    }
                }

                $schemas[] = $product_schema;
            }
        }

        // 5. Schema FAQPage (Lấy các câu hỏi thường gặp chèn trong bài viết)
        if ( is_singular() ) {
            $faqs = get_post_meta( get_the_ID(), '_dawp_seo_faqs', true );
            if ( is_array($faqs) && ! empty($faqs) ) {
                $qa_elements = [];
                foreach ( $faqs as $faq ) {
                    if ( ! empty($faq['q']) && ! empty($faq['a']) ) {
                        $qa_elements[] = [
                            '@type'          => 'Question',
                            'name'           => sanitize_text_field( $faq['q'] ),
                            'acceptedAnswer' => [
                                '@type' => 'Answer',
                                'text'  => wp_kses_post( $faq['a'] )
                            ]
                        ];
                    }
                }
                if ( ! empty($qa_elements) ) {
                    $schemas[] = [
                        '@context'   => 'https://schema.org',
                        '@type'      => 'FAQPage',
                        'mainEntity' => $qa_elements
                    ];
                }
            }
        }

        // Xuất tất cả các Schema nén trong thẻ script
        if ( ! empty($schemas) ) {
            foreach ( $schemas as $schema ) {
                echo '<script type="application/ld+json">' . wp_json_encode( $schema, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_PRETTY_PRINT ) . '</script>' . "\n";
            }
        }
    }

    /**
     * Tự động tiêm nội dung FAQ vào cuối bài viết và chèn thẻ Alt mô tả ảnh bị trống
     */
    public function inject_faq_and_auto_alt( $content ) {
        if ( is_admin() || ! in_the_loop() || ! is_main_query() ) {
            return $content;
        }

        // 1. Tự động điền mô tả Alt & Title hình ảnh (Image SEO) và tối ưu hóa giải mã ảnh máy khách
        $options = get_option( 'dawp_settings', [] );
        $auto_alt_active = ! isset($options['seo_auto_alt_active']) || ! empty($options['seo_auto_alt_active']);
        $auto_title_active = ! empty($options['seo_auto_image_title']);
        
        if ( ! empty($content) ) {
            $img_counter = 0;
            // Quét và xử lý các thẻ <img> bị rỗng hoặc thiếu alt/title
            $content = preg_replace_callback('/<img([^>]+)>/i', function($matches) use (&$img_counter, $auto_alt_active, $auto_title_active) {
                $img_attributes = rtrim( $matches[1], '/ ' );
                $post_title = get_the_title();
                
                // Xử lý ALT
                if ( $auto_alt_active ) {
                    if ( stripos($img_attributes, 'alt=') === false || preg_match('/alt=["\']\s*["\']/i', $img_attributes) ) {
                        $img_attributes = preg_replace('/alt=["\']\s*["\']/i', '', $img_attributes);
                        $img_attributes .= ' alt="' . esc_attr($post_title) . '"';
                    }
                }
                
                // Xử lý TITLE
                if ( $auto_title_active ) {
                    if ( stripos($img_attributes, 'title=') === false || preg_match('/title=["\']\s*["\']/i', $img_attributes) ) {
                        $img_counter++;
                        $img_attributes = preg_replace('/title=["\']\s*["\']/i', '', $img_attributes);
                        $img_attributes .= ' title="' . esc_attr($post_title . ' - Ảnh ' . $img_counter) . '"';
                    }
                }

                // Luôn tự động bổ sung giải mã bất đồng bộ decoding="async" giúp cuộn trang mượt mà
                if ( stripos($img_attributes, 'decoding=') === false ) {
                    $img_attributes .= ' decoding="async"';
                }
                
                return '<img ' . $img_attributes . ' />';
            }, $content);
        }

        // 2. Chèn khối FAQ đẹp đẽ vào cuối bài viết
        if ( is_singular() ) {
            $faqs = get_post_meta( get_the_ID(), '_dawp_seo_faqs', true );
            if ( is_array($faqs) && ! empty($faqs) ) {
                $faq_title = '❓ Câu hỏi thường gặp';
                if ( class_exists( 'DAWP_Multilingual' ) ) {
                    $lang = DAWP_Multilingual::get_current_language();
                    $default_lang = DAWP_Multilingual::get_default_language();
                    if ( $lang !== $default_lang ) {
                        $options = get_option( 'dawp_settings', [] );
                        $trans_faq = isset( $options['trans_faq_title_' . $lang] ) ? trim( $options['trans_faq_title_' . $lang] ) : '';
                        if ( ! empty( $trans_faq ) ) {
                            $faq_title = '❓ ' . $trans_faq;
                        } else {
                            $translations_faq = [
                                'en' => 'Frequently Asked Questions',
                                'ja' => 'よくある質問',
                                'zh' => '常见问题',
                                'ko' => '자주 묻는 질문',
                                'fr' => 'Questions fréquemment posées',
                                'de' => 'Häufig gestellte Fragen',
                                'ru' => 'Часто задаваемые вопросы'
                            ];
                            if ( isset( $translations_faq[ $lang ] ) ) {
                                $faq_title = '❓ ' . $translations_faq[ $lang ];
                            }
                        }
                    }
                }

                $faq_html = '<div class="dawp-faq-wrapper" style="margin-top: 30px; border: 1px solid #e2e8f0; border-radius: 12px; padding: 25px; background-color: #f8fafc; font-family: -apple-system, BlinkMacSystemFont, sans-serif;">';
                $faq_html .= '<h3 class="dawp-faq-main-title" style="margin-top: 0; margin-bottom: 20px; font-size: 20px; color: #0f172a; border-bottom: 2px solid #e2e8f0; padding-bottom: 10px; font-weight: 700;">' . esc_html($faq_title) . '</h3>';
                
                foreach ( $faqs as $faq ) {
                    if ( ! empty($faq['q']) && ! empty($faq['a']) ) {
                        $faq_html .= '<div class="dawp-faq-item" style="margin-bottom: 20px; border-bottom: 1px dashed #e2e8f0; padding-bottom: 15px;">';
                        $faq_html .= '<h4 class="dawp-faq-q" style="margin: 0 0 10px 0; font-size: 16px; color: #1e293b; font-weight: 600; display: flex; align-items: flex-start; gap: 8px;">';
                        $faq_html .= '<span style="color: #0068ff; font-weight: bold;">Q:</span> ' . esc_html( $faq['q'] ) . '</h4>';
                        $faq_html .= '<div class="dawp-faq-a" style="margin: 0; color: #475569; font-size: 15px; line-height: 1.6; padding-left: 24px;">' . wpautop(wp_kses_post($faq['a'])) . '</div>';
                        $faq_html .= '</div>';
                    }
                }
                $faq_html .= '</div>';
                $content .= $faq_html;
            }
        }

        return $content;
    }


    /**
     * Tự động thêm rel="nofollow noopener" và target="_blank" cho tất cả link trỏ ra ngoài website
     */
    public function auto_nofollow_external_links( $content ) {
        if ( is_admin() || ! in_the_loop() || ! is_main_query() ) {
            return $content;
        }

        $options = get_option( 'dawp_settings', [] );
        $external_nofollow_active = ! empty( $options['seo_external_nofollow'] );

        if ( ! $external_nofollow_active || empty( $content ) ) {
            return $content;
        }

        // Tìm tất cả thẻ <a> trong nội dung bằng regex
        return preg_replace_callback( '/<a\s+([^>]+)>/i', function( $matches ) {
            $anchor_attributes = $matches[1];

            // Trích xuất href
            if ( ! preg_match( '/(^|\s)href\s*=\s*(["\'])(.*?)\2/i', $anchor_attributes, $href_matches ) ) {
                return $matches[0];
            }

            $url = trim( $href_matches[3] );

            // Bỏ qua nếu là liên kết neo, số điện thoại, email hoặc javascript
            if ( empty( $url ) || $url[0] === '#' || preg_match( '/^(mailto|tel|javascript|sms):/i', $url ) ) {
                return $matches[0];
            }

            // Lấy domain hiện tại của website để đối chiếu
            $home_url = home_url();
            $home_host = wp_parse_url( $home_url, PHP_URL_HOST );
            $link_host = wp_parse_url( $url, PHP_URL_HOST );

            // Bỏ qua nếu là link nội bộ (không có host hoặc trùng host)
            if ( empty( $link_host ) || strcasecmp( $home_host, $link_host ) === 0 ) {
                return $matches[0];
            }

            // Xử lý target="_blank"
            if ( ! preg_match( '/(^|\s)target\s*=\s*(["\'])(.*?)\2/i', $anchor_attributes, $target_matches ) ) {
                $anchor_attributes .= ' target="_blank"';
            } else {
                $anchor_attributes = preg_replace( '/(^|\s)target\s*=\s*(["\'])(.*?)\2/i', '$1target="_blank"', $anchor_attributes );
            }

            // Xử lý rel
            if ( preg_match( '/(^|\s)rel\s*=\s*(["\'])(.*?)\2/i', $anchor_attributes, $rel_matches ) ) {
                $existing_rel = explode( ' ', strtolower( trim( $rel_matches[3] ) ) );
                if ( ! in_array( 'nofollow', $existing_rel ) ) {
                    $existing_rel[] = 'nofollow';
                }
                if ( ! in_array( 'noopener', $existing_rel ) ) {
                    $existing_rel[] = 'noopener';
                }
                $new_rel = implode( ' ', array_unique( array_filter( $existing_rel ) ) );
                $anchor_attributes = preg_replace( '/(^|\s)rel\s*=\s*(["\'])(.*?)\2/i', '$1rel="' . esc_attr( $new_rel ) . '"', $anchor_attributes );
            } else {
                $anchor_attributes .= ' rel="nofollow noopener"';
            }

            return '<a ' . $anchor_attributes . '>';
        }, $content );
    }

    /**
     * Tiêm mã Javascript tải trước liên kết nội bộ (Link Prefetching)
     */
    public function inject_link_prefetch_script() {
        // [TỐI ƯU HÓA QUAN TRỌNG] Tắt prefetch cho Admin và thành viên đã đăng nhập
        // Tránh tình trạng Admin lướt web gửi hàng loạt request prefetch bypass cache thẳng vào PHP gây nghẽn máy chủ
        if ( is_admin() || is_user_logged_in() ) return;

        $options = get_option( 'dawp_settings', [] );
        if ( empty( $options['seo_link_prefetch'] ) ) return;
        ?>
        <script>
        document.addEventListener('DOMContentLoaded', function() {
            var prefetch = function(url) {
                if (document.querySelector('link[href="' + url + '"]')) return;
                var link = document.createElement('link');
                link.rel = 'prefetch';
                link.href = url;
                document.head.appendChild(link);
            };

            var timer;
            document.addEventListener('mouseover', function(e) {
                var anchor = e.target.closest('a');
                if (!anchor) return;
                
                var url = anchor.href;
                if (!url) return;
                
                var origin = window.location.origin;
                // Chỉ tải trước liên kết nội bộ cùng domain, loại bỏ wp-admin, media files, anchors, query strings
                if (!url.startsWith(origin) || url.startsWith(origin + '/wp-admin') || url.indexOf('/wp-content') !== -1 || url.indexOf('#') !== -1 || url.indexOf('?') !== -1) {
                    return;
                }
                
                clearTimeout(timer);
                timer = setTimeout(function() {
                    prefetch(url);
                }, 65); // Di chuột qua link 65ms mới bắt đầu prefetch chạy ngầm
            });

            // Di động: Chỉ tải trước liên kết nếu người dùng chạm đứng yên (tap), hủy bỏ nếu người dùng cuộn/vuốt màn hình (swipe)
            var touchTimer;
            document.addEventListener('touchstart', function(e) {
                var anchor = e.target.closest('a');
                if (!anchor) return;
                
                var url = anchor.href;
                if (!url) return;
                
                var origin = window.location.origin;
                if (!url.startsWith(origin) || url.startsWith(origin + '/wp-admin') || url.indexOf('/wp-content') !== -1 || url.indexOf('#') !== -1 || url.indexOf('?') !== -1) {
                    return;
                }
                
                // Trì hoãn 80ms để kiểm tra xem người dùng có thực hiện cuộn/vuốt màn hình hay không
                touchTimer = setTimeout(function() {
                    prefetch(url);
                    touchTimer = null;
                }, 80);
            }, {passive: true});

            document.addEventListener('touchmove', function() {
                if (touchTimer) {
                    clearTimeout(touchTimer);
                    touchTimer = null;
                }
            }, {passive: true});

            document.addEventListener('touchend', function() {
                if (touchTimer) {
                    clearTimeout(touchTimer);
                    touchTimer = null;
                }
            }, {passive: true});
        });
        </script>
        <?php
    }

    /**
     * Dựng luồng cấu trúc phân cấp Breadcrumbs phục vụ frontend & schema
     */
    private function get_breadcrumbs_hierarchy() {
        $crumbs = [];
        
        // Trang chủ luôn là phần tử gốc
        $home_title = 'Trang chủ';
        $home_link = home_url('/');
        if ( class_exists( 'DAWP_Multilingual' ) ) {
            $lang = DAWP_Multilingual::get_current_language();
            $default_lang = DAWP_Multilingual::get_default_language();
            if ( $lang !== $default_lang ) {
                $home_link = home_url( '/' . $lang . '/' );

                $options = get_option( 'dawp_settings', [] );
                $trans_home = isset( $options['trans_home_' . $lang] ) ? trim( $options['trans_home_' . $lang] ) : '';
                if ( ! empty( $trans_home ) ) {
                    $home_title = $trans_home;
                } else {
                    $translations = [
                        'en' => 'Home',
                        'ja' => 'ホーム',
                        'zh' => '首页',
                        'ko' => '홈',
                        'fr' => 'Accueil',
                        'de' => 'Startseite',
                        'ru' => 'Главная'
                    ];
                    if ( isset( $translations[ $lang ] ) ) {
                        $home_title = $translations[ $lang ];
                    }
                }
            }
        }

        $crumbs[] = [
            'title' => $home_title,
            'url'   => $home_link
        ];

        if ( is_singular() ) {
            $post_id = get_the_ID();
            $post_type = get_post_type( $post_id );
            
            // Xử lý bài viết tin tức
            if ( 'post' === $post_type ) {
                $cats = get_the_category( $post_id );
                if ( ! empty($cats) ) {
                    // Lấy chuyên mục cấp sâu nhất (không có con hoặc nằm cuối)
                    $cat = $cats[0];
                    $crumbs[] = [
                        'title' => $cat->name,
                        'url'   => get_category_link( $cat->term_id )
                    ];
                }
            } 
            // Xử lý trang tĩnh phân cấp cha con
            elseif ( 'page' === $post_type ) {
                $parents = get_post_ancestors( $post_id );
                if ( ! empty($parents) ) {
                    $parents = array_reverse( $parents );
                    foreach ( $parents as $parent_id ) {
                        $crumbs[] = [
                            'title' => get_the_title( $parent_id ),
                            'url'   => get_permalink( $parent_id )
                        ];
                    }
                }
            }
            // Xử lý trang sản phẩm WooCommerce
            elseif ( 'product' === $post_type && function_exists('wc_get_product') ) {
                $terms = get_the_terms( $post_id, 'product_cat' );
                if ( ! empty($terms) && ! is_wp_error($terms) ) {
                    $term = $terms[0];
                    $crumbs[] = [
                        'title' => $term->name,
                        'url'   => get_term_link( $term )
                    ];
                }
            }

            // Bài viết hiện tại làm lá cuối
            $crumbs[] = [
                'title' => get_the_title( $post_id ),
                'url'   => get_permalink( $post_id )
            ];
        } 
        // Trang chuyên mục lưu trữ
        elseif ( is_category() ) {
            $crumbs[] = [
                'title' => single_cat_title('', false),
                'url'   => get_category_link( get_queried_object_id() )
            ];
        }
        // Trang chuyên mục sản phẩm WooCommerce
        elseif ( is_tax('product_cat') ) {
            $crumbs[] = [
                'title' => single_term_title('', false),
                'url'   => get_term_link( get_queried_object_id() )
            ];
        }

        return $crumbs;
    }

    /**
     * Render HTML breadcrumbs ngoài Frontend
     */
    public function render_breadcrumbs() {
        if ( is_admin() || is_home() || is_front_page() ) return '';
        
        $crumbs = $this->get_breadcrumbs_hierarchy();
        if ( empty($crumbs) ) return '';

        $html = '<div class="dawp-breadcrumbs-nav">';
        $items = [];
        $total = count($crumbs);
        
        foreach ( $crumbs as $idx => $crumb ) {
            if ( $idx === $total - 1 ) {
                $items[] = '<span class="dawp-crumb-current">' . esc_html($crumb['title']) . '</span>';
            } else {
                $items[] = '<a href="' . esc_url($crumb['url']) . '" class="dawp-crumb-link">' . esc_html($crumb['title']) . '</a>';
            }
        }

        $html .= implode( ' <span class="dawp-crumb-sep">/</span> ', $items );
        $html .= '</div>';

        return $html;
    }

    /**
     * Dựng và xuất Sitemap XML động siêu tốc
     */
    private function generate_xml_sitemap() {
        // Tắt bộ đệm và gửi tiêu đề XML
        if ( ob_get_length() ) ob_clean();
        header( 'Content-Type: text/xml; charset=utf-8' );
        
        echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
        echo '<?xml-stylesheet type="text/xsl" href="' . home_url('/sitemap-stylesheet.xsl') . '"?>' . "\n";
        echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";

        // 1. Trang chủ
        echo '  <url>' . "\n";
        echo '    <loc>' . esc_url( home_url('/') ) . '</loc>' . "\n";
        echo '    <changefreq>daily</changefreq>' . "\n";
        echo '    <priority>1.0</priority>' . "\n";
        echo '  </url>' . "\n";

        // 2. Bài viết, Trang và các Custom Post Types công khai
        $post_types = get_post_types( [ 'public' => true ], 'names' );
        if ( isset( $post_types['attachment'] ) ) {
            unset( $post_types['attachment'] );
        }
        global $wpdb;
        foreach ( $post_types as $type ) {
            if ( 'product' === $type && ! class_exists('WooCommerce') ) continue;
            
            // Tối ưu hóa truy vấn SQL trực tiếp để tránh tải post_content nặng nề lên RAM, nâng giới hạn lên 2000 link
            $posts = $wpdb->get_results( $wpdb->prepare(
                "SELECT ID, post_modified_gmt FROM {$wpdb->posts} WHERE post_type = %s AND post_status = 'publish' ORDER BY post_modified DESC LIMIT 2000",
                $type
            ) );

            if ( ! empty( $posts ) ) {
                foreach ( $posts as $p ) {
                    // Kiểm tra xem bài viết có bị noindex hay không
                    $noindex = get_post_meta( $p->ID, '_dawp_seo_noindex', true );
                    if ( $noindex ) continue;

                    echo '  <url>' . "\n";
                    echo '    <loc>' . esc_url( get_permalink($p->ID) ) . '</loc>' . "\n";
                    echo '    <lastmod>' . mysql2date( 'Y-m-d\TH:i:s+00:00', $p->post_modified_gmt, false ) . '</lastmod>' . "\n";
                    echo '    <changefreq>weekly</changefreq>' . "\n";
                    echo '    <priority>' . ('page' === $type ? '0.6' : '0.8') . '</priority>' . "\n";
                    echo '  </url>' . "\n";
                }
            }
        }

        // 3. Danh mục chuyên mục bài viết & sản phẩm
        $taxonomies = ['category', 'product_cat'];
        foreach ( $taxonomies as $tax ) {
            if ( 'product_cat' === $tax && ! class_exists('WooCommerce') ) continue;
            
            $terms = get_terms([
                'taxonomy'   => $tax,
                'hide_empty' => true
            ]);

            if ( ! is_wp_error($terms) && ! empty($terms) ) {
                foreach ( $terms as $term ) {
                    // Bỏ qua nếu có tag noindex
                    $noindex = get_term_meta( $term->term_id, '_dawp_seo_noindex', true );
                    if ( $noindex ) continue;

                    echo '  <url>' . "\n";
                    echo '    <loc>' . esc_url( get_term_link($term) ) . '</loc>' . "\n";
                    echo '    <changefreq>weekly</changefreq>' . "\n";
                    echo '    <priority>0.5</priority>' . "\n";
                    echo '  </url>' . "\n";
                }
            }
        }

        echo '</urlset>' . "\n";
    }

    /**
     * Giao diện XSL Stylesheet để Sitemap XML hiển thị cực kỳ chuyên nghiệp trên trình duyệt
     */
    private function output_sitemap_xsl() {
        if ( ob_get_length() ) ob_clean();
        header( 'Content-Type: text/xsl; charset=utf-8' );
        ?>
        <xsl:stylesheet version="2.0" 
            xmlns:html="http://www.w3.org/TR/REC-html40"
            xmlns:sitemap="http://www.sitemaps.org/schemas/sitemap/0.9"
            xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
            <xsl:output method="html" version="1.0" encoding="UTF-8" indent="yes"/>
            <xsl:template match="/">
                <html xmlns="http://www.w3.org/1999/xhtml">
                    <head>
                        <title>XML Sitemap - Duy Anh Web Pro</title>
                        <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
                        <style type="text/css">
                            body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif; color: #333; margin: 0; padding: 40px; background-color: #f8fafc; }
                            h1 { color: #0f172a; font-size: 24px; font-weight: 700; margin-bottom: 5px; }
                            p { color: #64748b; font-size: 14px; margin-top: 0; margin-bottom: 25px; }
                            table { width: 100%; border-collapse: collapse; background: #fff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 15px rgba(0,0,0,0.03); border: 1px solid #e2e8f0; }
                            th { background: #0068ff; color: #fff; text-align: left; padding: 12px 15px; font-size: 14px; font-weight: 600; }
                            td { padding: 12px 15px; border-bottom: 1px solid #f1f5f9; font-size: 14px; word-break: break-all; }
                            tr:hover td { background-color: #f8fafc; }
                            a { color: #0068ff; text-decoration: none; font-weight: 500; }
                            a:hover { text-decoration: underline; }
                        </style>
                    </head>
                    <body>
                        <h1>XML Sitemap</h1>
                        <p>Sơ đồ trang web này được tạo tự động bởi hệ thống tối ưu hóa SEO Duy Anh Web Pro.</p>
                        <table>
                            <tr>
                                <th>Đường dẫn (URL)</th>
                                <th>Tần suất thay đổi</th>
                                <th>Độ ưu tiên</th>
                                <th>Cập nhật cuối (GMT)</th>
                            </tr>
                            <xsl:for-each select="sitemap:urlset/sitemap:url">
                                <tr>
                                    <td>
                                        <a href="{sitemap:loc}"><xsl:value-of select="sitemap:loc"/></a>
                                    </td>
                                    <td><xsl:value-of select="sitemap:changefreq"/></td>
                                    <td><xsl:value-of select="sitemap:priority"/></td>
                                    <td><xsl:value-of select="sitemap:lastmod"/></td>
                                </tr>
                            </xsl:for-each>
                        </table>
                    </body>
                </html>
            </xsl:template>
        </xsl:stylesheet>
        <?php
    }

    public function add_seo_metabox() {
        $screens = get_post_types( [ 'public' => true ], 'names' );
        if ( isset( $screens['attachment'] ) ) {
            unset( $screens['attachment'] );
        }
        foreach ( $screens as $screen ) {
            add_meta_box(
                'dawp_seo_settings_box',
                'Duy Anh Web Pro - Cấu hình SEO & Snippet',
                [ $this, 'render_seo_metabox' ],
                $screen,
                'normal',
                'high'
            );
        }
    }

    /**
     * Render Giao diện SEO Metabox
     */
    public function render_seo_metabox( $post ) {
        // Nạp các meta đã lưu
        $seo_title = get_post_meta( $post->ID, '_dawp_seo_title', true );
        $seo_desc = get_post_meta( $post->ID, '_dawp_seo_desc', true );
        $seo_keyword = get_post_meta( $post->ID, '_dawp_seo_keyword', true );

        $seo_noindex = get_post_meta( $post->ID, '_dawp_seo_noindex', true );
        $seo_nofollow = get_post_meta( $post->ID, '_dawp_seo_nofollow', true );

        $seo_og_title = get_post_meta( $post->ID, '_dawp_seo_og_title', true );
        $seo_og_desc = get_post_meta( $post->ID, '_dawp_seo_og_desc', true );
        $seo_og_image = get_post_meta( $post->ID, '_dawp_seo_og_image', true );

        wp_nonce_field( 'dawp_save_seo_meta_action', 'dawp_seo_meta_nonce' );
        ?>
        <div class="dawp-seo-metabox-tabs" style="font-family: -apple-system, BlinkMacSystemFont, sans-serif; display: flex; flex-direction: column; margin: -6px -12px;">
            <!-- CSS Styles -->
            <style>
                .dawp-seo-tab-nav { display: flex; background: #f1f5f9; border-bottom: 1px solid #cbd5e1; margin: 0; padding: 0 10px; list-style: none; }
                .dawp-seo-tab-nav li { margin: 0; }
                .dawp-seo-tab-nav a { display: block; padding: 12px 20px; font-weight: 600; color: #64748b; text-decoration: none; border-bottom: 2px solid transparent; cursor: pointer; font-size: 13px; }
                .dawp-seo-tab-nav li.active a { color: #0068ff; border-bottom-color: #0068ff; background: #fff; }
                .dawp-seo-tab-content { padding: 25px; display: none; background: #fff; }
                .dawp-seo-tab-content.active { display: block; }
                .dawp-seo-row { display: flex; flex-direction: column; margin-bottom: 20px; }
                .dawp-seo-row label { font-weight: 600; font-size: 13px; color: #1e293b; margin-bottom: 8px; }
                .dawp-seo-row input[type="text"], .dawp-seo-row textarea { padding: 10px 12px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 14px; width: 100%; box-sizing: border-box; }
                .dawp-seo-row input:focus, .dawp-seo-row textarea:focus { border-color: #0068ff; outline: none; box-shadow: 0 0 0 3px rgba(0, 104, 255, 0.1); }
                .dawp-seo-char-counter { font-size: 12px; color: #64748b; margin-top: 5px; font-style: italic; text-align: right; }
                .dawp-seo-progress-bar { height: 4px; width: 100%; background: #e2e8f0; margin-top: 5px; border-radius: 2px; overflow: hidden; }
                .dawp-seo-progress-fill { height: 100%; width: 0%; transition: width 0.3s, background-color 0.3s; }
                
                /* Giao diện Snippet Preview */
                .dawp-preview-box { border: 1px solid #e2e8f0; border-radius: 8px; padding: 15px; background: #fff; margin-bottom: 20px; max-width: 600px; box-shadow: 0 2px 5px rgba(0,0,0,0.02); }
                .dawp-preview-url { font-size: 12px; color: #202124; margin-bottom: 4px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
                .dawp-preview-title { font-size: 19px; color: #1a0dab; margin-bottom: 4px; font-family: Roboto, sans-serif; cursor: pointer; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
                .dawp-preview-title:hover { text-decoration: underline; }
                .dawp-preview-desc { font-size: 14px; color: #4d5156; line-height: 1.5; font-family: Arial, sans-serif; }

                /* Đồng hồ điểm SEO / Dễ đọc */
                .dawp-score-wrap { display: flex; gap: 14px; margin-bottom: 22px; flex-wrap: wrap; }
                .dawp-score-card { flex: 1; min-width: 200px; display: flex; align-items: center; gap: 14px; border: 1px solid #e2e8f0; border-radius: 12px; padding: 14px 16px; background: #fff; box-shadow: 0 2px 6px rgba(0,0,0,0.03); }
                .dawp-gauge { --v: 0; --c: #94a3b8; width: 78px; height: 78px; border-radius: 50%; flex-shrink: 0; background: conic-gradient(var(--c) calc(var(--v) * 1%), #e5e7eb 0); display: flex; align-items: center; justify-content: center; transition: background 0.4s ease; }
                .dawp-gauge-inner { width: 60px; height: 60px; border-radius: 50%; background: #fff; display: flex; align-items: center; justify-content: center; }
                .dawp-gauge-num { font-size: 22px; font-weight: 800; color: #1e293b; line-height: 1; }
                .dawp-score-meta { display: flex; flex-direction: column; }
                .dawp-score-title { font-size: 13px; font-weight: 700; color: #1e293b; }
                .dawp-score-label { font-size: 12.5px; font-weight: 600; margin-top: 3px; }
                .dawp-score-sub { font-size: 11.5px; color: #94a3b8; margin-top: 2px; }
                .dawp-analysis-heading { font-weight: 700; font-size: 13px; color: #334155; margin: 4px 0 10px; display: flex; align-items: center; gap: 6px; }
                .dawp-check-list { margin: 0; padding: 0; list-style: none; font-size: 13.5px; line-height: 1.7; }
                .dawp-check-list li { display: flex; align-items: flex-start; gap: 8px; margin-bottom: 6px; }
            </style>

            <ul class="dawp-seo-tab-nav">
                <li class="active"><a data-target="dawp-tab-general">🌐 Cấu hình Chung & Snippet</a></li>
                <li><a data-target="dawp-tab-analysis">📊 Từ khóa & Phân tích</a></li>
                <li><a data-target="dawp-tab-social">📱 Mạng xã hội</a></li>
            </ul>

            <!-- TAB 1: Cấu hình chung -->
            <div id="dawp-tab-general" class="dawp-seo-tab-content active">
                <!-- Google Preview -->
                <div class="dawp-seo-row">
                    <label>Bản xem trước trên Google (Snippet Preview):</label>
                    <div class="dawp-preview-box">
                        <div class="dawp-preview-url"><?php echo esc_url(get_permalink($post->ID)); ?></div>
                        <div class="dawp-preview-title" id="dawp-snippet-title"><?php echo esc_html( !empty($seo_title) ? $seo_title : get_the_title($post->ID) ); ?></div>
                        <div class="dawp-preview-desc" id="dawp-snippet-desc"><?php echo esc_html( !empty($seo_desc) ? $seo_desc : 'Nhập mô tả Meta để hiển thị xem trước tại đây...' ); ?></div>
                    </div>
                </div>

                <div class="dawp-seo-row">
                    <label for="dawp_seo_title">Tiêu đề SEO (SEO Title):</label>
                    <input type="text" id="dawp_seo_title" name="dawp_seo_title" value="<?php echo esc_attr( $seo_title ); ?>" placeholder="<?php echo esc_attr(get_the_title($post->ID)); ?>">
                    <div class="dawp-seo-progress-bar"><div class="dawp-seo-progress-fill" id="dawp-title-progress"></div></div>
                    <div class="dawp-seo-char-counter" id="dawp-title-counter">0 / 60 ký tự</div>
                </div>

                <div class="dawp-seo-row">
                    <label for="dawp_seo_desc">Mô tả Meta (Meta Description):</label>
                    <textarea id="dawp_seo_desc" name="dawp_seo_desc" rows="3" placeholder="Nhập mô tả ngắn gọn cho trang để thu hút click tìm kiếm..."><?php echo esc_textarea( $seo_desc ); ?></textarea>
                    <div class="dawp-seo-progress-bar"><div class="dawp-seo-progress-fill" id="dawp-desc-progress"></div></div>
                    <div class="dawp-seo-char-counter" id="dawp-desc-counter">0 / 160 ký tự</div>
                </div>



                <div class="dawp-seo-row" style="gap: 15px; border-top: 1px solid #f1f5f9; padding-top: 15px; margin-top: 10px;">
                    <div style="margin-bottom: 10px;">
                        <label style="margin: 0; display: inline-flex; align-items: center; gap: 6px; font-weight: 600; cursor: pointer; color: #d63638;">
                            <input type="checkbox" name="dawp_seo_noindex" value="1" <?php checked( 1, $seo_noindex ); ?>>
                            Chặn Google Index (noindex)
                        </label>
                        <p class="description" style="margin: 4px 0 0 20px; font-size: 12px; color: #64748b;">
                            ⚠️ <strong>Khuyên dùng: KHÔNG CHỌN</strong>. Chỉ chọn nếu bạn muốn ẩn hoàn toàn **bài viết / trang đơn lẻ này** khỏi kết quả tìm kiếm Google (ví dụ: giỏ hàng, thanh toán, trang chính sách bảo mật).
                        </p>
                    </div>
                    <div>
                        <label style="margin: 0; display: inline-flex; align-items: center; gap: 6px; font-weight: 600; cursor: pointer; color: #e11d48;">
                            <input type="checkbox" name="dawp_seo_nofollow" value="1" <?php checked( 1, $seo_nofollow ); ?>>
                            Ngăn chặn theo dõi Link (nofollow)
                        </label>
                        <p class="description" style="margin: 4px 0 0 20px; font-size: 12px; color: #64748b;">
                            ⚠️ <strong>Khuyên dùng: KHÔNG CHỌN</strong>. Ngăn chặn Google đi theo tất cả các liên kết trong **bài viết / trang đơn lẻ này** (làm giảm hiệu quả của các liên kết nội bộ).
                        </p>
                    </div>
                </div>
            </div>

            <!-- TAB 2: Phân tích từ khóa -->
            <div id="dawp-tab-analysis" class="dawp-seo-tab-content">
                <div class="dawp-seo-row">
                    <label for="dawp_seo_keyword">Từ khóa chính (Focus Keyword):</label>
                    <input type="text" id="dawp_seo_keyword" name="dawp_seo_keyword" value="<?php echo esc_attr( $seo_keyword ); ?>" placeholder="vd: thiết kế web chuẩn SEO">
                </div>

                <!-- Đồng hồ điểm SEO & Dễ đọc -->
                <div class="dawp-score-wrap">
                    <div class="dawp-score-card">
                        <div class="dawp-gauge" id="dawp-seo-gauge"><div class="dawp-gauge-inner"><span class="dawp-gauge-num" id="dawp-seo-score-num">0</span></div></div>
                        <div class="dawp-score-meta">
                            <span class="dawp-score-title">📈 Điểm SEO</span>
                            <span class="dawp-score-label" id="dawp-seo-score-label" style="color:#94a3b8;">Chưa phân tích</span>
                            <span class="dawp-score-sub" id="dawp-seo-score-sub">Nhập từ khóa chính để chấm điểm</span>
                        </div>
                    </div>
                    <div class="dawp-score-card">
                        <div class="dawp-gauge" id="dawp-read-gauge"><div class="dawp-gauge-inner"><span class="dawp-gauge-num" id="dawp-read-score-num">0</span></div></div>
                        <div class="dawp-score-meta">
                            <span class="dawp-score-title">👁️ Điểm Dễ đọc</span>
                            <span class="dawp-score-label" id="dawp-read-score-label" style="color:#94a3b8;">Chưa phân tích</span>
                            <span class="dawp-score-sub" id="dawp-read-score-sub">Đánh giá độ dễ đọc của nội dung</span>
                        </div>
                    </div>
                </div>

                <div class="dawp-seo-row">
                    <div class="dawp-analysis-heading">📊 Phân tích tối ưu SEO</div>
                    <ul id="dawp-seo-analysis-list" class="dawp-check-list">
                        <!-- JS sẽ tự động chèn danh sách check đỏ/xanh tại đây -->
                    </ul>
                </div>

                <div class="dawp-seo-row" style="border-top: 1px solid #f1f5f9; padding-top: 15px;">
                    <div class="dawp-analysis-heading" style="justify-content: space-between;">
                        <span>👁️ Phân tích độ dễ đọc (Readability)</span>
                        <button type="button" id="dawp-auto-format-btn" class="button" style="height:auto; padding:4px 12px; font-weight:600; color:#0068ff; border-color:#0068ff;">✨ Tự động tối ưu trình bày</button>
                    </div>
                    <ul id="dawp-read-analysis-list" class="dawp-check-list">
                        <!-- JS chèn checklist dễ đọc tại đây -->
                    </ul>
                    <p class="description" id="dawp-auto-format-note" style="margin-top:8px; font-size:12px; color:#64748b;">Tự động tách đoạn dài, tách câu quá dài và chèn tiêu đề phụ để tăng điểm dễ đọc. <strong>Nên đọc lại</strong> sau khi tối ưu.</p>
                </div>

                <div class="dawp-seo-row" style="border-top: 1px solid #f1f5f9; padding-top: 15px; margin-top: 15px;">
                    <label>🔗 Đề xuất Liên kết nội bộ (Internal Link Suggestions):</label>
                    <ul id="dawp-seo-link-suggestions" style="margin: 5px 0 0 0; padding: 0; list-style: none; font-size: 13.5px; line-height: 1.8;">
                        <li style="color: #64748b; font-style: italic;">Nhập từ khóa chính để hiển thị gợi ý bài viết liên quan...</li>
                    </ul>
                </div>
            </div>

            <!-- TAB 3: Mạng xã hội -->
            <div id="dawp-tab-social" class="dawp-seo-tab-content">
                <div class="dawp-seo-row">
                    <label for="dawp_seo_og_title">Tiêu đề chia sẻ (Zalo/Facebook Title):</label>
                    <input type="text" id="dawp_seo_og_title" name="dawp_seo_og_title" value="<?php echo esc_attr( $seo_og_title ); ?>" placeholder="Mặc định lấy tiêu đề SEO...">
                </div>

                <div class="dawp-seo-row">
                    <label for="dawp_seo_og_desc">Mô tả chia sẻ (Zalo/Facebook Description):</label>
                    <textarea id="dawp_seo_og_desc" name="dawp_seo_og_desc" rows="3" placeholder="Mặc định lấy mô tả Meta..."><?php echo esc_textarea( $seo_og_desc ); ?></textarea>
                </div>

                <div class="dawp-seo-row">
                    <label for="dawp_seo_og_image">Ảnh đại diện chia sẻ (Zalo/Facebook Share Image):</label>
                    <div style="display: flex; gap: 10px;">
                        <input type="text" id="dawp_seo_og_image" name="dawp_seo_og_image" value="<?php echo esc_attr( $seo_og_image ); ?>" style="flex: 1;" placeholder="https://domain.com/image.png">
                        <button type="button" class="button dawp-seo-upload-btn">Chọn ảnh</button>
                    </div>
                    <p class="description">Định dạng khuyên dùng: 1200x630px JPG hoặc PNG. Để trống sẽ tự động lấy ảnh đại diện bài viết.</p>
                </div>

                <div class="dawp-seo-row" style="border-top: 1px solid #f1f5f9; padding-top: 15px; margin-top: 15px;">
                    <label>🛠️ Công cụ sửa lỗi hiển thị MXH (Share Debugger):</label>
                    <div style="display: flex; gap: 12px; flex-wrap: wrap;">
                        <a href="https://developers.facebook.com/tools/debug/?q=<?php echo urlencode(get_permalink($post->ID)); ?>" target="_blank" class="button" style="display: inline-flex; align-items: center; gap: 6px; border-color: #1877f2; color: #1877f2; text-decoration: none;">
                            🔵 Sửa lỗi hiển thị Facebook
                        </a>
                        <a href="https://developers.zalo.me/tools/debug-sharing?q=<?php echo urlencode(get_permalink($post->ID)); ?>" target="_blank" class="button" style="display: inline-flex; align-items: center; gap: 6px; border-color: #0068ff; color: #0068ff; text-decoration: none;">
                            🔹 Sửa lỗi hiển thị Zalo
                        </a>
                    </div>
                    <p class="description">Click vào các công cụ trên để yêu cầu Facebook/Zalo cập nhật lại ảnh đại diện và tiêu đề mới nhất của bài viết này nếu chia sẻ bị hiển thị thông tin cũ.</p>
                </div>
            </div>

        </div>
        
        <script>
        jQuery(document).ready(function($) {
            // Tự động đồng bộ Real-time từ Cấu hình chung khi gõ
            var originalSeoTitle = $('#dawp_seo_title').val();
            var originalSeoDesc = $('#dawp_seo_desc').val();
            var lastSyncedImage = $('#dawp_seo_og_image').val();

            function syncOnLoad() {
                var ogTitle = $('#dawp_seo_og_title');
                var ogDesc = $('#dawp_seo_og_desc');
                var ogImage = $('#dawp_seo_og_image');
                
                var genTitle = $('#dawp_seo_title').val();
                var genDesc = $('#dawp_seo_desc').val();
                
                var currentPostTitle = $('#title').val() || '';
                if (window.wp && wp.data && wp.data.select) {
                    var editorSelect = wp.data.select('core/editor');
                    if (editorSelect) {
                        var gTitle = editorSelect.getEditedPostAttribute('title');
                        if (gTitle) {
                            currentPostTitle = gTitle;
                        }
                    }
                }

                // Nếu Tiêu đề chia sẻ đang trống hoặc chỉ là tiêu đề bài viết gốc, và có Tiêu đề SEO
                if (genTitle && (ogTitle.val() === '' || ogTitle.val() === currentPostTitle)) {
                    ogTitle.val(genTitle);
                }
                // Nếu Mô tả chia sẻ đang trống, tự động lấy từ Mô tả Meta
                if (genDesc && ogDesc.val() === '') {
                    ogDesc.val(genDesc);
                }
            }

            // Chạy ngay khi tải xong trang để đồng bộ
            syncOnLoad();

            // Chuyển Tab và tự động cập nhật dữ liệu nếu trống
            $('.dawp-seo-tab-nav a').on('click', function(e) {
                e.preventDefault();
                var target = $(this).data('target');
                $('.dawp-seo-tab-nav li').removeClass('active');
                $(this).parent().addClass('active');
                
                $('.dawp-seo-tab-content').removeClass('active');
                $('#' + target).addClass('active');

                // Nếu chuyển sang tab Mạng xã hội, tự động lấy dữ liệu nếu trống
                if (target === 'dawp-tab-social') {
                    var ogTitle = $('#dawp_seo_og_title');
                    var ogDesc = $('#dawp_seo_og_desc');
                    var ogImage = $('#dawp_seo_og_image');

                    var currentPostTitle = $('#title').val() || '';
                    if (window.wp && wp.data && wp.data.select) {
                        var editorSelect = wp.data.select('core/editor');
                        if (editorSelect) {
                            var gTitle = editorSelect.getEditedPostAttribute('title');
                            if (gTitle) {
                                currentPostTitle = gTitle;
                            }
                        }
                    }

                    if (ogTitle.val() === '' || ogTitle.val() === currentPostTitle) {
                        var genTitle = $('#dawp_seo_title').val();
                        ogTitle.val(genTitle ? genTitle : currentPostTitle);
                    }
                    if (ogDesc.val() === '') {
                        ogDesc.val($('#dawp_seo_desc').val() || '');
                    }
                    if (ogImage.val() === '' || ogImage.val() === lastSyncedImage) {
                        // Thử lấy ảnh đại diện từ Classic Editor
                        var classicImg = $('#set-post-thumbnail img').first();
                        if (classicImg.length) {
                            var src = classicImg.attr('src');
                            if (src) {
                                var cleanSrc = src.replace(/-[0-9]+x[0-9]+\.([a-z]+)$/i, '.$1');
                                ogImage.val(cleanSrc);
                                lastSyncedImage = cleanSrc;
                            }
                        } else if (window.wp && wp.data && wp.data.select) {
                            // Thử lấy từ Gutenberg Block Editor
                            var editorSelect = wp.data.select('core/editor');
                            if (editorSelect) {
                                var mediaId = editorSelect.getEditedPostAttribute('featured_media');
                                if (mediaId) {
                                    var mediaSelect = wp.data.select('core');
                                    if (mediaSelect) {
                                        var media = mediaSelect.getMedia(mediaId);
                                        if (media && media.source_url) {
                                            ogImage.val(media.source_url);
                                            lastSyncedImage = media.source_url;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            });

            $('#dawp_seo_title').on('input', function() {
                var currentVal = $(this).val();
                var ogTitleInput = $('#dawp_seo_og_title');
                
                var currentPostTitle = $('#title').val() || '';
                if (window.wp && wp.data && wp.data.select) {
                    var editorSelect = wp.data.select('core/editor');
                    if (editorSelect) {
                        var gTitle = editorSelect.getEditedPostAttribute('title');
                        if (gTitle) {
                            currentPostTitle = gTitle;
                        }
                    }
                }

                if (ogTitleInput.val() === '' || 
                    ogTitleInput.val() === originalSeoTitle || 
                    ogTitleInput.val() === currentPostTitle) {
                    ogTitleInput.val(currentVal);
                }
                originalSeoTitle = currentVal;
            });

            $('#dawp_seo_desc').on('input', function() {
                var currentVal = $(this).val();
                var ogDescInput = $('#dawp_seo_og_desc');
                if (ogDescInput.val() === '' || ogDescInput.val() === originalSeoDesc) {
                    ogDescInput.val(currentVal);
                }
                originalSeoDesc = currentVal;
            });

            // Lắng nghe thay đổi ảnh đại diện trong Gutenberg Block Editor
            if (window.wp && wp.data && wp.data.subscribe) {
                var lastFeaturedMediaId = null;
                wp.data.subscribe(function() {
                    var editorSelect = wp.data.select('core/editor');
                    if (editorSelect) {
                        var mediaId = editorSelect.getEditedPostAttribute('featured_media');
                        if (mediaId && mediaId !== lastFeaturedMediaId) {
                            lastFeaturedMediaId = mediaId;
                            var mediaSelect = wp.data.select('core');
                            if (mediaSelect) {
                                var media = mediaSelect.getMedia(mediaId);
                                if (media && media.source_url) {
                                    var ogImageInput = $('#dawp_seo_og_image');
                                    if (ogImageInput.val() === '' || ogImageInput.val() === lastSyncedImage) {
                                        ogImageInput.val(media.source_url);
                                        lastSyncedImage = media.source_url;
                                    }
                                }
                            }
                        }
                    }
                });
            }

            // Gọi Bộ tải ảnh Media WordPress
            $('.dawp-seo-upload-btn').on('click', function(e) {
                e.preventDefault();
                var $btn = $(this);
                var $input = $btn.prev('input');
                
                var frame = wp.media({
                    title: 'Chọn ảnh đại diện chia sẻ MXH',
                    multiple: false,
                    library: { type: 'image' },
                    button: { text: 'Sử dụng ảnh này' }
                });
                
                frame.on('select', function() {
                    var attachment = frame.state().get('selection').first().toJSON();
                    $input.val(attachment.url);
                });
                
                frame.open();
            });

        });
        </script>
        <?php
    }

    /**
     * Lưu trữ Meta dữ liệu SEO cho bài viết/trang/sản phẩm
     */
    public function save_seo_meta( $post_id ) {
        if ( ! isset( $_POST['dawp_seo_meta_nonce'] ) || ! wp_verify_nonce( $_POST['dawp_seo_meta_nonce'], 'dawp_save_seo_meta_action' ) ) {
            return;
        }

        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
        if ( ! current_user_can( 'edit_post', $post_id ) ) return;

        // Lấy dữ liệu gửi lên
        $seo_title = isset($_POST['dawp_seo_title']) ? sanitize_text_field($_POST['dawp_seo_title']) : '';
        $seo_desc = isset($_POST['dawp_seo_desc']) ? sanitize_text_field($_POST['dawp_seo_desc']) : '';
        $seo_og_title = isset($_POST['dawp_seo_og_title']) ? sanitize_text_field($_POST['dawp_seo_og_title']) : '';
        $seo_og_desc = isset($_POST['dawp_seo_og_desc']) ? sanitize_text_field($_POST['dawp_seo_og_desc']) : '';
        $seo_og_image = isset($_POST['dawp_seo_og_image']) ? sanitize_text_field($_POST['dawp_seo_og_image']) : '';

        // Cơ chế đồng bộ tuyệt đối: Nhập 1 nơi lưu 2 nơi
        $post_title = get_the_title($post_id);
        if ( empty( $seo_og_title ) || $seo_og_title === $post_title ) {
            $seo_og_title = ! empty( $seo_title ) ? $seo_title : $post_title;
        }
        if ( empty( $seo_og_desc ) ) {
            $seo_og_desc = $seo_desc;
        }
        if ( empty( $seo_og_image ) && has_post_thumbnail( $post_id ) ) {
            $thumbnail_id = get_post_thumbnail_id( $post_id );
            $thumbnail_url = wp_get_attachment_image_url( $thumbnail_id, 'full' );
            if ( $thumbnail_url ) {
                $seo_og_image = $thumbnail_url;
            }
        }

        // Ghi đè vào mảng $_POST để lưu đồng thời
        $_POST['dawp_seo_og_title'] = $seo_og_title;
        $_POST['dawp_seo_og_desc'] = $seo_og_desc;
        $_POST['dawp_seo_og_image'] = $seo_og_image;

        $fields = [
            'dawp_seo_title'     => '_dawp_seo_title',
            'dawp_seo_desc'      => '_dawp_seo_desc',
            'dawp_seo_keyword'   => '_dawp_seo_keyword',
            'dawp_seo_og_title'  => '_dawp_seo_og_title',
            'dawp_seo_og_desc'   => '_dawp_seo_og_desc',
            'dawp_seo_og_image'  => '_dawp_seo_og_image'
        ];

        foreach ( $fields as $post_key => $meta_key ) {
            if ( isset($_POST[$post_key]) ) {
                update_post_meta( $post_id, $meta_key, sanitize_text_field( $_POST[$post_key] ) );
            }
        }

        // Lưu checkboxes robots
        update_post_meta( $post_id, '_dawp_seo_noindex', isset($_POST['dawp_seo_noindex']) ? 1 : 0 );
        update_post_meta( $post_id, '_dawp_seo_nofollow', isset($_POST['dawp_seo_nofollow']) ? 1 : 0 );

    }

    /**
     * AJAX đề xuất các liên kết nội bộ liên quan đến từ khóa chính
     */
    public function get_link_suggestions_callback() {
        if ( ! current_user_can( 'edit_posts' ) ) {
            wp_send_json_error( [ 'message' => 'Bạn không có quyền thực hiện!' ] );
        }

        check_ajax_referer( 'dawp_save_seo_meta_action', 'nonce' );

        $keyword = isset( $_POST['keyword'] ) ? sanitize_text_field( $_POST['keyword'] ) : '';
        $exclude_id = isset( $_POST['exclude_id'] ) ? (int)$_POST['exclude_id'] : 0;

        if ( empty( $keyword ) ) {
            wp_send_json_success( [] );
        }

        global $wpdb;
        $like_query = '%' . $wpdb->esc_like( $keyword ) . '%';

        $allowed_types = get_post_types( [ 'public' => true ], 'names' );
        if ( isset( $allowed_types['attachment'] ) ) {
            unset( $allowed_types['attachment'] );
        }
        $post_types_in = "'" . implode("', '", array_map('esc_sql', $allowed_types)) . "'";

        // Lấy tối đa 5 bài viết/trang/sản phẩm có tiêu đề hoặc nội dung chứa từ khóa (loại bỏ bài viết hiện tại)
        $sql = "SELECT ID, post_title 
                FROM {$wpdb->posts} 
                WHERE post_status = 'publish' 
                  AND post_type IN ($post_types_in)
                  AND ID != %d
                  AND (post_title LIKE %s OR post_content LIKE %s)
                ORDER BY post_date DESC 
                LIMIT 5";
                
        $results = $wpdb->get_results( $wpdb->prepare( $sql, $exclude_id, $like_query, $like_query ) );

        $suggestions = [];
        if ( ! empty( $results ) ) {
            foreach ( $results as $row ) {
                $suggestions[] = [
                    'title' => esc_html( $row->post_title ),
                    'url'   => esc_url( get_permalink( $row->ID ) )
                ];
            }
        }

        wp_send_json_success( $suggestions );
    }

    /**
     * Tùy biến form biên tập SEO trong chuyên mục / taxonomy
     */
    public function render_taxonomy_seo_fields( $tag ) {
        $seo_title = get_term_meta( $tag->term_id, '_dawp_seo_title', true );
        $seo_desc  = get_term_meta( $tag->term_id, '_dawp_seo_desc', true );
        $noindex   = get_term_meta( $tag->term_id, '_dawp_seo_noindex', true );
        $nofollow  = get_term_meta( $tag->term_id, '_dawp_seo_nofollow', true );
        ?>
        <tr class="form-field">
            <th scope="row" valign="top"><label for="dawp_seo_title">Tiêu đề SEO</label></th>
            <td>
                <input type="text" name="dawp_seo_title" id="dawp_seo_title" value="<?php echo esc_attr( $seo_title ); ?>">
                <p class="description">Được hiển thị thay thế tiêu đề mặc định của chuyên mục/danh mục.</p>
            </td>
        </tr>
        <tr class="form-field">
            <th scope="row" valign="top"><label for="dawp_seo_desc">Mô tả Meta (Description)</label></th>
            <td>
                <textarea name="dawp_seo_desc" id="dawp_seo_desc" rows="3"><?php echo esc_textarea( $seo_desc ); ?></textarea>
                <p class="description">Được hiển thị làm thẻ mô tả meta công cụ tìm kiếm.</p>
            </td>
        </tr>
        <tr class="form-field">
            <th scope="row" valign="top"><label>Robots Nâng cao</label></th>
            <td>
                <div style="margin-bottom: 8px;">
                    <label style="font-weight: 600; color: #d63638; cursor: pointer;">
                        <input type="checkbox" name="dawp_seo_noindex" value="1" <?php checked( 1, $noindex ); ?>> Chặn index (noindex)
                    </label>
                    <p class="description" style="margin: 2px 0 0 20px; font-size: 12px;">⚠️ Hạn chế chọn. Chỉ chọn nếu muốn ẩn hoàn toàn **chuyên mục / thẻ đơn lẻ này** khỏi Google Search.</p>
                </div>
                <div>
                    <label style="font-weight: 600; color: #e11d48; cursor: pointer;">
                        <input type="checkbox" name="dawp_seo_nofollow" value="1" <?php checked( 1, $nofollow ); ?>> Chặn follow links (nofollow)
                    </label>
                    <p class="description" style="margin: 2px 0 0 20px; font-size: 12px;">⚠️ Hạn chế chọn. Chỉ chọn nếu muốn bot Google bỏ qua mọi liên kết trong **chuyên mục / thẻ đơn lẻ này**.</p>
                </div>
            </td>
        </tr>
        <?php
    }

    /**
     * Lưu cài đặt SEO cho Taxonomy
     */
    public function save_taxonomy_seo_fields( $term_id ) {
        if ( isset($_POST['dawp_seo_title']) ) {
            update_term_meta( $term_id, '_dawp_seo_title', sanitize_text_field( $_POST['dawp_seo_title'] ) );
        }
        if ( isset($_POST['dawp_seo_desc']) ) {
            update_term_meta( $term_id, '_dawp_seo_desc', sanitize_text_field( $_POST['dawp_seo_desc'] ) );
        }
        update_term_meta( $term_id, '_dawp_seo_noindex', isset($_POST['dawp_seo_noindex']) ? 1 : 0 );
        update_term_meta( $term_id, '_dawp_seo_nofollow', isset($_POST['dawp_seo_nofollow']) ? 1 : 0 );
    }

    /**
     * Nạp file JS quản lý đếm kí tự và Focus Keyword trong admin edit screen
     */
    public function enqueue_admin_assets( $hook ) {
        if ( in_array( $hook, [ 'post.php', 'post-new.php' ] ) ) {
            wp_enqueue_media(); // Kích hoạt bộ thư viện Media
            
            $js_path = DAWP_DIR . 'assets/js/dawp-seo-admin.js';
            $ver = file_exists( $js_path ) ? filemtime( $js_path ) : DAWP_VERSION;
            
            wp_enqueue_script( 'dawp-seo-admin-js', DAWP_URL . 'assets/js/dawp-seo-admin.js', [ 'jquery' ], $ver, true );
            
            // Truyền dữ liệu bài viết sang JS để thực hiện phân tích
            global $post;
            wp_localize_script( 'dawp-seo-admin-js', 'dawpSeoData', [
                'postTitle'   => get_the_title( $post->ID ),
                'postContent' => $post->post_content,
                'postSlug'    => $post->post_name,
                'permalink'   => get_permalink( $post->ID )
            ] );
        }
    }

    /**
     * Tiêm mã script tùy biến vào Header (<head>)
     */
    public function inject_header_code() {
        if ( is_admin() ) return;
        $options = get_option( 'dawp_settings', [] );
        if ( ! empty( $options['seo_header_code'] ) ) {
            echo $options['seo_header_code'] . "\n";
        }
    }

    /**
     * Tiêm mã script tùy biến vào ngay sau thẻ mở Body (<body>)
     */
    public function inject_body_code() {
        if ( is_admin() ) return;
        $options = get_option( 'dawp_settings', [] );
        if ( ! empty( $options['seo_body_code'] ) ) {
            echo $options['seo_body_code'] . "\n";
        }
    }

    /**
     * Tiêm mã script tùy biến vào chân trang Footer (trước </body>)
     */
    public function inject_footer_code() {
        if ( is_admin() ) return;
        $options = get_option( 'dawp_settings', [] );
        if ( ! empty( $options['seo_footer_code'] ) ) {
            echo $options['seo_footer_code'] . "\n";
        }
    }

    /**
     * Đăng ký cột Chi tiết SEO vào danh sách bài viết / trang
     */
    public function add_seo_column_header( $columns ) {
        $new_columns = [];
        $added = false;
        
        foreach ( $columns as $key => $value ) {
            // Chèn trước cột Date (Thời gian) để đẩy sang bên phải giống Yoast SEO
            if ( $key === 'date' ) {
                $new_columns['dawp_post_views'] = '<span class="dashicons dashicons-visibility" style="vertical-align: text-bottom; margin-right: 3px;"></span> Lượt xem';
                $new_columns['dawp_seo_details'] = '<span class="dashicons dashicons-admin-site" style="vertical-align: text-bottom; margin-right: 3px;"></span> Chi tiết SEO';
                $added = true;
            }
            $new_columns[$key] = $value;
        }
        
        if ( ! $added ) {
            $new_columns['dawp_post_views'] = '<span class="dashicons dashicons-visibility" style="vertical-align: text-bottom; margin-right: 3px;"></span> Lượt xem';
            $new_columns['dawp_seo_details'] = '<span class="dashicons dashicons-admin-site" style="vertical-align: text-bottom; margin-right: 3px;"></span> Chi tiết SEO';
        }
        
        // Loại bỏ cột views trùng lặp của các plugin khác
        if ( isset( $new_columns['views'] ) ) {
            unset( $new_columns['views'] );
        }
        
        return $new_columns;
    }

    /**
     * Hiển thị nội dung cột Chi tiết SEO và Lượt xem
     */
    public function render_seo_column_content( $column_name, $post_id ) {
        if ( $column_name === 'dawp_post_views' ) {
            $views = (int) get_post_meta( $post_id, '_dawp_post_views', true );
            if ( $views <= 0 ) {
                $views = (int) get_post_meta( $post_id, 'views', true );
                if ( $views <= 0 ) {
                    $views = (int) get_post_meta( $post_id, 'post_views_count', true );
                }
            }
            echo '<span style="font-weight: 600; color: #0068ff; font-size: 13px;">' . number_format( $views ) . '</span>';
            return;
        }

        if ( $column_name !== 'dawp_seo_details' ) {
            return;
        }
        
        $keyword = get_post_meta( $post_id, '_dawp_seo_keyword', true );
        $score = $this->calculate_seo_score( $post_id );
        $schema = $this->get_post_schema_type( $post_id );
        
        $dot_class = 'dawp-seo-dot-na';
        $status_text = 'Chưa SEO';
        $score_title = 'Chưa cấu hình từ khóa chính';
        
        if ( $score >= 80 ) {
            $dot_class = 'dawp-seo-dot-good';
            $status_text = 'Tốt';
            $score_title = 'Điểm SEO: ' . $score . '/100';
        } elseif ( $score >= 50 ) {
            $dot_class = 'dawp-seo-dot-ok';
            $status_text = 'Cần cải thiện';
            $score_title = 'Điểm SEO: ' . $score . '/100';
        } elseif ( $score >= 0 ) {
            $dot_class = 'dawp-seo-dot-bad';
            $status_text = 'Chưa tối ưu';
            $score_title = 'Điểm SEO: ' . $score . '/100';
        }
        
        // Điểm dễ đọc
        $read_score = $this->calculate_readability_score( $post_id );
        $read_bucket = $this->get_score_bucket( $read_score );
        $read_dot = [ 'good' => 'dawp-seo-dot-good', 'ok' => 'dawp-seo-dot-ok', 'bad' => 'dawp-seo-dot-bad', 'none' => 'dawp-seo-dot-na' ][ $read_bucket ];
        $read_text = [ 'good' => 'Dễ đọc', 'ok' => 'Tạm ổn', 'bad' => 'Khó đọc', 'none' => 'Chưa có ND' ][ $read_bucket ];
        $read_title = $read_score >= 0 ? ( 'Điểm dễ đọc: ' . $read_score . '/100' ) : 'Nội dung quá ngắn để đánh giá';

        echo '<div class="dawp-seo-column-val">';
        echo '  <div class="dawp-seo-status-wrap" title="' . esc_attr($score_title) . '">';
        echo '    <span class="dawp-seo-dot ' . esc_attr($dot_class) . '"></span>';
        echo '    <span>SEO: ' . esc_html($status_text) . '</span>';
        echo '  </div>';
        echo '  <div class="dawp-seo-status-wrap" style="margin-top:5px;" title="' . esc_attr($read_title) . '">';
        echo '    <span class="dawp-seo-dot ' . esc_attr($read_dot) . '"></span>';
        echo '    <span>Đọc: ' . esc_html($read_text) . '</span>';
        echo '  </div>';
        echo '  <div class="dawp-seo-meta-info" style="margin-top: 6px; font-size: 11px; line-height: 1.4; color: #64748b;">';
        echo '    <div><strong>Từ khóa:</strong> ' . esc_html( $keyword ? $keyword : 'Chưa đặt' ) . '</div>';
        echo '    <div style="margin-top: 2px;"><strong>Schema:</strong> ' . esc_html( $schema ) . '</div>';
        echo '  </div>';
        echo '</div>';
    }

    /**
     * Thêm CSS làm đẹp cho cột SEO trong trang quản trị
     */
    public function add_seo_column_styles() {
        $screen = get_current_screen();
        if ( ! $screen || ( $screen->base !== 'edit' && $screen->base !== 'upload' ) ) {
            return;
        }
        ?>
        <style id="dawp-seo-column-css">
            .column-dawp_post_views {
                width: 110px !important;
                white-space: nowrap !important;
            }
            .column-dawp_seo_details {
                width: 170px !important;
            }
            .dawp-seo-status-wrap {
                display: inline-flex;
                align-items: center;
                gap: 6px;
                font-weight: 600;
                font-size: 12px;
                color: #1e293b;
                background: #f8fafc;
                padding: 4px 8px;
                border-radius: 6px;
                border: 1px solid #e2e8f0;
                transition: all 0.2s ease-in-out;
            }
            .dawp-seo-status-wrap:hover {
                background: #f1f5f9;
                border-color: #cbd5e1;
                transform: translateY(-1px);
                box-shadow: 0 2px 4px rgba(0,0,0,0.05);
            }
            .dawp-seo-dot {
                display: inline-block;
                width: 10px;
                height: 10px;
                border-radius: 50%;
                box-shadow: inset 0 -1.5px 0 rgba(0,0,0,0.15), 0 1px 2px rgba(0,0,0,0.1);
            }
            .dawp-seo-dot-good {
                background-color: #22c55e;
                box-shadow: inset 0 -1.5px 0 rgba(0,0,0,0.15), 0 0 5px rgba(34, 197, 94, 0.4);
            }
            .dawp-seo-dot-ok {
                background-color: #f59e0b;
                box-shadow: inset 0 -1.5px 0 rgba(0,0,0,0.15), 0 0 5px rgba(245, 158, 11, 0.4);
            }
            .dawp-seo-dot-bad {
                background-color: #ef4444;
                box-shadow: inset 0 -1.5px 0 rgba(0,0,0,0.15), 0 0 5px rgba(239, 68, 68, 0.4);
            }
            .dawp-seo-dot-na {
                background-color: #94a3b8;
                box-shadow: inset 0 -1.5px 0 rgba(0,0,0,0.15), 0 0 5px rgba(148, 163, 184, 0.4);
            }
        </style>
        <?php
    }

    /**
     * Tính toán điểm SEO thực tế dựa trên nội dung bài viết
     */
    private function calculate_seo_score( $post_id ) {
        $post = get_post( $post_id );
        if ( ! $post ) return 0;
        
        $keyword = get_post_meta( $post_id, '_dawp_seo_keyword', true );
        if ( empty( $keyword ) ) {
            return -1; // Chưa đặt từ khóa
        }
        
        $title = $post->post_title;
        $content = $post->post_content;
        $slug = $post->post_name;
        $desc = get_post_meta( $post_id, '_dawp_seo_desc', true );
        
        $score = 0;
        $keyword_lower = mb_strtolower( $keyword );
        
        // 1. Từ khóa trong Tiêu đề (+25 điểm)
        if ( mb_stripos( $title, $keyword_lower ) !== false ) {
            $score += 25;
        }
        
        // 2. Từ khóa trong URL / Slug (+20 điểm)
        $clean_slug = str_replace( '-', ' ', $slug );
        if ( mb_stripos( $clean_slug, $keyword_lower ) !== false || mb_stripos( $slug, str_replace( ' ', '-', $keyword_lower ) ) !== false ) {
            $score += 20;
        }
        
        // 3. Từ khóa trong Meta Description (+20 điểm)
        if ( ! empty( $desc ) && mb_stripos( $desc, $keyword_lower ) !== false ) {
            $score += 20;
        }
        
        // 4. Từ khóa xuất hiện trong Nội dung bài viết (+20 điểm)
        if ( mb_stripos( strip_tags( $content ), $keyword_lower ) !== false ) {
            $score += 20;
        }
        
        // 5. Độ dài Meta Description tốt (120 - 160 ký tự) (+15 điểm)
        $desc_len = mb_strlen( $desc );
        if ( $desc_len >= 120 && $desc_len <= 160 ) {
            $score += 15;
        } elseif ( $desc_len > 0 ) {
            $score += 8;
        }
        
        return $score;
    }

    /**
     * Xác định Schema đang áp dụng cho bài viết
     */
    private function get_post_schema_type( $post_id ) {
        $post_type = get_post_type( $post_id );
        
        // Kiểm tra FAQ
        $faqs = get_post_meta( $post_id, '_dawp_seo_faqs', true );
        $has_faq = ( is_array($faqs) && ! empty($faqs) );
        
        if ( $post_type === 'product' ) {
            return $has_faq ? 'Sản phẩm + Hỏi đáp (FAQPage)' : 'Sản phẩm (Product)';
        } elseif ( $post_type === 'post' ) {
            return $has_faq ? 'Bài viết + Hỏi đáp (FAQPage)' : 'Bài viết (BlogPosting)';
        } elseif ( $post_type === 'page' ) {
            return $has_faq ? 'Trang + Hỏi đáp (FAQPage)' : 'Trang (WebPage)';
        }
        
        return $has_faq ? 'Mặc định + Hỏi đáp (FAQPage)' : 'Mặc định (WebPage)';
    }

    /**
     * Đếm số từ (hỗ trợ Unicode tiếng Việt).
     */
    private function dawp_count_words( $str ) {
        $str = trim( (string) $str );
        if ( $str === '' ) return 0;
        $parts = preg_split( '/\s+/u', $str );
        return $parts ? count( array_filter( $parts, function( $w ) { return $w !== ''; } ) ) : 0;
    }

    /**
     * Chấm điểm Dễ đọc (Readability) phía server, đồng bộ logic với trình soạn thảo.
     * Trả về 0..100, hoặc -1 nếu nội dung quá ngắn để đánh giá.
     */
    private function calculate_readability_score( $post_id ) {
        $post = get_post( $post_id );
        if ( ! $post ) return -1;

        $html = $post->post_content;
        $text = trim( preg_replace( '/\s+/u', ' ', wp_strip_all_tags( $html ) ) );
        $words = $this->dawp_count_words( $text );
        if ( $words < 20 ) return -1;

        // Tách câu
        $parts = preg_split( '/[.!?…]+/u', $text );
        $sentences = array_values( array_filter( array_map( 'trim', (array) $parts ), function( $s ) { return $s !== ''; } ) );
        $sent_count = max( 1, count( $sentences ) );
        $avg = $words / $sent_count;
        $long = 0;
        foreach ( $sentences as $s ) {
            if ( $this->dawp_count_words( $s ) > 25 ) $long++;
        }
        $long_pct = $long / $sent_count * 100;

        // Đoạn văn
        if ( preg_match_all( '/<p[^>]*>(.*?)<\/p>/is', $html, $m ) && ! empty( $m[1] ) ) {
            $paras = array_map( 'wp_strip_all_tags', $m[1] );
        } else {
            $paras = preg_split( '/\n+/', $text );
        }
        $max_para = 0;
        foreach ( (array) $paras as $p ) {
            $w = $this->dawp_count_words( $p );
            if ( $w > $max_para ) $max_para = $w;
        }

        $headings = (int) preg_match_all( '/<h[23][^>]*>/i', $html );

        $good = 0; $counted = 0;
        // Độ dài bài
        if ( $words >= 300 ) { $good++; $counted++; } elseif ( $words < 150 ) { $counted++; }
        // Độ dài câu trung bình
        if ( $avg <= 20 ) { $good++; $counted++; } elseif ( $avg > 25 ) { $counted++; }
        // % câu dài
        if ( $long_pct <= 25 ) { $good++; $counted++; } elseif ( $long_pct > 40 ) { $counted++; }
        // Đoạn văn dài nhất
        if ( $max_para <= 150 ) { $good++; $counted++; } elseif ( $max_para > 200 ) { $counted++; }
        // Tiêu đề phụ (chỉ tính khi bài đủ dài)
        if ( $words >= 300 ) { $counted++; if ( $headings > 0 ) $good++; }

        return $counted ? (int) round( $good / $counted * 100 ) : 100;
    }

    /**
     * Phân nhóm điểm: good (>=80), ok (50-79), bad (0-49), none (<0 = chưa đủ ĐK).
     */
    private function get_score_bucket( $score ) {
        $score = (int) $score;
        if ( $score < 0 ) return 'none';
        if ( $score >= 80 ) return 'good';
        if ( $score >= 50 ) return 'ok';
        return 'bad';
    }

    /**
     * Lưu điểm SEO + Dễ đọc vào post meta khi lưu bài (phục vụ lọc & đếm).
     */
    public function store_scores_on_save( $post_id ) {
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
        if ( wp_is_post_revision( $post_id ) ) return;
        $public = get_post_types( [ 'public' => true ], 'names' );
        unset( $public['attachment'] );
        if ( ! in_array( get_post_type( $post_id ), $public, true ) ) return;

        update_post_meta( $post_id, '_dawp_seo_score', (int) $this->calculate_seo_score( $post_id ) );
        update_post_meta( $post_id, '_dawp_read_score', (int) $this->calculate_readability_score( $post_id ) );

        foreach ( $public as $pt ) {
            delete_transient( 'dawp_seo_counts_' . $pt );
        }
    }

    /**
     * Dropdown lọc theo Điểm SEO & Điểm Dễ đọc phía trên danh sách.
     */
    public function render_score_filters() {
        $screen = get_current_screen();
        if ( ! $screen || $screen->base !== 'edit' ) return;
        $public = get_post_types( [ 'public' => true ], 'names' );
        unset( $public['attachment'] );
        if ( ! in_array( $screen->post_type, $public, true ) ) return;

        $seo_sel = isset( $_GET['dawp_seo_filter'] ) ? sanitize_key( $_GET['dawp_seo_filter'] ) : '';
        echo '<select name="dawp_seo_filter" style="max-width:170px;">';
        echo '<option value="">Tất cả các Điểm SEO</option>';
        foreach ( [ 'good' => 'SEO: Tốt', 'ok' => 'SEO: Cần cải thiện', 'bad' => 'SEO: Kém', 'none' => 'SEO: Chưa đặt từ khóa' ] as $k => $v ) {
            echo '<option value="' . esc_attr( $k ) . '" ' . selected( $seo_sel, $k, false ) . '>' . esc_html( $v ) . '</option>';
        }
        echo '</select>';

        $read_sel = isset( $_GET['dawp_read_filter'] ) ? sanitize_key( $_GET['dawp_read_filter'] ) : '';
        echo '<select name="dawp_read_filter" style="max-width:170px;">';
        echo '<option value="">Tổng điểm dễ đọc</option>';
        foreach ( [ 'good' => 'Đọc: Tốt', 'ok' => 'Đọc: Tạm ổn', 'bad' => 'Đọc: Khó đọc' ] as $k => $v ) {
            echo '<option value="' . esc_attr( $k ) . '" ' . selected( $read_sel, $k, false ) . '>' . esc_html( $v ) . '</option>';
        }
        echo '</select>';
    }

    /**
     * Chuyển bucket thành điều kiện meta_query.
     */
    private function score_range_meta( $key, $bucket ) {
        switch ( $bucket ) {
            case 'good': return [ 'key' => $key, 'value' => 80, 'type' => 'NUMERIC', 'compare' => '>=' ];
            case 'ok':   return [ 'key' => $key, 'value' => [ 50, 79 ], 'type' => 'NUMERIC', 'compare' => 'BETWEEN' ];
            case 'bad':  return [ 'key' => $key, 'value' => [ 0, 49 ], 'type' => 'NUMERIC', 'compare' => 'BETWEEN' ];
            case 'none': return [ 'key' => $key, 'value' => 0, 'type' => 'NUMERIC', 'compare' => '<' ];
        }
        return null;
    }

    /**
     * Áp bộ lọc điểm vào truy vấn danh sách admin.
     */
    public function filter_admin_by_score( $query ) {
        if ( ! is_admin() || ! $query->is_main_query() ) return;
        if ( ! function_exists( 'get_current_screen' ) ) return;
        $screen = get_current_screen();
        if ( ! $screen || $screen->base !== 'edit' ) return;

        $mq = [];
        if ( ! empty( $_GET['dawp_seo_filter'] ) ) {
            $r = $this->score_range_meta( '_dawp_seo_score', sanitize_key( $_GET['dawp_seo_filter'] ) );
            if ( $r ) $mq[] = $r;
        }
        if ( ! empty( $_GET['dawp_read_filter'] ) ) {
            $r = $this->score_range_meta( '_dawp_read_score', sanitize_key( $_GET['dawp_read_filter'] ) );
            if ( $r ) $mq[] = $r;
        }
        if ( empty( $mq ) ) return;
        if ( count( $mq ) > 1 ) $mq['relation'] = 'AND';
        $existing = $query->get( 'meta_query' );
        if ( ! empty( $existing ) ) $mq = array_merge( (array) $existing, $mq );
        $query->set( 'meta_query', $mq );
    }

    /**
     * Đếm số bài theo nhóm điểm SEO (cache 5 phút).
     */
    private function get_score_counts( $post_type ) {
        $cache_key = 'dawp_seo_counts_' . $post_type;
        $cached = get_transient( $cache_key );
        if ( is_array( $cached ) ) return $cached;

        global $wpdb;
        $counts = [ 'good' => 0, 'ok' => 0, 'bad' => 0, 'none' => 0 ];
        $rows = $wpdb->get_col( $wpdb->prepare(
            "SELECT pm.meta_value FROM {$wpdb->postmeta} pm
             INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
             WHERE pm.meta_key = '_dawp_seo_score'
               AND p.post_type = %s
               AND p.post_status IN ('publish','draft','pending','future','private')",
            $post_type
        ) );
        foreach ( (array) $rows as $v ) {
            $v = (int) $v;
            if ( $v < 0 ) $counts['none']++;
            elseif ( $v >= 80 ) $counts['good']++;
            elseif ( $v >= 50 ) $counts['ok']++;
            else $counts['bad']++;
        }
        set_transient( $cache_key, $counts, 5 * MINUTE_IN_SECONDS );
        return $counts;
    }

    /**
     * Thêm link đếm trạng thái điểm SEO ở đầu danh sách.
     */
    public function add_score_status_links( $views ) {
        $screen = get_current_screen();
        if ( ! $screen ) return $views;
        $pt = $screen->post_type;
        $counts = $this->get_score_counts( $pt );
        $base = admin_url( 'edit.php?post_type=' . $pt );
        $cur = isset( $_GET['dawp_seo_filter'] ) ? sanitize_key( $_GET['dawp_seo_filter'] ) : '';

        $items = [
            'good' => [ 'Tốt', '#22c55e' ],
            'ok'   => [ 'Cần cải thiện', '#f59e0b' ],
            'bad'  => [ 'Kém', '#ef4444' ],
            'none' => [ 'Chưa đặt từ khóa', '#94a3b8' ],
        ];
        foreach ( $items as $k => $info ) {
            $url = add_query_arg( 'dawp_seo_filter', $k, $base );
            $cls = ( $cur === $k ) ? ' class="current"' : '';
            $views[ 'dawp_seo_' . $k ] = '<a href="' . esc_url( $url ) . '"' . $cls . '><span style="color:' . $info[1] . ';">●</span> ' . esc_html( $info[0] ) . ' <span class="count">(' . (int) $counts[ $k ] . ')</span></a>';
        }
        return $views;
    }

    /**
     * AJAX: quét lại & lưu điểm cho toàn bộ bài viết theo lô.
     */
    public function ajax_rescan_scores() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( [ 'message' => 'Không có quyền.' ] );
        }
        check_ajax_referer( 'dawp_rescan_scores_nonce', 'nonce' );

        $offset = isset( $_POST['offset'] ) ? max( 0, (int) $_POST['offset'] ) : 0;
        $batch  = 50;
        $public = get_post_types( [ 'public' => true ], 'names' );
        unset( $public['attachment'] );

        $q = new WP_Query( [
            'post_type'      => array_values( $public ),
            'post_status'    => [ 'publish', 'draft', 'pending', 'future', 'private' ],
            'posts_per_page' => $batch,
            'offset'         => $offset,
            'fields'         => 'ids',
            'orderby'        => 'ID',
            'order'          => 'ASC',
        ] );

        $ids = $q->posts;
        foreach ( $ids as $id ) {
            update_post_meta( $id, '_dawp_seo_score', (int) $this->calculate_seo_score( $id ) );
            update_post_meta( $id, '_dawp_read_score', (int) $this->calculate_readability_score( $id ) );
        }

        foreach ( $public as $pt ) {
            delete_transient( 'dawp_seo_counts_' . $pt );
        }

        $total     = (int) $q->found_posts;
        $processed = $offset + count( $ids );

        wp_send_json_success( [
            'processed' => $processed,
            'total'     => $total,
            'done'      => ( count( $ids ) < $batch || $processed >= $total ),
        ] );
    }

    public function inject_track_view_script() {
        if ( is_singular() ) {
            $post_id = get_the_ID();
            $ajax_url = wp_parse_url( admin_url( 'admin-ajax.php' ), PHP_URL_PATH );
            ?>
            <script id="dawp-track-view-js">
                (function() {
                    var track = function() {
                        if (typeof fetch === "function") {
                            fetch("<?php echo esc_url( $ajax_url ); ?>?action=dawp_inc_pv&post_id=<?php echo $post_id; ?>&_ts=" + Date.now());
                        }
                    };
                    if (document.readyState !== "loading") {
                        track();
                    } else {
                        document.addEventListener("DOMContentLoaded", track);
                    }
                })();
            </script>
            <?php
        }
    }

    /**
     * Xử lý AJAX cộng dồn lượt xem bài viết
     */
    public function ajax_track_view() {
        $post_id = isset($_GET['post_id']) ? (int)$_GET['post_id'] : 0;
        if ( $post_id <= 0 ) {
            wp_send_json_success();
        }

        // Endpoint này gọi được từ khách chưa đăng nhập (nopriv) nên phải tự phòng
        // lạm dụng: chỉ đếm bài ĐÃ publish thuộc loại nội dung công khai — chặn bơm
        // lượt xem vào bài nháp/riêng tư hoặc ID bất kỳ.
        $post = get_post( $post_id );
        if ( ! $post || 'publish' !== $post->post_status ) {
            wp_send_json_success();
        }
        $type_obj = get_post_type_object( $post->post_type );
        if ( ! $type_obj || empty( $type_obj->public ) ) {
            wp_send_json_success();
        }

        // Chống bơm số + khuếch đại ghi DB: mỗi IP chỉ cộng 1 lượt cho mỗi bài
        // trong 6 giờ. Không nonce (để tương thích cache trang tĩnh) nhưng có cửa
        // chặn tần suất này là đủ cho một bộ đếm lượt xem.
        $ip  = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : 'unknown';
        $key = 'dawp_pv_' . $post_id . '_' . md5( $ip );
        if ( get_transient( $key ) ) {
            wp_send_json_success();
        }
        set_transient( $key, 1, 6 * HOUR_IN_SECONDS );

        $views = (int) get_post_meta( $post_id, '_dawp_post_views', true );
        $views++;
        update_post_meta( $post_id, '_dawp_post_views', $views );

        // Đồng bộ sang các key phổ biến của Flatsome và các plugin khác
        update_post_meta( $post_id, 'views', $views );
        update_post_meta( $post_id, 'post_views_count', $views );

        wp_send_json_success();
    }

    /**
     * Hiển thị số lượt xem qua Shortcode [dawp_post_views]
     */
    public function render_post_views() {
        $post_id = get_the_ID();
        if ( ! $post_id ) return '';
        $views = (int) get_post_meta( $post_id, '_dawp_post_views', true );
        if ( $views <= 0 ) {
            $views = (int) get_post_meta( $post_id, 'views', true );
            if ( $views <= 0 ) {
                $views = (int) get_post_meta( $post_id, 'post_views_count', true );
            }
        }
        return number_format( $views );
    }

    /**
     * Hiển thị nội dung cột Chi tiết SEO cho Hình ảnh (Media Library)
     */
    public function render_media_column_content( $column_name, $post_id ) {
        if ( $column_name !== 'dawp_seo_details' ) {
            return;
        }
        
        $alt = get_post_meta( $post_id, '_wp_attachment_image_alt', true );
        $post = get_post( $post_id );
        $title = $post ? $post->post_title : '';
        $caption = $post ? $post->post_excerpt : '';
        $desc = $post ? $post->post_content : '';
        
        $score = 0;
        if ( ! empty( $alt ) ) {
            $score += 50;
        }
        if ( ! empty( $title ) && ! preg_match( '/\b(dsc|img|screenshot|image|photo)[-_]?\d+\b/i', $title ) ) {
            $score += 30;
        }
        if ( ! empty( $caption ) || ! empty( $desc ) ) {
            $score += 20;
        }
        
        $dot_class = 'dawp-seo-dot-bad';
        $status_text = 'Chưa tối ưu';
        $score_title = 'Điểm tối ưu ảnh: ' . $score . '/100';
        
        if ( $score >= 80 ) {
            $dot_class = 'dawp-seo-dot-good';
            $status_text = 'Tốt';
        } elseif ( $score >= 50 ) {
            $dot_class = 'dawp-seo-dot-ok';
            $status_text = 'Cần cải thiện';
        }
        
        echo '<div class="dawp-seo-column-val">';
        echo '  <div class="dawp-seo-status-wrap" title="' . esc_attr($score_title) . '">';
        echo '    <span class="dawp-seo-dot ' . esc_attr($dot_class) . '"></span>';
        echo '    <span>' . esc_html($status_text) . '</span>';
        echo '  </div>';
        echo '  <div class="dawp-seo-meta-info" style="margin-top: 6px; font-size: 11px; line-height: 1.4; color: #64748b;">';
        echo '    <div><strong>Thẻ Alt:</strong> ' . ( $alt ? '<span style="color:#137333; font-weight: 500;">✔️ ' . esc_html($alt) . '</span>' : '<span style="color:#c5221f; font-weight: 500;">❌ Chưa đặt (Yêu cầu)</span>' ) . '</div>';
        echo '    <div style="margin-top: 2px;"><strong>Chú thích:</strong> ' . ( $caption ? '✔️ Đã đặt' : '❌ Chưa đặt' ) . '</div>';
        echo '  </div>';
        echo '</div>';
    }
}
