<?php
defined( 'ABSPATH' ) || exit;

class DAWP_Settings {
    public function __construct() {
        add_action( 'admin_menu', [ $this, 'add_plugin_page' ] );
        add_action( 'admin_init', [ $this, 'page_init' ] );
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_settings_assets' ] );
        add_action( 'wp_ajax_dawp_test_smtp', [ $this, 'test_smtp_callback' ] );
        add_action( 'wp_ajax_dawp_clean_comments', [ $this, 'clean_comments_callback' ] );
        add_action( 'wp_ajax_dawp_scan_db', [ $this, 'scan_db_callback' ] );
        add_action( 'wp_ajax_dawp_clean_db', [ $this, 'clean_db_callback' ] );
        
        // SEO AJAX Callbacks
        add_action( 'wp_ajax_dawp_add_redirect', [ $this, 'add_redirect_callback' ] );
        add_action( 'wp_ajax_dawp_delete_redirect', [ $this, 'delete_redirect_callback' ] );
        add_action( 'wp_ajax_dawp_delete_404', [ $this, 'delete_404_callback' ] );
        add_action( 'wp_ajax_dawp_clear_404', [ $this, 'clear_404_callback' ] );
        add_action( 'wp_ajax_dawp_get_migration_stats', [ $this, 'get_migration_stats_callback' ] );
        add_action( 'wp_ajax_dawp_migrate_seo', [ $this, 'migrate_seo_callback' ] );
        
        // Tự động đồng bộ hóa cấu hình .htaccess khi lưu cài đặt
        add_action( 'update_option_dawp_settings', [ $this, 'trigger_htaccess_update' ], 10, 2 );
        add_action( 'add_option_dawp_settings', [ $this, 'trigger_htaccess_update' ], 10, 2 );

        // Chuông báo "đổi chủ": site dựng từ mẫu/nhân bản mang theo cài đặt liên hệ
        // của site gốc (số Zalo, hotline, SMTP...) — từng lộ số của công ty trên
        // site khách. Khi địa chỉ site thay đổi so với dấu vân tay đã lưu, hiện
        // cảnh báo liệt kê các thông tin liên hệ đang cấu hình để rà lại.
        add_action( 'admin_init', [ $this, 'check_site_fingerprint' ] );
        add_action( 'admin_notices', [ $this, 'site_moved_notice' ] );
        add_action( 'admin_post_dawp_confirm_site_move', [ $this, 'confirm_site_move' ] );
    }

    /**
     * So dấu vân tay địa chỉ site. Chưa có thì ghi (site đang chạy bình thường,
     * không phải bản nhân bản — hoặc là bản cũ nâng cấp lên, coi như hợp lệ).
     */
    public function check_site_fingerprint() {
        $current = md5( strtolower( (string) wp_parse_url( home_url(), PHP_URL_HOST ) ) );
        $stored  = get_option( 'dawp_site_fingerprint', '' );
        if ( '' === $stored ) {
            update_option( 'dawp_site_fingerprint', $current, false );
        }
    }

    public function site_moved_notice() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }
        $current = md5( strtolower( (string) wp_parse_url( home_url(), PHP_URL_HOST ) ) );
        $stored  = get_option( 'dawp_site_fingerprint', '' );
        if ( '' === $stored || $stored === $current ) {
            return;
        }

        $options = get_option( 'dawp_settings', [] );
        $mang_theo = [];
        $nhan = [
            'hotline_number'  => 'Hotline',
            'zalo_link'       => 'Zalo',
            'whatsapp_number' => 'WhatsApp',
            'messenger_link'  => 'Messenger',
            'map_link'        => 'Bản đồ',
            'smtp_user'       => 'Tài khoản SMTP',
            'smtp_from_email' => 'Email gửi đi',
        ];
        foreach ( $nhan as $key => $ten ) {
            if ( ! empty( $options[ $key ] ) ) {
                $mang_theo[] = '<strong>' . esc_html( $ten ) . ':</strong> ' . esc_html( mb_strimwidth( (string) $options[ $key ], 0, 60, '…' ) );
            }
        }

        $url_xac_nhan = wp_nonce_url( admin_url( 'admin-post.php?action=dawp_confirm_site_move' ), 'dawp_confirm_site_move' );
        echo '<div class="notice notice-warning dawp-notice"><p>'
            . '<strong>Duy Anh Web Pro:</strong> website này vừa đổi địa chỉ (thường do dựng từ site mẫu hoặc chuyển hosting). '
            . 'Các thông tin liên hệ dưới đây đang mang theo từ site gốc — hãy kiểm tra kẻo hiển thị nhầm số của người khác trên website của bạn:</p>'
            . ( $mang_theo ? '<p>' . implode( '<br>', $mang_theo ) . '</p>' : '<p><em>(Chưa cấu hình thông tin liên hệ nào.)</em></p>' )
            . '<p><a class="button button-primary" href="' . esc_url( admin_url( 'admin.php?page=dawp-settings&tab=contact' ) ) . '">Kiểm tra cài đặt liên hệ</a> '
            . '<a class="button" href="' . esc_url( $url_xac_nhan ) . '">Tôi đã kiểm tra xong — ẩn cảnh báo</a></p>'
            . '</div>';
    }

    public function confirm_site_move() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( 'Không đủ quyền.' );
        }
        check_admin_referer( 'dawp_confirm_site_move' );
        update_option( 'dawp_site_fingerprint', md5( strtolower( (string) wp_parse_url( home_url(), PHP_URL_HOST ) ) ), false );
        wp_safe_redirect( wp_get_referer() ? wp_get_referer() : admin_url() );
        exit;
    }

    public function add_plugin_page() {
        add_menu_page(
            'Duy Anh Web Pro', 
            'DAW Pro', 
            'manage_options', 
            'dawp-settings', 
            [ $this, 'create_admin_page' ], 
            'dashicons-superhero', 
            81
        );
    }

    public function enqueue_settings_assets( $hook_suffix ) {
        if ( $hook_suffix !== 'toplevel_page_dawp-settings' && ( ! isset( $_GET['page'] ) || $_GET['page'] !== 'dawp-settings' ) ) {
            return;
        }

        wp_enqueue_media();




    }

    public function create_admin_page() {
        require_once DAWP_DIR . 'views/view-main-settings.php';
    }

    public function page_init() {
        register_setting( 'dawp_option_group', 'dawp_settings', [ 'sanitize_callback' => [ $this, 'sanitize_settings' ] ] );
    }

    public function sanitize_settings( $input ) {
        $sanitized = [];
        if ( is_array( $input ) ) {
            // Logic kích hoạt độc lập (chọn 1 trong 2)
            if ( isset( $input['multilingual_active'] ) && $input['multilingual_active'] == '1' ) {
                $input['google_translate_active'] = '0';
            } elseif ( isset( $input['google_translate_active'] ) && $input['google_translate_active'] == '1' ) {
                $input['multilingual_active'] = '0';
            }

            foreach ( $input as $key => $value ) {
                if ( $key === 'maintenance_content' || strpos( $key, 'trans_maintenance_content_' ) === 0 ) {
                    $sanitized[$key] = wp_kses_post( $value );
                } elseif ( in_array( $key, [ 'seo_robots_txt', 'seo_htaccess', 'seo_header_code', 'seo_body_code', 'seo_footer_code', 'ps_lazy_exclude', 'ps_preconnect_domains', 'ps_defer_exclude', 'ps_delay_js_custom', 'ps_delay_js_exclude', 'ps_slim_css_safelist', 'ps_slim_css_exclude' ], true ) ) {
                    // Cho phép lưu trữ text thô để cấu hình robots.txt, .htaccess và các mã theo dõi hoạt động đúng
                    $sanitized[$key] = wp_unslash( $value );
                } elseif ( $key === 'multilingual_langs' && is_array( $value ) ) {
                    $sanitized[$key] = array_map( 'sanitize_text_field', $value );
                } elseif ( $key === 'google_translate_languages' ) {
                    // Danh sách cờ gửi lên dạng mảng checkbox. KHÔNG được để rơi xuống
                    // sanitize_text_field: hàm đó nhận mảng sẽ trả chuỗi rỗng → mọi lựa
                    // chọn bị xóa khi lưu và nút dịch rơi về 5 thứ tiếng mặc định.
                    $codes = is_array( $value ) ? $value : explode( ',', (string) $value );
                    $codes = array_filter( array_map( function ( $code ) {
                        $code = trim( (string) $code );
                        // Mã ngôn ngữ hợp lệ kiểu vi, en, zh-CN, pt-BR
                        return preg_match( '/^[a-zA-Z]{2,3}(-[a-zA-Z]{2,4})?$/', $code ) ? $code : '';
                    }, $codes ) );
                    $sanitized[$key] = implode( ',', array_unique( $codes ) );
                } elseif ( $key === 'multilingual_strings' && is_array( $value ) ) {
                    $sanitized_strings = [];
                    foreach ( $value as $item ) {
                        if ( is_array( $item ) && ! empty( $item['original'] ) ) {
                            $original = sanitize_text_field( $item['original'] );
                            $translations = [];
                            if ( isset( $item['translations'] ) && is_array( $item['translations'] ) ) {
                                foreach ( $item['translations'] as $lang => $trans_text ) {
                                    $translations[ sanitize_key( $lang ) ] = sanitize_text_field( $trans_text );
                                }
                            }
                            $sanitized_strings[] = [
                                'original'     => $original,
                                'translations' => $translations
                            ];
                        }
                    }
                    $sanitized[$key] = $sanitized_strings;
                } elseif ( $key === 'smtp_pass' ) {
                    // Ô mật khẩu luôn render trống để không lộ ra HTML admin;
                    // để trống khi lưu nghĩa là giữ nguyên mật khẩu cũ.
                    $value = trim( wp_unslash( $value ) );
                    if ( '' === $value ) {
                        $existing = get_option( 'dawp_settings', [] );
                        $value    = isset( $existing['smtp_pass'] ) ? $existing['smtp_pass'] : '';
                    }
                    $sanitized[$key] = $value;
                } else {
                    $sanitized[$key] = sanitize_text_field( $value );
                }
            }
        }
        return $sanitized;
    }

    public function test_smtp_callback() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( [ 'message' => 'Bạn không có quyền thực hiện tác vụ này!' ] );
        }

        check_ajax_referer( 'dawp_test_smtp_nonce', 'nonce' );

        $to_email = isset( $_POST['email'] ) ? sanitize_email( $_POST['email'] ) : '';
        if ( empty( $to_email ) || ! is_email( $to_email ) ) {
            wp_send_json_error( [ 'message' => 'Email nhận không hợp lệ!' ] );
        }

        $test_host = isset( $_POST['host'] ) ? sanitize_text_field( $_POST['host'] ) : '';
        $test_port = isset( $_POST['port'] ) ? sanitize_text_field( $_POST['port'] ) : '';
        $test_user = isset( $_POST['user'] ) ? sanitize_text_field( $_POST['user'] ) : '';
        $test_pass = isset( $_POST['pass'] ) ? trim( wp_unslash( $_POST['pass'] ) ) : '';
        $test_enc  = isset( $_POST['enc'] ) ? sanitize_text_field( $_POST['enc'] ) : 'ssl';
        $test_from = isset( $_POST['from_name'] ) ? sanitize_text_field( $_POST['from_name'] ) : get_bloginfo('name');

        $saved_options = get_option( 'dawp_settings', [] );

        // Ô mật khẩu trên form luôn trống (không echo lại mật khẩu đã lưu),
        // nên khi thử nghiệm mà bỏ trống thì dùng mật khẩu đang lưu.
        if ( '' === $test_pass && isset( $saved_options['smtp_pass'] ) ) {
            $test_pass = $saved_options['smtp_pass'];
        }

        if ( empty( $test_host ) || empty( $test_user ) || empty( $test_pass ) ) {
            wp_send_json_error( [ 'message' => 'Vui lòng điền đầy đủ Host, Username và Password để thử nghiệm!' ] );
        }

        $skip_verify = ! empty( $saved_options['smtp_insecure'] )
            || in_array( wp_get_environment_type(), [ 'local', 'development' ], true );

        $test_smtp_handler = function( $phpmailer ) use ( $test_host, $test_port, $test_user, $test_pass, $test_enc, $test_from, $skip_verify ) {
            try {
                $phpmailer->isSMTP();
                $phpmailer->CharSet    = 'UTF-8';
                $phpmailer->Encoding   = 'base64';
                $phpmailer->Host       = $test_host;
                $phpmailer->SMTPAuth   = true;
                $phpmailer->Port       = (int) $test_port;
                $phpmailer->Username   = $test_user;
                $phpmailer->Password   = $test_pass;
                $phpmailer->SMTPSecure = $test_enc;
                if ( $skip_verify ) {
                    $phpmailer->SMTPAutoTLS = false;
                    $phpmailer->SMTPOptions = [
                        'ssl' => [
                            'verify_peer'       => false,
                            'verify_peer_name'  => false,
                            'allow_self_signed' => true,
                        ],
                    ];
                }
                if ( is_email( $test_user ) ) {
                    $phpmailer->setFrom( $test_user, $test_from );
                    $phpmailer->Sender = $test_user;
                }
            } catch ( \Throwable $e ) {
                // Chống crash
            }
        };

        remove_all_actions( 'phpmailer_init' );
        add_action( 'phpmailer_init', $test_smtp_handler, 9999 );

        $subject = 'Duy Anh Web Pro - Thử nghiệm SMTP Mail';
        $message = "Chúc mừng bạn!\n\nEmail này được gửi thử từ chức năng kiểm tra SMTP của plugin Duy Anh Web Pro.\nHệ thống SMTP của bạn đã được cấu hình CHÍNH XÁC và hoạt động HOÀN HẢO 100%.\n\nTrân trọng,\nBan quản trị.";

        $wp_mail_error = '';
        add_action( 'wp_mail_failed', function( $error ) use ( &$wp_mail_error ) {
            if ( is_wp_error( $error ) ) {
                $wp_mail_error = $error->get_error_message();
            }
        } );

        $success = wp_mail( $to_email, $subject, $message );

        if ( $success ) {
            wp_send_json_success( [ 'message' => 'Gửi email thử nghiệm thành công! Vui lòng kiểm tra Hộp thư đến (Inbox) hoặc Thư rác (Spam) của email ' . $to_email ] );
        } else {
            global $phpmailer;
            $err_msg = 'Gửi email thất bại. Vui lòng kiểm tra lại cấu hình SMTP, cổng kết nối hoặc mật khẩu ứng dụng!';
            if ( ! empty( $wp_mail_error ) ) {
                $err_msg .= ' Lỗi cụ thể: ' . $wp_mail_error;
            } elseif ( isset( $phpmailer->ErrorInfo ) && ! empty( $phpmailer->ErrorInfo ) ) {
                $err_msg .= ' Lỗi cụ thể: ' . $phpmailer->ErrorInfo;
            }
            wp_send_json_error( [ 'message' => $err_msg ] );
        }
    }

    /**
     * AJAX callback xử lý dọn dẹp bình luận siêu tốc
     */
    public function clean_comments_callback() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( [ 'message' => 'Bạn không có quyền thực hiện tác vụ này!' ] );
        }

        check_ajax_referer( 'dawp_clean_comments_nonce', 'nonce' );

        // Nạp file security class nếu chưa được nạp
        $security_file = DAWP_MODULES_DIR . 'security/class-security.php';
        if ( file_exists( $security_file ) ) {
            require_once $security_file;
        }

        if ( class_exists( 'DAWP_Security' ) ) {
            DAWP_Security::clean_all_comments();
            wp_send_json_success( [ 'message' => 'Đã dọn dẹp và xóa sạch 100% bình luận trong cơ sở dữ liệu thành công!' ] );
        } else {
            wp_send_json_error( [ 'message' => 'Không tìm thấy class xử lý bảo mật!' ] );
        }
    }

    /**
     * AJAX callback quét cơ sở dữ liệu tìm mã độc chrome-extension
     */
    public function scan_db_callback() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( [ 'message' => 'Bạn không có quyền thực hiện tác vụ này!' ] );
        }

        check_ajax_referer( 'dawp_db_cleaner_nonce', 'nonce' );

        $security_file = DAWP_MODULES_DIR . 'security/class-security.php';
        if ( file_exists( $security_file ) ) {
            require_once $security_file;
        }

        if ( class_exists( 'DAWP_Security' ) ) {
            $infected = DAWP_Security::scan_infected_posts();
            wp_send_json_success( [
                'count' => count( $infected ),
                'posts' => $infected
            ] );
        } else {
            wp_send_json_error( [ 'message' => 'Không tìm thấy class xử lý bảo mật!' ] );
        }
    }

    /**
     * AJAX callback làm sạch mã độc chrome-extension trong cơ sở dữ liệu
     */
    public function clean_db_callback() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( [ 'message' => 'Bạn không có quyền thực hiện tác vụ này!' ] );
        }

        check_ajax_referer( 'dawp_db_cleaner_nonce', 'nonce' );

        $security_file = DAWP_MODULES_DIR . 'security/class-security.php';
        if ( file_exists( $security_file ) ) {
            require_once $security_file;
        }

        if ( class_exists( 'DAWP_Security' ) ) {
            $result = DAWP_Security::clean_infected_posts();
            wp_send_json_success( [
                'message' => 'Đã làm sạch thành công ' . $result['count'] . ' bài viết bị nhiễm mã độc!',
                'count'   => $result['count'],
                'cleaned' => $result['cleaned']
            ] );
        } else {
            wp_send_json_error( [ 'message' => 'Không tìm thấy class xử lý bảo mật!' ] );
        }
    }

    /**
     * AJAX callback thêm một redirect 301 thủ công
     */
    public function add_redirect_callback() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( [ 'message' => 'Bạn không có quyền thực hiện!' ] );
        }
        check_ajax_referer( 'dawp_seo_actions_nonce', 'nonce' );

        $old_url = isset($_POST['old_url']) ? trim(sanitize_text_field($_POST['old_url'])) : '';
        $new_url = isset($_POST['new_url']) ? trim(sanitize_text_field($_POST['new_url'])) : '';

        if ( empty($old_url) || empty($new_url) ) {
            wp_send_json_error( [ 'message' => 'Vui lòng nhập đầy đủ link cũ và link mới!' ] );
        }

        // Tự động chuẩn hóa: Chỉ giữ lại đường dẫn tương đối (bắt đầu bằng dấu /) nếu là link nội bộ
        $home_url = home_url();
        $old_url = str_replace($home_url, '', $old_url);
        if (strpos($old_url, 'http') !== 0 && strpos($old_url, '/') !== 0) {
            $old_url = '/' . $old_url;
        }

        global $wpdb;
        $table_name = $wpdb->prefix . 'dawp_redirects';

        // Kiểm tra xem đã tồn tại link cũ này chưa
        $exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM $table_name WHERE old_url = %s LIMIT 1", $old_url));
        if ($exists) {
            wp_send_json_error( [ 'message' => 'Đường dẫn cũ này đã được cấu hình chuyển hướng trước đó!' ] );
        }

        $inserted = $wpdb->insert(
            $table_name,
            [
                'old_url' => $old_url,
                'new_url' => $new_url,
                'type'    => '301'
            ],
            [ '%s', '%s', '%s' ]
        );

        if ( $inserted ) {
            wp_send_json_success( [ 'message' => 'Đã thêm chuyển hướng thành công!', 'id' => $wpdb->insert_id ] );
        } else {
            wp_send_json_error( [ 'message' => 'Lỗi cơ sở dữ liệu, không thể lưu!' ] );
        }
    }

    /**
     * AJAX callback xóa một redirect
     */
    public function delete_redirect_callback() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( [ 'message' => 'Bạn không có quyền!' ] );
        }
        check_ajax_referer( 'dawp_seo_actions_nonce', 'nonce' );

        $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
        if ( $id ) {
            global $wpdb;
            $table_name = $wpdb->prefix . 'dawp_redirects';
            $wpdb->delete( $table_name, [ 'id' => $id ], [ '%d' ] );
            wp_send_json_success( [ 'message' => 'Đã xóa chuyển hướng thành công!' ] );
        }
        wp_send_json_error( [ 'message' => 'ID chuyển hướng không hợp lệ!' ] );
    }

    /**
     * AJAX callback xóa một dòng 404 log
     */
    public function delete_404_callback() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( [ 'message' => 'Bạn không có quyền!' ] );
        }
        check_ajax_referer( 'dawp_seo_actions_nonce', 'nonce' );

        $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
        if ( $id ) {
            global $wpdb;
            $table_name = $wpdb->prefix . 'dawp_404_logs';
            $wpdb->delete( $table_name, [ 'id' => $id ], [ '%d' ] );
            wp_send_json_success( [ 'message' => 'Đã xóa log 404 thành công!' ] );
        }
        wp_send_json_error( [ 'message' => 'ID log không hợp lệ!' ] );
    }

    /**
     * AJAX callback dọn sạch bảng 404 logs
     */
    public function clear_404_callback() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( [ 'message' => 'Bạn không có quyền!' ] );
        }
        check_ajax_referer( 'dawp_seo_actions_nonce', 'nonce' );

        global $wpdb;
        $table_name = $wpdb->prefix . 'dawp_404_logs';
        $wpdb->query( "TRUNCATE TABLE $table_name" );
        wp_send_json_success( [ 'message' => 'Đã dọn sạch lịch sử lỗi 404!' ] );
    }

    /**
     * Đồng bộ hóa quy tắc .htaccess khi có sự thay đổi cấu hình lưu vào DB
     */
    public function trigger_htaccess_update( $old_value, $new_value = null ) {
        if ( class_exists( 'DAWP_Optimization' ) ) {
            DAWP_Optimization::update_htaccess_rules();
            $opt = new DAWP_Optimization();
            $opt->clear_static_cache();
        } else {
            $optimization_file = DAWP_MODULES_DIR . 'optimization/class-optimization.php';
            if ( file_exists( $optimization_file ) ) {
                require_once $optimization_file;
                DAWP_Optimization::update_htaccess_rules();
                $opt = new DAWP_Optimization();
                $opt->clear_static_cache();
            }
        }
    }

    /**
     * AJAX callback to check for Yoast/Rank Math database statistics
     */
    public function get_migration_stats_callback() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( [ 'message' => 'Bạn không có quyền!' ] );
        }
        check_ajax_referer( 'dawp_seo_migration_nonce', 'nonce' );

        global $wpdb;

        // Yoast check
        $yoast_count = 0;
        $yoast_keys = [
            '_yoast_wpseo_title', 
            '_yoast_wpseo_metadesc', 
            '_yoast_wpseo_opengraph-title', 
            '_yoast_wpseo_opengraph-description', 
            '_yoast_wpseo_opengraph-image'
        ];
        $yoast_keys_str = "'" . implode("','", $yoast_keys) . "'";
        $yoast_count = (int) $wpdb->get_var( "SELECT COUNT(DISTINCT post_id) FROM {$wpdb->postmeta} WHERE meta_key IN ($yoast_keys_str)" );

        // Rank Math check
        $rm_count = 0;
        $rm_keys = [
            'rank_math_title', 
            'rank_math_description', 
            'rank_math_facebook_title', 
            'rank_math_facebook_description', 
            'rank_math_facebook_image'
        ];
        $rm_keys_str = "'" . implode("','", $rm_keys) . "'";
        $rm_count = (int) $wpdb->get_var( "SELECT COUNT(DISTINCT post_id) FROM {$wpdb->postmeta} WHERE meta_key IN ($rm_keys_str)" );

        wp_send_json_success([
            'yoast_count' => $yoast_count,
            'rm_count'    => $rm_count
        ]);
    }

    /**
     * AJAX callback to perform batch migration
     */
    public function migrate_seo_callback() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( [ 'message' => 'Bạn không có quyền thực hiện!' ] );
        }
        check_ajax_referer( 'dawp_seo_migration_nonce', 'nonce' );

        $source = isset( $_POST['source'] ) ? sanitize_text_field( $_POST['source'] ) : '';
        $offset = isset( $_POST['offset'] ) ? (int) $_POST['offset'] : 0;
        $batch_size = isset( $_POST['batch_size'] ) ? (int) $_POST['batch_size'] : 100;
        $overwrite = isset( $_POST['overwrite'] ) && $_POST['overwrite'] === 'true';

        if ( ! in_array( $source, [ 'yoast', 'rank_math' ] ) ) {
            wp_send_json_error( [ 'message' => 'Nguồn dữ liệu không hợp lệ!' ] );
        }

        global $wpdb;

        // Define keys based on source
        if ( $source === 'yoast' ) {
            $keys = [
                '_yoast_wpseo_title', 
                '_yoast_wpseo_metadesc', 
                '_yoast_wpseo_opengraph-title', 
                '_yoast_wpseo_opengraph-description', 
                '_yoast_wpseo_opengraph-image'
            ];
        } else {
            $keys = [
                'rank_math_title', 
                'rank_math_description', 
                'rank_math_facebook_title', 
                'rank_math_facebook_description', 
                'rank_math_facebook_image'
            ];
        }

        $keys_str = "'" . implode("','", $keys) . "'";

        // Retrieve post IDs in batch
        $post_ids = $wpdb->get_col( $wpdb->prepare(
            "SELECT DISTINCT post_id FROM {$wpdb->postmeta} WHERE meta_key IN ($keys_str) ORDER BY post_id ASC LIMIT %d OFFSET %d",
            $batch_size,
            $offset
        ) );

        if ( empty( $post_ids ) ) {
            wp_send_json_success( [ 'processed' => 0, 'completed' => true ] );
        }

        $processed = 0;
        $migrated = 0;

        foreach ( $post_ids as $post_id ) {
            $processed++;

            // If not overwrite, skip if we already have DAW Pro SEO data
            if ( ! $overwrite ) {
                $existing = get_post_meta( $post_id, '_dawp_seo_title', true ) || get_post_meta( $post_id, '_dawp_seo_desc', true );
                if ( $existing ) {
                    continue;
                }
            }

            if ( $source === 'yoast' ) {
                // Yoast Migration mapping
                $title     = get_post_meta( $post_id, '_yoast_wpseo_title', true );
                $desc      = get_post_meta( $post_id, '_yoast_wpseo_metadesc', true );
                $keyword   = get_post_meta( $post_id, '_yoast_wpseo_focuskw', true );
                $canonical = get_post_meta( $post_id, '_yoast_wpseo_canonical', true );
                $noindex   = get_post_meta( $post_id, '_yoast_wpseo_meta-robots-noindex', true );
                $nofollow  = get_post_meta( $post_id, '_yoast_wpseo_meta-robots-nofollow', true );
                
                // Opengraph (Facebook/Zalo)
                $og_title  = get_post_meta( $post_id, '_yoast_wpseo_opengraph-title', true );
                $og_desc   = get_post_meta( $post_id, '_yoast_wpseo_opengraph-description', true );
                $og_image  = get_post_meta( $post_id, '_yoast_wpseo_opengraph-image', true );
                if ( empty( $og_image ) ) {
                    $og_image_id = get_post_meta( $post_id, '_yoast_wpseo_opengraph-image-id', true );
                    if ( ! empty( $og_image_id ) ) {
                        $og_image = wp_get_attachment_image_url( $og_image_id, 'full' );
                    }
                }

                // Twitter fallback if Facebook is empty
                if ( empty( $og_title ) ) {
                    $og_title = get_post_meta( $post_id, '_yoast_wpseo_twitter-title', true );
                }
                if ( empty( $og_desc ) ) {
                    $og_desc = get_post_meta( $post_id, '_yoast_wpseo_twitter-description', true );
                }
                if ( empty( $og_image ) ) {
                    $og_image = get_post_meta( $post_id, '_yoast_wpseo_twitter-image', true );
                    if ( empty( $og_image ) ) {
                        $og_image_id = get_post_meta( $post_id, '_yoast_wpseo_twitter-image-id', true );
                        if ( ! empty( $og_image_id ) ) {
                            $og_image = wp_get_attachment_image_url( $og_image_id, 'full' );
                        }
                    }
                }

                // Map noindex/nofollow (Yoast stores "1" / "2" or text)
                $dawp_noindex = ( $noindex == '1' || $noindex === 'noindex' ) ? 1 : 0;
                $dawp_nofollow = ( $nofollow == '1' || $nofollow === 'nofollow' ) ? 1 : 0;

            } else {
                // Rank Math Migration mapping
                $title     = get_post_meta( $post_id, 'rank_math_title', true );
                $desc      = get_post_meta( $post_id, 'rank_math_description', true );
                $keyword   = get_post_meta( $post_id, 'rank_math_focus_keyword', true );
                $canonical = get_post_meta( $post_id, 'rank_math_canonical_url', true );
                $robots    = get_post_meta( $post_id, 'rank_math_robots', true );
                
                // Facebook
                $og_title  = get_post_meta( $post_id, 'rank_math_facebook_title', true );
                $og_desc   = get_post_meta( $post_id, 'rank_math_facebook_description', true );
                $og_image  = get_post_meta( $post_id, 'rank_math_facebook_image', true );
                if ( empty( $og_image ) ) {
                    $og_image_id = get_post_meta( $post_id, 'rank_math_facebook_image_id', true );
                    if ( ! empty( $og_image_id ) ) {
                        $og_image = wp_get_attachment_image_url( $og_image_id, 'full' );
                    }
                }

                // Twitter fallback if Facebook is empty
                if ( empty( $og_title ) ) {
                    $og_title = get_post_meta( $post_id, 'rank_math_twitter_title', true );
                }
                if ( empty( $og_desc ) ) {
                    $og_desc = get_post_meta( $post_id, 'rank_math_twitter_description', true );
                }
                if ( empty( $og_image ) ) {
                    $og_image = get_post_meta( $post_id, 'rank_math_twitter_image', true );
                    if ( empty( $og_image ) ) {
                        $og_image_id = get_post_meta( $post_id, 'rank_math_twitter_image_id', true );
                        if ( ! empty( $og_image_id ) ) {
                            $og_image = wp_get_attachment_image_url( $og_image_id, 'full' );
                        }
                    }
                }

                // Map noindex/nofollow from robots array/string
                $dawp_noindex = 0;
                $dawp_nofollow = 0;
                if ( is_array( $robots ) ) {
                    $dawp_noindex = in_array( 'noindex', $robots ) ? 1 : 0;
                    $dawp_nofollow = in_array( 'nofollow', $robots ) ? 1 : 0;
                } elseif ( is_string( $robots ) ) {
                    $dawp_noindex = ( stripos( $robots, 'noindex' ) !== false ) ? 1 : 0;
                    $dawp_nofollow = ( stripos( $robots, 'nofollow' ) !== false ) ? 1 : 0;
                }
            }

            // Fallback for social metadata if empty in the database
            if ( empty( $og_title ) ) {
                $og_title = ! empty( $title ) ? $title : get_the_title( $post_id );
            }
            if ( empty( $og_desc ) ) {
                $og_desc = ! empty( $desc ) ? $desc : wp_strip_all_tags( wp_trim_words( get_post_field( 'post_content', $post_id ), 30 ) );
            }
            if ( empty( $og_image ) ) {
                if ( has_post_thumbnail( $post_id ) ) {
                    $og_image = wp_get_attachment_image_url( get_post_thumbnail_id( $post_id ), 'full' );
                }
            }

            // Convert placeholder variables to static values
            $title    = $this->convert_seo_placeholders( $title, $post_id );
            $desc     = $this->convert_seo_placeholders( $desc, $post_id );
            $og_title = $this->convert_seo_placeholders( $og_title, $post_id );
            $og_desc  = $this->convert_seo_placeholders( $og_desc, $post_id );

            // Save values
            if ( ! empty( $title ) ) {
                update_post_meta( $post_id, '_dawp_seo_title', sanitize_text_field( $title ) );
            }
            if ( ! empty( $desc ) ) {
                update_post_meta( $post_id, '_dawp_seo_desc', sanitize_text_field( $desc ) );
            }
            if ( ! empty( $keyword ) ) {
                update_post_meta( $post_id, '_dawp_seo_keyword', sanitize_text_field( $keyword ) );
            }
            if ( ! empty( $canonical ) ) {
                update_post_meta( $post_id, '_dawp_seo_canonical', esc_url_raw( $canonical ) );
            }
            
            update_post_meta( $post_id, '_dawp_seo_noindex', $dawp_noindex );
            update_post_meta( $post_id, '_dawp_seo_nofollow', $dawp_nofollow );

            if ( ! empty( $og_title ) ) {
                update_post_meta( $post_id, '_dawp_seo_og_title', sanitize_text_field( $og_title ) );
            }
            if ( ! empty( $og_desc ) ) {
                update_post_meta( $post_id, '_dawp_seo_og_desc', sanitize_text_field( $og_desc ) );
            }
            if ( ! empty( $og_image ) ) {
                update_post_meta( $post_id, '_dawp_seo_og_image', esc_url_raw( $og_image ) );
            }

            $migrated++;
        }

        wp_send_json_success( [
            'processed' => $processed,
            'migrated'  => $migrated,
            'completed' => count( $post_ids ) < $batch_size
        ] );
    }

    /**
     * Helper to statically convert template variable placeholders
     */
    private function convert_seo_placeholders( $string, $post_id ) {
        if ( empty( $string ) ) {
            return '';
        }

        $post = get_post( $post_id );
        if ( ! $post ) {
            return $string;
        }

        $title = get_the_title( $post_id );
        $sitename = get_bloginfo( 'name' );
        $excerpt = $post->post_excerpt;
        if ( empty( $excerpt ) ) {
            $excerpt = wp_strip_all_tags( wp_trim_words( $post->post_content, 30 ) );
        }
        
        // Yoast replacements
        $yoast_replacements = [
            '%%title%%'            => $title,
            '%%sep%%'              => '-',
            '%%sitename%%'         => $sitename,
            '%%sitedesc%%'         => get_bloginfo( 'description' ),
            '%%excerpt%%'          => $excerpt,
            '%%primary_category%%' => '',
            '%%category%%'         => '',
            '%%tag%%'              => '',
            '%%modified%%'         => get_the_modified_date( '', $post_id ),
            '%%date%%'             => get_the_date( '', $post_id ),
            '%%author%%'           => get_the_author_meta( 'display_name', $post->post_author ),
        ];

        $categories = get_the_category( $post_id );
        if ( ! empty( $categories ) && ! is_wp_error( $categories ) ) {
            $yoast_replacements['%%primary_category%%'] = $categories[0]->name;
            $yoast_replacements['%%category%%'] = $categories[0]->name;
        }
        
        $tags = get_the_tags( $post_id );
        if ( ! empty( $tags ) && ! is_wp_error( $tags ) ) {
            $yoast_replacements['%%tag%%'] = $tags[0]->name;
        }

        foreach ( $yoast_replacements as $placeholder => $value ) {
            $string = str_replace( $placeholder, $value, $string );
        }

        // Rank Math replacements
        $rm_replacements = [
            '%title%'            => $title,
            '%sep%'              => '-',
            '%sitename%'         => $sitename,
            '%sitedesc%'         => get_bloginfo( 'description' ),
            '%excerpt%'          => $excerpt,
            '%primary_category%' => isset($yoast_replacements['%%primary_category%%']) ? $yoast_replacements['%%primary_category%%'] : '',
            '%category%'         => isset($yoast_replacements['%%category%%']) ? $yoast_replacements['%%category%%'] : '',
            '%tag%'              => isset($yoast_replacements['%%tag%%']) ? $yoast_replacements['%%tag%%'] : '',
            '%modified%'         => get_the_modified_date( '', $post_id ),
            '%date%'             => get_the_date( '', $post_id ),
            '%author%'           => get_the_author_meta( 'display_name', $post->post_author ),
        ];

        foreach ( $rm_replacements as $placeholder => $value ) {
            $string = str_replace( $placeholder, $value, $string );
        }

        $string = preg_replace( '/\s+/', ' ', $string );
        $string = trim( $string );

        return $string;
    }
}
