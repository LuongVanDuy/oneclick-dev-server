jQuery(document).ready(function($) {
    var titleInput = $('#dawp_seo_title');
    var descInput = $('#dawp_seo_desc');
    var keywordInput = $('#dawp_seo_keyword');

    // Các thành phần preview
    var previewTitle = $('#dawp-snippet-title');
    var previewDesc = $('#dawp-snippet-desc');

    // Các bộ đếm & progress bar
    var titleCounter = $('#dawp-title-counter');
    var descCounter = $('#dawp-desc-counter');
    var titleProgress = $('#dawp-title-progress');
    var descProgress = $('#dawp-desc-progress');

    // Bảng checklist phân tích
    var analysisList = $('#dawp-seo-analysis-list');
    var readList = $('#dawp-read-analysis-list');

    // Lấy thông tin bài viết từ đối tượng localize truyền qua PHP
    var postData = typeof dawpSeoData !== 'undefined' ? dawpSeoData : {
        postTitle: '', postContent: '', postSlug: '', permalink: ''
    };

    // Lấy nội dung HTML thô (giữ thẻ) để phân tích cấu trúc (heading, đoạn văn, ảnh)
    function getEditorContentHTML() {
        var content = '';
        if (typeof wp !== 'undefined' && wp.data && wp.data.select('core/editor')) {
            content = wp.data.select('core/editor').getEditedPostContent() || '';
        } else if (typeof tinyMCE !== 'undefined' && tinyMCE.get('content') && !tinyMCE.get('content').isHidden()) {
            content = tinyMCE.get('content').getContent();
        } else {
            content = $('#content').val() || '';
        }
        return content;
    }

    // Lấy nội dung dạng văn bản thuần (bỏ thẻ) để đếm từ/câu
    function getEditorContent() {
        return getEditorContentHTML().replace(/<\/?[^>]+(>|$)/g, ' ');
    }

    function getPostSlug() {
        return $('#post_name').val() || postData.postSlug || '';
    }

    function getWordCount(str) {
        if (!str || str.trim() === '') return 0;
        return str.trim().split(/\s+/).filter(Boolean).length;
    }

    function countKeywordDensity(content, keyword) {
        var words = getWordCount(content);
        if (words === 0) return 0;
        var esc = keyword.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');
        var regex = new RegExp(esc, 'g');
        var matches = content.match(regex);
        return ((matches ? matches.length : 0) / words) * 100;
    }

    // ================= Đồng hồ điểm =================
    function scoreColor(score) {
        if (score >= 80) return '#10b981';
        if (score >= 50) return '#f59e0b';
        return '#ef4444';
    }
    function scoreLabel(score) {
        if (score >= 80) return 'Tốt';
        if (score >= 50) return 'Cần cải thiện';
        return 'Kém';
    }
    function setGauge(gaugeId, numId, labelId, subId, score, subText) {
        var color = scoreColor(score);
        var g = document.getElementById(gaugeId);
        if (g) { g.style.setProperty('--v', score); g.style.setProperty('--c', color); }
        var num = document.getElementById(numId);
        if (num) { num.textContent = score; num.style.color = color; }
        var lbl = document.getElementById(labelId);
        if (lbl) { lbl.textContent = scoreLabel(score); lbl.style.color = color; }
        var sub = document.getElementById(subId);
        if (sub && subText) sub.textContent = subText;
    }

    // Render 1 danh sách check ra HTML. Mỗi item: {state:'good'|'bad'|'na', msg}
    function renderChecks(list, items) {
        var icon = { good: '🟢', bad: '🔴', na: '⚪' };
        var col = { good: '#10b981', bad: '#ef4444', na: '#94a3b8' };
        var html = '';
        items.forEach(function(it) {
            html += '<li style="color:' + col[it.state] + ';">' +
                    '<span style="font-size:15px;line-height:1.4;">' + icon[it.state] + '</span>' +
                    '<span>' + it.msg + '</span></li>';
        });
        list.html(html);
    }

    // ================= Phân tích SEO =================
    function runSeoAnalysis() {
        var keyword = keywordInput.val().trim().toLowerCase();
        if (keyword === '') {
            analysisList.html('<li style="color:#64748b;font-style:italic;">⚠️ Nhập Từ khóa chính ở trên để chấm điểm SEO.</li>');
            setGauge('dawp-seo-gauge', 'dawp-seo-score-num', 'dawp-seo-score-label', 'dawp-seo-score-sub', 0, 'Nhập từ khóa chính để chấm điểm');
            return;
        }

        var seoTitle = (titleInput.val() || $('#title').val() || postData.postTitle).toLowerCase();
        var seoDesc = descInput.val().toLowerCase();
        var slug = getPostSlug().toLowerCase();
        var html = getEditorContentHTML();
        var content = getEditorContent().toLowerCase();
        var words = getWordCount(getEditorContent());
        var density = countKeywordDensity(content, keyword);

        // Đoạn văn đầu tiên
        var firstPara = '';
        var pMatch = html.match(/<p[^>]*>([\s\S]*?)<\/p>/i);
        if (pMatch) firstPara = pMatch[1].replace(/<\/?[^>]+(>|$)/g, ' ').toLowerCase();
        else firstPara = content.slice(0, 160);

        // Tiêu đề phụ H2/H3
        var headings = html.match(/<h[23][^>]*>([\s\S]*?)<\/h[23]>/gi) || [];
        var headingText = headings.join(' ').replace(/<\/?[^>]+(>|$)/g, ' ').toLowerCase();

        // Ảnh + alt
        var imgs = html.match(/<img[^>]*>/gi) || [];
        var imgWithKwAlt = imgs.some(function(t) {
            var m = t.match(/alt\s*=\s*["']([^"']*)["']/i);
            return m && m[1].toLowerCase().indexOf(keyword) !== -1;
        });

        var titleLen = (titleInput.val() || '').length;
        var descLen = (descInput.val() || '').length;

        var checks = [
            { state: seoTitle.indexOf(keyword) !== -1 ? 'good' : 'bad',
              msg: seoTitle.indexOf(keyword) !== -1 ? 'Từ khóa có trong Tiêu đề SEO.' : 'Chưa có từ khóa trong Tiêu đề SEO (nên đặt gần đầu).' },
            { state: (titleLen >= 45 && titleLen <= 60) ? 'good' : 'na',
              msg: (titleLen >= 45 && titleLen <= 60) ? 'Độ dài Tiêu đề SEO tối ưu (' + titleLen + ' ký tự).' : 'Tiêu đề SEO nên dài 45–60 ký tự (hiện ' + titleLen + ').' },
            { state: seoDesc.indexOf(keyword) !== -1 ? 'good' : 'bad',
              msg: seoDesc.indexOf(keyword) !== -1 ? 'Mô tả Meta có chứa từ khóa.' : 'Chưa có từ khóa trong Mô tả Meta (tăng CTR).' },
            { state: (descLen >= 120 && descLen <= 160) ? 'good' : 'na',
              msg: (descLen >= 120 && descLen <= 160) ? 'Độ dài Mô tả Meta tối ưu (' + descLen + ' ký tự).' : 'Mô tả Meta nên dài 120–160 ký tự (hiện ' + descLen + ').' },
            { state: slug.replace(/-/g, ' ').indexOf(keyword) !== -1 ? 'good' : 'bad',
              msg: slug.replace(/-/g, ' ').indexOf(keyword) !== -1 ? 'Đường dẫn URL chứa từ khóa.' : 'Đường dẫn URL (slug) chưa chứa từ khóa.' },
            { state: firstPara.indexOf(keyword) !== -1 ? 'good' : 'bad',
              msg: firstPara.indexOf(keyword) !== -1 ? 'Từ khóa xuất hiện trong đoạn mở đầu.' : 'Nên đưa từ khóa vào đoạn văn đầu tiên.' },
            { state: headingText.indexOf(keyword) !== -1 ? 'good' : (headings.length ? 'bad' : 'na'),
              msg: headingText.indexOf(keyword) !== -1 ? 'Từ khóa có trong tiêu đề phụ (H2/H3).' : (headings.length ? 'Nên đưa từ khóa vào ít nhất 1 tiêu đề phụ.' : 'Chưa có tiêu đề phụ H2/H3 để chèn từ khóa.') },
            { state: words >= 300 ? 'good' : 'bad',
              msg: words >= 300 ? 'Độ dài nội dung tốt (' + words + ' từ).' : 'Nội dung hơi ngắn (' + words + ' từ). Nên ≥ 300 từ.' },
            { state: (density >= 0.5 && density <= 3) ? 'good' : 'bad',
              msg: (density >= 0.5 && density <= 3) ? 'Mật độ từ khóa hợp lý (' + density.toFixed(2) + '%).' : (density < 0.5 ? 'Mật độ từ khóa thấp (' + density.toFixed(2) + '%). Nhắc lại thêm.' : 'Mật độ từ khóa cao (' + density.toFixed(2) + '%). Tránh nhồi nhét.') },
            { state: imgs.length === 0 ? 'na' : (imgWithKwAlt ? 'good' : 'bad'),
              msg: imgs.length === 0 ? 'Chưa có hình ảnh trong bài (nên thêm ảnh minh họa).' : (imgWithKwAlt ? 'Có ảnh với thuộc tính alt chứa từ khóa.' : 'Nên đặt alt chứa từ khóa cho ít nhất 1 ảnh.') }
        ];

        renderChecks(analysisList, checks);

        var good = checks.filter(function(c){ return c.state === 'good'; }).length;
        var counted = checks.filter(function(c){ return c.state !== 'na'; }).length;
        var score = counted ? Math.round(good / counted * 100) : 0;
        setGauge('dawp-seo-gauge', 'dawp-seo-score-num', 'dawp-seo-score-label', 'dawp-seo-score-sub', score, good + '/' + counted + ' tiêu chí đạt');
    }

    // ================= Phân tích Dễ đọc =================
    function runReadability() {
        var html = getEditorContentHTML();
        var text = getEditorContent().replace(/\s+/g, ' ').trim();
        var words = getWordCount(text);

        if (words < 20) {
            readList.html('<li style="color:#64748b;font-style:italic;">⚠️ Viết thêm nội dung để đánh giá độ dễ đọc.</li>');
            setGauge('dawp-read-gauge', 'dawp-read-score-num', 'dawp-read-score-label', 'dawp-read-score-sub', 0, 'Nội dung chưa đủ để đánh giá');
            return;
        }

        // Tách câu
        var sentences = text.split(/[.!?…]+/).map(function(s){ return s.trim(); }).filter(function(s){ return getWordCount(s) > 0; });
        var sentCount = sentences.length || 1;
        var avgWords = words / sentCount;
        var longSentences = sentences.filter(function(s){ return getWordCount(s) > 25; }).length;
        var longPct = longSentences / sentCount * 100;

        // Đoạn văn (từ HTML nếu có <p>, nếu không tách theo xuống dòng)
        var paras = (html.match(/<p[^>]*>([\s\S]*?)<\/p>/gi) || []).map(function(p){ return p.replace(/<\/?[^>]+(>|$)/g, ' '); });
        if (!paras.length) paras = text.split(/\n{1,}/);
        var maxPara = 0;
        paras.forEach(function(p){ var w = getWordCount(p); if (w > maxPara) maxPara = w; });

        // Tiêu đề phụ
        var headings = (html.match(/<h[23][^>]*>/gi) || []).length;

        var checks = [
            { state: words >= 300 ? 'good' : (words >= 150 ? 'na' : 'bad'),
              msg: 'Độ dài bài viết: ' + words + ' từ' + (words >= 300 ? ' (tốt).' : (words >= 150 ? ' (tạm ổn, nên dài hơn).' : ' (quá ngắn).')) },
            { state: avgWords <= 20 ? 'good' : (avgWords <= 25 ? 'na' : 'bad'),
              msg: 'Độ dài câu trung bình: ' + avgWords.toFixed(1) + ' từ/câu' + (avgWords <= 20 ? ' (dễ đọc).' : ' (nên viết câu ngắn hơn).') },
            { state: longPct <= 25 ? 'good' : (longPct <= 40 ? 'na' : 'bad'),
              msg: longPct.toFixed(0) + '% câu dài trên 25 từ' + (longPct <= 25 ? ' (tốt).' : ' (nên chia nhỏ câu dài).') },
            { state: maxPara <= 150 ? 'good' : (maxPara <= 200 ? 'na' : 'bad'),
              msg: 'Đoạn văn dài nhất: ' + maxPara + ' từ' + (maxPara <= 150 ? ' (tốt).' : ' (nên tách đoạn ngắn hơn).') },
            { state: (words < 300) ? 'na' : (headings > 0 ? 'good' : 'bad'),
              msg: headings > 0 ? ('Có ' + headings + ' tiêu đề phụ (H2/H3) giúp dễ theo dõi.') : (words < 300 ? 'Bài ngắn chưa cần tiêu đề phụ.' : 'Nên thêm tiêu đề phụ H2/H3 để chia mục.') }
        ];

        renderChecks(readList, checks);

        var good = checks.filter(function(c){ return c.state === 'good'; }).length;
        var counted = checks.filter(function(c){ return c.state !== 'na'; }).length;
        var score = counted ? Math.round(good / counted * 100) : 100;
        setGauge('dawp-read-gauge', 'dawp-read-score-num', 'dawp-read-score-label', 'dawp-read-score-sub', score, good + '/' + counted + ' tiêu chí đạt');
    }

    // ================= Tự động tối ưu trình bày (Dễ đọc) =================
    function wc(str) { return getWordCount(str); }

    // Các từ chuyển ý có thể ĐỨNG ĐẦU CÂU một cách tự nhiên.
    // Chỉ tách trước những từ này (hoặc tại dấu chấm phẩy) để câu sau không bị "chuối".
    var DAWP_TRANSITIONS = [
        'tuy nhiên', 'do đó', 'vì vậy', 'vì thế', 'chính vì vậy', 'chính vì thế',
        'ngoài ra', 'bên cạnh đó', 'hơn nữa', 'mặt khác', 'đồng thời', 'trong khi đó',
        'nhờ đó', 'không những vậy', 'đặc biệt', 'cụ thể', 'ví dụ', 'chẳng hạn',
        'sau đó', 'trước tiên', 'đầu tiên', 'cuối cùng', 'tiếp theo', 'thứ nhất',
        'thứ hai', 'thứ ba', 'nói cách khác', 'nhìn chung', 'tóm lại', 'nhưng', 'song'
    ];

    // Chuẩn hóa bỏ dấu để so khớp từ chuyển ý không phụ thuộc dấu tiếng Việt
    function stripTones(s) {
        return s.normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/đ/g, 'd').replace(/Đ/g, 'D').toLowerCase();
    }

    // Từ mở đầu gây câu CỤT nếu đứng sau khi tách (không có chủ ngữ độc lập)
    var DAWP_BAD_STARTERS = ['va', 'hoac', 'hay', 'cua', 'de', 'cho', 'voi', 'trong', 'ngoai',
        'nham', 'khien', 'giup', 'ma', 'nen', 'roi', 'cung', 'theo', 'nhu', 'boi', 'tu', 've',
        'tren', 'duoi', 'qua', 'bang', 'do', 'tai', 'vao', 'moi', 'cac', 'o', 'la'];

    // Từ mở đầu MỆNH ĐỀ PHỤ: nếu vế TRÁI bắt đầu bằng chúng, tách sẽ tạo mảnh cụt bên trái
    var DAWP_SUBORDINATORS = ['khi', 'neu', 'vi', 'do', 'boi', 'du', 'mac', 'tuy', 'de', 'sau',
        'truoc', 'trong', 'nham', 'gia', 'he', 'mien', 'voi', 'giup', 'khien', 'dau'];

    function startsWithTransition(afterLow) {
        for (var i = 0; i < DAWP_TRANSITIONS.length; i++) {
            var t = stripTones(DAWP_TRANSITIONS[i]);
            if (afterLow.indexOf(t) === 0) {
                var ch = afterLow.charAt(t.length);
                if (ch === '' || ch === ' ' || ch === ',') return true;
            }
        }
        return false;
    }

    // Tìm các vị trí AN TOÀN để tách câu:
    //  - trước từ chuyển ý (tuy nhiên, do đó...) hoặc dấu chấm phẩy: luôn an toàn
    //  - dấu phẩy khác: chỉ khi vế sau có chủ ngữ rõ (không bắt đầu bằng từ gây cụt)
    //    và vế trái KHÔNG phải mệnh đề phụ
    function findSafeSplits(core) {
        var res = [];
        var low = stripTones(core);

        var re = /;/g, m;
        while ((m = re.exec(core)) !== null) res.push(m.index);

        var reC = /,/g, mc;
        while ((mc = reC.exec(core)) !== null) {
            var idx = mc.index;
            var afterLow = low.slice(idx + 1).replace(/^\s+/, '');
            var firstWord = afterLow.split(/\s+/)[0] || '';
            var leftLow = low.slice(0, idx).trim();
            var leftFirst = leftLow.split(/\s+/)[0] || '';

            if (startsWithTransition(afterLow)) {
                res.push(idx);
            } else if (
                DAWP_BAD_STARTERS.indexOf(firstWord) === -1 &&
                DAWP_SUBORDINATORS.indexOf(leftFirst) === -1
            ) {
                res.push(idx);
            }
        }
        return res;
    }

    // Tách 1 mệnh đề dài tại ranh giới AN TOÀN gần giữa nhất (đệ quy).
    // Nếu không có chỗ tách an toàn -> GIỮ NGUYÊN để tránh câu chuối.
    function splitCore(core) {
        core = core.trim();
        if (wc(core) <= 22) return [core];

        var cands = findSafeSplits(core);
        if (!cands.length) return [core];

        var mid = core.length / 2, chosen = null, best = 1e9;
        cands.forEach(function(cut) {
            var left = core.slice(0, cut).trim();
            var right = core.slice(cut + 1).trim(); // bỏ dấu , hoặc ;
            // Hai vế phải đủ dài để thành câu hoàn chỉnh (tránh mảnh cụt)
            if (wc(left) < 5 || wc(right) < 5) return;
            var d = Math.abs(cut - mid);
            if (d < best) { best = d; chosen = { left: left, right: right }; }
        });

        if (!chosen) return [core]; // không có ranh giới an toàn & cân đối -> giữ nguyên

        var right = chosen.right;
        right = right.charAt(0).toUpperCase() + right.slice(1);
        return splitCore(chosen.left).concat(splitCore(right));
    }

    // TẦNG 2: câu vẫn quá dài (>25 từ) & không có ranh giới an toàn -> tách tại
    // dấu phẩy gần giữa. Tự bỏ liên từ thuần "và/hoặc/hay" ở đầu vế sau để câu
    // không bị cụt. Vế trái là mệnh đề phụ (khi/nếu/vì...) thì bỏ qua chỗ đó.
    function forceSplitCore(core) {
        core = core.trim();
        if (wc(core) <= 25) return [core];

        var idxs = [], re = /,/g, m;
        while ((m = re.exec(core)) !== null) idxs.push(m.index);
        if (!idxs.length) return [core]; // không có dấu phẩy -> giữ nguyên

        var low = stripTones(core);
        var mid = core.length / 2;
        idxs.sort(function(a, b) { return Math.abs(a - mid) - Math.abs(b - mid); });

        for (var k = 0; k < idxs.length; k++) {
            var cut = idxs[k];
            var left = core.slice(0, cut).trim();
            var right = core.slice(cut + 1).trim();
            if (wc(left) < 5 || wc(right) < 5) continue;

            var leftFirst = stripTones(left).split(/\s+/)[0] || '';
            if (DAWP_SUBORDINATORS.indexOf(leftFirst) !== -1) continue; // tránh cụt vế trái

            var rlow = stripTones(right);
            var fw = rlow.split(/\s+/)[0] || '';
            if (fw === 'va' || fw === 'hoac' || fw === 'hay') {
                right = right.replace(/^\S+\s+/, ''); // bỏ liên từ thừa ở đầu
                if (wc(right) < 5) continue;
            }
            right = right.charAt(0).toUpperCase() + right.slice(1);
            return forceSplitCore(left).concat(forceSplitCore(right));
        }
        return [core];
    }

    // Tách 1 câu (kèm dấu kết thúc) thành nhiều câu ngắn: an toàn trước, ép sau
    function shortenSentence(s) {
        var m = s.match(/^([\s\S]*?)([.!?…]+)\s*$/);
        var core = m ? m[1] : s;
        var end = m ? m[2] : '.';

        var parts = splitCore(core);
        var refined = [];
        parts.forEach(function(p) {
            if (wc(p) > 25) refined = refined.concat(forceSplitCore(p));
            else refined.push(p);
        });

        return refined.map(function(p, i) { return p + (i === refined.length - 1 ? end : '.'); });
    }

    function splitIntoSentences(text) {
        var matches = text.match(/[^.!?…]+[.!?…]+|\S[^.!?…]*$/g) || [text];
        return matches.map(function(s) { return s.trim(); }).filter(Boolean);
    }

    // Đưa 1 khối văn bản thành nhiều thẻ <p> ngắn (tối đa 3 câu / ~110 từ)
    function appendParagraphs(out, text) {
        var expanded = [];
        splitIntoSentences(text).forEach(function(s) { expanded = expanded.concat(shortenSentence(s)); });
        var buf = [], bufW = 0;
        function flush() {
            if (buf.length) {
                var p = document.createElement('p');
                p.textContent = buf.join(' ');
                out.appendChild(p);
                buf = []; bufW = 0;
            }
        }
        expanded.forEach(function(s) {
            var w = wc(s);
            if (buf.length >= 3 || (buf.length && bufW + w > 110)) flush();
            buf.push(s); bufW += w;
        });
        flush();
    }

    // Chèn tiêu đề phụ H2 nếu bài dài mà chưa có heading nào
    function maybeInsertHeadings(out) {
        if (out.querySelector('h2, h3')) return;
        if (wc(out.textContent) < 300) return;
        var ps = Array.prototype.slice.call(out.querySelectorAll('p'));
        var kw = (keywordInput.val() || '').trim();
        var titles = kw
            ? ['Giới thiệu về ' + kw, 'Chi tiết về ' + kw, 'Lợi ích của ' + kw, 'Những lưu ý về ' + kw, 'Tổng kết']
            : ['Giới thiệu', 'Nội dung chi tiết', 'Thông tin bổ sung', 'Những lưu ý quan trọng', 'Tổng kết'];
        var every = 4, ti = 0;
        for (var i = 0; i < ps.length; i += every) {
            var h = document.createElement('h2');
            h.textContent = titles[ti % titles.length]; ti++;
            ps[i].parentNode.insertBefore(h, ps[i]);
        }
    }

    // Các thẻ giữ nguyên (không tách)
    var DAWP_KEEP_TAGS = ['h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'ul', 'ol', 'figure', 'img',
        'table', 'blockquote', 'pre', 'hr', 'iframe', 'video', 'audio', 'form', 'style', 'script'];

    // Xử lý 1 khối như đoạn văn: giữ nguyên nếu chứa link/ảnh/nút (tránh phá hỏng),
    // ngược lại tách câu từ phần text.
    function paragraphFromEl(el, out) {
        if (el.querySelector && el.querySelector('a, img, iframe, button, input, svg')) {
            out.appendChild(el.cloneNode(true));
            return;
        }
        var text = (el.textContent || '').trim();
        if (!text) { out.appendChild(el.cloneNode(true)); return; }
        appendParagraphs(out, text);
    }

    function handleNode(node, out) {
        if (node.nodeType === 3) {
            var t = node.textContent.trim();
            if (t) appendParagraphs(out, t);
            return;
        }
        if (node.nodeType !== 1) return;

        var tag = node.tagName.toLowerCase();
        if (DAWP_KEEP_TAGS.indexOf(tag) !== -1) {
            out.appendChild(node.cloneNode(true));
            return;
        }
        if (tag === 'div' || tag === 'section' || tag === 'article' || tag === 'main' || tag === 'span') {
            // Có chứa khối con -> đệ quy vào; không thì coi như 1 đoạn văn
            var hasBlock = node.querySelector('p, div, section, article, h1, h2, h3, h4, h5, h6, ul, ol, table, figure');
            if (hasBlock) {
                Array.prototype.slice.call(node.childNodes).forEach(function(c) { handleNode(c, out); });
            } else {
                paragraphFromEl(node, out);
            }
            return;
        }
        // p, li rời, hoặc thẻ text khác
        paragraphFromEl(node, out);
    }

    function autoFormatReadability(html) {
        html = html.replace(/<br\s*\/?>/gi, ' ');
        var container = document.createElement('div');
        container.innerHTML = html;
        var out = document.createElement('div');
        Array.prototype.slice.call(container.childNodes).forEach(function(node) { handleNode(node, out); });
        maybeInsertHeadings(out);
        return out.innerHTML;
    }

    function setEditorContent(html) {
        if (typeof tinyMCE !== 'undefined' && tinyMCE.get('content') && !tinyMCE.get('content').isHidden()) {
            tinyMCE.get('content').setContent(html);
            tinyMCE.get('content').fire('change');
        } else if ($('#content').length) {
            $('#content').val(html).trigger('change');
        } else if (typeof wp !== 'undefined' && wp.data && wp.blocks && wp.data.dispatch('core/editor')) {
            wp.data.dispatch('core/editor').resetEditorBlocks(wp.blocks.parse(html));
        }
        setTimeout(runAll, 200);
    }

    $(document).on('click', '#dawp-auto-format-btn', function(e) {
        e.preventDefault();
        var html = getEditorContentHTML();
        if (!html || !html.trim()) { alert('Chưa có nội dung để tối ưu.'); return; }
        if (!confirm('Tự động tối ưu sẽ TÁCH ĐOẠN & CÂU DÀI (và chèn tiêu đề phụ nếu bài chưa có) để tăng điểm dễ đọc.\n\nNội dung trong trình soạn thảo sẽ được viết lại bố cục — bạn nên đọc lại trước khi Cập nhật.\n\nTiếp tục?')) return;
        try {
            var formatted = autoFormatReadability(html);
            setEditorContent(formatted);
            $('#dawp-auto-format-note').html('✅ Đã tối ưu trình bày. Hãy kiểm tra lại nội dung rồi bấm <strong>Cập nhật</strong> để lưu.').css('color', '#008a20');
        } catch (err) {
            $('#dawp-auto-format-note').text('❌ Có lỗi khi tối ưu: ' + err.message).css('color', '#d63638');
        }
    });

    function runAll() { runSeoAnalysis(); runReadability(); }

    // ================= Bộ đếm tiêu đề / mô tả =================
    function updateTitleCounter() {
        var val = titleInput.val();
        var currentTitle = val || $('#title').val() || postData.postTitle;
        previewTitle.text(currentTitle);
        var len = val.length;
        titleCounter.text(len + ' / 60 ký tự');
        var pct = Math.min((len / 60) * 100, 100);
        titleProgress.css('width', pct + '%');
        if (len >= 45 && len <= 60) { titleProgress.css('background-color', '#10b981'); titleCounter.css('color', '#10b981'); }
        else if (len > 60) { titleProgress.css('background-color', '#ef4444'); titleCounter.css('color', '#ef4444'); }
        else { titleProgress.css('background-color', '#f59e0b'); titleCounter.css('color', '#f59e0b'); }
    }
    function updateDescCounter() {
        var val = descInput.val();
        previewDesc.text(val || 'Nhập mô tả Meta để hiển thị xem trước tại đây...');
        var len = val.length;
        descCounter.text(len + ' / 160 ký tự');
        var pct = Math.min((len / 160) * 100, 100);
        descProgress.css('width', pct + '%');
        if (len >= 120 && len <= 160) { descProgress.css('background-color', '#10b981'); descCounter.css('color', '#10b981'); }
        else if (len > 160) { descProgress.css('background-color', '#ef4444'); descCounter.css('color', '#ef4444'); }
        else { descProgress.css('background-color', '#f59e0b'); descCounter.css('color', '#f59e0b'); }
    }

    // ================= Sự kiện =================
    titleInput.on('input keyup change', function() { updateTitleCounter(); runSeoAnalysis(); });
    descInput.on('input keyup change', function() { updateDescCounter(); runSeoAnalysis(); });
    keywordInput.on('input keyup change', function() { runSeoAnalysis(); fetchLinkSuggestions(); });

    // ================= Gợi ý liên kết nội bộ =================
    var suggestionsList = $('#dawp-seo-link-suggestions');
    var suggestionsTimeout = null;
    function fetchLinkSuggestions() {
        var keyword = keywordInput.val().trim();
        if (keyword === '') {
            suggestionsList.html('<li style="color: #64748b; font-style: italic;">Nhập từ khóa chính để hiển thị gợi ý bài viết liên quan...</li>');
            return;
        }
        clearTimeout(suggestionsTimeout);
        suggestionsTimeout = setTimeout(function() {
            suggestionsList.html('<li style="color: #64748b; font-style: italic;">⏳ Đang tìm kiếm bài viết liên quan...</li>');
            var excludeId = $('#post_ID').val() || 0;
            var nonce = $('#dawp_seo_meta_nonce').val();
            $.ajax({
                url: ajaxurl, type: 'POST',
                data: { action: 'dawp_get_link_suggestions', keyword: keyword, exclude_id: excludeId, nonce: nonce },
                success: function(response) {
                    if (response.success && response.data.length > 0) {
                        var html = '';
                        response.data.forEach(function(item) {
                            html += '<li style="display: flex; justify-content: space-between; align-items: center; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px; padding: 6px 12px; margin-bottom: 6px; font-size: 13px;">' +
                                    '  <span style="font-weight: 500; color: #1e293b; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 70%;" title="' + item.title + '">' + item.title + '</span>' +
                                    '  <span style="display: flex; gap: 8px;">' +
                                    '    <a href="' + item.url + '" target="_blank" style="color: #0068ff; text-decoration: none; font-size: 12px; font-weight: 600;">Xem 👁️</a>' +
                                    '    <button type="button" class="dawp-copy-link-btn" data-url="' + item.url + '" style="background: none; border: none; color: #10b981; cursor: pointer; font-size: 12px; font-weight: 600; padding: 0;">Copy 📋</button>' +
                                    '  </span>' +
                                    '</li>';
                        });
                        suggestionsList.html(html);
                    } else {
                        suggestionsList.html('<li style="color: #ea580c; font-style: italic;">❌ Không tìm thấy bài viết liên quan nào chứa từ khóa này.</li>');
                    }
                },
                error: function() {
                    suggestionsList.html('<li style="color: #ef4444; font-style: italic;">❌ Lỗi kết nối máy chủ, không thể tìm kiếm gợi ý.</li>');
                }
            });
        }, 500);
    }

    $(document).on('click', '.dawp-copy-link-btn', function(e) {
        e.preventDefault();
        var $btn = $(this);
        var url = $btn.data('url');
        navigator.clipboard.writeText(url).then(function() {
            var originalText = $btn.text();
            $btn.text('Đã Copy! ✓').css('color', '#10b981');
            setTimeout(function() { $btn.text(originalText).css('color', '#10b981'); }, 1500);
        });
    });

    // ================= Lắng nghe trình soạn thảo =================
    if (typeof tinyMCE !== 'undefined') {
        tinyMCE.on('AddEditor', function(e) {
            if (e.editor.id === 'content') {
                e.editor.on('init', function() { setTimeout(function() { runAll(); updateTitleCounter(); updateDescCounter(); }, 100); });
                e.editor.on('keyup change NodeChange', function() { runAll(); });
            }
        });
        var editor = tinyMCE.get('content');
        if (editor) {
            if (editor.initialized) { runAll(); }
            else { editor.on('init', function() { runAll(); }); }
            editor.on('keyup change NodeChange', function() { runAll(); });
        }
    }

    if (typeof wp !== 'undefined' && wp.data && wp.data.subscribe) {
        var prevContent = '';
        wp.data.subscribe(function() {
            var editorSelect = wp.data.select('core/editor');
            if (editorSelect) {
                var content = editorSelect.getEditedPostContent() || '';
                if (content !== prevContent) { prevContent = content; runAll(); }
            }
        });
    }

    $('#content').on('input keyup change', function() { runAll(); });
    $('#title').on('input keyup change', function() { updateTitleCounter(); runSeoAnalysis(); });

    // Khởi chạy ban đầu + chạy lại tránh race condition
    updateTitleCounter();
    updateDescCounter();
    runAll();
    fetchLinkSuggestions();
    setTimeout(runAll, 1000);
    setTimeout(runAll, 2500);
    setTimeout(runAll, 5000);
});
