<?php
defined( 'ABSPATH' ) || exit;

class DAWP_Google_Translate {
    public function __construct() {
        add_action( 'wp_footer', [ $this, 'render_translator' ] );
        add_action( 'wp_footer', [ $this, 'render_footer_assets' ], 99 );
        add_shortcode( 'dawp_translate', [ $this, 'render_shortcode' ] );
    }

    /**
     * Danh sách tất cả các ngôn ngữ hỗ trợ sẵn
     */
    public function get_language_list() {
        return [
            'vi' => ['name' => 'Tiếng Việt', 'flag' => '🇻🇳', 'country' => 'vn'],
            'en' => ['name' => 'English', 'flag' => '🇬🇧', 'country' => 'gb'],
            'zh-CN' => ['name' => '简体中文', 'flag' => '🇨🇳', 'country' => 'cn'],
            'ja' => ['name' => '日本語', 'flag' => '🇯🇵', 'country' => 'jp'],
            'ko' => ['name' => '한국어', 'flag' => '🇰🇷', 'country' => 'kr'],
            'fr' => ['name' => 'Français', 'flag' => '🇫🇷', 'country' => 'fr'],
            'de' => ['name' => 'Deutsch', 'flag' => '🇩🇪', 'country' => 'de'],
            'ru' => ['name' => 'Русский', 'flag' => '🇷🇺', 'country' => 'ru'],
            'es' => ['name' => 'Español', 'flag' => '🇪🇸', 'country' => 'es'],
            'it' => ['name' => 'Italiano', 'flag' => '🇮🇹', 'country' => 'it'],
            'pt' => ['name' => 'Português', 'flag' => '🇵🇹', 'country' => 'pt'],
            'th' => ['name' => 'ไทย', 'flag' => '🇹🇭', 'country' => 'th'],
            'lo' => ['name' => 'ພາສາລາວ', 'flag' => '🇱🇦', 'country' => 'la'],
            'km' => ['name' => 'ភាសាខ្មែរ', 'flag' => '🇰🇭', 'country' => 'kh'],
            'my' => ['name' => 'မြန်မာဘာသာ', 'flag' => '🇲🇲', 'country' => 'mm'],
            'id' => ['name' => 'Bahasa Indonesia', 'flag' => '🇮🇩', 'country' => 'id'],
            'ms' => ['name' => 'Bahasa Melayu', 'flag' => '🇲🇾', 'country' => 'my'],
            'ar' => ['name' => 'العربية', 'flag' => '🇸🇦', 'country' => 'sa'],
            'hi' => ['name' => 'हिन्दी', 'flag' => '🇮🇳', 'country' => 'in'],
            'bn' => ['name' => 'বাংলা', 'flag' => '🇧🇩', 'country' => 'bd'],
            'tr' => ['name' => 'Türkçe', 'flag' => '🇹🇷', 'country' => 'tr'],
            'nl' => ['name' => 'Nederlands', 'flag' => '🇳🇱', 'country' => 'nl'],
            'pl' => ['name' => 'Polski', 'flag' => '🇵🇱', 'country' => 'pl'],
            'sv' => ['name' => 'Svenska', 'flag' => '🇸🇪', 'country' => 'se'],
            'da' => ['name' => 'Dansk', 'flag' => '🇩🇰', 'country' => 'dk'],
            'fi' => ['name' => 'Suomi', 'flag' => '🇫🇮', 'country' => 'fi'],
            'no' => ['name' => 'Norsk', 'flag' => '🇳🇴', 'country' => 'no'],
            'el' => ['name' => 'Ελληνικά', 'flag' => '🇬🇷', 'country' => 'gr'],
            'he' => ['name' => 'עברית', 'flag' => '🇮🇱', 'country' => 'il'],
            'cs' => ['name' => 'Čeština', 'flag' => '🇨🇿', 'country' => 'cz'],
            'hu' => ['name' => 'Magyar', 'flag' => '🇭🇺', 'country' => 'hu'],
            'ro' => ['name' => 'Română', 'flag' => '🇷🇴', 'country' => 'ro'],
            'uk' => ['name' => 'Українська', 'flag' => '🇺🇦', 'country' => 'ua'],
            'sk' => ['name' => 'Slovenčina', 'flag' => '🇸🇰', 'country' => 'sk'],
            'sl' => ['name' => 'Slovenščina', 'flag' => '🇸🇮', 'country' => 'si'],
            'hr' => ['name' => 'Hrvatski', 'flag' => '🇭🇷', 'country' => 'hr'],
            'sr' => ['name' => 'Српски', 'flag' => '🇷🇸', 'country' => 'rs'],
            'bg' => ['name' => 'Български', 'flag' => '🇧🇬', 'country' => 'bg'],
            'mk' => ['name' => 'Македонски', 'flag' => '🇲🇰', 'country' => 'mk'],
            'et' => ['name' => 'Eesti', 'flag' => '🇪🇪', 'country' => 'ee'],
            'lv' => ['name' => 'Latviešu', 'flag' => '🇱🇻', 'country' => 'lv'],
            'lt' => ['name' => 'Lietuvių', 'flag' => '🇱🇹', 'country' => 'lt'],
            'is' => ['name' => 'Íslenska', 'flag' => '🇮🇸', 'country' => 'is'],
            'ga' => ['name' => 'Gaeilge', 'flag' => '🇮🇪', 'country' => 'ie'],
            'ca' => ['name' => 'Català', 'flag' => '🇪🇸', 'country' => 'es'],
            'eu' => ['name' => 'Euskara', 'flag' => '🇪🇸', 'country' => 'es'],
            'gl' => ['name' => 'Galego', 'flag' => '🇪🇸', 'country' => 'es'],
            'sq' => ['name' => 'Shqip', 'flag' => '🇦🇱', 'country' => 'al'],
            'hy' => ['name' => 'Հայերեն', 'flag' => '🇦🇲', 'country' => 'am'],
            'ka' => ['name' => 'ქართული', 'flag' => '🇬🇪', 'country' => 'ge'],
            'az' => ['name' => 'Azərbaycan', 'flag' => '🇦🇿', 'country' => 'az'],
            'kk' => ['name' => 'Қазақ', 'flag' => '🇰🇿', 'country' => 'kz'],
            'uz' => ['name' => 'Oʻzbek', 'flag' => '🇺🇿', 'country' => 'uz'],
            'mn' => ['name' => 'Монгол', 'flag' => '🇲🇳', 'country' => 'mn'],
            'fa' => ['name' => 'فارسی', 'flag' => '🇮🇷', 'country' => 'ir'],
            'ur' => ['name' => 'اردو', 'flag' => '🇵🇰', 'country' => 'pk'],
            'ta' => ['name' => 'தமிழ்', 'flag' => '🇮🇳', 'country' => 'in'],
            'te' => ['name' => 'తెలుగు', 'flag' => '🇮🇳', 'country' => 'in'],
            'gu' => ['name' => 'ગુજરાતી', 'flag' => '🇮🇳', 'country' => 'in'],
            'ne' => ['name' => 'नेपाली', 'flag' => '🇳🇵', 'country' => 'np'],
            'si' => ['name' => 'සිංහල', 'flag' => '🇱🇰', 'country' => 'lk'],
            'tl' => ['name' => 'Filipino', 'flag' => '🇵🇭', 'country' => 'ph'],
            'sw' => ['name' => 'Kiswahili', 'flag' => '🇰🇪', 'country' => 'ke'],
            'af' => ['name' => 'Afrikaans', 'flag' => '🇿🇦', 'country' => 'za'],
        ];
    }

    /**
     * Lấy danh sách ngôn ngữ được cấu hình trong admin
     */
    public function get_configured_languages($options) {
        $all_langs = $this->get_language_list();
        $config_val = isset($options['google_translate_languages']) ? $options['google_translate_languages'] : '';
        if (empty($config_val)) {
            // Mặc định nếu không cấu hình gì
            return [
                'vi' => $all_langs['vi'],
                'en' => $all_langs['en'],
                'zh-CN' => $all_langs['zh-CN'],
                'ja' => $all_langs['ja'],
                'ko' => $all_langs['ko'],
            ];
        }

        if (is_array($config_val)) {
            $codes = $config_val;
        } else {
            $codes = array_map('trim', explode(',', $config_val));
        }

        $filtered = [];
        foreach ($codes as $code) {
            if (isset($all_langs[$code])) {
                $filtered[$code] = $all_langs[$code];
            } else {
                $filtered[$code] = ['name' => strtoupper($code), 'flag' => '🌐', 'country' => 'un'];
            }
        }
        return $filtered;
    }

    /**
     * Render widget dạng nổi ở footer
     */
    public function render_translator() {
        $options = get_option( 'dawp_settings', [] );
        $active = isset($options['google_translate_active']) ? (bool)$options['google_translate_active'] : false;
        if ( ! $active ) {
            return;
        }

        $layout = isset($options['google_translate_layout']) ? $options['google_translate_layout'] : 'floating';
        if ($layout !== 'floating') {
            return;
        }

        echo $this->generate_html($options, 'floating');
    }

    /**
     * Render widget dạng inline thông qua shortcode
     */
    public function render_shortcode($atts) {
        $options = get_option( 'dawp_settings', [] );
        $active = isset($options['google_translate_active']) ? (bool)$options['google_translate_active'] : false;
        if ( ! $active ) {
            return '';
        }
        
        $default_style = isset($options['google_translate_inline_style']) ? $options['google_translate_inline_style'] : 'dropdown-pill';
        
        $atts = shortcode_atts([
            'style' => $default_style,
        ], $atts, 'dawp_translate');

        return $this->generate_html($options, 'inline', $atts['style']);
    }

    /**
     * Tạo mã HTML/CSS tĩnh cho widget dịch
     */
    private function generate_html($options, $type = 'floating', $inline_style = 'dropdown-pill') {
        static $css_rendered = false;
        $position = isset($options['google_translate_position']) ? $options['google_translate_position'] : 'right';
        $default_lang = isset($options['google_translate_default_lang']) ? $options['google_translate_default_lang'] : 'vi';
        $langs = $this->get_configured_languages($options);
        
        // Xác định ngôn ngữ hiện tại đang hoạt động
        $current_lang = $default_lang;
        if ( isset( $_COOKIE['googtrans'] ) ) {
            $cookie_parts = explode( '/', $_COOKIE['googtrans'] );
            if ( count( $cookie_parts ) >= 3 ) {
                $current_lang = end( $cookie_parts );
            }
        }
        $active_lang_info = isset($langs[$current_lang]) ? $langs[$current_lang] : ['name' => strtoupper($current_lang), 'flag' => '🌐'];

        ob_start();
        
        if ( ! $css_rendered ) {
            $css_rendered = true;
            ?>
            <style>
                /* Ẩn widget mặc định của Google Translate bằng cách đẩy khỏi màn hình (tránh bị trình duyệt ngừng chạy iframe do display: none) */
                #google_translate_element {
                    position: absolute !important;
                    top: -9999px !important;
                    left: -9999px !important;
                    width: 0 !important;
                    height: 0 !important;
                    overflow: hidden !important;
                    visibility: hidden !important;
                    opacity: 0 !important;
                    pointer-events: none !important;
                }
                .skiptranslate > iframe,
                .goog-te-banner-frame,
                .goog-te-balloon-frame {
                    display: none !important;
                    visibility: hidden !important;
                    height: 0 !important;
                    width: 0 !important;
                }
                body {
                    top: 0px !important;
                }
                .goog-te-menu-value {
                    display: none !important;
                }
                
                /* Custom Style cho Widget Dịch */
                .dawp-translate-container {
                    font-family: system-ui, -apple-system, sans-serif;
                    z-index: 99998;
                    box-sizing: border-box;
                }
                .dawp-translate-container * {
                    box-sizing: border-box;
                }
                .dawp-translate-container.floating {
                    position: fixed;
                    bottom: 110px;
                    <?php echo $position === 'right' ? 'right: 30px;' : 'left: 30px;'; ?>
                }
                .dawp-translate-btn {
                    position: relative;
                    width: 56px;
                    height: 56px;
                    border-radius: 50%;
                    background: linear-gradient(135deg, #1a73e8, #4285f4);
                    color: #ffffff;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    cursor: pointer;
                    box-shadow: 0 8px 20px rgba(26, 115, 232, 0.35);
                    transition: transform 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275), box-shadow 0.4s;
                    border: none;
                    outline: none;
                }
                .dawp-translate-btn:hover {
                    transform: scale(1.12) translateY(-5px);
                    box-shadow: 0 12px 28px rgba(26, 115, 232, 0.5);
                }
                .dawp-translate-btn svg {
                    width: 26px;
                    height: 26px;
                    fill: #ffffff;
                    transition: transform 0.4s ease;
                }
                .dawp-translate-btn:hover svg {
                    transform: rotate(30deg);
                }
                
                /* Hiệu ứng viền phát sáng nhấp nháy (Ripple) */
                .dawp-translate-btn::before,
                .dawp-translate-btn::after {
                    content: "" !important;
                    position: absolute !important;
                    top: 0 !important;
                    left: 0 !important;
                    right: 0 !important;
                    bottom: 0 !important;
                    border-radius: inherit !important;
                    background: inherit !important;
                    z-index: -1 !important;
                    opacity: 0 !important;
                    transform: scale(1) !important;
                    pointer-events: none !important;
                }
                .dawp-translate-btn::before {
                    animation: dawp-translate-ripple 2.4s infinite cubic-bezier(0.25, 0, 0, 1) !important;
                }
                .dawp-translate-btn::after {
                    animation: dawp-translate-ripple 2.4s infinite cubic-bezier(0.25, 0, 0, 1) !important;
                    animation-delay: 1.2s !important;
                }
                @keyframes dawp-translate-ripple {
                    0% { transform: scale(1); opacity: 0.6; }
                    100% { transform: scale(1.5); opacity: 0; }
                }

                .dawp-translate-menu {
                    position: absolute;
                    bottom: 70px;
                    <?php echo $position === 'right' ? 'right: 0;' : 'left: 0;'; ?>
                    background: rgba(255, 255, 255, 0.95);
                    backdrop-filter: blur(10px);
                    -webkit-backdrop-filter: blur(10px);
                    border-radius: 12px;
                    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
                    padding: 8px 0;
                    min-width: 170px;
                    display: none;
                    opacity: 0;
                    transform: translateY(15px);
                    transition: opacity 0.3s, transform 0.3s, display 0.3s allow-discrete;
                    border: 1px solid rgba(255,255,255,0.4);
                }
                .dawp-translate-menu.open {
                    display: block;
                    opacity: 1;
                    transform: translateY(0);
                }
                @supports (background-blend-mode: overlay) {
                    .dawp-translate-menu {
                        background: rgba(255, 255, 255, 0.85);
                    }
                }
                .dawp-translate-item {
                    display: flex;
                    align-items: center;
                    padding: 10px 18px;
                    color: #2c3e50;
                    text-decoration: none;
                    font-size: 14px;
                    font-weight: 600;
                    cursor: pointer;
                    transition: background 0.25s, color 0.25s;
                }
                .dawp-translate-item:hover {
                    background: rgba(26, 115, 232, 0.08);
                    color: #1a73e8;
                }
                .dawp-translate-item:first-child {
                    border-top-left-radius: 12px;
                    border-top-right-radius: 12px;
                }
                .dawp-translate-item:last-child {
                    border-bottom-left-radius: 12px;
                    border-bottom-right-radius: 12px;
                }
                .dawp-translate-flag {
                    font-size: 20px;
                    margin-right: 12px;
                    line-height: 1;
                    display: inline-block;
                    vertical-align: middle;
                }
                
                /* Style cho dạng Inline/Shortcode (Menu) */
                .dawp-translate-container.inline {
                    position: relative;
                    display: inline-flex !important;
                    align-items: center;
                    vertical-align: middle;
                    white-space: nowrap !important;
                    flex-wrap: nowrap !important;
                }
                .dawp-translate-container.inline .dawp-translate-btn {
                    background: transparent;
                    color: inherit;
                    width: auto;
                    height: 38px;
                    padding: 0 14px;
                    font-size: 13px;
                    font-weight: 600;
                    display: inline-flex !important;
                    align-items: center;
                    gap: 8px;
                    box-shadow: none;
                    transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
                    white-space: nowrap !important;
                    flex-wrap: nowrap !important;
                    border: none;
                    outline: none;
                }

                <?php if ($inline_style === 'dropdown-pill'): ?>
                /* Dạng Dropdown Pill (Viên thuốc) */
                .dawp-translate-container.inline .dawp-translate-btn {
                    border: 1px solid rgba(120, 120, 120, 0.25);
                    border-radius: 50px;
                }
                .dawp-translate-container.inline .dawp-translate-btn:hover {
                    transform: translateY(-1px);
                    background-color: rgba(120, 120, 120, 0.08);
                    border-color: rgba(120, 120, 120, 0.4);
                    box-shadow: 0 4px 12px rgba(0,0,0,0.03);
                }
                <?php elseif ($inline_style === 'dropdown-flat'): ?>
                /* Dạng Dropdown Flat (Phẳng không viền) */
                .dawp-translate-container.inline .dawp-translate-btn {
                    border: 1px solid transparent;
                    border-radius: 4px;
                    padding: 0 8px;
                }
                .dawp-translate-container.inline .dawp-translate-btn:hover {
                    background-color: rgba(120, 120, 120, 0.08);
                }
                <?php endif; ?>

                /* Vô hiệu hóa hiệu ứng ripple cho menu inline */
                .dawp-translate-container.inline .dawp-translate-btn::before,
                .dawp-translate-container.inline .dawp-translate-btn::after {
                    display: none !important;
                    content: none !important;
                    animation: none !important;
                }
                .dawp-translate-flag-img {
                    width: 20px !important;
                    height: 20px !important;
                    border-radius: 50% !important;
                    object-fit: cover !important;
                    box-shadow: 0 1px 4px rgba(0,0,0,0.15);
                    display: inline-block;
                    vertical-align: middle;
                    border: 1px solid rgba(0,0,0,0.08);
                }
                .dawp-translate-current-flag {
                    display: inline-flex;
                    align-items: center;
                    line-height: 1;
                }
                .dawp-translate-current-name {
                    font-size: 13px;
                    font-weight: 600;
                }
                .dawp-translate-chevron {
                    display: inline-flex;
                    align-items: center;
                    transition: transform 0.3s ease;
                    opacity: 0.7;
                }
                .dawp-translate-container.inline.open .dawp-translate-chevron {
                    transform: rotate(180deg);
                }
                
                .dawp-translate-container.inline .dawp-translate-menu {
                    bottom: auto;
                    top: calc(100% + 8px);
                    <?php echo $position === 'right' ? 'right: 0; left: auto;' : 'left: 0; right: auto;'; ?>
                    background: rgba(255, 255, 255, 0.9);
                    backdrop-filter: blur(20px);
                    -webkit-backdrop-filter: blur(20px);
                    border-radius: 12px;
                    border: 1px solid rgba(0, 0, 0, 0.08);
                    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08), 0 3px 10px rgba(0, 0, 0, 0.03);
                    padding: 6px 0;
                    min-width: 160px;
                    opacity: 0;
                    transform: translateY(10px);
                    pointer-events: none;
                    display: block !important;
                    transition: opacity 0.25s cubic-bezier(0.4, 0, 0.2, 1), transform 0.25s cubic-bezier(0.4, 0, 0.2, 1);
                    z-index: 99999;
                }
                .dawp-translate-container.inline .dawp-translate-menu.open {
                    opacity: 1;
                    transform: translateY(0);
                    pointer-events: auto;
                }
                .dawp-translate-container.inline .dawp-translate-item {
                    display: flex;
                    align-items: center;
                    padding: 8px 16px;
                    color: #2c3e50;
                    font-size: 13px;
                    font-weight: 550;
                    transition: background-color 0.2s, color 0.2s;
                    gap: 10px;
                    border-radius: 0;
                }
                .dawp-translate-container.inline .dawp-translate-item:hover {
                    background-color: rgba(26, 115, 232, 0.06);
                    color: #1a73e8;
                }
                .dawp-translate-container.inline .dawp-translate-item.active {
                    background-color: rgba(26, 115, 232, 0.08);
                    color: #1a73e8;
                    font-weight: 700;
                }
                .dawp-translate-container.inline .dawp-translate-flag {
                    margin-right: 0;
                    display: inline-flex;
                    align-items: center;
                }

                /* Cờ quốc gia nằm ngang (Horizontal Flags Style) */
                .dawp-translate-flags-list {
                    display: inline-flex !important;
                    align-items: center;
                    gap: 10px;
                    flex-wrap: nowrap !important;
                    white-space: nowrap !important;
                    vertical-align: middle;
                }
                .dawp-translate-flag-item {
                    cursor: pointer;
                    transition: transform 0.2s cubic-bezier(0.175, 0.885, 0.32, 1.275), filter 0.2s;
                    display: inline-flex;
                    align-items: center;
                    justify-content: center;
                    filter: grayscale(0.2) opacity(0.8);
                    padding: 2px;
                    border-bottom: 2px solid transparent;
                }
                .dawp-translate-flag-item:hover {
                    transform: scale(1.2) translateY(-2px);
                    filter: grayscale(0) opacity(1);
                }
                .dawp-translate-flag-item.active {
                    transform: scale(1.1);
                    filter: grayscale(0) opacity(1);
                }
                .dawp-translate-flag-item.active .dawp-translate-flag-img {
                    border: 2px solid #1a73e8 !important;
                }
            </style>
            <?php
        }
        ?>

        <div class="dawp-translate-container <?php echo $type; ?> <?php echo esc_attr($inline_style); ?>">
            <?php if ($type === 'inline' && $inline_style === 'flags'): ?>
                <!-- Dạng hiển thị danh sách cờ quốc gia nằm ngang -->
                <div class="dawp-translate-flags-list">
                    <?php foreach ($langs as $code => $lang): 
                        $is_active = ($code === $current_lang);
                    ?>
                        <span class="dawp-translate-flag-item <?php echo $is_active ? 'active' : ''; ?>" data-lang="<?php echo esc_attr($code); ?>" title="<?php echo esc_attr($lang['name']); ?>">
                            <img src="<?php echo esc_url( DAWP_URL . 'assets/flags/' . $lang['country'] . '.png' ); ?>" 
                                 width="20" height="20" alt="<?php echo esc_attr($lang['name']); ?>" 
                                 class="dawp-translate-flag-img" />
                        </span>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <!-- Dạng Dropdown (Viên thuốc / Phẳng / Nổi) -->
                <button class="dawp-translate-btn" aria-label="Translate Website" title="Dịch trang web">
                    <?php if ($type === 'inline'): ?>
                        <span class="dawp-translate-current-flag">
                            <img src="<?php echo esc_url( DAWP_URL . 'assets/flags/' . $active_lang_info['country'] . '.png' ); ?>" 
                                 width="20" height="20" alt="<?php echo esc_attr($active_lang_info['name']); ?>" 
                                 class="dawp-translate-flag-img" />
                        </span>
                        <span class="dawp-translate-current-name"><?php echo esc_html($active_lang_info['name']); ?></span>
                        <span class="dawp-translate-chevron">
                            <svg viewBox="0 0 24 24" width="14" height="14" fill="currentColor">
                                <path d="M7 10l5 5 5-5z"/>
                            </svg>
                        </span>
                    <?php else: ?>
                        <svg viewBox="0 0 24 24">
                            <path d="M12.87 15.07l-2.54-2.51.03-.03c1.74-1.94 2.98-4.17 3.71-6.53H17V4h-7V2H8v2H1v2h11.17C11.5 7.92 10.44 9.75 9 11.35 8.07 10.32 7.3 9.19 6.69 8h-2c.73 1.63 1.73 3.17 2.98 4.56l-5.09 5.02L4 19l5-5 3.11 3.11.76-2.04zM18.5 10h-2L12 22h2l1.12-3h4.75L21 22h2l-4.5-12zm-2.62 7l1.62-4.33L19.12 17h-3.24z"/>
                        </svg>
                    <?php endif; ?>
                </button>
                <div class="dawp-translate-menu">
                    <?php foreach ($langs as $code => $lang): 
                        $is_active = ($code === $current_lang);
                    ?>
                        <div class="dawp-translate-item <?php echo $is_active ? 'active' : ''; ?>" data-lang="<?php echo esc_attr($code); ?>">
                            <span class="dawp-translate-flag">
                                <img src="<?php echo esc_url( DAWP_URL . 'assets/flags/' . $lang['country'] . '.png' ); ?>" 
                                     width="20" height="20" alt="<?php echo esc_attr($lang['name']); ?>" 
                                     class="dawp-translate-flag-img" />
                            </span>
                            <span class="dawp-translate-name"><?php echo esc_html($lang['name']); ?></span>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
        <?php
        return ob_get_clean();
    }

    /**
     * Render container và mã JS gộp của Google Translate ở footer
     */
    public function render_footer_assets() {
        $options = get_option( 'dawp_settings', [] );
        $active = isset($options['google_translate_active']) ? (bool)$options['google_translate_active'] : false;
        if ( ! $active ) {
            return;
        }

        $default_lang = isset($options['google_translate_default_lang']) ? $options['google_translate_default_lang'] : 'vi';
        $langs = $this->get_configured_languages($options);
        $lang_list_str = implode(',', array_keys($langs));

        $has_translation_cookie = false;
        if ( isset( $_COOKIE['googtrans'] ) && $_COOKIE['googtrans'] !== '/' . $default_lang . '/' . $default_lang ) {
            $has_translation_cookie = true;
        }

        ?>
        <div id="google_translate_element"></div>
        <script>
            (function() {
                var defaultLang = '<?php echo esc_js($default_lang); ?>';
                var includedLanguages = '<?php echo esc_js($lang_list_str); ?>';
                var hasTranslationCookie = <?php echo $has_translation_cookie ? 'true' : 'false'; ?>;
                var scriptAppended = false;

                function loadGoogleTranslate() {
                    if (scriptAppended) return;
                    scriptAppended = true;
                    
                    window.googleTranslateElementInit = function() {
                        var initTranslate = function() {
                            try {
                                if (document.getElementById('google_translate_element')) {
                                    new google.translate.TranslateElement({
                                        pageLanguage: defaultLang,
                                        includedLanguages: includedLanguages,
                                        layout: google.translate.TranslateElement.InlineLayout.SIMPLE,
                                        autoDisplay: false
                                    }, 'google_translate_element');
                                }
                            } catch (e) {
                                console.error('Google Translate init error:', e);
                            }
                        };
                        
                        if (document.readyState === 'loading') {
                            document.addEventListener('DOMContentLoaded', initTranslate);
                        } else {
                            initTranslate();
                        }
                    };
                    
                    var s = document.createElement('script');
                    s.type = 'text/javascript';
                    s.charset = 'UTF-8';
                    s.async = true;
                    s.src = 'https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit';
                    (document.getElementsByTagName('head')[0] || document.getElementsByTagName('body')[0]).appendChild(s);
                }

                if (hasTranslationCookie) {
                    loadGoogleTranslate();
                }

                function initContainers() {
                    var containers = document.querySelectorAll('.dawp-translate-container');
                    containers.forEach(function(container) {
                        if (container.classList.contains('dawp-initialized')) {
                            return;
                        }
                        container.classList.add('dawp-initialized');

                        var trigger = container.querySelector('.dawp-translate-btn');
                        var menu = container.querySelector('.dawp-translate-menu');

                        if (trigger && menu) {
                            trigger.addEventListener('click', function(e) {
                                e.stopPropagation();
                                
                                // Đóng toàn bộ các menu khác
                                document.querySelectorAll('.dawp-translate-container').forEach(function(other) {
                                    if (other !== container) {
                                        other.classList.remove('open');
                                        var m = other.querySelector('.dawp-translate-menu');
                                        if (m) m.classList.remove('open');
                                    }
                                });

                                container.classList.toggle('open');
                                menu.classList.toggle('open');
                                loadGoogleTranslate();
                            });
                        }

                        container.addEventListener('mouseenter', loadGoogleTranslate);
                        container.addEventListener('touchstart', loadGoogleTranslate, {passive: true});

                        var items = container.querySelectorAll('.dawp-translate-item, .dawp-translate-flag-item');
                        items.forEach(function(item) {
                            item.addEventListener('click', function(e) {
                                e.stopPropagation();
                                var lang = this.getAttribute('data-lang');
                                doTranslate(lang);
                                container.classList.remove('open');
                                if (menu) menu.classList.remove('open');
                            });
                        });
                    });
                }

                if (document.readyState === 'loading') {
                    document.addEventListener('DOMContentLoaded', initContainers);
                } else {
                    initContainers();
                }

                if (window.MutationObserver) {
                    var observer = new MutationObserver(function() {
                        initContainers();
                    });
                    observer.observe(document.body, { childList: true, subtree: true });
                }

                function doTranslate(langCode) {
                    var cookieValue = "/" + defaultLang + "/" + langCode;
                    var host = window.location.hostname;
                    var parts = host.split('.');
                    
                    // Clear cookie on all possible domain levels
                    document.cookie = "googtrans=; path=/; expires=Thu, 01 Jan 1970 00:00:00 UTC;";
                    document.cookie = "googtrans=; path=/; domain=" + host + "; expires=Thu, 01 Jan 1970 00:00:00 UTC;";
                    document.cookie = "googtrans=; path=/; domain=." + host + "; expires=Thu, 01 Jan 1970 00:00:00 UTC;";
                    
                    var tempParts = parts.slice();
                    while (tempParts.length > 1) {
                        tempParts.shift();
                        var d = tempParts.join('.');
                        document.cookie = "googtrans=; path=/; domain=" + d + "; expires=Thu, 01 Jan 1970 00:00:00 UTC;";
                        document.cookie = "googtrans=; path=/; domain=." + d + "; expires=Thu, 01 Jan 1970 00:00:00 UTC;";
                    }

                    // Find writable root domain using write-test
                    var cookieDomain = "";
                    if (parts.length > 1) {
                        for (var i = parts.length - 2; i >= 0; i--) {
                            var domain = parts.slice(i).join('.');
                            var testName = '__dawp_test_cookie_' + Math.random().toString(36).substring(2);
                            document.cookie = testName + "=1; path=/; domain=." + domain;
                            if (document.cookie.indexOf(testName) > -1) {
                                document.cookie = testName + "=; path=/; domain=." + domain + "; expires=Thu, 01 Jan 1970 00:00:00 UTC;";
                                cookieDomain = "." + domain;
                                break;
                            }
                        }
                    }

                    if (langCode !== defaultLang) {
                        if (cookieDomain) {
                            document.cookie = "googtrans=" + cookieValue + "; path=/; domain=" + cookieDomain;
                        } else {
                            document.cookie = "googtrans=" + cookieValue + "; path=/";
                        }
                    }

                    window.location.reload();
                }

                document.addEventListener('click', function() {
                    document.querySelectorAll('.dawp-translate-container').forEach(function(container) {
                        container.classList.remove('open');
                        var menu = container.querySelector('.dawp-translate-menu');
                        if (menu) menu.classList.remove('open');
                    });
                });
            })();
        </script>
        <?php
    }
}
