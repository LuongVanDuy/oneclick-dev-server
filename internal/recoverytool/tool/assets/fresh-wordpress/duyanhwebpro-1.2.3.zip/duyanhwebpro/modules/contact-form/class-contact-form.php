<?php
defined( 'ABSPATH' ) || exit;

class DAWP_Contact_Form {
    public function __construct() {
        $options = get_option( 'dawp_settings', [] );
        $active = !isset($options['contact_form_active']) || !empty($options['contact_form_active']);

        if ( $active ) {
            add_action( 'init', [ $this, 'register_post_type' ] );
            add_shortcode( 'dawp_contact_form', [ $this, 'render_form' ] );
            add_action( 'wp_ajax_dawp_submit_contact_form', [ $this, 'handle_form_submission' ] );
            add_action( 'wp_ajax_nopriv_dawp_submit_contact_form', [ $this, 'handle_form_submission' ] );
            
            // Đăng ký AJAX endpoint nạp captcha động
            add_action( 'wp_ajax_dawp_get_form_captcha', [ $this, 'ajax_get_form_captcha' ] );
            add_action( 'wp_ajax_nopriv_dawp_get_form_captcha', [ $this, 'ajax_get_form_captcha' ] );
            
            if ( is_admin() ) {
                add_action( 'add_meta_boxes', [ $this, 'add_form_metabox' ] );
                add_action( 'save_post_dawp_contact_form', [ $this, 'save_form_meta' ] );
                add_filter( 'manage_dawp_contact_form_posts_columns', [ $this, 'set_contact_form_columns' ] );
                add_action( 'manage_dawp_contact_form_posts_custom_column', [ $this, 'custom_contact_form_column' ], 10, 2 );
                add_action( 'edit_form_after_title', [ $this, 'render_form_helpers' ] );
            }
        }

        if ( is_admin() ) {
            add_action( 'admin_init', [ $this, 'handle_export_csv' ] );
            add_action( 'wp_ajax_dawp_delete_contact', [ $this, 'ajax_delete_contact' ] );
            add_action( 'wp_ajax_dawp_clear_all_contacts', [ $this, 'ajax_clear_all_contacts' ] );
        }
    }

    /**
     * Tạo bảng lưu trữ thông tin liên hệ trong Database
     */
    public static function create_db_table() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'dawp_contacts';
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE $table_name (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            created_at datetime NOT NULL,
            form_title varchar(255) DEFAULT '',
            name varchar(255) NOT NULL,
            phone varchar(50) NOT NULL,
            email varchar(100) DEFAULT '',
            message text NOT NULL,
            ip_address varchar(50) DEFAULT '',
            status varchar(20) DEFAULT 'new',
            PRIMARY KEY  (id)
        ) $charset_collate;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta( $sql );
    }

    /**
     * Đăng ký Custom Post Type 'dawp_contact_form'
     */
    public function register_post_type() {
        $labels = [
            'name'               => 'Form Liên Hệ',
            'singular_name'      => 'Form Liên Hệ',
            'menu_name'          => 'Form Liên Hệ',
            'name_admin_bar'     => 'Form Liên Hệ',
            'add_new'            => 'Thêm Form Mới',
            'add_new_item'       => 'Thêm Form Liên Hệ Mới',
            'new_item'           => 'Form Mới',
            'edit_item'          => 'Sửa Form Liên Hệ',
            'view_item'          => 'Xem Form',
            'all_items'          => 'Tất cả Form',
            'search_items'       => 'Tìm kiếm Form',
            'parent_item_colon'  => 'Form cha:',
            'not_found'          => 'Không tìm thấy Form nào.',
            'not_found_in_trash' => 'Không tìm thấy Form nào trong Thùng rác.'
        ];

        $args = [
            'labels'             => $labels,
            'public'             => false,
            'publicly_queryable' => false,
            'show_ui'            => true,
            'show_in_menu'       => true,
            'query_var'          => true,
            'rewrite'            => [ 'slug' => 'dawp-form' ],
            'capability_type'    => 'post',
            'has_archive'        => false,
            'hierarchical'       => false,
            'menu_position'      => 58,
            'menu_icon'          => 'dashicons-email-alt',
            'supports'           => [ 'title', 'editor', 'revisions' ]
        ];

        register_post_type( 'dawp_contact_form', $args );
    }

    /**
     * Hiển thị cột mã Shortcode trong danh sách Form quản trị
     */
    public function set_contact_form_columns($columns) {
        $new_columns = [];
        $new_columns['cb'] = $columns['cb'];
        $new_columns['title'] = 'Tên Form';
        $new_columns['shortcode'] = 'Mã Shortcode';
        $new_columns['date'] = $columns['date'];
        return $new_columns;
    }

    public function custom_contact_form_column($column, $post_id) {
        if ($column === 'shortcode') {
            echo '<code style="background: #f1f5f9; padding: 4px 8px; border-radius: 4px; font-weight: 600; font-family: monospace; border: 1px solid #cbd5e1; color: #0f172a;">[dawp_contact_form id="' . $post_id . '"]</code>';
        }
    }

    /**
     * Metabox Cài đặt Email & Thông báo cho từng Form
     */
    public function add_form_metabox() {
        add_meta_box(
            'dawp_form_settings_box',
            'Cài đặt Email & Thông báo',
            [ $this, 'render_form_metabox' ],
            'dawp_contact_form',
            'normal',
            'high'
        );
    }

    public function render_form_metabox( $post ) {
        $email = get_post_meta( $post->ID, '_dawp_email', true );
        $subject = get_post_meta( $post->ID, '_dawp_subject', true );
        $body = get_post_meta( $post->ID, '_dawp_body', true );
        $success_msg = get_post_meta( $post->ID, '_dawp_success_msg', true );

        // Cài đặt email tự động gửi cho khách (auto-reply)
        $reply_enable  = get_post_meta( $post->ID, '_dawp_customer_reply_enable', true );
        $reply_subject = get_post_meta( $post->ID, '_dawp_customer_subject', true );
        $reply_body    = get_post_meta( $post->ID, '_dawp_customer_body', true );
        // Mặc định BẬT gửi cho khách khi tạo form mới (chưa có meta lưu)
        $reply_enable_checked = ( $reply_enable === '' || $reply_enable === '1' ) ? '1' : '0';

        if ( empty($subject) ) $subject = 'Yêu cầu liên hệ mới từ Website';
        if ( empty($success_msg) ) $success_msg = 'Cảm ơn bạn! Thông tin liên hệ đã được gửi đi thành công.';
        if ( empty($body) ) {
            $body = "<h2>Thông tin yêu cầu liên hệ mới:</h2>\n<p><strong>Họ và tên:</strong> [your-name]</p>\n<p><strong>Số điện thoại:</strong> [your-phone]</p>\n<p><strong>Email:</strong> [your-email]</p>\n<p><strong>Nội dung:</strong><br>[your-message]</p>\n<br><hr><p><em>Thư này được gửi tự động từ Website.</em></p>";
        }
        if ( empty($reply_subject) ) $reply_subject = 'Cảm ơn bạn đã liên hệ với ' . get_bloginfo('name');
        if ( empty($reply_body) ) {
            $reply_body = "<p>Xin chào <strong>[your-name]</strong>,</p>\n<p>Cảm ơn bạn đã gửi thông tin liên hệ đến <strong>" . get_bloginfo('name') . "</strong>. Chúng tôi đã nhận được yêu cầu của bạn và sẽ phản hồi trong thời gian sớm nhất.</p>\n<p><strong>Nội dung bạn đã gửi:</strong><br>[your-message]</p>\n<br><hr><p style='font-size: 12px; color: #888;'><em>Đây là email tự động, vui lòng không trả lời trực tiếp email này.</em></p>";
        }

        wp_nonce_field( 'dawp_save_form_meta_action', 'dawp_form_meta_nonce' );
        ?>
        <div class="dawp-meta-box-wrap" style="font-family: -apple-system, BlinkMacSystemFont, sans-serif; padding: 5px 0;">
            <style>
                .dawp-meta-row { display: flex; flex-direction: column; margin-bottom: 20px; }
                .dawp-meta-row label { font-weight: 600; font-size: 14px; color: #1e293b; margin-bottom: 8px; }
                .dawp-meta-row input[type="text"], .dawp-meta-row input[type="email"], .dawp-meta-row textarea { padding: 10px 12px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 14px; width: 100%; box-sizing: border-box; }
                .dawp-meta-row input:focus, .dawp-meta-row textarea:focus { border-color: #0068ff; outline: none; box-shadow: 0 0 0 3px rgba(0, 104, 255, 0.1); }
                .dawp-meta-row p.desc { margin: 6px 0 0 0; font-size: 12px; color: #64748b; font-style: italic; }
            </style>
            
            <div class="dawp-meta-row">
                <label for="dawp_form_email">Email nhận thông báo:</label>
                <input type="email" id="dawp_form_email" name="dawp_form_email" value="<?php echo esc_attr( $email ); ?>" placeholder="<?php echo esc_attr( get_option('admin_email') ); ?>">
                <p class="desc">Nhập email sẽ nhận thông tin khách hàng gửi. Để trống sẽ tự động dùng email quản trị mặc định.</p>
            </div>

            <div class="dawp-meta-row">
                <label for="dawp_form_subject">Tiêu đề thư nhận:</label>
                <input type="text" id="dawp_form_subject" name="dawp_form_subject" value="<?php echo esc_attr( $subject ); ?>">
                <p class="desc">Tiêu đề của email gửi về quản trị viên.</p>
            </div>

            <div class="dawp-meta-row">
                <label for="dawp_form_body">Cấu hình Thư (Mail Body):</label>
                <textarea id="dawp_form_body" name="dawp_form_body" rows="8" style="font-family: monospace; font-size: 13px; line-height: 1.5;"><?php echo esc_textarea( $body ); ?></textarea>
                <p class="desc">Định dạng email gửi đi. Sử dụng các thẻ tag tương ứng như <code>[your-name]</code>, <code>[your-phone]</code>.</p>
            </div>

            <div class="dawp-meta-row">
                <label for="dawp_form_success_msg">Thông báo thành công:</label>
                <input type="text" id="dawp_form_success_msg" name="dawp_form_success_msg" value="<?php echo esc_attr( $success_msg ); ?>">
                <p class="desc">Thông báo hiển thị cho khách hàng ngay sau khi gửi form thành công.</p>
            </div>

            <hr style="border: none; border-top: 1px dashed #cbd5e1; margin: 25px 0 20px;">
            <h3 style="margin: 0 0 15px; font-size: 15px; color: #0068ff;">✉️ Email tự động gửi cho Khách hàng</h3>

            <div class="dawp-meta-row" style="margin-bottom: 15px;">
                <label style="display: flex; align-items: center; gap: 8px; cursor: pointer;">
                    <input type="hidden" name="dawp_customer_reply_enable" value="0">
                    <input type="checkbox" name="dawp_customer_reply_enable" value="1" <?php checked( '1', $reply_enable_checked ); ?> style="width: auto; margin: 0;">
                    <span>Gửi email xác nhận tự động cho khách sau khi gửi form</span>
                </label>
                <p class="desc">Khi bật, khách điền form (có nhập email) sẽ nhận được thư cảm ơn/xác nhận. Yêu cầu form phải có trường email <code>[email your-email]</code>.</p>
            </div>

            <div class="dawp-meta-row">
                <label for="dawp_form_customer_subject">Tiêu đề thư gửi khách:</label>
                <input type="text" id="dawp_form_customer_subject" name="dawp_form_customer_subject" value="<?php echo esc_attr( $reply_subject ); ?>">
            </div>

            <div class="dawp-meta-row">
                <label for="dawp_form_customer_body">Nội dung thư gửi khách:</label>
                <textarea id="dawp_form_customer_body" name="dawp_form_customer_body" rows="7" style="font-family: monospace; font-size: 13px; line-height: 1.5;"><?php echo esc_textarea( $reply_body ); ?></textarea>
                <p class="desc">Dùng các thẻ tag như <code>[your-name]</code>, <code>[your-phone]</code>, <code>[your-message]</code> để chèn thông tin khách đã điền.</p>
            </div>
        </div>
        <?php
    }

    public function save_form_meta( $post_id ) {
        if ( ! isset( $_POST['dawp_form_meta_nonce'] ) || ! wp_verify_nonce( $_POST['dawp_form_meta_nonce'], 'dawp_save_form_meta_action' ) ) {
            return;
        }

        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
        if ( ! current_user_can( 'edit_post', $post_id ) ) return;
        if ( get_post_type($post_id) !== 'dawp_contact_form' ) return;

        if ( isset($_POST['dawp_form_email']) ) {
            update_post_meta( $post_id, '_dawp_email', sanitize_email($_POST['dawp_form_email']) );
        }
        if ( isset($_POST['dawp_form_subject']) ) {
            update_post_meta( $post_id, '_dawp_subject', sanitize_text_field($_POST['dawp_form_subject']) );
        }
        if ( isset($_POST['dawp_form_body']) ) {
            update_post_meta( $post_id, '_dawp_body', wp_kses_post( wp_unslash( $_POST['dawp_form_body'] ) ) );
        }
        if ( isset($_POST['dawp_form_success_msg']) ) {
            update_post_meta( $post_id, '_dawp_success_msg', sanitize_text_field($_POST['dawp_form_success_msg']) );
        }

        // Lưu cài đặt email tự động gửi cho khách
        $reply_enable = ( isset($_POST['dawp_customer_reply_enable']) && $_POST['dawp_customer_reply_enable'] === '1' ) ? '1' : '0';
        update_post_meta( $post_id, '_dawp_customer_reply_enable', $reply_enable );

        if ( isset($_POST['dawp_form_customer_subject']) ) {
            update_post_meta( $post_id, '_dawp_customer_subject', sanitize_text_field($_POST['dawp_form_customer_subject']) );
        }
        if ( isset($_POST['dawp_form_customer_body']) ) {
            update_post_meta( $post_id, '_dawp_customer_body', wp_kses_post( wp_unslash( $_POST['dawp_form_customer_body'] ) ) );
        }
    }

    /**
     * Tiêm giao diện Preset và Helper buttons trên hook 'edit_form_after_title'
     */
    public function render_form_helpers( $post ) {
        if ( $post->post_type !== 'dawp_contact_form' ) {
            return;
        }
        ?>
        <div class="dawp-editor-helpers" style="margin: 20px 0 10px 0; font-family: -apple-system, BlinkMacSystemFont, sans-serif;">
            <!-- Presets Section -->
            <div class="dawp-presets-wrap" style="margin-bottom: 12px; background: #f8fafc; padding: 12px 15px; border-radius: 8px; border: 1px solid #e2e8f0;">
                <span style="font-weight: 600; font-size: 13px; display: block; margin-bottom: 8px; color: #1e293b;">📋 Nạp Form Mẫu Nhanh (5 Presets):</span>
                <div style="display: flex; gap: 10px; flex-wrap: wrap;">
                    <button type="button" class="button dawp-preset-btn" data-preset="simple">⚡ Form Đơn Giản</button>
                    <button type="button" class="button dawp-preset-btn" data-preset="service">💼 Form Tư Vấn Dịch Vụ</button>
                    <button type="button" class="button dawp-preset-btn" data-preset="order">🛒 Form Đặt Hàng Nhanh</button>
                    <button type="button" class="button dawp-preset-btn" data-preset="event">🎓 Đăng Ký Khóa Học / Sự Kiện</button>
                    <button type="button" class="button dawp-preset-btn" data-preset="recruitment">📝 Form Tuyển Dụng / Ứng Tuyển</button>
                </div>
            </div>
            
            <!-- Helper Tag Insertion Section -->
            <div class="dawp-helpers-wrap" style="margin-bottom: 5px; display: flex; flex-wrap: wrap; gap: 8px; align-items: center; background: #ffffff; padding: 10px; border-radius: 6px; border: 1px solid #e2e8f0;">
                <span style="font-weight: 600; font-size: 12px; color: #64748b; margin-right: 5px;">➕ Chèn nhanh:</span>
                <!-- Bố cục -->
                <button type="button" class="button button-small dawp-helper-btn" data-tag="row" title="Hàng chia cột">Dòng [row]</button>
                <button type="button" class="button button-small dawp-helper-btn" data-tag="col6" title="Cột rộng 50%">Cột 50% [col 6]</button>
                <button type="button" class="button button-small dawp-helper-btn" data-tag="col4" title="Cột rộng 33.33%">Cột 33% [col 4]</button>
                <button type="button" class="button button-small dawp-helper-btn" data-tag="col3" title="Cột rộng 25%">Cột 25% [col 3]</button>
                <button type="button" class="button button-small dawp-helper-btn" data-tag="col8" title="Cột rộng 66.66%">Cột 66% [col 8]</button>
                <span style="color: #cbd5e1;">|</span>
                <!-- Trường -->
                <button type="button" class="button button-small dawp-helper-btn" data-tag="text" title="Trường văn bản bắt buộc">Họ tên [text*]</button>
                <button type="button" class="button button-small dawp-helper-btn" data-tag="tel" title="Trường số điện thoại bắt buộc">SĐT [tel*]</button>
                <button type="button" class="button button-small dawp-helper-btn" data-tag="email" title="Trường email">Email [email]</button>
                <button type="button" class="button button-small dawp-helper-btn" data-tag="number" title="Trường nhập số bắt buộc">Số [number*]</button>
                <button type="button" class="button button-small dawp-helper-btn" data-tag="date" title="Trường ngày tháng bắt buộc">Ngày [date*]</button>
                <button type="button" class="button button-small dawp-helper-btn" data-tag="url" title="Trường website">Website [url]</button>
                <button type="button" class="button button-small dawp-helper-btn" data-tag="textarea" title="Hộp văn bản lớn">Lời nhắn [textarea]</button>
                <button type="button" class="button button-small dawp-helper-btn" data-tag="select" title="Menu lựa chọn thả xuống">Menu [select]</button>
                <button type="button" class="button button-small dawp-helper-btn" data-tag="checkbox" title="Hộp kiểm chọn nhiều">Hộp kiểm [checkbox]</button>
                <button type="button" class="button button-small dawp-helper-btn" data-tag="radio" title="Nút chọn một">Nút tròn [radio]</button>
                <button type="button" class="button button-small dawp-helper-btn" data-tag="acceptance" title="Hộp kiểm đồng ý điều khoản bắt buộc">Đồng ý [acceptance]</button>
                <span style="color: #cbd5e1;">|</span>
                <button type="button" class="button button-small dawp-helper-btn button-primary" data-tag="submit" style="background: #0068ff; border-color: #0068ff; color: #fff;" title="Nút gửi form">Nút gửi [submit]</button>
            </div>
        </div>

        <script>
        jQuery(document).ready(function($) {
             var presets = {
                simple: {
                    template: "[row]\n  [col 6]\n    <div class=\"dawp-form-group\">\n      <label>Họ và tên <span class=\"required\">*</span></label>\n      [text* your-name placeholder \"Họ tên của bạn\"]\n    </div>\n  [/col]\n  [col 6]\n    <div class=\"dawp-form-group\">\n      <label>Số điện thoại <span class=\"required\">*</span></label>\n      [tel* your-phone placeholder \"Số điện thoại\"]\n    </div>\n  [/col]\n[/row]\n<div class=\"dawp-form-group\">\n  <label>Địa chỉ Email</label>\n  [email your-email placeholder \"Địa chỉ Email\"]\n</div>\n<div class=\"dawp-form-group\">\n  <label>Lời nhắn <span class=\"required\">*</span></label>\n  [textarea* your-message placeholder \"Nội dung liên hệ...\"]\n</div>\n[submit \"Gửi đi\"]",
                    body: "<div style='max-width: 600px; margin: 10px auto; padding: 25px; border: 1px solid #e2e8f0; border-radius: 12px; font-family: sans-serif; background: #ffffff; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05);'>\n  <h2 style='color: #0068ff; margin: 0 0 20px 0; font-size: 20px; border-bottom: 2px solid #f1f5f9; padding-bottom: 12px; font-weight: 700;'>📩 Yêu cầu liên hệ mới</h2>\n  <table style='width: 100%; border-collapse: collapse;'>\n    <tr><td style='padding: 12px 0; border-bottom: 1px solid #f1f5f9; font-weight: bold; color: #475569; width: 140px;'>Họ và tên:</td><td style='padding: 12px 0; border-bottom: 1px solid #f1f5f9; color: #1e293b;'>[your-name]</td></tr>\n    <tr><td style='padding: 12px 0; border-bottom: 1px solid #f1f5f9; font-weight: bold; color: #475569;'>Số điện thoại:</td><td style='padding: 12px 0; border-bottom: 1px solid #f1f5f9; font-weight: 600; color: #0068ff;'>[your-phone]</td></tr>\n    <tr><td style='padding: 12px 0; border-bottom: 1px solid #f1f5f9; font-weight: bold; color: #475569;'>Email:</td><td style='padding: 12px 0; border-bottom: 1px solid #f1f5f9; color: #1e293b;'>[your-email]</td></tr>\n    <tr><td style='padding: 12px 0; font-weight: bold; color: #475569; vertical-align: top;'>Lời nhắn:</td><td style='padding: 12px 0; line-height: 1.6; color: #1e293b;'>[your-message]</td></tr>\n  </table>\n  <hr style='border: none; border-top: 1px solid #f1f5f9; margin: 20px 0;'>\n  <p style='font-size: 12px; color: #94a3b8; font-style: italic; margin: 0;'>Thư này được gửi tự động qua hệ thống Duy Anh Web Pro.</p>\n</div>"
                },
                service: {
                    template: "[row]\n  [col 6]\n    <div class=\"dawp-form-group\">\n      <label>Họ và tên <span class=\"required\">*</span></label>\n      [text* your-name placeholder \"Họ tên của bạn\"]\n    </div>\n  [/col]\n  [col 6]\n    <div class=\"dawp-form-group\">\n      <label>Số điện thoại <span class=\"required\">*</span></label>\n      [tel* your-phone placeholder \"Số điện thoại\"]\n    </div>\n  [/col]\n[/row]\n[row]\n  [col 6]\n    <div class=\"dawp-form-group\">\n      <label>Địa chỉ Email</label>\n      [email your-email placeholder \"Địa chỉ Email\"]\n    </div>\n  [/col]\n  [col 6]\n    <div class=\"dawp-form-group\">\n      <label>Dịch vụ cần tư vấn <span class=\"required\">*</span></label>\n      [select your-service \"Tư vấn thiết kế Website\" \"SEO & Marketing Online\" \"Chăm sóc & Quản trị Web\"]\n    </div>\n  [/col]\n[/row]\n<div class=\"dawp-form-group\">\n  <label>Lời nhắn / Yêu cầu thêm</label>\n  [textarea your-message placeholder \"Mô tả chi tiết yêu cầu của bạn...\"]\n</div>\n[submit \"Gửi yêu cầu tư vấn\"]",
                    body: "<div style='max-width: 600px; margin: 10px auto; padding: 25px; border: 1px solid #e2e8f0; border-radius: 12px; font-family: sans-serif; background: #ffffff; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05);'>\n  <h2 style='color: #0d9488; margin: 0 0 20px 0; font-size: 20px; border-bottom: 2px solid #f1f5f9; padding-bottom: 12px; font-weight: 700;'>💼 Yêu cầu tư vấn dịch vụ</h2>\n  <table style='width: 100%; border-collapse: collapse;'>\n    <tr><td style='padding: 12px 0; border-bottom: 1px solid #f1f5f9; font-weight: bold; color: #475569; width: 150px;'>Họ và tên:</td><td style='padding: 12px 0; border-bottom: 1px solid #f1f5f9; color: #1e293b;'>[your-name]</td></tr>\n    <tr><td style='padding: 12px 0; border-bottom: 1px solid #f1f5f9; font-weight: bold; color: #475569;'>Số điện thoại:</td><td style='padding: 12px 0; border-bottom: 1px solid #f1f5f9; font-weight: 600; color: #0d9488;'>[your-phone]</td></tr>\n    <tr><td style='padding: 12px 0; border-bottom: 1px solid #f1f5f9; font-weight: bold; color: #475569;'>Email:</td><td style='padding: 12px 0; border-bottom: 1px solid #f1f5f9; color: #1e293b;'>[your-email]</td></tr>\n    <tr><td style='padding: 12px 0; border-bottom: 1px solid #f1f5f9; font-weight: bold; color: #475569;'>Dịch vụ lựa chọn:</td><td style='padding: 12px 0; border-bottom: 1px solid #f1f5f9; font-weight: 600; color: #1e293b;'>[your-service]</td></tr>\n    <tr><td style='padding: 12px 0; font-weight: bold; color: #475569; vertical-align: top;'>Nội dung yêu cầu:</td><td style='padding: 12px 0; line-height: 1.6; color: #1e293b;'>[your-message]</td></tr>\n  </table>\n  <hr style='border: none; border-top: 1px solid #f1f5f9; margin: 20px 0;'>\n  <p style='font-size: 12px; color: #94a3b8; font-style: italic; margin: 0;'>Thư này được gửi tự động qua hệ thống Duy Anh Web Pro.</p>\n</div>"
                },
                order: {
                    template: "[row]\n  [col 6]\n    <div class=\"dawp-form-group\">\n      <label>Họ và tên người nhận <span class=\"required\">*</span></label>\n      [text* your-name placeholder \"Họ tên người nhận\"]\n    </div>\n  [/col]\n  [col 6]\n    <div class=\"dawp-form-group\">\n      <label>Số điện thoại nhận hàng <span class=\"required\">*</span></label>\n      [tel* your-phone placeholder \"Số điện thoại nhận hàng\"]\n    </div>\n  [/col]\n[/row]\n<div class=\"dawp-form-group\">\n  <label>Sản phẩm muốn đặt mua <span class=\"required\">*</span></label>\n  [select your-product \"Sản phẩm A - 299k\" \"Sản phẩm B - 499k\" \"Sản phẩm C - 999k\"]\n</div>\n<div class=\"dawp-form-group\">\n  <label>Địa chỉ giao hàng chi tiết <span class=\"required\">*</span></label>\n  [text* your-address placeholder \"Địa chỉ nhận hàng (Số nhà, đường, phường/xã, quận/huyện...)\"]\n</div>\n<div class=\"dawp-form-group\">\n  <label>Ghi chú đơn hàng (nếu có)</label>\n  [textarea your-message placeholder \"Thời gian nhận hàng thuận tiện, yêu cầu thêm...\"]\n</div>\n[submit \"Xác nhận đặt hàng nhanh\"]",
                    body: "<div style='max-width: 600px; margin: 10px auto; padding: 25px; border: 1px solid #e2e8f0; border-radius: 12px; font-family: sans-serif; background: #ffffff; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05);'>\n  <h2 style='color: #ea580c; margin: 0 0 20px 0; font-size: 20px; border-bottom: 2px solid #f1f5f9; padding-bottom: 12px; font-weight: 700;'>🛒 Đơn đặt hàng nhanh mới</h2>\n  <table style='width: 100%; border-collapse: collapse;'>\n    <tr><td style='padding: 12px 0; border-bottom: 1px solid #f1f5f9; font-weight: bold; color: #475569; width: 160px;'>Họ tên người nhận:</td><td style='padding: 12px 0; border-bottom: 1px solid #f1f5f9; color: #1e293b;'>[your-name]</td></tr>\n    <tr><td style='padding: 12px 0; border-bottom: 1px solid #f1f5f9; font-weight: bold; color: #475569;'>Số điện thoại:</td><td style='padding: 12px 0; border-bottom: 1px solid #f1f5f9; font-weight: 600; color: #ea580c;'>[your-phone]</td></tr>\n    <tr><td style='padding: 12px 0; border-bottom: 1px solid #f1f5f9; font-weight: bold; color: #475569;'>Sản phẩm mua:</td><td style='padding: 12px 0; border-bottom: 1px solid #f1f5f9; font-weight: 600; color: #1e293b;'>[your-product]</td></tr>\n    <tr><td style='padding: 12px 0; border-bottom: 1px solid #f1f5f9; font-weight: bold; color: #475569;'>Địa chỉ nhận hàng:</td><td style='padding: 12px 0; border-bottom: 1px solid #f1f5f9; color: #1e293b;'>[your-address]</td></tr>\n    <tr><td style='padding: 12px 0; font-weight: bold; color: #475569; vertical-align: top;'>Ghi chú đơn hàng:</td><td style='padding: 12px 0; line-height: 1.6; color: #1e293b;'>[your-message]</td></tr>\n  </table>\n  <hr style='border: none; border-top: 1px solid #f1f5f9; margin: 20px 0;'>\n  <p style='font-size: 12px; color: #94a3b8; font-style: italic; margin: 0;'>Thư này được gửi tự động qua hệ thống Duy Anh Web Pro.</p>\n</div>"
                },
                event: {
                    template: "[row]\n  [col 6]\n    <div class=\"dawp-form-group\">\n      <label>Họ và tên học viên <span class=\"required\">*</span></label>\n      [text* your-name placeholder \"Họ tên của bạn\"]\n    </div>\n  [/col]\n  [col 6]\n    <div class=\"dawp-form-group\">\n      <label>Số điện thoại liên hệ <span class=\"required\">*</span></label>\n      [tel* your-phone placeholder \"Số điện thoại\"]\n    </div>\n  [/col]\n[/row]\n[row]\n  [col 6]\n    <div class=\"dawp-form-group\">\n      <label>Địa chỉ Email</label>\n      [email your-email placeholder \"Địa chỉ Email\"]\n    </div>\n  [/col]\n  [col 6]\n    <div class=\"dawp-form-group\">\n      <label>Khóa học / Sự kiện đăng ký <span class=\"required\">*</span></label>\n      [select your-event \"Khóa học Thiết kế Web chuyên nghiệp\" \"Workshop Marketing Online\" \"Khóa học Lập trình Frontend\"]\n    </div>\n  [/col]\n[/row]\n[row]\n  [col 6]\n    <div class=\"dawp-form-group\">\n      <label>Ngày muốn tham gia <span class=\"required\">*</span></label>\n      [date* your-date]\n    </div>\n  [/col]\n  [col 6]\n    <div class=\"dawp-form-group\">\n      <label>Số lượng đăng ký <span class=\"required\">*</span></label>\n      [number* your-quantity placeholder \"Số người tham gia\"]\n    </div>\n  [/col]\n[/row]\n[acceptance your-consent \"Tôi cam kết tham dự sự kiện đúng giờ và đồng ý với các điều khoản\"]\n[submit \"Đăng ký tham gia ngay\"]",
                    body: "<div style='max-width: 600px; margin: 10px auto; padding: 25px; border: 1px solid #e2e8f0; border-radius: 12px; font-family: sans-serif; background: #ffffff; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05);'>\n  <h2 style='color: #6366f1; margin: 0 0 20px 0; font-size: 20px; border-bottom: 2px solid #f1f5f9; padding-bottom: 12px; font-weight: 700;'>🎓 Đăng ký Khóa học / Sự kiện mới</h2>\n  <table style='width: 100%; border-collapse: collapse;'>\n    <tr><td style='padding: 12px 0; border-bottom: 1px solid #f1f5f9; font-weight: bold; color: #475569; width: 160px;'>Họ tên học viên:</td><td style='padding: 12px 0; border-bottom: 1px solid #f1f5f9; color: #1e293b;'>[your-name]</td></tr>\n    <tr><td style='padding: 12px 0; border-bottom: 1px solid #f1f5f9; font-weight: bold; color: #475569;'>Số điện thoại:</td><td style='padding: 12px 0; border-bottom: 1px solid #f1f5f9; font-weight: 600; color: #6366f1;'>[your-phone]</td></tr>\n    <tr><td style='padding: 12px 0; border-bottom: 1px solid #f1f5f9; font-weight: bold; color: #475569;'>Email:</td><td style='padding: 12px 0; border-bottom: 1px solid #f1f5f9; color: #1e293b;'>[your-email]</td></tr>\n    <tr><td style='padding: 12px 0; border-bottom: 1px solid #f1f5f9; font-weight: bold; color: #475569;'>Sự kiện / Khóa học:</td><td style='padding: 12px 0; border-bottom: 1px solid #f1f5f9; font-weight: 600; color: #1e293b;'>[your-event]</td></tr>\n    <tr><td style='padding: 12px 0; border-bottom: 1px solid #f1f5f9; font-weight: bold; color: #475569;'>Ngày đăng ký học:</td><td style='padding: 12px 0; border-bottom: 1px solid #f1f5f9; color: #1e293b;'>[your-date]</td></tr>\n    <tr><td style='padding: 12px 0; border-bottom: 1px solid #f1f5f9; font-weight: bold; color: #475569;'>Số lượng người:</td><td style='padding: 12px 0; border-bottom: 1px solid #f1f5f9; color: #1e293b;'>[your-quantity]</td></tr>\n  </table>\n  <hr style='border: none; border-top: 1px solid #f1f5f9; margin: 20px 0;'>\n  <p style='font-size: 12px; color: #94a3b8; font-style: italic; margin: 0;'>Thư này được gửi tự động qua hệ thống Duy Anh Web Pro.</p>\n</div>"
                },
                recruitment: {
                    template: "[row]\n  [col 6]\n    <div class=\"dawp-form-group\">\n      <label>Họ và tên ứng viên <span class=\"required\">*</span></label>\n      [text* your-name placeholder \"Họ tên của bạn\"]\n    </div>\n  [/col]\n  [col 6]\n    <div class=\"dawp-form-group\">\n      <label>Số điện thoại liên hệ <span class=\"required\">*</span></label>\n      [tel* your-phone placeholder \"Số điện thoại\"]\n    </div>\n  [/col]\n[/row]\n[row]\n  [col 6]\n    <div class=\"dawp-form-group\">\n      <label>Địa chỉ Email <span class=\"required\">*</span></label>\n      [email* your-email placeholder \"Địa chỉ Email\"]\n    </div>\n  [/col]\n  [col 6]\n    <div class=\"dawp-form-group\">\n      <label>Vị trí ứng tuyển <span class=\"required\">*</span></label>\n      [select your-position \"Nhân viên Thiết kế Web\" \"Nhân viên Lập trình WP\" \"Nhân viên SEO & Content\"]\n    </div>\n  [/col]\n[/row]\n<div class=\"dawp-form-group\">\n  <label>Link CV / Portfolio (Google Drive, Behance...) <span class=\"required\">*</span></label>\n  [url* your-portfolio placeholder \"https://drive.google.com/...\"]\n</div>\n<div class=\"dawp-form-group\">\n  <label>Giới thiệu bản thân & Kinh nghiệm làm việc</label>\n  [textarea your-message placeholder \"Kinh nghiệm làm việc trước đây, thời gian có thể đi làm...\"]\n</div>\n[acceptance your-consent \"Tôi xác nhận thông tin trên là chính xác và đồng ý tham gia phỏng vấn\"]\n[submit \"Nộp hồ sơ ứng tuyển\"]",
                    body: "<div style='max-width: 600px; margin: 10px auto; padding: 25px; border: 1px solid #e2e8f0; border-radius: 12px; font-family: sans-serif; background: #ffffff; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05);'>\n  <h2 style='color: #4b5563; margin: 0 0 20px 0; font-size: 20px; border-bottom: 2px solid #f1f5f9; padding-bottom: 12px; font-weight: 700;'>📝 Hồ sơ ứng cử viên mới</h2>\n  <table style='width: 100%; border-collapse: collapse;'>\n    <tr><td style='padding: 12px 0; border-bottom: 1px solid #f1f5f9; font-weight: bold; color: #475569; width: 170px;'>Họ tên ứng viên:</td><td style='padding: 12px 0; border-bottom: 1px solid #f1f5f9; color: #1e293b;'>[your-name]</td></tr>\n    <tr><td style='padding: 12px 0; border-bottom: 1px solid #f1f5f9; font-weight: bold; color: #475569;'>Số điện thoại:</td><td style='padding: 12px 0; border-bottom: 1px solid #f1f5f9; font-weight: 600; color: #1e293b;'>[your-phone]</td></tr>\n    <tr><td style='padding: 12px 0; border-bottom: 1px solid #f1f5f9; font-weight: bold; color: #475569;'>Email:</td><td style='padding: 12px 0; border-bottom: 1px solid #f1f5f9; color: #1e293b;'>[your-email]</td></tr>\n    <tr><td style='padding: 12px 0; border-bottom: 1px solid #f1f5f9; font-weight: bold; color: #475569;'>Vị trí ứng tuyển:</td><td style='padding: 12px 0; border-bottom: 1px solid #f1f5f9; font-weight: 600; color: #1e293b;'>[your-position]</td></tr>\n    <tr><td style='padding: 12px 0; border-bottom: 1px solid #f1f5f9; font-weight: bold; color: #475569;'>Link CV / Portfolio:</td><td style='padding: 12px 0; border-bottom: 1px solid #f1f5f9;'><a href='[your-portfolio]' target='_blank' style='color: #0068ff;'>[your-portfolio]</a></td></tr>\n    <tr><td style='padding: 12px 0; font-weight: bold; color: #475569; vertical-align: top;'>Kinh nghiệm / Giới thiệu:</td><td style='padding: 12px 0; line-height: 1.6; color: #1e293b;'>[your-message]</td></tr>\n  </table>\n  <hr style='border: none; border-top: 1px solid #f1f5f9; margin: 20px 0;'>\n  <p style='font-size: 12px; color: #94a3b8; font-style: italic; margin: 0;'>Thư này được gửi tự động qua hệ thống Duy Anh Web Pro.</p>\n</div>"
                }
            };

            $('.dawp-preset-btn').on('click', function(e) {
                e.preventDefault();
                var key = $(this).data('preset');
                if (!presets[key]) return;

                if (confirm('Bạn có chắc chắn muốn nạp mẫu này? Hành động này sẽ ghi đè toàn bộ nội dung trong ô soạn thảo chính và các trường cấu hình ở Metabox bên dưới.')) {
                    if (typeof tinyMCE !== 'undefined' && tinyMCE.get('content') && !tinyMCE.get('content').isHidden()) {
                        tinyMCE.get('content').setContent(presets[key].template);
                    } else {
                        $('#content').val(presets[key].template);
                    }
                    $('#dawp_form_body').val(presets[key].body);
                }
            });

            function insertAtCursor(myValue) {
                if (typeof tinyMCE !== 'undefined' && tinyMCE.get('content') && !tinyMCE.get('content').isHidden()) {
                    tinyMCE.get('content').execCommand('mceInsertContent', false, myValue);
                } else {
                    var myField = $('#content')[0];
                    if (!myField) return;
                    
                    if (myField.selectionStart || myField.selectionStart == '0') {
                        var startPos = myField.selectionStart;
                        var endPos = myField.selectionEnd;
                        var val = myField.value;
                        myField.value = val.substring(0, startPos) + myValue + val.substring(endPos, val.length);
                        myField.focus();
                        myField.selectionStart = startPos + myValue.length;
                        myField.selectionEnd = startPos + myValue.length;
                    } else {
                        myField.value += myValue;
                    }
                }
            }

            $('.dawp-helper-btn').on('click', function(e) {
                e.preventDefault();
                var tagKey = $(this).data('tag');
                var insertVal = '';

                switch(tagKey) {
                    case 'row':
                        insertVal = "[row]\n  [col 6]\n    \n  [/col]\n  [col 6]\n    \n  [/col]\n[/row]";
                        break;
                    case 'col6':
                        insertVal = "[col 6]\n  \n[/col]";
                        break;
                    case 'col4':
                        insertVal = "[col 4]\n  \n[/col]";
                        break;
                    case 'col3':
                        insertVal = "[col 3]\n  \n[/col]";
                        break;
                    case 'col8':
                        insertVal = "[col 8]\n  \n[/col]";
                        break;
                    case 'text':
                        insertVal = '[text* your-name placeholder "Họ tên"]';
                        break;
                    case 'tel':
                        insertVal = '[tel* your-phone placeholder "Số điện thoại"]';
                        break;
                    case 'email':
                        insertVal = '[email your-email placeholder "Địa chỉ Email"]';
                        break;
                    case 'number':
                        insertVal = '[number* your-number placeholder "Nhập số"]';
                        break;
                    case 'date':
                        insertVal = '[date* your-date]';
                        break;
                    case 'url':
                        insertVal = '[url your-website placeholder "https://example.com"]';
                        break;
                    case 'textarea':
                        insertVal = '[textarea your-message placeholder "Nội dung liên hệ..."]';
                        break;
                    case 'select':
                        insertVal = '[select your-select "Lựa chọn 1" "Lựa chọn 2"]';
                        break;
                    case 'checkbox':
                        insertVal = '[checkbox your-checkbox "Tùy chọn A" "Tùy chọn B"]';
                        break;
                    case 'radio':
                        insertVal = '[radio your-radio "Lựa chọn A" "Lựa chọn B"]';
                        break;
                    case 'acceptance':
                        insertVal = '[acceptance your-consent "Tôi đồng ý với các điều khoản dịch vụ và chính sách bảo mật"]';
                        break;
                    case 'submit':
                        insertVal = '[submit "Gửi đi"]';
                        break;
                }

                if (insertVal !== '') {
                    insertAtCursor(insertVal);
                }
            });
        });
        </script>
        <?php
    }

    /**
     * Phân tích và biên dịch cú pháp tag của Contact Form 7 thành HTML
     */
    public static function parse_form_template( $template ) {
        if ( empty($template) ) {
            return '';
        }

        // 1. Phân tích các thẻ bố cục dòng & cột [row], [col 6], [/col], [/row]
        $template = str_replace( '[row]', '<div class="dawp-form-row">', $template );
        $template = str_replace( '[/row]', '</div>', $template );
        
        $template = preg_replace_callback('/\[col\s+(\d+)\]/i', function($m) {
            return '<div class="dawp-form-col dawp-col-' . esc_attr($m[1]) . '">';
        }, $template);
        $template = str_replace( '[/col]', '</div>', $template );

        // 2. Dịch các tag select, checkbox, radio với danh sách options dạng: [select your-service "Option 1" "Option 2"]
        $template = preg_replace_callback('/\[(select|checkbox|radio)(\*)?\s+([a-zA-Z0-9\-_]+)((?:\s+"[^"]+")+)?\]/i', function($m) {
            $type = $m[1];
            $required = !empty($m[2]) ? 'required' : '';
            $name = $m[3];
            $options_str = isset($m[4]) ? $m[4] : '';
            
            preg_match_all('/"([^"]+)"/', $options_str, $opts_matches);
            $options = !empty($opts_matches[1]) ? $opts_matches[1] : [];

            if ($type === 'select') {
                $html = '<select name="' . esc_attr($name) . '" ' . $required . ' class="dawp-select">';
                if ($required === '') {
                    $lbl_select = '--- Chọn tùy chọn ---';
                    if ( class_exists( 'DAWP_Multilingual' ) ) {
                        $lang = DAWP_Multilingual::get_current_language();
                        $default_lang = DAWP_Multilingual::get_default_language();
                        if ( $lang !== $default_lang ) {
                            $select_translations = [
                                'en' => '--- Select option ---',
                                'ja' => '--- オプションを選択してください ---',
                                'zh' => '--- 请选择选项 ---',
                                'ko' => '--- 옵션을 선택하세요 ---',
                                'fr' => '--- Choisissez une option ---',
                                'de' => '--- Option wählen ---',
                                'ru' => '--- Выберите вариант ---'
                            ];
                            if ( isset( $select_translations[ $lang ] ) ) {
                                $lbl_select = $select_translations[ $lang ];
                            }
                        }
                    }
                    $html .= '<option value="">' . esc_html($lbl_select) . '</option>';
                }
                foreach ($options as $opt) {
                    $html .= '<option value="' . esc_attr($opt) . '">' . esc_html($opt) . '</option>';
                }
                $html .= '</select>';
                return $html;
            } elseif ($type === 'checkbox') {
                $html = '<div class="dawp-checkbox-group">';
                foreach ($options as $opt) {
                    $html .= '<label class="dawp-checkbox-label"><input type="checkbox" name="' . esc_attr($name) . '[]" value="' . esc_attr($opt) . '" class="dawp-checkbox"> ' . esc_html($opt) . '</label>';
                }
                $html .= '</div>';
                return $html;
            } elseif ($type === 'radio') {
                $html = '<div class="dawp-radio-group">';
                foreach ($options as $opt) {
                    $html .= '<label class="dawp-radio-label"><input type="radio" name="' . esc_attr($name) . '" value="' . esc_attr($opt) . '" ' . $required . ' class="dawp-radio"> ' . esc_html($opt) . '</label>';
                }
                $html .= '</div>';
                return $html;
            }
            return '';
        }, $template);

        // 2.5 Dịch tag acceptance dạng: [acceptance your-consent "Tôi đồng ý với điều khoản"]
        $template = preg_replace_callback('/\[acceptance\s+([a-zA-Z0-9\-_]+)\s+"([^"]+)"\]/i', function($m) {
            $name = $m[1];
            $label = $m[2];
            return '<div class="dawp-acceptance-group" style="margin-top: 10px; margin-bottom: 10px;">
                <label class="dawp-checkbox-label">
                    <input type="checkbox" name="' . esc_attr($name) . '" required class="dawp-checkbox"> ' . esc_html($label) . ' <span class="required" style="color: #f44336;">*</span>
                </label>
            </div>';
        }, $template);

        // 3. Dịch các tag nhập liệu dạng: [text* your-name placeholder "Họ tên"] hoặc [email your-email]
        $template = preg_replace_callback('/\[(text|email|tel|number|date|url|textarea)(\*)?\s+([a-zA-Z0-9\-_]+)(?:\s+placeholder\s+"([^"]+)")?\]/i', function($m) {
            $type = $m[1];
            $required = !empty($m[2]) ? 'required' : '';
            $name = $m[3];
            $placeholder = isset($m[4]) ? 'placeholder="' . esc_attr($m[4]) . '"' : '';
            
            if ($type === 'textarea') {
                return '<textarea name="' . esc_attr($name) . '" ' . $required . ' ' . $placeholder . ' class="dawp-textarea" rows="4"></textarea>';
            } else {
                return '<input type="' . esc_attr($type) . '" name="' . esc_attr($name) . '" ' . $required . ' ' . $placeholder . ' class="dawp-input">';
            }
        }, $template);

        // 4. Dịch tag nút gửi dạng: [submit "Gửi đi"]
        $template = preg_replace_callback('/\[submit\s+"([^"]+)"\]/i', function($m) {
            return '<button type="submit" class="dawp-form-submit">
                <span>' . esc_html($m[1]) . '</span>
                <svg class="dawp-spinner" viewBox="0 0 50 50"><circle class="path" cx="25" cy="25" r="20" fill="none" stroke-width="5"></circle></svg>
            </button>';
        }, $template);

        return $template;
    }

    /**
     * Hiển thị Form liên hệ ngoài Frontend thông qua Shortcode
     */
    public function render_form( $atts = [] ) {
        $atts = shortcode_atts( [
            'id' => 0
        ], $atts, 'dawp_contact_form' );

        $form_id = (int)$atts['id'];

        if ( !$form_id ) {
            // Lấy form mới nhất đã xuất bản làm mặc định
            $latest_forms = get_posts( [
                'post_type'      => 'dawp_contact_form',
                'posts_per_page' => 1,
                'post_status'    => 'publish'
            ] );
            if ( !empty($latest_forms) ) {
                $form_id = $latest_forms[0]->ID;
            }
        }

        if ( !$form_id || get_post_type($form_id) !== 'dawp_contact_form' ) {
            return '<div class="dawp-form-error" style="color: #f44336; border: 1px solid #f44336; padding: 15px; border-radius: 8px; font-weight: 600; font-family: sans-serif;">Lỗi: Không tìm thấy form liên hệ nào.</div>';
        }

        // Lấy nội dung thô để tránh wpautop phá vỡ cấu trúc form
        $form_template = get_post_field( 'post_content', $form_id );

        // Biên dịch tag
        $parsed_form = self::parse_form_template( $form_template );

        $uniq_id = 'dawp-form-' . rand(1000, 9999) . '-' . $form_id;

        // Lấy ngôn ngữ hiện tại của Form
        $form_lang = '';
        if ( class_exists( 'DAWP_Multilingual' ) ) {
            $form_lang = DAWP_Multilingual::get_current_language();
        }

        // Placeholder HTML cho captcha, sẽ được nạp động qua AJAX để bypass cache
        $captcha_html = '
        <div class="dawp-form-group dawp-captcha-wrap" style="margin-top: 15px; display: none;">
            <label><span class="dawp-captcha-label">Mã bảo mật</span> <span class="required">*</span></label>
            <div class="dawp-captcha-row">
                <div class="dawp-captcha-code" aria-hidden="true"></div>
                <button type="button" class="dawp-captcha-reload" title="Đổi mã khác" aria-label="Đổi mã khác">&#8635;</button>
                <input type="text" name="dawp_captcha" class="dawp-captcha-input" required autocomplete="off" spellcheck="false" maxlength="8" placeholder="Nhập mã">
                <input type="hidden" name="dawp_captcha_hash" value="" class="dawp-captcha-hash">
            </div>
        </div>';

        // Chèn captcha vào ngay trước nút submit
        if ( strpos( $parsed_form, '<button type="submit"' ) !== false ) {
            $parsed_form = str_replace( '<button type="submit"', $captcha_html . '<button type="submit"', $parsed_form );
        } else {
            $parsed_form .= $captcha_html;
        }

        ob_start();
        ?>
        <div class="dawp-form-container">
            <form id="<?php echo esc_attr( $uniq_id ); ?>" class="dawp-contact-form-el" method="POST">
                <?php echo $parsed_form; ?>
                
                <input type="hidden" name="dawp_form_id" value="<?php echo esc_attr( $form_id ); ?>">
                <input type="hidden" name="dawp_form_lang" value="<?php echo esc_attr( $form_lang ); ?>">
                
                <div class="dawp-form-response"></div>
            </form>
        </div>

        <style>
            .dawp-spinner { display: none; width: 20px; height: 20px; animation: dawp-rotate 2s linear infinite; }
            .dawp-spinner .path { stroke: #ffffff; stroke-linecap: round; animation: dawp-dash 1.5s ease-in-out infinite; }
            @keyframes dawp-rotate { 100% { transform: rotate(360deg); } }
            @keyframes dawp-dash { 0% { stroke-dasharray: 1, 150; stroke-dashoffset: 0; } 50% { stroke-dasharray: 90, 150; stroke-dashoffset: -35; } 100% { stroke-dasharray: 90, 150; stroke-dashoffset: -124; } }
            .dawp-form-response { display: none; }
            .dawp-form-response.success, .dawp-form-response.error { display: block; }

            /* Captcha chữ */
            .dawp-captcha-row { display: flex; gap: 10px; align-items: center; flex-wrap: wrap; }
            .dawp-captcha-code {
                display: inline-flex; align-items: center; gap: 4px;
                padding: 8px 16px; min-width: 130px; height: 44px; box-sizing: border-box;
                border: 1px solid #d5dbe3; border-radius: 10px;
                background: linear-gradient(135deg, #eef2ff 0%, #e0f2fe 100%);
                background-size: cover; user-select: none;
                font-family: "Courier New", Consolas, monospace; font-weight: 800; font-size: 25px;
                letter-spacing: 3px; text-shadow: 1px 1px 0 rgba(255,255,255,.6);
            }
            .dawp-captcha-code span { display: inline-block; line-height: 1; }
            .dawp-captcha-reload {
                width: 44px; height: 44px; flex-shrink: 0; cursor: pointer;
                border: 1px solid #d5dbe3; border-radius: 10px; background: #f4f6f9;
                color: #475569; font-size: 20px; line-height: 1;
                display: inline-flex; align-items: center; justify-content: center;
                transition: transform .35s ease, background .2s ease;
            }
            .dawp-captcha-reload:hover { background: #e6eaf0; transform: rotate(-180deg); }
            .dawp-captcha-input {
                width: 140px; height: 44px; box-sizing: border-box; text-align: center;
                padding: 10px; border: 1px solid #d5dbe3; border-radius: 10px;
                font-size: 16px; font-weight: 600; letter-spacing: 3px; text-transform: uppercase;
            }
            .dawp-captcha-input:focus { border-color: #2563eb; outline: none; box-shadow: 0 0 0 3px rgba(37,99,235,.12); }
        </style>

        <script>
            (function() {
                if (window.dawpFormListenerBound) return;
                window.dawpFormListenerBound = true;

                var dawpCaptchaColors = ["#2563eb", "#dc2626", "#059669", "#d97706", "#7c3aed", "#0891b2", "#db2777"];

                // Dựng mã captcha chữ có màu + nghiêng nhẹ cho đẹp
                function dawpRenderCaptcha(form, code, hash, label) {
                    var box = form.querySelector(".dawp-captcha-code");
                    var hashInput = form.querySelector(".dawp-captcha-hash");
                    var labelEl = form.querySelector(".dawp-captcha-label");
                    if (box) {
                        box.innerHTML = "";
                        for (var i = 0; i < code.length; i++) {
                            var s = document.createElement("span");
                            s.textContent = code.charAt(i);
                            var rot = (Math.random() * 24 - 12).toFixed(1);
                            s.style.transform = "rotate(" + rot + "deg)";
                            s.style.color = dawpCaptchaColors[Math.floor(Math.random() * dawpCaptchaColors.length)];
                            box.appendChild(s);
                        }
                    }
                    if (hashInput) hashInput.value = hash;
                    if (labelEl && label) labelEl.textContent = label;
                }

                // Gọi máy chủ lấy mã captcha mới
                function dawpLoadCaptcha(form) {
                    var lang = form.querySelector("input[name=\'dawp_form_lang\']");
                    var langVal = lang ? lang.value : "vi";
                    var input = form.querySelector(".dawp-captcha-input");
                    if (input) input.value = "";

                    var xhr = new XMLHttpRequest();
                    xhr.open("POST", "<?php echo admin_url('admin-ajax.php'); ?>");
                    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                    xhr.onload = function() {
                        if (xhr.status === 200) {
                            try {
                                var res = JSON.parse(xhr.responseText);
                                if (res.success) {
                                    var wrap = form.querySelector(".dawp-captcha-wrap");
                                    if (wrap) {
                                        dawpRenderCaptcha(form, res.data.code, res.data.hash, res.data.label);
                                        wrap.style.display = "block";
                                    }
                                }
                            } catch(err) {}
                        }
                    };
                    xhr.send("action=dawp_get_form_captcha&lang=" + encodeURIComponent(langVal));
                }

                // Tự động load captcha khi người dùng bắt đầu tương tác với form
                document.addEventListener("focusin", function(e) {
                    var form = e.target.form;
                    if (!form || !form.classList.contains("dawp-contact-form-el") || form.dawpCaptchaLoaded) return;
                    form.dawpCaptchaLoaded = true;
                    dawpLoadCaptcha(form);
                });

                // Bấm nút đổi mã để lấy captcha khác
                document.addEventListener("click", function(e) {
                    var btn = e.target.closest(".dawp-captcha-reload");
                    if (!btn) return;
                    var form = btn.form || btn.closest("form");
                    if (form) dawpLoadCaptcha(form);
                });

                document.addEventListener("submit", function(e) {
                    var form = e.target;
                    if (!form || !form.classList.contains("dawp-contact-form-el")) return;
                    
                    e.preventDefault();
                    
                    var submitBtn = form.querySelector(".dawp-form-submit");
                    var spinner = form.querySelector(".dawp-spinner");
                    var responseDiv = form.querySelector(".dawp-form-response");
                    
                    if (submitBtn) submitBtn.disabled = true;
                    if (spinner) spinner.style.display = "block";
                    if (responseDiv) responseDiv.style.display = "none";
                    
                    var formData = new FormData(form);
                    formData.append("action", "dawp_submit_contact_form");
                    
                    var ajaxUrl = "<?php echo admin_url('admin-ajax.php'); ?>";
                    // Tự động khớp giao thức trang tránh Mixed Content (HTTP/HTTPS)
                    if (window.location.protocol === 'https:') {
                        ajaxUrl = ajaxUrl.replace('http://', 'https://');
                     } else if (window.location.protocol === 'http:') {
                        ajaxUrl = ajaxUrl.replace('https://', 'http://');
                    }
                    
                    var xhr = new XMLHttpRequest();
                    xhr.open("POST", ajaxUrl);
                    xhr.onload = function() {
                        if (submitBtn) submitBtn.disabled = false;
                        if (spinner) spinner.style.display = "none";
                        
                        if (xhr.status === 200) {
                            try {
                                var res = JSON.parse(xhr.responseText);
                                if (res.success) {
                                    if (responseDiv) {
                                        responseDiv.textContent = res.data.message;
                                        responseDiv.className = "dawp-form-response success";
                                        responseDiv.style.display = "block";
                                    }
                                    form.reset();
                                    form.dawpCaptchaLoaded = false;
                                    var wrap = form.querySelector(".dawp-captcha-wrap");
                                    if (wrap) wrap.style.display = "none";
                                } else {
                                    if (responseDiv) {
                                        responseDiv.textContent = res.data.message;
                                        responseDiv.className = "dawp-form-response error";
                                        responseDiv.style.display = "block";
                                    }
                                }
                            } catch(err) {
                                if (responseDiv) {
                                    responseDiv.textContent = "Đã xảy ra lỗi khi xử lý phản hồi!";
                                    responseDiv.className = "dawp-form-response error";
                                    responseDiv.style.display = "block";
                                }
                            }
                        } else {
                            if (responseDiv) {
                                responseDiv.textContent = "Không thể kết nối tới máy chủ!";
                                responseDiv.className = "dawp-form-response error";
                                responseDiv.style.display = "block";
                            }
                        }
                    };
                    xhr.onerror = function() {
                        if (submitBtn) submitBtn.disabled = false;
                        if (spinner) spinner.style.display = "none";
                        if (responseDiv) {
                            responseDiv.textContent = "Đã xảy ra lỗi kết nối!";
                            responseDiv.className = "dawp-form-response error";
                            responseDiv.style.display = "block";
                        }
                    };
                    xhr.send(formData);
                });
            })();
        </script>
        <?php
        return ob_get_clean();
    }

    /**
     * AJAX xử lý khi khách gửi form liên hệ ngoài frontend
     */
    public function handle_form_submission() {
        // Loại bỏ check_ajax_referer nonce để tương thích hoàn hảo với các plugin tạo Cache (như LiteSpeed Cache)

        $captcha   = isset($_POST['dawp_captcha']) ? trim($_POST['dawp_captcha']) : '';
        $hash      = isset($_POST['dawp_captcha_hash']) ? trim($_POST['dawp_captcha_hash']) : '';
        $form_id   = isset($_POST['dawp_form_id']) ? (int)$_POST['dawp_form_id'] : 0;
        $form_lang = isset($_POST['dawp_form_lang']) ? sanitize_text_field($_POST['dawp_form_lang']) : 'vi';

        // Thiết lập thông báo đa ngôn ngữ
        $err_captcha_empty = 'Vui lòng hoàn thành phép tính bảo mật.';
        $err_captcha_wrong = 'Mã bảo mật không chính xác. Vui lòng tính lại!';

        if ( ! empty( $form_lang ) && $form_lang !== 'vi' ) {
            $options = get_option( 'dawp_settings', [] );
            $trans_empty = isset( $options['trans_captcha_empty_' . $form_lang] ) ? trim( $options['trans_captcha_empty_' . $form_lang] ) : '';
            $trans_wrong = isset( $options['trans_captcha_wrong_' . $form_lang] ) ? trim( $options['trans_captcha_wrong_' . $form_lang] ) : '';
            
            if ( ! empty( $trans_empty ) ) {
                $err_captcha_empty = $trans_empty;
            } else {
                $empty_translations = [
                    'en' => 'Please complete the security calculation.',
                    'ja' => 'セキュリティの計算を完了してください。',
                    'zh' => '请完成验证码计算。',
                    'ko' => '보안 계산을 완료해 주세요.',
                    'fr' => 'Veuillez effectuer le calcul de sécurité.',
                    'de' => 'Bitte führen Sie die Sicherheitsberechnung durch.',
                    'ru' => 'Пожалуйста, выполните проверку безопасности.'
                ];
                if ( isset( $empty_translations[ $form_lang ] ) ) {
                    $err_captcha_empty = $empty_translations[ $form_lang ];
                }
            }
            
            if ( ! empty( $trans_wrong ) ) {
                $err_captcha_wrong = $trans_wrong;
            } else {
                $wrong_translations = [
                    'en' => 'Incorrect security code. Please calculate again!',
                    'ja' => 'セキュリティコードが正しくありません。もう一度計算してください！',
                    'zh' => '验证码错误，请重新计算！',
                    'ko' => '보안 코드가 올바르지 않습니다. 다시 계산해 주세요!',
                    'fr' => 'Code de sécurité incorrect. Veuillez recalculer !',
                    'de' => 'Falscher Sicherheitscode. Bitte erneut berechnen!',
                    'ru' => 'Неверный защитный код. Пожалуйста, посчитайте еще раз!'
                ];
                if ( isset( $wrong_translations[ $form_lang ] ) ) {
                    $err_captcha_wrong = $wrong_translations[ $form_lang ];
                }
            }
        }

        // 1. Giới hạn tần suất gửi theo IP: chặn bot flood khi handler này là nopriv
        $client_ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( $_SERVER['REMOTE_ADDR'] ) : '';
        $rl_key    = 'dawp_cf_rl_' . md5( $client_ip );
        $attempts  = (int) get_transient( $rl_key );
        // Ngưỡng 10 lần/10 phút: đủ rộng cho nhiều người dùng chung IP (CGNAT 4G)
        if ( $attempts >= 10 ) {
            wp_send_json_error( [ 'message' => 'Bạn thao tác quá nhanh. Vui lòng thử lại sau ít phút.' ] );
        }
        set_transient( $rl_key, $attempts + 1, 10 * MINUTE_IN_SECONDS );

        // 2. Kiểm tra Captcha bằng token 1 lần do máy chủ phát qua AJAX
        if ( empty($captcha) || empty($hash) ) {
            wp_send_json_error( [ 'message' => $err_captcha_empty ] );
        }

        if ( ! preg_match( '/^cf_[a-f0-9]{32}$/', $hash ) ) {
            wp_send_json_error( [ 'message' => $err_captcha_wrong ] );
        }

        $stored = get_transient( 'dawp_' . $hash );

        // Chuẩn hóa về IN HOA để không phân biệt hoa/thường khi nhập mã chữ
        $captcha_norm = strtoupper( $captcha );

        if ( empty( $stored ) || ! hash_equals( (string) $stored, md5( $captcha_norm . wp_salt( 'nonce' ) ) ) ) {
            wp_send_json_error( [ 'message' => $err_captcha_wrong ] );
        }

        // Token dùng 1 lần: hủy ngay khi khớp để chặn gửi lặp (replay)
        delete_transient( 'dawp_' . $hash );

        // 2. Thu thập dữ liệu trường động gửi lên và nhận diện thông tin chính
        $name_val = '';
        $phone_val = '';
        $email_val = '';
        $message_parts = [];

        foreach ( $_POST as $key => $val ) {
            if ( in_array( $key, [ 'action', 'nonce', 'dawp_captcha', 'dawp_captcha_hash', 'dawp_form_id', 'dawp_form_lang' ] ) ) {
                continue;
            }

            if ( is_array( $val ) ) {
                $clean_val = implode( ', ', array_map( 'sanitize_text_field', $val ) );
            } else {
                $clean_val = sanitize_text_field( $val );
            }

            // Nhận diện cột dựa trên từ khóa tên trường phổ biến hoặc định dạng dữ liệu
            if ( empty($name_val) && preg_match( '/name|ten|ho_ten|fullname/i', $key ) ) {
                $name_val = $clean_val;
            } elseif ( empty($phone_val) && preg_match( '/phone|tel|sdt|dien_thoai|mobile/i', $key ) ) {
                $phone_val = $clean_val;
            } elseif ( empty($email_val) && (preg_match( '/email|mail/i', $key ) || is_email($clean_val)) ) {
                $email_val = is_array($val) ? sanitize_email(reset($val)) : sanitize_email( $val );
            } else {
                // Nhãn trường thân thiện
                $friendly_label = ucwords( str_replace( [ 'your-', '-', '_' ], [ '', ' ', ' ' ], $key ) );
                $message_parts[] = $friendly_label . ': ' . $clean_val;
            }
        }

        $message_val = isset($_POST['your-message']) ? sanitize_textarea_field($_POST['your-message']) : (isset($_POST['message']) ? sanitize_textarea_field($_POST['message']) : implode("\n", $message_parts));
        if ( empty($name_val) ) $name_val = 'Khách liên hệ';
        if ( empty($phone_val) ) $phone_val = 'Không cung cấp';

        $form_title = $form_id ? get_the_title($form_id) : 'Không rõ';

        // 3. Ghi dữ liệu liên hệ vào Database
        global $wpdb;
        $table_name = $wpdb->prefix . 'dawp_contacts';
        $wpdb->insert(
            $table_name,
            [
                'created_at' => current_time( 'mysql' ),
                'form_title' => $form_title,
                'name'       => $name_val,
                'phone'      => $phone_val,
                'email'      => $email_val,
                'message'    => $message_val,
                'ip_address' => $client_ip,
                'status'     => 'new'
            ],
            [ '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s' ]
        );

        // 4. Định dạng và gửi email thông báo từ cấu hình meta của form
        $to_email = '';
        $subject = '';
        $body_template = '';
        $success_msg = '';

        if ( $form_id ) {
            $to_email = get_post_meta( $form_id, '_dawp_email', true );
            $subject = get_post_meta( $form_id, '_dawp_subject', true );
            $body_template = get_post_meta( $form_id, '_dawp_body', true );
            $success_msg = get_post_meta( $form_id, '_dawp_success_msg', true );
        }

        if ( empty($to_email) ) $to_email = get_option('admin_email');
        if ( empty($subject) ) $subject = 'Yêu cầu liên hệ mới từ Website';
        if ( empty($success_msg) ) {
            $success_msg = 'Cảm ơn bạn! Thông tin liên hệ đã được gửi đi thành công.';
            if ( ! empty( $form_lang ) && $form_lang !== 'vi' ) {
                $options = get_option( 'dawp_settings', [] );
                $trans_success = isset( $options['trans_form_success_' . $form_lang] ) ? trim( $options['trans_form_success_' . $form_lang] ) : '';
                if ( ! empty( $trans_success ) ) {
                    $success_msg = $trans_success;
                } else {
                    $translations_success = [
                        'en' => 'Thank you! Your contact information has been sent successfully.',
                        'ja' => 'ありがとうございました！連絡先情報が正常送信されました。',
                        'zh' => '谢谢！您的联系信息已成功发送。',
                        'ko' => '감사합니다! 귀하의 연락처 정보가 성공적으로 전송되었습니다.',
                        'fr' => 'Merci ! Vos informations de contact ont été envoyées avec succès.',
                        'de' => 'Vielen Dank! Ihre Kontaktinformationen wurden erfolgreich gesendet.',
                        'ru' => 'Спасибо! Ваша контактная информация была успешно отправлена.'
                    ];
                    if ( isset( $translations_success[ $form_lang ] ) ) {
                        $success_msg = $translations_success[ $form_lang ];
                    }
                }
            }
        }

        // Tự động tạo Mail Body nếu người dùng để trống cài đặt (Thông minh bậc nhất!)
        if ( empty($body_template) ) {
            $body = "<h2>Thông tin liên hệ mới nhận được:</h2>";
            $body .= "<table style='border-collapse: collapse; width: 100%; max-width: 600px; font-family: sans-serif; font-size: 14px;'>";
            $body .= "<tr><td style='border: 1px solid #ddd; padding: 10px; font-weight: bold; width: 150px; background: #fafafa;'>Form gửi</td><td style='border: 1px solid #ddd; padding: 10px;'>" . esc_html($form_title) . "</td></tr>";
            $body .= "<tr><td style='border: 1px solid #ddd; padding: 10px; font-weight: bold; background: #fafafa;'>Họ và tên</td><td style='border: 1px solid #ddd; padding: 10px;'>" . esc_html($name_val) . "</td></tr>";
            $body .= "<tr><td style='border: 1px solid #ddd; padding: 10px; font-weight: bold; background: #fafafa;'>Số điện thoại</td><td style='border: 1px solid #ddd; padding: 10px;'><strong>" . esc_html($phone_val) . "</strong></td></tr>";
            if ( !empty($email_val) ) {
                $body .= "<tr><td style='border: 1px solid #ddd; padding: 10px; font-weight: bold; background: #fafafa;'>Email</td><td style='border: 1px solid #ddd; padding: 10px;'>" . esc_html($email_val) . "</td></tr>";
            }
            
            // Lặp các trường động khác
            foreach ( $_POST as $key => $val ) {
                if ( in_array( $key, [ 'action', 'nonce', 'dawp_captcha', 'dawp_captcha_hash', 'dawp_form_id', 'dawp_form_lang', 'your-name', 'name', 'your-phone', 'phone', 'your-email', 'email', 'your-message', 'message' ] ) ) {
                    continue;
                }
                $field_label = ucwords( str_replace( [ 'your-', '-', '_' ], [ '', ' ', ' ' ], $key ) );
                if ( is_array( $val ) ) {
                    $clean_val = implode( ', ', array_map( 'sanitize_text_field', $val ) );
                } else {
                    $clean_val = sanitize_text_field( $val );
                }
                $body .= "<tr><td style='border: 1px solid #ddd; padding: 10px; font-weight: bold; background: #fafafa;'>" . esc_html($field_label) . "</td><td style='border: 1px solid #ddd; padding: 10px;'>" . nl2br(esc_html($clean_val)) . "</td></tr>";
            }
            
            // Chỉ in Lời nhắn nếu thực sự được gửi từ form (tránh lặp nội dung trường động khi template trống)
            if ( isset($_POST['your-message']) || isset($_POST['message']) ) {
                $body .= "<tr><td style='border: 1px solid #ddd; padding: 10px; font-weight: bold; background: #fafafa;'>Lời nhắn</td><td style='border: 1px solid #ddd; padding: 10px;'>" . nl2br(esc_html($message_val)) . "</td></tr>";
            }
            $body .= "</table>";
            $body .= "<br><hr><p style='font-size: 12px; color: #888;'><em>Thư gửi tự động qua hệ thống Duy Anh Web Pro.</em></p>";
        } else {
            // Khớp và thay thế các tag trong mẫu email bằng nội dung thực tế khách điền
            $body = $body_template;
            foreach ( $_POST as $key => $val ) {
                if ( in_array( $key, [ 'action', 'nonce', 'dawp_captcha', 'dawp_captcha_hash', 'dawp_form_id', 'dawp_form_lang' ] ) ) {
                    continue;
                }
                if ( is_array( $val ) ) {
                    $clean_val = implode( ', ', array_map( 'sanitize_text_field', $val ) );
                } else {
                    $clean_val = sanitize_text_field( $val );
                }
                $body = str_replace( '[' . $key . ']', esc_html( $clean_val ), $body );
            }
            // Thay thế các tag fallback phổ biến
            $body = str_replace( '[your-name]', esc_html($name_val), $body );
            $body = str_replace( '[your-phone]', esc_html($phone_val), $body );
            $body = str_replace( '[your-email]', esc_html($email_val), $body );
            $body = str_replace( '[your-message]', nl2br(esc_html($message_val)), $body );
        }

        $headers = [ 'Content-Type: text/html; charset=UTF-8' ];

        // Nếu khách có nhập email, thêm Reply-To để chủ web bấm "Trả lời" là gửi thẳng cho khách
        if ( ! empty( $email_val ) && is_email( $email_val ) ) {
            $reply_name = ! empty( $name_val ) ? $name_val : $email_val;
            $headers[] = 'Reply-To: ' . $reply_name . ' <' . $email_val . '>';
        }

        // Chuẩn bị TRƯỚC email xác nhận cho khách (nếu bật và có email hợp lệ)
        $customer_mail = null;
        $reply_enable = $form_id ? get_post_meta( $form_id, '_dawp_customer_reply_enable', true ) : '';
        $send_to_customer = ( $reply_enable === '' || $reply_enable === '1' ); // mặc định bật

        if ( $send_to_customer && ! empty( $email_val ) && is_email( $email_val ) ) {
            $customer_subject = $form_id ? get_post_meta( $form_id, '_dawp_customer_subject', true ) : '';
            $customer_body    = $form_id ? get_post_meta( $form_id, '_dawp_customer_body', true ) : '';

            if ( empty( $customer_subject ) ) {
                $customer_subject = 'Cảm ơn bạn đã liên hệ với ' . get_bloginfo('name');
            }
            if ( empty( $customer_body ) ) {
                $customer_body = "<p>Xin chào <strong>[your-name]</strong>,</p>"
                    . "<p>Cảm ơn bạn đã gửi thông tin liên hệ đến <strong>" . esc_html( get_bloginfo('name') ) . "</strong>. Chúng tôi đã nhận được yêu cầu của bạn và sẽ phản hồi trong thời gian sớm nhất.</p>"
                    . "<p><strong>Nội dung bạn đã gửi:</strong><br>[your-message]</p>"
                    . "<br><hr><p style='font-size: 12px; color: #888;'><em>Đây là email tự động, vui lòng không trả lời trực tiếp email này.</em></p>";
            }

            // Thay thế các tag trong thư gửi khách bằng dữ liệu thực tế
            $customer_body_final = $customer_body;
            foreach ( $_POST as $key => $val ) {
                if ( in_array( $key, [ 'action', 'nonce', 'dawp_captcha', 'dawp_captcha_hash', 'dawp_form_id', 'dawp_form_lang' ], true ) ) {
                    continue;
                }
                if ( is_array( $val ) ) {
                    $clean_val = implode( ', ', array_map( 'sanitize_text_field', $val ) );
                } else {
                    $clean_val = sanitize_text_field( $val );
                }
                $customer_body_final = str_replace( '[' . $key . ']', esc_html( $clean_val ), $customer_body_final );
            }
            $customer_body_final = str_replace( '[your-name]', esc_html( $name_val ), $customer_body_final );
            $customer_body_final = str_replace( '[your-phone]', esc_html( $phone_val ), $customer_body_final );
            $customer_body_final = str_replace( '[your-email]', esc_html( $email_val ), $customer_body_final );
            $customer_body_final = str_replace( '[your-message]', nl2br( esc_html( $message_val ) ), $customer_body_final );

            // Reply-To là email quản trị để khách có thể phản hồi lại chủ web
            $customer_mail = [
                'to'      => $email_val,
                'subject' => $customer_subject,
                'body'    => $customer_body_final,
                'headers' => [
                    'Content-Type: text/html; charset=UTF-8',
                    'Reply-To: ' . get_option('admin_email'),
                ],
            ];
        }

        // Trả kết quả cho trình duyệt NGAY (dữ liệu đã lưu DB), rồi mới gửi mail ở nền
        // để nút gửi không phải chờ kết nối SMTP chậm.
        $this->respond_and_continue( [ 'message' => $success_msg ] );

        // Gửi email SAU khi đã phản hồi — không ảnh hưởng tốc độ / kết quả nút gửi
        wp_mail( $to_email, $subject, $body, $headers );
        if ( $customer_mail ) {
            wp_mail( $customer_mail['to'], $customer_mail['subject'], $customer_mail['body'], $customer_mail['headers'] );
        }

        exit;
    }

    /**
     * Gửi phản hồi JSON về trình duyệt và đóng kết nối ngay, để script tiếp tục
     * chạy phần gửi mail ở nền (tránh nút gửi form bị chờ lâu vì SMTP).
     */
    private function respond_and_continue( $data ) {
        $payload = wp_json_encode( [ 'success' => true, 'data' => $data ] );

        // Dọn sạch buffer đang mở để Content-Length chính xác
        while ( ob_get_level() > 0 ) {
            @ob_end_clean();
        }

        if ( ! headers_sent() ) {
            header( 'Content-Type: application/json; charset=' . get_option( 'blog_charset' ) );
            header( 'Connection: close' );
            header( 'Content-Length: ' . strlen( $payload ) );
        }

        echo $payload;

        // Đẩy hết dữ liệu ra client rồi kết thúc kết nối (nếu server hỗ trợ)
        @flush();
        if ( function_exists( 'fastcgi_finish_request' ) ) {
            fastcgi_finish_request();
        } elseif ( function_exists( 'litespeed_finish_request' ) ) {
            litespeed_finish_request();
        }

        // Cho phép script chạy tiếp phần gửi mail mà không bị giới hạn thời gian
        if ( function_exists( 'ignore_user_abort' ) ) {
            ignore_user_abort( true );
        }
        @set_time_limit( 30 );
    }

    /**
     * AJAX endpoint sinh CAPTCHA động bypass cache cho form liên hệ
     */
    public function ajax_get_form_captcha() {
        // Sinh mã chữ ngẫu nhiên, bỏ các ký tự dễ nhầm (0/O, 1/I/L)
        $alphabet = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
        $len      = 5;
        $code     = '';
        $max      = strlen( $alphabet ) - 1;
        for ( $i = 0; $i < $len; $i++ ) {
            $code .= $alphabet[ random_int( 0, $max ) ];
        }

        // Token 1 lần thay cho hash theo ngày: hash cũ tính từ ngày + salt nên cùng
        // một cặp mã/hash dùng lại được cả ngày (bot giải 1 lần rồi replay vô hạn).
        // Token phát qua AJAX nên vẫn tương thích page cache, hết hạn sau 15 phút
        // và bị hủy ngay khi dùng thành công.
        $token = 'cf_' . bin2hex( random_bytes( 16 ) );
        set_transient( 'dawp_' . $token, md5( strtoupper( $code ) . wp_salt( 'nonce' ) ), 15 * MINUTE_IN_SECONDS );
        $hash = $token;

        $form_lang = isset($_POST['lang']) ? sanitize_text_field($_POST['lang']) : 'vi';

        $lbl_captcha = 'Mã bảo mật';
        if ( ! empty( $form_lang ) && $form_lang !== 'vi' ) {
            $options = get_option( 'dawp_settings', [] );
            $trans_captcha = isset( $options['trans_captcha_label_' . $form_lang] ) ? trim( $options['trans_captcha_label_' . $form_lang] ) : '';
            if ( ! empty( $trans_captcha ) ) {
                $lbl_captcha = $trans_captcha;
            } else {
                $translations = [
                    'en' => 'Security code',
                    'ja' => 'セキュリティコード',
                    'zh' => '验证码',
                    'ko' => '보안 코드',
                    'fr' => 'Code de sécurité',
                    'de' => 'Sicherheitscode',
                    'ru' => 'Защитный код'
                ];
                if ( isset( $translations[ $form_lang ] ) ) {
                    $lbl_captcha = $translations[ $form_lang ];
                }
            }
        }

        wp_send_json_success([
            'code'  => $code,
            'label' => $lbl_captcha,
            'hash'  => $hash
        ]);
    }

    /**
     * Xuất dữ liệu liên hệ ra file CSV hỗ trợ hiển thị tiếng Việt UTF-8
     */
    public function handle_export_csv() {
        if ( isset($_GET['dawp_export_csv']) && $_GET['dawp_export_csv'] == '1' ) {
            if ( ! current_user_can( 'manage_options' ) ) {
                wp_die( 'Bạn không có quyền thực hiện tác vụ này!' );
            }
            
            check_admin_referer( 'dawp_export_csv_action' );

            global $wpdb;
            $table_name = $wpdb->prefix . 'dawp_contacts';
            $results = $wpdb->get_results( "SELECT created_at, form_title, name, phone, email, message, ip_address FROM $table_name ORDER BY id DESC", ARRAY_A );

            header( 'Content-Type: text/csv; charset=utf-8' );
            header( 'Content-Disposition: attachment; filename=dawp-leads-' . date('Y-m-d') . '.csv' );
            
            echo "\xEF\xBB\xBF";

            $output = fopen( 'php://output', 'w' );
            fputcsv( $output, [ 'Ngày gửi', 'Form gửi', 'Họ và tên', 'Số điện thoại', 'Email', 'Nội dung', 'Địa chỉ IP' ] );
            
            if ( !empty($results) ) {
                foreach ( $results as $row ) {
                    // Chống CSV formula injection: ô bắt đầu bằng = + - @ sẽ bị Excel
                    // thực thi như công thức khi admin mở file
                    $row = array_map( function( $cell ) {
                        $cell = (string) $cell;
                        if ( '' !== $cell && in_array( $cell[0], [ '=', '+', '-', '@' ], true ) ) {
                            $cell = "'" . $cell;
                        }
                        return $cell;
                    }, $row );
                    fputcsv( $output, $row );
                }
            }
            fclose( $output );
            exit;
        }
    }

    /**
     * AJAX Xóa một dòng liên hệ trong Database
     */
    public function ajax_delete_contact() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( [ 'message' => 'Bạn không có quyền!' ] );
        }
        check_ajax_referer( 'dawp_contact_actions_nonce', 'nonce' );
        
        $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
        if ( $id ) {
            global $wpdb;
            $table_name = $wpdb->prefix . 'dawp_contacts';
            $wpdb->delete( $table_name, [ 'id' => $id ], [ '%d' ] );
            wp_send_json_success( [ 'message' => 'Đã xóa liên hệ thành công!' ] );
        }
        wp_send_json_error( [ 'message' => 'ID liên hệ không hợp lệ!' ] );
    }

    /**
     * AJAX Xóa sạch toàn bộ bảng liên hệ
     */
    public function ajax_clear_all_contacts() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( [ 'message' => 'Bạn không có quyền!' ] );
        }
        check_ajax_referer( 'dawp_contact_actions_nonce', 'nonce' );
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'dawp_contacts';
        $wpdb->query( "TRUNCATE TABLE $table_name" );
        wp_send_json_success( [ 'message' => 'Đã xóa toàn bộ liên hệ thành công!' ] );
    }
}
