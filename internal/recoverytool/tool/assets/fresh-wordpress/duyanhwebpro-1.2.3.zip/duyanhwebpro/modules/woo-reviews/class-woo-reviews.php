<?php
defined( 'ABSPATH' ) || exit;

class DAWP_Woo_Reviews {
    private $runtime_rating_cache = [];

    public function __construct() {
        add_action( 'plugins_loaded', [ $this, 'init_hooks' ], 11 );
    }

    public function init_hooks() {
        // Hook only if WooCommerce is active
        if ( ! class_exists( 'WooCommerce' ) ) {
            return;
        }

        // Auto-create table if not exists (checked once using option flag to prevent redundant queries)
        if ( ! get_option( 'dawp_woo_reviews_table_created' ) ) {
            self::create_db_table();
            update_option( 'dawp_woo_reviews_table_created', 1 );
        }

        // Frontend filters & actions
        add_filter( 'woocommerce_product_tabs', [ $this, 'custom_product_tabs' ], 99 );
        add_action( 'woocommerce_after_single_product_summary', [ $this, 'render_reviews_tab_content' ], 15 );
        add_filter( 'woocommerce_product_get_review_count', [ $this, 'filter_product_review_count' ], 10, 2 );
        add_filter( 'woocommerce_product_get_average_rating', [ $this, 'filter_product_average_rating' ], 10, 2 );
        add_filter( 'woocommerce_product_get_rating_counts', [ $this, 'filter_product_rating_counts' ], 10, 2 );
        add_filter( 'get_comments_number', [ $this, 'filter_get_comments_number' ], 10, 2 );

        // Enqueue frontend scripts & styles
        add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_assets' ] );
        add_action( 'wp_footer', [ $this, 'render_review_modal_footer' ] );

        // Frontend AJAX submission and query
        add_action( 'wp_ajax_dawp_woo_reviews_submit_review', [ $this, 'ajax_submit_review' ] );
        add_action( 'wp_ajax_nopriv_dawp_woo_reviews_submit_review', [ $this, 'ajax_submit_review' ] );
        add_action( 'wp_ajax_dawp_woo_reviews_get_reviews', [ $this, 'ajax_get_reviews' ] );
        add_action( 'wp_ajax_nopriv_dawp_woo_reviews_get_reviews', [ $this, 'ajax_get_reviews' ] );
        add_action( 'wp_ajax_dawp_woo_reviews_get_captcha', [ $this, 'ajax_get_captcha' ] );
        add_action( 'wp_ajax_nopriv_dawp_woo_reviews_get_captcha', [ $this, 'ajax_get_captcha' ] );

        // Admin AJAX operations for reviews management
        if ( is_admin() ) {
            add_action( 'wp_ajax_dawp_woo_reviews_toggle_status', [ $this, 'ajax_toggle_status' ] );
            add_action( 'wp_ajax_dawp_woo_reviews_reply', [ $this, 'ajax_reply' ] );
            add_action( 'wp_ajax_dawp_woo_reviews_delete', [ $this, 'ajax_delete' ] );
            add_action( 'wp_ajax_dawp_woo_reviews_clear_all', [ $this, 'ajax_clear_all' ] );
        }
    }

    /**
     * Tạo bảng lưu trữ đánh giá WooCommerce riêng trong database
     */
    public static function create_db_table() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'dawp_reviews';
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE $table_name (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            product_id bigint(20) NOT NULL,
            rating int(1) NOT NULL,
            name varchar(255) NOT NULL,
            email varchar(100) NOT NULL,
            content text NOT NULL,
            images text DEFAULT '',
            tags text DEFAULT '',
            reply_content text DEFAULT '',
            reply_date datetime DEFAULT NULL,
            ip_address varchar(50) DEFAULT '',
            status varchar(20) DEFAULT 'approved',
            created_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY product_id (product_id),
            KEY status (status)
        ) $charset_collate;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta( $sql );

        // Đảm bảo cột tags tồn tại
        $row = $wpdb->get_row( "SELECT * FROM $table_name LIMIT 1" );
        if ( $row && ! isset( $row->tags ) ) {
            $wpdb->query( "ALTER TABLE $table_name ADD COLUMN tags text DEFAULT '' AFTER images" );
        }
    }

    /**
     * Lấy dữ liệu rating của sản phẩm (Sử dụng Transient Cache tối ưu hóa N+1 query)
     */
    public function get_product_rating_data( $product_id ) {
        if ( isset( $this->runtime_rating_cache[ $product_id ] ) ) {
            return $this->runtime_rating_cache[ $product_id ];
        }

        $cache_key = 'dawp_rating_data_' . $product_id;
        $rating_data = get_transient( $cache_key );
        if ( false === $rating_data ) {
            global $wpdb;
            $db_type = DAWP_Helpers::get_setting( 'woo_reviews_database_type', 'native' );

            if ( $db_type === 'native' ) {
                $results = $wpdb->get_results( $wpdb->prepare(
                    "SELECT cm.meta_value as rating, COUNT(*) as count 
                     FROM {$wpdb->comments} c 
                     INNER JOIN {$wpdb->commentmeta} cm ON c.comment_ID = cm.comment_id 
                     WHERE c.comment_post_ID = %d 
                       AND c.comment_approved = '1' 
                       AND c.comment_type = 'review' 
                       AND cm.meta_key = 'rating' 
                     GROUP BY cm.meta_value",
                    $product_id
                ) );
            } else {
                $table_name = $wpdb->prefix . 'dawp_reviews';
                $results = $wpdb->get_results( $wpdb->prepare(
                    "SELECT rating, COUNT(*) as count FROM $table_name WHERE product_id = %d AND status = 'approved' GROUP BY rating",
                    $product_id
                ) );
            }

            $counts = array( 1 => 0, 2 => 0, 3 => 0, 4 => 0, 5 => 0 );
            $total_reviews = 0;
            $total_stars = 0;

            foreach ( $results as $row ) {
                $rating = (int) $row->rating;
                $count = (int) $row->count;
                if ( isset( $counts[$rating] ) ) {
                    $counts[$rating] = $count;
                    $total_reviews += $count;
                    $total_stars += ( $rating * $count );
                }
            }

            $average = $total_reviews > 0 ? round( $total_stars / $total_reviews, 1 ) : 0;

            $rating_data = array(
                'review_count'   => $total_reviews,
                'average_rating' => $average,
                'rating_counts'  => $counts
            );

            set_transient( $cache_key, $rating_data, DAY_IN_SECONDS );
        }

        $this->runtime_rating_cache[ $product_id ] = $rating_data;
        return $rating_data;
    }

    public function clean_product_rating_cache( $product_id ) {
        unset( $this->runtime_rating_cache[ $product_id ] );
        delete_transient( 'dawp_rating_data_' . $product_id );
        delete_transient( 'dawp_product_images_' . $product_id );
        if ( class_exists( 'DAWP_Helpers' ) ) {
            DAWP_Helpers::purge_static_cache();
            
            // Tự động mồi cache lại cho Trang chủ và trang Sản phẩm này (cả Desktop và Mobile/Tablet)
            DAWP_Helpers::preload_url( home_url('/') );
            if ( $product_id ) {
                $url = get_permalink( $product_id );
                if ( $url ) {
                    DAWP_Helpers::preload_url( $url );
                }
            }
        }
    }

    /**
     * Bộ lọc ghi đè đếm số lượng reviews của WC
     */
    public function filter_product_review_count( $count, $product ) {
        $product_id = $product->get_id();
        $data = $this->get_product_rating_data( $product_id );
        return $data['review_count'];
    }

    /**
     * Bộ lọc ghi đè điểm trung bình sao của WC
     */
    public function filter_product_average_rating( $average, $product ) {
        $product_id = $product->get_id();
        $data = $this->get_product_rating_data( $product_id );
        return $data['average_rating'];
    }

    /**
     * Bộ lọc ghi đè phân phối sao của WC
     */
    public function filter_product_rating_counts( $counts, $product ) {
        $product_id = $product->get_id();
        $data = $this->get_product_rating_data( $product_id );
        return array_filter( $data['rating_counts'] );
    }

    /**
     * Bộ lọc ghi đè số lượng bình luận tại frontend cho WC Post Type 'product'
     */
    public function filter_get_comments_number( $count, $post_id ) {
        if ( ! is_admin() && get_post_type( $post_id ) === 'product' ) {
            $data = $this->get_product_rating_data( $post_id );
            return $data['review_count'];
        }
        return $count;
    }

    /**
     * Nạp CSS & JS cho trang chi tiết sản phẩm
     */
    public function enqueue_assets() {
        if ( is_product() ) {
            $css_path = DAWP_DIR . 'assets/css/dawp-woo-reviews.css';
            $css_ver = file_exists( $css_path ) ? filemtime( $css_path ) : DAWP_VERSION;
            wp_enqueue_style( 'dawp-woo-reviews', DAWP_URL . 'assets/css/dawp-woo-reviews.css', array(), $css_ver );

            $js_path = DAWP_DIR . 'assets/js/dawp-woo-reviews.js';
            $js_ver = file_exists( $js_path ) ? filemtime( $js_path ) : DAWP_VERSION;
            wp_enqueue_script( 'dawp-woo-reviews', DAWP_URL . 'assets/js/dawp-woo-reviews.js', array(), $js_ver, true );

            wp_localize_script( 'dawp-woo-reviews', 'dawp_reviews_ajax', array(
                'ajax_url'     => admin_url( 'admin-ajax.php' ),
                'nonce'        => wp_create_nonce( 'dawp_reviews_nonce' ),
                'product_id'   => get_the_ID(),
                'max_images'   => (int) DAWP_Helpers::get_setting( 'woo_reviews_max_images', 3 ),
                'is_logged_in' => is_user_logged_in() ? 1 : 0
            ) );
        }
    }

    /**
     * Thay đổi tab Đánh giá mặc định bằng tab custom Premium
     */
    public function custom_product_tabs( $tabs ) {
        if ( isset( $tabs['reviews'] ) ) {
            unset( $tabs['reviews'] );
        }
        return $tabs;
    }

    /**
     * Thu thập hình ảnh từ các review đã được duyệt của sản phẩm
     */
    public function get_product_images( $product_id ) {
        $cache_key = 'dawp_product_images_' . $product_id;
        $all_images = get_transient( $cache_key );
        if ( false === $all_images ) {
            global $wpdb;
            $db_type = DAWP_Helpers::get_setting( 'woo_reviews_database_type', 'native' );

            if ( $db_type === 'native' ) {
                $results = $wpdb->get_results( $wpdb->prepare(
                    "SELECT cm.meta_value as images 
                     FROM {$wpdb->comments} c
                     INNER JOIN {$wpdb->commentmeta} cm ON c.comment_ID = cm.comment_id
                     WHERE c.comment_post_ID = %d 
                       AND c.comment_approved = '1' 
                       AND c.comment_type = 'review' 
                       AND cm.meta_key = 'dawp_images' 
                       AND cm.meta_value != '' 
                       AND cm.meta_value != '[]' 
                     ORDER BY c.comment_date DESC LIMIT 24",
                    $product_id
                ) );
            } else {
                $table_name = $wpdb->prefix . 'dawp_reviews';
                $results = $wpdb->get_results( $wpdb->prepare(
                    "SELECT id, images FROM $table_name WHERE product_id = %d AND status = 'approved' AND images != '' AND images != '[]' ORDER BY created_at DESC LIMIT 24",
                    $product_id
                ) );
            }

            $all_images = [];
            foreach ( $results as $row ) {
                $imgs = json_decode( $row->images, true );
                if ( is_array( $imgs ) ) {
                    foreach ( $imgs as $img ) {
                        $all_images[] = $img['url'];
                    }
                }
            }
            set_transient( $cache_key, $all_images, DAY_IN_SECONDS );
        }
        return $all_images;
    }

    /**
     * Kiểm tra khách mua hàng thực tế
     */
    public function is_verified_buyer( $email, $product_id ) {
        if ( empty( $email ) ) return false;
        $user = get_user_by( 'email', $email );
        $user_id = $user ? $user->ID : 0;
        return wc_customer_bought_product( $email, $user_id, $product_id );
    }

    /**
     * Render giao diện của tab Đánh giá custom
     */
    public function render_reviews_tab_content() {
        $product_id = get_the_ID();
        if ( ! $product_id ) {
            return;
        }

        $rating_data = $this->get_product_rating_data( $product_id );

        $average = $rating_data['average_rating'];
        $review_count = $rating_data['review_count'];
        $counts = $rating_data['rating_counts'];

        $max_images = (int) DAWP_Helpers::get_setting( 'woo_reviews_max_images', 3 );
        $product_title = get_the_title( $product_id );
        ?>
        <div class="dawp-reviews-wrapper" id="dawp-reviews-app" data-product-id="<?php echo $product_id; ?>">
            
            <!-- Header tiêu đề số lượng đánh giá -->
            <h3 class="dawp-reviews-title-header">
                <?php echo sprintf( _n( '%s đánh giá cho %s', '%s đánh giá cho %s', $review_count, 'duyanhwebpro' ), number_format( $review_count ), esc_html($product_title) ); ?>
            </h3>

            <!-- Bảng tổng quan đánh giá -->
            <div class="dawp-reviews-summary">
                <div class="dawp-summary-left">
                    <div class="dawp-rating-avg-wrapper">
                        <span class="dawp-rating-avg"><?php echo number_format( $average, 1 ); ?></span>
                        <span class="dawp-rating-avg-star">★</span>
                    </div>
                    <div class="dawp-rating-avg-text">ĐÁNH GIÁ TRUNG BÌNH</div>
                </div>

                <div class="dawp-summary-center">
                    <?php
                    for ( $i = 5; $i >= 1; $i-- ) {
                        $count = isset( $counts[$i] ) ? $counts[$i] : 0;
                        $pct = $review_count > 0 ? round( ( $count / $review_count ) * 100 ) : 0;
                        ?>
                        <div class="dawp-summary-bar-row" data-rating="<?php echo $i; ?>">
                            <span class="dawp-bar-label"><?php echo $i; ?> ★</span>
                            <div class="dawp-bar-track">
                                <div class="dawp-bar-fill" style="width: <?php echo $pct; ?>%;"></div>
                            </div>
                            <span class="dawp-bar-count"><?php echo $pct; ?>% | <?php echo $count; ?> đánh giá</span>
                        </div>
                        <?php
                    }
                    ?>
                </div>

                <div class="dawp-summary-right">
                    <button type="button" class="dawp-btn-toggle-form" id="dawp-write-review-btn">
                        ĐÁNH GIÁ NGAY
                    </button>
                </div>
            </div>




            <!-- Khối slide ngang ảnh thực tế từ khách hàng -->
            <?php
            $product_images = $this->get_product_images( $product_id );
            if ( ! empty( $product_images ) ) :
            ?>
                <div class="dawp-reviews-customer-gallery">
                    <h4 class="dawp-gallery-title">Hình ảnh từ khách hàng</h4>
                    <div class="dawp-gallery-scroll">
                        <?php foreach ( $product_images as $idx => $img_url ) : ?>
                            <div class="dawp-gallery-item" data-src="<?php echo esc_url( $img_url ); ?>" data-index="<?php echo $idx; ?>">
                                <img src="<?php echo esc_url( $img_url ); ?>" alt="Ảnh thực tế" />
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Header bộ lọc đánh giá -->
            <div class="dawp-reviews-filters">
                <div class="dawp-filter-buttons">
                    <button type="button" class="dawp-filter-btn active" data-rating="all">Tất cả</button>
                    <button type="button" class="dawp-filter-btn" data-rating="5">5 ★</button>
                    <button type="button" class="dawp-filter-btn" data-rating="4">4 ★</button>
                    <button type="button" class="dawp-filter-btn" data-rating="3">3 ★</button>
                    <button type="button" class="dawp-filter-btn" data-rating="2">2 ★</button>
                    <button type="button" class="dawp-filter-btn" data-rating="1">1 ★</button>
                    <button type="button" class="dawp-filter-btn" data-images="1">Có ảnh</button>
                </div>
            </div>

            <!-- Danh sách Reviews load AJAX -->
            <div class="dawp-reviews-list-outer">
                <div id="dawp-reviews-list-container">
                    <div class="dawp-reviews-loading">Đang tải đánh giá...</div>
                </div>
            </div>
        </div>

        <!-- Lightbox xem ảnh lớn -->
        <div class="dawp-lightbox" id="dawp-reviews-lightbox" style="display: none;">
            <span class="dawp-lightbox-close">&times;</span>
            <div class="dawp-lightbox-content-wrap">
                <img class="dawp-lightbox-img" id="dawp-lightbox-image" src="" alt="Xem ảnh lớn" />
                <a class="dawp-lightbox-prev">&#10094;</a>
                <a class="dawp-lightbox-next">&#10095;</a>
            </div>
        </div>
        <?php
    }

    /**
     * Render form đánh giá dạng Modal ở wp_footer để tránh lỗi z-index stacking context đè dưới hotline/zalo
     */
    public function render_review_modal_footer() {
        if ( ! is_product() ) {
            return;
        }
        $product_id = get_the_ID();
        if ( ! $product_id ) {
            return;
        }
        $max_images = (int) DAWP_Helpers::get_setting( 'woo_reviews_max_images', 3 );
        ?>
        <!-- Form điền đánh giá (Popup Modal) -->
        <div class="dawp-review-form-modal-overlay" id="dawp-review-form-box" style="display: none;">
            <div class="dawp-review-form-modal-content">
                <button type="button" class="dawp-modal-close-btn" id="dawp-modal-close-btn">&times;</button>
                <form id="dawp-frontend-review-form" method="post" enctype="multipart/form-data">
                    <h3 class="dawp-form-title">Đánh giá sản phẩm</h3>

                    <div class="dawp-form-cols">
                        <div class="dawp-form-col">
                            <div class="dawp-form-group">
                                <label class="dawp-form-label">Chọn xếp hạng của bạn: <span class="required">*</span></label>
                                <div class="dawp-rating-select-wrap">
                                    <div class="dawp-rating-stars-input">
                                        <span class="dawp-star-select" data-value="5">★</span>
                                        <span class="dawp-star-select" data-value="4">★</span>
                                        <span class="dawp-star-select" data-value="3">★</span>
                                        <span class="dawp-star-select" data-value="2">★</span>
                                        <span class="dawp-star-select" data-value="1">★</span>
                                    </div>
                                    <span class="dawp-rating-desc" id="dawp-rating-text">Vui lòng chọn số sao</span>
                                    <input type="hidden" name="rating" id="dawp-rating-value" value="0" />
                                </div>
                            </div>

                            <div class="dawp-form-grid">
                                <div class="dawp-form-group">
                                    <?php
                                    $current_user_name = '';
                                    $current_user_email = '';
                                    if ( is_user_logged_in() ) {
                                        $current_user = wp_get_current_user();
                                        $current_user_name = $current_user->display_name;
                                        $current_user_email = $current_user->user_email;
                                    }
                                    ?>
                                    <label for="dawp-review-name" class="dawp-form-label">Họ và tên: <span class="required">*</span></label>
                                    <input type="text" name="name" id="dawp-review-name" class="dawp-form-control" required placeholder="Nhập họ tên của bạn..." value="<?php echo esc_attr($current_user_name); ?>" />
                                </div>
                                <div class="dawp-form-group">
                                    <label for="dawp-review-email" class="dawp-form-label">Email: <span class="required">*</span></label>
                                    <input type="email" name="email" id="dawp-review-email" class="dawp-form-control" required placeholder="Nhập email của bạn..." value="<?php echo esc_attr($current_user_email); ?>" />
                                </div>
                            </div>

                            <!-- Lọc tiêu chí đánh giá nhanh (Tags Checklist) -->
                            <div class="dawp-form-group">
                                <label class="dawp-form-label">Nhận xét nhanh tiêu chí:</label>
                                <div class="dawp-form-tags-select">
                                    <label class="dawp-tag-select-item">
                                        <input type="checkbox" name="tags[]" value="Giao hàng nhanh" />
                                        <span>Giao hàng nhanh</span>
                                    </label>
                                    <label class="dawp-tag-select-item">
                                        <input type="checkbox" name="tags[]" value="Đóng gói sản phẩm chắc chắn" />
                                        <span>Đóng gói chắc chắn</span>
                                    </label>
                                    <label class="dawp-tag-select-item">
                                        <input type="checkbox" name="tags[]" value="Rất đáng tiền" />
                                        <span>Rất đáng tiền</span>
                                    </label>
                                    <label class="dawp-tag-select-item">
                                        <input type="checkbox" name="tags[]" value="Chất lượng tuyệt vời" />
                                        <span>Chất lượng tuyệt vời</span>
                                    </label>
                                    <label class="dawp-tag-select-item">
                                        <input type="checkbox" name="tags[]" value="Tư vấn nhiệt tình" />
                                        <span>Tư vấn nhiệt tình</span>
                                    </label>
                                </div>
                            </div>

                            <!-- Math CAPTCHA chống spam -->
                            <div class="dawp-form-group dawp-reviews-captcha-wrap" style="display: none; margin-top: 15px;">
                                <label for="dawp-reviews-captcha-ans" class="dawp-form-label">
                                    <span class="dawp-reviews-captcha-question">...</span> <span class="required">*</span>
                                </label>
                                <div style="display: flex; gap: 10px; align-items: center;">
                                    <input type="number" id="dawp-reviews-captcha-ans" name="dawp_reviews_captcha_ans" class="dawp-form-control" style="width: 120px;" placeholder="Kết quả..." />
                                    <input type="hidden" id="dawp-reviews-captcha-hash" name="dawp_reviews_captcha_hash" value="" />
                                </div>
                            </div>
                        </div>

                        <div class="dawp-form-col">
                            <div class="dawp-form-group" style="height: 100%; display: flex; flex-direction: column;">
                                <label for="dawp-review-content" class="dawp-form-label">Nội dung đánh giá: <span class="required">*</span></label>
                                <textarea name="content" id="dawp-review-content" class="dawp-form-control" style="flex: 1; min-height: 90px;" required placeholder="Chia sẻ cảm nhận thực tế về sản phẩm..."></textarea>
                            </div>

                            <div class="dawp-form-group" style="margin-top: 15px;">
                                <label class="dawp-form-label">Đính kèm hình ảnh thực tế (Tối đa <?php echo $max_images; ?> ảnh):</label>
                                <div class="dawp-image-upload-zone" id="dawp-upload-zone">
                                    <div class="dawp-upload-prompt">
                                        <span class="dashicons dashicons-camera"></span>
                                        <p>Nhập chuột để tải ảnh lên hoặc kéo thả tệp tin vào đây</p>
                                        <span class="dawp-upload-note">Hệ thống sẽ nén tối ưu WebP tự động trước khi tải lên</span>
                                    </div>
                                </div>
                                <input type="file" id="dawp-file-input" multiple accept="image/*" style="opacity: 0; position: absolute; left: -9999px; top: -9999px; z-index: -1;" />
                                <div class="dawp-image-preview-grid" id="dawp-preview-grid"></div>
                            </div>
                        </div>
                    </div>

                    <div class="dawp-form-submit-row">
                        <button type="submit" class="dawp-btn-submit" id="dawp-submit-review-btn">
                            <span class="dawp-btn-text">Gửi đánh giá ngay</span>
                            <div class="dawp-spinner" style="display: none;"></div>
                        </button>
                    </div>

                    <div class="dawp-form-message" id="dawp-form-status-msg"></div>
                </form>
            </div>
        </div>
        <?php
    }

    /**
     * Xuất HTML các ngôi sao đánh giá
     */
    public function get_stars_html( $rating ) {
        $html = '';
        $rating = round( $rating, 1 );
        for ( $i = 1; $i <= 5; $i++ ) {
            if ( $rating >= $i ) {
                $html .= '<span class="dawp-star full">★</span>';
            } elseif ( $rating > ( $i - 1 ) && $rating < $i ) {
                $html .= '<span class="dawp-star half">★</span>';
            } else {
                $html .= '<span class="dawp-star empty">★</span>';
            }
        }
        return $html;
    }

    /**
     * Lấy danh sách reviews từ CSDL theo các bộ lọc
     */
    public function get_reviews( $product_id, $page = 1, $limit = 5, $rating_filter = 0, $has_images_filter = false ) {
        global $wpdb;
        $db_type = DAWP_Helpers::get_setting( 'woo_reviews_database_type', 'native' );

        if ( $db_type === 'native' ) {
            $offset = ( $page - 1 ) * $limit;
            $where_clauses = [
                $wpdb->prepare( "c.comment_post_ID = %d", $product_id ),
                "c.comment_approved = '1'",
                "c.comment_type = 'review'",
                "cm_rating.meta_key = 'rating'"
            ];

            $joins = "INNER JOIN {$wpdb->commentmeta} cm_rating ON c.comment_ID = cm_rating.comment_id";

            if ( $rating_filter >= 1 && $rating_filter <= 5 ) {
                $where_clauses[] = $wpdb->prepare( "cm_rating.meta_value = %s", (string)$rating_filter );
            }

            if ( $has_images_filter ) {
                $joins .= " INNER JOIN {$wpdb->commentmeta} cm_images ON c.comment_ID = cm_images.comment_id AND cm_images.meta_key = 'dawp_images' AND cm_images.meta_value != '' AND cm_images.meta_value IS NOT NULL AND cm_images.meta_value != '[]'";
            }

            $where_sql = implode( ' AND ', $where_clauses );

            $total_items = $wpdb->get_var( "SELECT COUNT(DISTINCT c.comment_ID) FROM {$wpdb->comments} c $joins WHERE $where_sql" );

            $results = $wpdb->get_results( $wpdb->prepare(
                "SELECT DISTINCT c.comment_ID as id, 
                        c.comment_post_ID as product_id,
                        cm_rating.meta_value as rating,
                        c.comment_author as name,
                        c.comment_author_email as email,
                        c.comment_content as content,
                        c.comment_date as created_at
                 FROM {$wpdb->comments} c 
                 $joins 
                 WHERE $where_sql 
                 ORDER BY c.comment_date DESC 
                 LIMIT %d OFFSET %d",
                $limit,
                $offset
            ) );

            $reviews = [];
            foreach ( $results as $row ) {
                $comment_id = $row->id;
                $images = get_comment_meta( $comment_id, 'dawp_images', true );
                $tags = get_comment_meta( $comment_id, 'dawp_tags', true );

                $reply = $wpdb->get_row( $wpdb->prepare(
                    "SELECT comment_content, comment_date FROM {$wpdb->comments} 
                     WHERE comment_parent = %d AND comment_approved = '1' 
                     ORDER BY comment_date ASC LIMIT 1",
                    $comment_id
                ) );

                $row->images = $images ? $images : '';
                $row->tags = $tags ? $tags : '';
                $row->reply_content = $reply ? $reply->comment_content : '';
                $row->reply_date = $reply ? $reply->comment_date : '';

                $reviews[] = $row;
            }

            return [
                'reviews'     => $reviews,
                'total_items' => (int) $total_items,
                'total_pages' => ceil( $total_items / $limit )
            ];
        } else {
            $table_name = $wpdb->prefix . 'dawp_reviews';
            $offset = ( $page - 1 ) * $limit;

            $where_clauses = [
                $wpdb->prepare( "product_id = %d", $product_id ),
                "status = 'approved'"
            ];

            if ( $rating_filter >= 1 && $rating_filter <= 5 ) {
                $where_clauses[] = $wpdb->prepare( "rating = %d", $rating_filter );
            }

            if ( $has_images_filter ) {
                $where_clauses[] = "images != '' AND images IS NOT NULL AND images != '[]'";
            }

            $where_sql = implode( ' AND ', $where_clauses );

            $total_items = $wpdb->get_var( "SELECT COUNT(*) FROM $table_name WHERE $where_sql" );

            $reviews = $wpdb->get_results( $wpdb->prepare(
                "SELECT * FROM $table_name WHERE $where_sql ORDER BY created_at DESC LIMIT %d OFFSET %d",
                $limit,
                $offset
            ) );

            return [
                'reviews'     => $reviews,
                'total_items' => (int) $total_items,
                'total_pages' => ceil( $total_items / $limit )
            ];
        }
    }

    /**
     * AJAX Endpoint tải danh sách review ngoài frontend
     */
    public function ajax_get_reviews() {
        $product_id = isset( $_POST['product_id'] ) ? (int) $_POST['product_id'] : 0;
        $page = isset( $_POST['page'] ) ? (int) $_POST['page'] : 1;
        $rating = isset( $_POST['rating'] ) ? sanitize_text_field( $_POST['rating'] ) : 'all';
        $has_images = isset( $_POST['has_images'] ) && $_POST['has_images'] == '1';

        $rating_filter = ( $rating === 'all' ) ? 0 : (int) $rating;

        $data = $this->get_reviews( $product_id, $page, 5, $rating_filter, $has_images );
        $reviews = $data['reviews'];
        $total_pages = $data['total_pages'];

        $url_parts = parse_url( home_url() );
        $clean_domain = isset( $url_parts['host'] ) ? $url_parts['host'] : $_SERVER['HTTP_HOST'];

        ob_start();
        if ( empty( $reviews ) ) {
            ?>
            <div class="dawp-no-reviews">Chưa có đánh giá nào phù hợp với bộ lọc đã chọn.</div>
            <?php
        } else {
            foreach ( $reviews as $review ) {
                $images = [];
                if ( ! empty( $review->images ) ) {
                    $images = json_decode( $review->images, true );
                    if ( ! is_array( $images ) ) {
                        $images = [];
                    }
                }
                
                $tags = [];
                if ( ! empty( $review->tags ) ) {
                    $tags = explode( ',', $review->tags );
                }
                
                // Kiểm tra xem khách đã mua sản phẩm hay chưa
                $is_verified = $this->is_verified_buyer( $review->email, $product_id );
                ?>
                <div class="dawp-review-item" data-id="<?php echo $review->id; ?>">
                    <div class="dawp-review-header">
                        <div class="dawp-reviewer-info">
                            <div class="dawp-reviewer-avatar">
                                <?php echo strtoupper( substr( esc_html($review->name), 0, 1 ) ); ?>
                            </div>
                            <div class="dawp-reviewer-meta">
                                <div class="dawp-reviewer-name-row">
                                    <span class="dawp-reviewer-name"><?php echo esc_html( $review->name ); ?></span>
                                    <?php if ( $is_verified ) : ?>
                                        <span class="dawp-verified-badge">✓ Đã mua tại <?php echo esc_html($clean_domain); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="dawp-review-stars">
                                    <?php echo $this->get_stars_html( $review->rating ); ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="dawp-review-body">
                        <div class="dawp-review-text"><?php echo nl2br( esc_html( $review->content ) ); ?></div>

                        <!-- Render các tags nhận xét tiêu chí (pill badges) -->
                        <?php if ( ! empty( $tags ) ) : ?>
                            <div class="dawp-review-item-tags">
                                <?php foreach ( $tags as $t ) : if (empty(trim($t))) continue; ?>
                                    <span class="dawp-review-tag-pill"><?php echo esc_html( trim( $t ) ); ?></span>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>

                        <?php if ( ! empty( $images ) ) : ?>
                            <div class="dawp-review-images">
                                <?php foreach ( $images as $idx => $img ) : ?>
                                    <div class="dawp-review-img-thumb" data-src="<?php echo esc_url( $img['url'] ); ?>" data-index="<?php echo $idx; ?>">
                                        <img src="<?php echo esc_url( $img['url'] ); ?>" alt="Review attachment" />
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="dawp-review-footer">
                        <button type="button" class="dawp-btn-reply-link">Trả lời</button>
                        <span class="dawp-footer-dot">•</span>
                        <span class="dawp-review-footer-date"><?php echo date_i18n( get_option( 'date_format' ), strtotime( $review->created_at ) ); ?></span>
                    </div>

                    <?php if ( ! empty( $review->reply_content ) ) : ?>
                        <div class="dawp-review-reply">
                            <div class="dawp-reply-header">
                                <span class="dashicons dashicons-admin-users"></span>
                                <span class="dawp-reply-author">Phản hồi từ cửa hàng</span>
                                <span class="dawp-reply-date"><?php echo date_i18n( get_option( 'date_format' ), strtotime( $review->reply_date ) ); ?></span>
                            </div>
                            <div class="dawp-reply-body">
                                <?php echo nl2br( esc_html( $review->reply_content ) ); ?>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
                <?php
            }

            if ( $total_pages > 1 ) {
                ?>
                <div class="dawp-reviews-pagination">
                    <?php for ( $p = 1; $p <= $total_pages; $p++ ) : ?>
                        <button type="button" class="dawp-page-btn <?php echo $p === $page ? 'active' : ''; ?>" data-page="<?php echo $p; ?>"><?php echo $p; ?></button>
                    <?php endfor; ?>
                </div>
                <?php
            }
        }
        $html = ob_get_clean();

        wp_send_json_success( array( 'html' => $html ) );
    }

    /**
     * AJAX endpoint sinh CAPTCHA động bypass cache cho reviews
     */
    public function ajax_get_captcha() {
        $num1 = rand( 1, 9 );
        $num2 = rand( 1, 9 );
        $ans  = $num1 + $num2;

        $salt_today = date('Ymd') . wp_salt( 'nonce' );
        $hash = md5( $ans . $salt_today );

        $lang = 'vi';
        if ( class_exists( 'DAWP_Multilingual' ) ) {
            $lang = DAWP_Multilingual::get_current_language();
        }

        $lbl_captcha = 'Xác minh bảo mật:';
        if ( $lang !== 'vi' ) {
            $options = get_option( 'dawp_settings', [] );
            $trans_captcha = isset( $options['trans_captcha_label_' . $lang] ) ? trim( $options['trans_captcha_label_' . $lang] ) : '';
            if ( ! empty( $trans_captcha ) ) {
                $lbl_captcha = $trans_captcha;
            } else {
                $translations = [
                    'en' => 'Security verification:',
                    'ja' => 'セキュリティ検証:',
                    'zh' => '安全验证:',
                    'ko' => '보안 확인:',
                    'fr' => 'Vérification de sécurité:',
                    'de' => 'Sicherheitsüberprüfung:',
                    'ru' => 'Проверка безопасности:'
                ];
                if ( isset( $translations[ $lang ] ) ) {
                    $lbl_captcha = $translations[ $lang ];
                }
            }
        }

        $question = $lbl_captcha . ' ' . $num1 . ' + ' . $num2 . ' = ?';

        wp_send_json_success([
            'question' => $question,
            'hash'     => $hash
        ]);
    }

    /**
     * AJAX Endpoint gửi đánh giá mới ngoài frontend
     */
    public function ajax_submit_review() {
        check_ajax_referer( 'dawp_reviews_nonce', 'nonce' );

        $product_id = isset( $_POST['product_id'] ) ? (int) $_POST['product_id'] : 0;
        $rating = isset( $_POST['rating'] ) ? (int) $_POST['rating'] : 0;
        $name = isset( $_POST['name'] ) ? sanitize_text_field( $_POST['name'] ) : '';
        $email = isset( $_POST['email'] ) ? sanitize_email( $_POST['email'] ) : '';
        $content = isset( $_POST['content'] ) ? sanitize_textarea_field( $_POST['content'] ) : '';

        if ( ! $product_id || $rating < 1 || $rating > 5 || empty( $name ) || empty( $email ) || empty( $content ) ) {
            wp_send_json_error( array( 'message' => 'Vui lòng nhập đầy đủ các thông tin bắt buộc!' ) );
        }

        // Kiểm tra Math CAPTCHA chống spam cho khách vãng lai (không đăng nhập)
        if ( ! is_user_logged_in() ) {
            $captcha_ans  = isset( $_POST['dawp_reviews_captcha_ans'] ) ? trim( $_POST['dawp_reviews_captcha_ans'] ) : '';
            $captcha_hash = isset( $_POST['dawp_reviews_captcha_hash'] ) ? trim( $_POST['dawp_reviews_captcha_hash'] ) : '';

            $lang = 'vi';
            if ( class_exists( 'DAWP_Multilingual' ) ) {
                $lang = DAWP_Multilingual::get_current_language();
            }

            $err_empty = 'Vui lòng hoàn thành phép tính bảo mật chống spam!';
            $err_wrong = 'Phép tính chống spam không chính xác. Vui lòng quay lại và thử lại!';

            if ( $lang !== 'vi' ) {
                $options = get_option( 'dawp_settings', [] );
                $trans_empty = isset( $options['trans_captcha_empty_' . $lang] ) ? trim( $options['trans_captcha_empty_' . $lang] ) : '';
                $trans_wrong = isset( $options['trans_captcha_wrong_' . $lang] ) ? trim( $options['trans_captcha_wrong_' . $lang] ) : '';

                if ( ! empty( $trans_empty ) ) {
                    $err_empty = $trans_empty;
                } else {
                    $empty_translations = [
                        'en' => 'Please complete the security calculation to post your review.',
                        'ja' => 'レビューを投稿するには、セキュリティの計算を完了してください。',
                        'zh' => '请完成安全计算以发表评论。',
                        'ko' => '리뷰를 게시하려면 보안 계산을 완료해 주세요.',
                        'fr' => 'Veuillez effectuer le calcul de sécurité pour publier votre avis.',
                        'de' => 'Bitte führen Sie die Sicherheitsberechnung durch, um Ihre Bewertung abzugeben.',
                        'ru' => 'Пожалуйста, выполните проверку безопасности, чтобы отправить отзыв.'
                    ];
                    if ( isset( $empty_translations[ $lang ] ) ) {
                        $err_empty = $empty_translations[ $lang ];
                    }
                }

                if ( ! empty( $trans_wrong ) ) {
                    $err_wrong = $trans_wrong;
                } else {
                    $wrong_translations = [
                        'en' => 'Incorrect security calculation. Please try again.',
                        'ja' => 'セキュリティの計算が正しくありません。もう一度お試しください。',
                        'zh' => '安全计算不正确。请重试。',
                        'ko' => '보안 계산이 올바르지 않습니다. 다시 시도해 주세요.',
                        'fr' => 'Calcul de sécurité incorrect. Veuillez réessayer.',
                        'de' => 'Ungültige Sicherheitsberechnung. Bitte versuchen Sie es erneut.',
                        'ru' => 'Неверный расчет безопасности. Пожалуйста, попробуйте еще раз.'
                    ];
                    if ( isset( $wrong_translations[ $lang ] ) ) {
                        $err_wrong = $wrong_translations[ $lang ];
                    }
                }
            }

            if ( empty( $captcha_ans ) || empty( $captcha_hash ) ) {
                wp_send_json_error( array( 'message' => $err_empty ) );
            }

            $salt_today     = date('Ymd') . wp_salt( 'nonce' );
            $salt_yesterday = date('Ymd', strtotime('-1 day')) . wp_salt( 'nonce' );

            $verify_today     = md5( $captcha_ans . $salt_today );
            $verify_yesterday = md5( $captcha_ans . $salt_yesterday );

            if ( $captcha_hash !== $verify_today && $captcha_hash !== $verify_yesterday ) {
                wp_send_json_error( array( 'message' => $err_wrong ) );
            }
        }

        // Nhận dữ liệu tags
        $tags_str = '';
        if ( isset( $_POST['tags'] ) && is_array( $_POST['tags'] ) ) {
            $tags_str = implode( ',', array_map( 'sanitize_text_field', $_POST['tags'] ) );
        }

        $uploaded_images = [];
        $max_images = (int) DAWP_Helpers::get_setting( 'woo_reviews_max_images', 3 );

        if ( isset( $_POST['images'] ) && is_array( $_POST['images'] ) ) {
            $images_data = $_POST['images'];
            $count = 0;
            foreach ( $images_data as $base64_img ) {
                if ( $count >= $max_images ) {
                    break;
                }
                $uploaded = $this->upload_base64_webp_image( $base64_img, $product_id );
                if ( $uploaded ) {
                    $uploaded_images[] = $uploaded;
                    $count++;
                }
            }
        }

        $auto_approve = (int) DAWP_Helpers::get_setting( 'woo_reviews_auto_approve', 1 );
        $status = $auto_approve ? 'approved' : 'pending';

        $db_type = DAWP_Helpers::get_setting( 'woo_reviews_database_type', 'native' );

        if ( $db_type === 'native' ) {
            $comment_data = array(
                'comment_post_ID'      => $product_id,
                'comment_author'       => $name,
                'comment_author_email' => $email,
                'comment_content'      => $content,
                'comment_type'         => 'review',
                'comment_parent'       => 0,
                'user_id'              => is_user_logged_in() ? get_current_user_id() : 0,
                'comment_author_IP'    => isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( $_SERVER['REMOTE_ADDR'] ) : '',
                'comment_agent'        => isset( $_SERVER['HTTP_USER_AGENT'] ) ? substr( $_SERVER['HTTP_USER_AGENT'], 0, 254 ) : '',
                'comment_date'         => current_time( 'mysql' ),
                'comment_approved'     => $auto_approve ? 1 : 0,
            );

            $comment_id = wp_insert_comment( $comment_data );
            if ( $comment_id ) {
                update_comment_meta( $comment_id, 'rating', $rating );
                if ( ! empty( $uploaded_images ) ) {
                    update_comment_meta( $comment_id, 'dawp_images', json_encode( $uploaded_images ) );
                }
                if ( ! empty( $tags_str ) ) {
                    update_comment_meta( $comment_id, 'dawp_tags', $tags_str );
                }

                $this->clean_product_rating_cache( $product_id );
                if ( function_exists( 'wc_delete_product_transients' ) ) {
                    wc_delete_product_transients( $product_id );
                }

                $msg = $auto_approve 
                    ? 'Cảm ơn bạn! Đánh giá của bạn đã được gửi và hiển thị thành công.' 
                    : 'Cảm ơn bạn! Đánh giá của bạn đã được gửi và đang chờ quản trị viên phê duyệt.';

                wp_send_json_success( array( 'message' => $msg ) );
            } else {
                wp_send_json_error( array( 'message' => 'Lỗi lưu trữ đánh giá. Vui lòng thử lại!' ) );
            }
        } else {
            global $wpdb;
            $table_name = $wpdb->prefix . 'dawp_reviews';

            $inserted = $wpdb->insert(
                $table_name,
                array(
                    'product_id' => $product_id,
                    'rating'     => $rating,
                    'name'       => $name,
                    'email'      => $email,
                    'content'    => $content,
                    'images'     => json_encode( $uploaded_images ),
                    'tags'       => $tags_str,
                    'ip_address' => isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( $_SERVER['REMOTE_ADDR'] ) : '',
                    'status'     => $status,
                    'created_at' => current_time( 'mysql' )
                ),
                array( '%d', '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s' )
            );

            if ( $inserted ) {
                $this->clean_product_rating_cache( $product_id );

                $msg = $auto_approve 
                    ? 'Cảm ơn bạn! Đánh giá của bạn đã được gửi và hiển thị thành công.' 
                    : 'Cảm ơn bạn! Đánh giá của bạn đã được gửi và đang chờ quản trị viên phê duyệt.';

                wp_send_json_success( array( 'message' => $msg ) );
            } else {
                wp_send_json_error( array( 'message' => 'Lỗi lưu trữ đánh giá. Vui lòng thử lại!' ) );
            }
        }
    }

    /**
     * Giải mã và lưu tệp WebP Base64, sau đó đăng ký vào WP Media Library
     */
    private function upload_base64_webp_image( $base64_data, $product_id ) {
        if ( preg_match( '/^data:image\/(\w+);base64,/', $base64_data, $type ) ) {
            $data = substr( $base64_data, strpos( $base64_data, ',' ) + 1 );
            $data = base64_decode( $data );
            if ( $data === false ) {
                return false;
            }
        } else {
            return false;
        }

        // Chặn nhồi ổ đĩa: giới hạn 3MB mỗi ảnh sau giải mã
        if ( strlen( $data ) > 3 * MB_IN_BYTES ) {
            return false;
        }

        // Xác minh dữ liệu thực sự là ảnh WebP hợp lệ (client đã convert sang WebP),
        // không chấp nhận nội dung tùy ý đội lốt chuỗi base64
        $img_info = function_exists( 'getimagesizefromstring' ) ? @getimagesizefromstring( $data ) : false;
        if ( false === $img_info || empty( $img_info['mime'] ) || 'image/webp' !== $img_info['mime'] ) {
            return false;
        }

        $upload_dir = wp_upload_dir();
        $reviews_dir = $upload_dir['basedir'] . '/dawp-reviews';
        if ( ! file_exists( $reviews_dir ) ) {
            wp_mkdir_p( $reviews_dir );
        }

        $filename = 'review_' . $product_id . '_' . uniqid() . '.webp';
        $filepath = $reviews_dir . '/' . $filename;

        if ( file_put_contents( $filepath, $data ) !== false ) {
            $wp_filetype = wp_check_filetype( $filename, null );
            $attachment = array(
                'post_mime_type' => $wp_filetype['type'],
                'post_title'     => sanitize_file_name( $filename ),
                'post_content'   => '',
                'post_status'    => 'inherit'
            );

            $attach_id = wp_insert_attachment( $attachment, $filepath, $product_id );

            require_once ABSPATH . 'wp-admin/includes/image.php';
            $attach_data = wp_generate_attachment_metadata( $attach_id, $filepath );
            wp_update_attachment_metadata( $attach_id, $attach_data );

            return array(
                'id'  => $attach_id,
                'url' => wp_get_attachment_url( $attach_id )
            );
        }

        return false;
    }

    /**
     * Xóa đánh giá và dọn sạch các tệp tin đính kèm
     */
    public function delete_review( $id ) {
        global $wpdb;
        $db_type = DAWP_Helpers::get_setting( 'woo_reviews_database_type', 'native' );

        if ( $db_type === 'native' ) {
            $comment = get_comment( $id );
            if ( ! $comment || $comment->comment_type !== 'review' ) {
                return false;
            }

            // Delete attachments if any
            $images_meta = get_comment_meta( $id, 'dawp_images', true );
            if ( ! empty( $images_meta ) ) {
                $images = json_decode( $images_meta, true );
                if ( is_array( $images ) ) {
                    foreach ( $images as $img ) {
                        if ( isset( $img['id'] ) ) {
                            wp_delete_attachment( (int) $img['id'], true );
                        }
                    }
                }
            }

            // Delete replies (child comments)
            $replies = $wpdb->get_results( $wpdb->prepare(
                "SELECT comment_ID FROM {$wpdb->comments} WHERE comment_parent = %d",
                $id
            ) );
            foreach ( $replies as $r ) {
                wp_delete_comment( $r->comment_ID, true );
            }

            // Delete comment
            $deleted = wp_delete_comment( $id, true );
            if ( $deleted ) {
                $product_id = $comment->comment_post_ID;
                $this->clean_product_rating_cache( $product_id );
                if ( function_exists( 'wc_delete_product_transients' ) ) {
                    wc_delete_product_transients( $product_id );
                }
                return true;
            }
            return false;
        } else {
            $table_name = $wpdb->prefix . 'dawp_reviews';
            $review = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table_name WHERE id = %d", $id ) );
            if ( ! $review ) {
                return false;
            }

            if ( ! empty( $review->images ) ) {
                $images = json_decode( $review->images, true );
                if ( is_array( $images ) ) {
                    foreach ( $images as $img ) {
                        if ( isset( $img['id'] ) ) {
                            wp_delete_attachment( (int) $img['id'], true );
                        }
                    }
                }
            }

            $deleted = $wpdb->delete( $table_name, array( 'id' => $id ), array( '%d' ) );
            if ( $deleted ) {
                $this->clean_product_rating_cache( $review->product_id );
                return true;
            }
            return false;
        }
    }

    /**
     * AJAX duyệt/ẩn đánh giá
     */
    public function ajax_toggle_status() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => 'Bạn không có quyền thực hiện tác vụ này!' ) );
        }

        check_ajax_referer( 'dawp_admin_reviews_nonce', 'nonce' );

        $id = isset( $_POST['id'] ) ? (int) $_POST['id'] : 0;
        if ( ! $id ) {
            wp_send_json_error( array( 'message' => 'ID đánh giá không hợp lệ!' ) );
        }

        $db_type = DAWP_Helpers::get_setting( 'woo_reviews_database_type', 'native' );

        if ( $db_type === 'native' ) {
            global $wpdb;
            $comment = get_comment( $id );
            if ( ! $comment || $comment->comment_type !== 'review' ) {
                wp_send_json_error( array( 'message' => 'Không tìm thấy đánh giá!' ) );
            }
            $new_approved = $comment->comment_approved === '1' ? '0' : '1';
            $updated = wp_update_comment( array(
                'comment_ID'       => $id,
                'comment_approved' => $new_approved
            ) );
            if ( $updated !== false ) {
                $product_id = $comment->comment_post_ID;
                $this->clean_product_rating_cache( $product_id );
                if ( function_exists( 'wc_delete_product_transients' ) ) {
                    wc_delete_product_transients( $product_id );
                }
                wp_send_json_success( array( 
                    'status'  => $new_approved === '1' ? 'approved' : 'pending',
                    'message' => 'Cập nhật trạng thái đánh giá thành công!' 
                ) );
            } else {
                wp_send_json_error( array( 'message' => 'Không thể cập nhật trạng thái!' ) );
            }
        } else {
            global $wpdb;
            $table_name = $wpdb->prefix . 'dawp_reviews';

            $review = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table_name WHERE id = %d", $id ) );
            if ( ! $review ) {
                wp_send_json_error( array( 'message' => 'Không tìm thấy đánh giá!' ) );
            }

            $new_status = $review->status === 'approved' ? 'pending' : 'approved';

            $updated = $wpdb->update(
                $table_name,
                array( 'status' => $new_status ),
                array( 'id' => $id ),
                array( '%s' ),
                array( '%d' )
            );

            if ( $updated !== false ) {
                $this->clean_product_rating_cache( $review->product_id );
                wp_send_json_success( array( 
                    'status'  => $new_status,
                    'message' => 'Cập nhật trạng thái đánh giá thành công!' 
                ) );
            } else {
                wp_send_json_error( array( 'message' => 'Không thể cập nhật trạng thái!' ) );
            }
        }
    }

    /**
     * AJAX Phản hồi đánh giá
     */
    public function ajax_reply() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => 'Bạn không có quyền thực hiện tác vụ này!' ) );
        }

        check_ajax_referer( 'dawp_admin_reviews_nonce', 'nonce' );

        $id = isset( $_POST['id'] ) ? (int) $_POST['id'] : 0;
        $reply_content = isset( $_POST['reply'] ) ? sanitize_textarea_field( $_POST['reply'] ) : '';

        if ( ! $id ) {
            wp_send_json_error( array( 'message' => 'ID đánh giá không hợp lệ!' ) );
        }

        $db_type = DAWP_Helpers::get_setting( 'woo_reviews_database_type', 'native' );

        if ( $db_type === 'native' ) {
            global $wpdb;
            $comment = get_comment( $id );
            if ( ! $comment || $comment->comment_type !== 'review' ) {
                wp_send_json_error( array( 'message' => 'Không tìm thấy đánh giá!' ) );
            }

            // Check if there is already a reply
            $reply = $wpdb->get_row( $wpdb->prepare(
                "SELECT comment_ID FROM {$wpdb->comments} 
                 WHERE comment_parent = %d AND comment_approved = '1' 
                 ORDER BY comment_date ASC LIMIT 1",
                $id
            ) );

            if ( $reply ) {
                if ( empty( $reply_content ) ) {
                    wp_delete_comment( $reply->comment_ID, true );
                } else {
                    wp_update_comment( array(
                        'comment_ID'      => $reply->comment_ID,
                        'comment_content' => $reply_content
                    ) );
                }
            } else {
                if ( ! empty( $reply_content ) ) {
                    $user = wp_get_current_user();
                    wp_insert_comment( array(
                        'comment_post_ID'      => $comment->comment_post_ID,
                        'comment_author'       => $user->display_name,
                        'comment_author_email' => $user->user_email,
                        'comment_content'      => $reply_content,
                        'comment_type'         => 'comment',
                        'comment_parent'       => $id,
                        'user_id'              => $user->ID,
                        'comment_approved'     => 1,
                        'comment_date'         => current_time( 'mysql' )
                    ) );
                }
            }

            $this->clean_product_rating_cache( $comment->comment_post_ID );
            wp_send_json_success( array( 'message' => 'Phản hồi đánh giá thành công!' ) );
        } else {
            global $wpdb;
            $table_name = $wpdb->prefix . 'dawp_reviews';

            $review = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table_name WHERE id = %d", $id ) );
            if ( ! $review ) {
                wp_send_json_error( array( 'message' => 'Không tìm thấy đánh giá!' ) );
            }

            $updated = $wpdb->update(
                $table_name,
                array( 
                    'reply_content' => $reply_content,
                    'reply_date'    => current_time( 'mysql' )
                ),
                array( 'id' => $id ),
                array( '%s', '%s' ),
                array( '%d' )
            );

            if ( $updated !== false ) {
                $this->clean_product_rating_cache( $review->product_id );
                wp_send_json_success( array( 'message' => 'Phản hồi đánh giá thành công!' ) );
            } else {
                wp_send_json_error( array( 'message' => 'Không thể gửi phản hồi!' ) );
            }
        }
    }

    /**
     * AJAX Xóa đánh giá
     */
    public function ajax_delete() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => 'Bạn không có quyền thực hiện tác vụ này!' ) );
        }

        check_ajax_referer( 'dawp_admin_reviews_nonce', 'nonce' );

        $id = isset( $_POST['id'] ) ? (int) $_POST['id'] : 0;
        if ( ! $id ) {
            wp_send_json_error( array( 'message' => 'ID đánh giá không hợp lệ!' ) );
        }

        if ( $this->delete_review( $id ) ) {
            wp_send_json_success( array( 'message' => 'Xóa đánh giá thành công!' ) );
        } else {
            wp_send_json_error( array( 'message' => 'Không thể xóa đánh giá!' ) );
        }
    }

    /**
     * AJAX Xóa toàn bộ đánh giá trong CSDL
     */
    public function ajax_clear_all() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => 'Bạn không có quyền thực hiện tác vụ này!' ) );
        }

        check_ajax_referer( 'dawp_admin_reviews_nonce', 'nonce' );

        $db_type = DAWP_Helpers::get_setting( 'woo_reviews_database_type', 'native' );

        if ( $db_type === 'native' ) {
            global $wpdb;
            $reviews = $wpdb->get_results( "SELECT comment_ID, comment_post_ID FROM {$wpdb->comments} WHERE comment_type = 'review'" );
            foreach ( $reviews as $review ) {
                $id = $review->comment_ID;
                $images_meta = get_comment_meta( $id, 'dawp_images', true );
                if ( ! empty( $images_meta ) ) {
                    $images = json_decode( $images_meta, true );
                    if ( is_array( $images ) ) {
                        foreach ( $images as $img ) {
                            if ( isset( $img['id'] ) ) {
                                wp_delete_attachment( (int) $img['id'], true );
                            }
                        }
                    }
                }

                $replies = $wpdb->get_results( $wpdb->prepare(
                    "SELECT comment_ID FROM {$wpdb->comments} WHERE comment_parent = %d",
                    $id
                ) );
                foreach ( $replies as $r ) {
                    wp_delete_comment( $r->comment_ID, true );
                }

                wp_delete_comment( $id, true );
                $this->clean_product_rating_cache( $review->comment_post_ID );
            }

            wp_send_json_success( array( 'message' => 'Đã xóa sạch toàn bộ đánh giá và các tệp đính kèm thành công!' ) );
        } else {
            global $wpdb;
            $table_name = $wpdb->prefix . 'dawp_reviews';

            $reviews = $wpdb->get_results( "SELECT id, product_id, images FROM $table_name" );

            foreach ( $reviews as $review ) {
                if ( ! empty( $review->images ) ) {
                    $images = json_decode( $review->images, true );
                    if ( is_array( $images ) ) {
                        foreach ( $images as $img ) {
                            if ( isset( $img['id'] ) ) {
                                wp_delete_attachment( (int) $img['id'], true );
                            }
                        }
                    }
                }
                $this->clean_product_rating_cache( $review->product_id );
            }

            $wpdb->query( "TRUNCATE TABLE $table_name" );

            wp_send_json_success( array( 'message' => 'Đã xóa sạch toàn bộ đánh giá và các tệp đính kèm thành công!' ) );
        }
    }
}
