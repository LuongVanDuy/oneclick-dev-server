<?php
defined( 'ABSPATH' ) || exit;

require_once __DIR__ . '/class-css-slim.php';

class DAWP_Pagespeed {
    private $slider_count = 0;
    private $slide_lazy_loader_printed = false;

    public function __construct() {
        $saved_options = get_option( 'dawp_settings', [] );
        $defaults = [
            'ps_lcp_opt' => 1,
            'ps_remove_emojis' => 1,
            'ps_clean_header' => 1,
            'ps_local_fonts' => 1,
            'ps_dedupe_fa' => 1,
            'ps_http_timeout' => 1,
            'ps_failsafe' => 1,
            'ps_client_webp' => 1,
            'ps_lazy_iframe' => 1,
            'ps_video_facade' => 0,
            'ps_remove_jquery_migrate' => 0,
            'ps_speculation' => 1,
            'ps_preconnect_domains' => '',
            'ps_icon_font_swap' => 1,
            'ps_defer_scripts' => 0,
            'ps_defer_exclude' => '',
            'ps_delay_js' => 0,
            'ps_delay_js_timeout' => 10,
            'ps_delay_js_custom' => '',
            'ps_delay_js_exclude' => '',
            'ps_slim_css' => 0,
            'ps_slim_css_fallback' => 1,
            'ps_slim_css_safelist' => '',
            'ps_slim_css_exclude' => '',
            'ps_img_srcset' => 1,
            'ps_content_visibility' => 1
        ];
        $options = array_merge( $defaults, is_array( $saved_options ) ? $saved_options : [] );

        // 1. Tối ưu LCP & Tải trước ảnh chính (Không dùng regex nặng nề làm tăng TTFB)
        if ( !empty($options['ps_lcp_opt']) ) {
            add_filter( 'wp_omit_loading_attr_threshold', [ $this, 'set_lazyload_threshold' ] );
            add_action( 'wp_head', [ $this, 'preload_lcp_image' ], 2 );
            add_action( 'wp_head', [ $this, 'add_preconnect_links' ], 1 );
            add_filter( 'the_content', [ $this, 'add_missing_image_dimensions' ], 99 );
            add_filter( 'wp_get_attachment_image_attributes', [ $this, 'optimize_logo_image_attributes' ], 10, 2 );
            add_filter( 'get_custom_logo', [ $this, 'optimize_logo_html' ], 999 );
        }

        // 2. Xóa Emojis (Đã loại bỏ xóa jQuery Migrate để giữ tính tương thích cao nhất)
        if ( !empty($options['ps_remove_emojis']) ) {
            add_action( 'init', [ $this, 'remove_emojis' ] );
        }

        // 3. Dọn dẹp Header (Rút ngắn HTML)
        if ( !empty($options['ps_clean_header']) ) {
            add_action( 'init', [ $this, 'clean_header' ] );
        }

        // 4. Tải Google Fonts nội bộ (Local Google Fonts) - Ngăn chặn Render-blocking
        if ( !empty($options['ps_local_fonts']) ) {
            add_filter( 'style_loader_src', [ $this, 'local_google_fonts' ], 15, 2 );
        }

        // 5. Loại bỏ Font Awesome trùng lặp
        if ( !empty($options['ps_dedupe_fa']) ) {
            add_action( 'wp_enqueue_scripts', [ $this, 'dequeue_duplicate_assets' ], 999 );
        }

        // 6. Giới hạn thời gian kết nối HTTP bên ngoài (Tránh treo PHP xử lý)
        if ( !empty($options['ps_http_timeout']) ) {
            add_filter( 'http_request_args', [ $this, 'limit_external_http_timeout' ], 10, 2 );
        }

        // 7. Chống kẹt Preloader (Failsafe) - In trực tiếp vào Head không qua buffer
        if ( !empty($options['ps_failsafe']) ) {
            add_action( 'wp_head', [ $this, 'inject_failsafe_preloader' ], 1 );
        }
        
        // CSS Slider Failsafe: Hộp trượt không bị xếp chồng dọc trước khi Flickity chạy
        add_action( 'wp_head', [ $this, 'inject_slider_failsafe_css' ], 1 );

        // 8. Tự động chuyển đổi ảnh sang WebP ở máy khách (Nén ảnh tại trình duyệt trước khi upload)
        $ps_client_webp = isset($options['ps_client_webp']) ? !empty($options['ps_client_webp']) : true;
        if ( $ps_client_webp ) {
            add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_client_webp_script' ] );
        }

        // 8.1. Tự động nén tệp PDF tại máy khách
        $ps_client_pdf = isset($options['ps_client_pdf']) ? !empty($options['ps_client_pdf']) : true;
        if ( $ps_client_pdf ) {
            add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_client_pdf_script' ] );
        }

        // 8.2. Gỡ bỏ jQuery Migrate ngoài frontend
        if ( !empty($options['ps_remove_jquery_migrate']) ) {
            add_action( 'wp_default_scripts', [ $this, 'remove_jquery_migrate' ] );
        }

        // 8.3. Preconnect thêm các domain bên thứ ba
        if ( !empty($options['ps_preconnect_domains']) ) {
            add_action( 'wp_head', [ $this, 'inject_preconnect_domains' ], 2 );
        }

        // 8.4. Speculation Rules API (Prerender liên kết cho khách truy cập)
        if ( !empty($options['ps_speculation']) ) {
            add_action( 'wp_footer', [ $this, 'inject_speculation_rules' ], 999 );
        }

        // 8.5. Khởi chạy Output Buffer cho tối ưu Iframe & Font Swap & Minify Inline CSS
        // & Hoãn JS theo dõi & Gọn CSS (Critical CSS)
        if ( ! is_admin() && (
            !empty($options['ps_lazy_iframe']) ||
            !empty($options['ps_video_facade']) ||
            !empty($options['ps_icon_font_swap']) ||
            !empty($options['ps_delay_js']) ||
            !empty($options['ps_slim_css']) ||
            !empty($options['ps_img_srcset']) ||
            !empty($options['ps_defer_scripts'])
        ) ) {
            add_action( 'template_redirect', [ $this, 'start_pagespeed_buffer' ], 5 );
        }

        // 8.5.1. Gọn CSS + Critical CSS: đăng ký cron phân tích ngầm và nút dọn cache
        DAWP_CSS_Slim::init( $options );

        // 8.5.2. Quét & thu nhỏ ảnh quá khổ trong thư viện (AJAX trang quản trị)
        if ( is_admin() ) {
            add_action( 'wp_ajax_dawp_scan_big_images', [ $this, 'ajax_scan_big_images' ] );
            add_action( 'wp_ajax_dawp_shrink_image', [ $this, 'ajax_shrink_image' ] );
        }

        // 8.6. Trì hoãn tải Scripts thông minh (Smart Defer) — nay xử lý trong output
        // buffer (xem process_defer_scripts) để defer được CẢ jQuery và bọc inline
        // script phụ thuộc jQuery cho an toàn. Không dùng script_loader_tag nữa vì
        // hook đó không thấy được inline script và script do theme in tay.

        // 9. Khử lazyload tận gốc cho ảnh trong slider của các Page Builder/Shortcodes phổ biến
        if ( ! is_admin() ) {
            add_filter( 'do_shortcode_tag', [ $this, 'exclude_slider_shortcode_images' ], 10, 3 );
            add_filter( 'render_block', [ $this, 'exclude_slider_block_images' ], 10, 2 );
            add_filter( 'elementor/widget/render_content', [ $this, 'exclude_elementor_slider_images' ], 10, 2 );
        }


    }

    // Thiết lập số lượng ảnh bỏ qua lazy-load bằng API gốc của WP (Không tốn CPU)
    public function set_lazyload_threshold( $threshold ) {
        // Đồng bộ với bộ tiêm lazy trong buffer: điện thoại 1 ảnh, máy tính 3
        return (int) apply_filters( 'dawp_eager_image_count', wp_is_mobile() ? 1 : 3 );
    }

    // Tải trước hình ảnh LCP (Chỉ tải cho trang chi tiết nếu có ảnh đại diện, tránh dùng regex cào HTML làm chậm TTFB)
    public function preload_lcp_image() {
        if ( is_admin() || is_preview() || is_feed() ) return;

        // Tải trước Logo tùy biến nếu được kích hoạt (Áp dụng cho mọi trang của website)
        $custom_logo_id = get_theme_mod( 'custom_logo' );
        if ( $custom_logo_id ) {
            $logo_url = wp_get_attachment_image_url( $custom_logo_id, 'full' );
            if ( $logo_url ) {
                echo '<link rel="preload" as="image" href="' . esc_url( $logo_url ) . '" fetchpriority="high">' . "\n";
            }
        }

        // Tải trước banner LCP và ảnh nền Hero cho trang chủ
        if ( is_front_page() ) {
            $options = get_option( 'dawp_settings', [] );

            // Tải trước ảnh LCP tùy biến cấu hình theo thiết bị
            $is_mobile = wp_is_mobile();
            if ( $is_mobile && ! empty( $options['ps_preload_lcp_mobile'] ) ) {
                echo '<link rel="preload" as="image" href="' . esc_url( $options['ps_preload_lcp_mobile'] ) . '" fetchpriority="high">' . "\n";
            } elseif ( ! $is_mobile && ! empty( $options['ps_preload_lcp_desktop'] ) ) {
                echo '<link rel="preload" as="image" href="' . esc_url( $options['ps_preload_lcp_desktop'] ) . '" fetchpriority="high">' . "\n";
            }

            // Tải trước font biểu tượng Flatsome mặc định nếu đang sử dụng Flatsome theme
            $theme = wp_get_theme();
            if ( $theme->get('Name') === 'Flatsome' || $theme->parent() && $theme->parent()->get('Name') === 'Flatsome' ) {
                echo '<link rel="preload" href="' . get_template_directory_uri() . '/assets/css/icons/fl-icons.woff2" as="font" type="font/woff2" crossorigin>' . "\n";
            }
        }
        // Nếu là trang chi tiết khác, tải trước ảnh đại diện ngay lập tức
        else if ( is_singular() && has_post_thumbnail() ) {
            $thumbnail_id = get_post_thumbnail_id();
            $img_src = wp_get_attachment_image_url( $thumbnail_id, 'full' );
            $img_srcset = wp_get_attachment_image_srcset( $thumbnail_id, 'full' );
            $img_sizes = wp_get_attachment_image_sizes( $thumbnail_id, 'full' );

            if ( $img_src ) {
                echo '<link rel="preload" as="image" href="' . esc_url( $img_src ) . '"';
                if ( $img_srcset ) {
                    echo ' imagesrcset="' . esc_attr( $img_srcset ) . '"';
                }
                if ( $img_sizes ) {
                    echo ' imagesizes="' . esc_attr( $img_sizes ) . '"';
                }
                echo ' fetchpriority="high">' . "\n";
            }
        }
    }

    /**
     * Tối ưu hóa các thuộc tính của thẻ img logo thông qua wp_get_attachment_image_attributes
     */
    public function optimize_logo_image_attributes( $attr, $attachment ) {
        $custom_logo_id = (int) get_theme_mod( 'custom_logo' );
        if ( $custom_logo_id && $attachment->ID === $custom_logo_id ) {
            $attr['fetchpriority'] = 'high';
            $attr['decoding'] = 'async';
            if ( isset( $attr['loading'] ) ) {
                unset( $attr['loading'] );
            }
        }
        return $attr;
    }

    /**
     * Tối ưu hóa HTML của logo tùy biến (fallback cho các theme render logo thủ công)
     */
    public function optimize_logo_html( $html ) {
        if ( empty( $html ) ) return $html;

        // 1. Xóa loading="lazy" nếu có
        $html = preg_replace( '/\s+loading=["\']lazy["\']/i', '', $html );
        
        // 2. Thêm decoding="async" nếu chưa có
        if ( strpos( $html, 'decoding=' ) === false ) {
            $html = str_replace( '<img ', '<img decoding="async" ', $html );
        }
        
        // 3. Thêm fetchpriority="high" nếu chưa có
        if ( strpos( $html, 'fetchpriority=' ) === false ) {
            $html = str_replace( '<img ', '<img fetchpriority="high" ', $html );
        }
        
        return $html;
    }

    // CSS Failsafe cho slider ngăn xếp chồng dọc và tải trước ảnh không cần thiết khi JS chưa khởi chạy
    public function inject_slider_failsafe_css() {
        if ( is_admin() || is_preview() || is_feed() ) return;
        ?>
        <style id="dawp-slider-failsafe-css">
        .slider[data-flickity-options]:not(.flickity-enabled),
        .row-slider[data-flickity-options]:not(.flickity-enabled),
        .ux-slider:not(.flickity-enabled) {
            display: flex !important;
            flex-wrap: nowrap !important;
            overflow: hidden !important;
        }
        .slider[data-flickity-options]:not(.flickity-enabled) > *,
        .row-slider[data-flickity-options]:not(.flickity-enabled) > *,
        .ux-slider:not(.flickity-enabled) > * {
            display: block !important;
            flex: 0 0 100% !important;
            width: 100% !important;
        }
        </style>
        <?php
    }

    // Tự động thêm Preconnect cho Google Fonts ngoài frontend (Siêu nhẹ, không tốn CPU)
    public function add_preconnect_links() {
        if ( is_admin() || is_preview() || is_feed() ) return;
        echo '<link rel="preconnect" href="https://fonts.googleapis.com">' . "\n";
        echo '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>' . "\n";
    }

    // Xóa Emojis
    public function remove_emojis() {
        remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
        remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
        remove_action( 'wp_print_styles', 'print_emoji_styles' );
        remove_action( 'admin_print_styles', 'print_emoji_styles' ); 
        remove_filter( 'the_content_feed', 'wp_staticize_emoji' );
        remove_filter( 'comment_text_rss', 'wp_staticize_emoji' ); 
        remove_filter( 'wp_mail', 'wp_staticize_emoji_for_email' );
        add_filter( 'tiny_mce_plugins', function( $plugins ) {
            return is_array( $plugins ) ? array_diff( $plugins, [ 'wpemoji' ] ) : [];
        });
    }

    // Dọn dẹp Header
    public function clean_header() {
        remove_action( 'wp_head', 'rsd_link' );
        remove_action( 'wp_head', 'wlwmanifest_link' );
        remove_action( 'wp_head', 'wp_generator' );
        remove_action( 'wp_head', 'wp_shortlink_wp_head' );
        remove_action( 'wp_head', 'rest_output_link_wp_head', 10 );
        remove_action( 'wp_head', 'oembed_discovery_links', 10 );
    }

    // Tải Google Fonts nội bộ cục bộ
    public function local_google_fonts( $src, $handle ) {
        if ( is_admin() || empty( $src ) || ! is_string( $src ) ) return $src;
        if ( strpos( $src, 'fonts.googleapis.com/css' ) === false ) return $src;

        static $fonts_cache_status = null;
        if ( $fonts_cache_status === null ) {
            $upload_dir = wp_upload_dir();
            if ( ! empty( $upload_dir['error'] ) ) {
                $fonts_cache_status = false;
            } else {
                $fonts_dir = $upload_dir['basedir'] . '/dawp-fonts';
                $fonts_url = $upload_dir['baseurl'] . '/dawp-fonts';

                if ( ! file_exists( $fonts_dir ) ) {
                    wp_mkdir_p( $fonts_dir );
                    @file_put_contents( $fonts_dir . '/index.php', '<?php // Silence is golden' );
                }

                // Kiểm tra quyền ghi của thư mục đệm để tránh tải lại file qua HTTP trên mỗi request nếu không ghi được
                if ( is_writable( $fonts_dir ) ) {
                    $fonts_cache_status = [
                        'dir' => $fonts_dir,
                        'url' => $fonts_url
                    ];
                } else {
                    $fonts_cache_status = false;
                }
            }
        }

        if ( $fonts_cache_status === false ) {
            return $src;
        }

        $fonts_dir = $fonts_cache_status['dir'];
        $fonts_url = $fonts_cache_status['url'];

        $src_decoded = html_entity_decode( $src );
        $hash = md5( $src_decoded );
        $local_css_file = $fonts_dir . '/font-' . $handle . '-' . $hash . '.css';
        $local_css_url = $fonts_url . '/font-' . $handle . '-' . $hash . '.css';

        if ( file_exists( $local_css_file ) && filesize( $local_css_file ) > 100 ) {
            return $local_css_url;
        }

        $download_url = $src_decoded;
        if ( strpos( $download_url, '//' ) === 0 ) {
            $download_url = 'https:' . $download_url;
        }

        $ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';
        $response = wp_remote_get( $download_url, [
            'user-agent' => $ua,
            'timeout'    => 15
        ] );

        if ( is_wp_error( $response ) ) return $src;

        $css_content = wp_remote_retrieve_body( $response );
        if ( empty( $css_content ) ) return $src;

        // Bỏ qua việc tải các file phông woff2 vật lý về máy chủ cục bộ (vốn gây nghẽn HTTP request 10s khi cache miss).
        // Trình duyệt của khách truy cập sẽ tải các file này từ CDN Google cực nhanh.

        // Ép thuộc tính font-display: swap để tối ưu tải phông chữ và hiển thị đúng thiết kế cho người dùng
        $css_content = preg_replace_callback('/@font-face\s*\{([^}]+)\}/is', function($face_matches) {
            $font_face = $face_matches[1];
            if ( preg_match('/font-display\s*:\s*([^;]+)/i', $font_face) ) {
                $font_face = preg_replace('/font-display\s*:\s*[^;]+/i', 'font-display: swap', $font_face);
            } else {
                $font_face .= "\n  font-display: swap;\n";
            }
            return '@font-face {' . $font_face . '}';
        }, $css_content);

        file_put_contents( $local_css_file, $css_content );
        return $local_css_url;
    }

    // Khử trùng lặp Font Awesome
    public function dequeue_duplicate_assets() {
        if ( is_admin() ) return;

        // Nếu là trang chủ, dequeue hoàn toàn vì không sử dụng icon Font Awesome nào
        if ( is_front_page() ) {
            wp_dequeue_style( 'font-awesome' );
            wp_dequeue_style( 'font-awesome-pro' );
            return;
        }

        if ( wp_style_is( 'font-awesome-pro', 'enqueued' ) && wp_style_is( 'font-awesome', 'enqueued' ) ) {
            wp_dequeue_style( 'font-awesome' );
        }
    }

    // Giới hạn HTTP Timeout ngoại vi
    public function limit_external_http_timeout( $args, $url ) {
        if ( ! is_admin() ) {
            $args['timeout'] = 3;
            $args['connect_timeout'] = 2;
        }
        return $args;
    }

    // Bơm Failsafe chống kẹt màn hình preloader
    public function inject_failsafe_preloader() {
        ?>
        <script id="dawp-preloader-failsafe">
        (function() {
            var releaseSite = function() {
                document.documentElement.classList.remove("loading-site");
                if (document.body) {
                    document.body.classList.remove("loading-site");
                }
                var preloader = document.getElementById("preloader") || document.querySelector(".loading-site") || document.querySelector(".preloader");
                if (preloader) {
                    preloader.style.setProperty("display", "none", "important");
                    preloader.style.setProperty("opacity", "0", "important");
                    preloader.style.setProperty("visibility", "hidden", "important");
                }
                var wrapper = document.getElementById("wrapper") || document.getElementById("main");
                if (wrapper) {
                    wrapper.style.setProperty("opacity", "1", "important");
                    wrapper.style.setProperty("visibility", "visible", "important");
                }
            };
            setTimeout(releaseSite, 2500);
            window.addEventListener("load", releaseSite);
        })();
        </script>
        <?php
    }

    // Tải script xử lý chuyển đổi WebP ở máy khách
    public function enqueue_client_webp_script() {
        $js_path = DAWP_DIR . 'assets/js/dawp-client-webp.js';
        $ver = file_exists( $js_path ) ? filemtime( $js_path ) : DAWP_VERSION;
        wp_enqueue_script( 'dawp-client-webp', DAWP_URL . 'assets/js/dawp-client-webp.js', ['jquery'], $ver, true );

        $saved_options = get_option( 'dawp_settings', [] );
        $webp_quality = isset( $saved_options['ps_webp_quality'] ) ? $saved_options['ps_webp_quality'] : 'high';

        wp_localize_script( 'dawp-client-webp', 'dawpWebpSettings', [
            'quality_level' => $webp_quality
        ] );
    }

    // Tải script xử lý nén PDF ở máy khách
    public function enqueue_client_pdf_script() {
        global $pagenow;
        if ( ! in_array( $pagenow, [ 'post.php', 'post-new.php', 'upload.php', 'media-upload.php' ] ) ) {
            return;
        }

        $pako_path = DAWP_DIR . 'assets/js/pako.min.js';
        $pako_ver = file_exists( $pako_path ) ? filemtime( $pako_path ) : DAWP_VERSION;
        wp_enqueue_script( 'pako', DAWP_URL . 'assets/js/pako.min.js', [], $pako_ver, true );

        $pdf_lib_path = DAWP_DIR . 'assets/js/pdf-lib.min.js';
        $pdf_lib_ver = file_exists( $pdf_lib_path ) ? filemtime( $pdf_lib_path ) : DAWP_VERSION;
        wp_enqueue_script( 'pdf-lib', DAWP_URL . 'assets/js/pdf-lib.min.js', [], $pdf_lib_ver, true );

        $js_path = DAWP_DIR . 'assets/js/dawp-client-pdf.js';
        $ver = file_exists( $js_path ) ? filemtime( $js_path ) : DAWP_VERSION;
        wp_enqueue_script( 'dawp-client-pdf', DAWP_URL . 'assets/js/dawp-client-pdf.js', ['jquery', 'pdf-lib', 'pako'], $ver, true );

        $saved_options = get_option( 'dawp_settings', [] );
        $webp_quality = isset( $saved_options['ps_webp_quality'] ) ? $saved_options['ps_webp_quality'] : 'high';

        wp_localize_script( 'dawp-client-pdf', 'dawpPdfSettings', [
            'quality_level' => $webp_quality
        ] );
    }



    /**
     * Gỡ bỏ lazyload cho ảnh trong slider dạng shortcode (Flatsome, WPBakery,...)
     */
    public function exclude_slider_shortcode_images( $output, $tag, $attr ) {
        if ( empty( $output ) ) {
            return $output;
        }
        $slider_tags = ['slider', 'carousel', 'flickity', 'swiper', 'slick', 'ux_slider', 'ux_gallery'];
        $is_slider = false;
        foreach ( $slider_tags as $t ) {
            if ( stripos( $tag, $t ) !== false ) {
                $is_slider = true;
                break;
            }
        }
        
        if ( $is_slider ) {
            $this->slider_count++;
            if ( $this->slider_count === 1 ) {
                $output = $this->add_no_lazy_to_html( $output );
            }
        }
        return $output;
    }

    /**
     * Gỡ bỏ lazyload cho ảnh trong block slider của Gutenberg
     */
    public function exclude_slider_block_images( $block_content, $block ) {
        if ( empty( $block_content ) || empty( $block['blockName'] ) ) {
            return $block_content;
        }
        if ( stripos( $block['blockName'], 'slider' ) !== false || stripos( $block['blockName'], 'carousel' ) !== false || stripos( $block['blockName'], 'gallery' ) !== false ) {
            $this->slider_count++;
            if ( $this->slider_count === 1 ) {
                $block_content = $this->add_no_lazy_to_html( $block_content );
            }
        }
        return $block_content;
    }

    /**
     * Gỡ bỏ lazyload cho ảnh trong widget slider của Elementor
     */
    public function exclude_elementor_slider_images( $content, $widget ) {
        if ( empty( $content ) ) {
            return $content;
        }
        $name = $widget->get_name();
        if ( stripos( $name, 'slider' ) !== false || stripos( $name, 'carousel' ) !== false || stripos( $name, 'slides' ) !== false || stripos( $name, 'gallery' ) !== false ) {
            $this->slider_count++;
            if ( $this->slider_count === 1 ) {
                $content = $this->add_no_lazy_to_html( $content );
            }
        }
        return $content;
    }

    /**
     * Hàm helper gỡ bỏ loading="lazy" và thêm data-no-lazy="1" cho các thẻ img trong khối HTML
     */
    private function add_no_lazy_to_html( $html ) {
        // Slider: chỉ 2 ảnh ĐẦU (slide đang hiện + kế tiếp) tải ngay. Từ slide
        // thứ 3 trở đi: loading="lazy" KHÔNG có tác dụng vì slider xếp ngang —
        // trình duyệt coi mọi slide là "gần viewport" và tải hết (đo được trên
        // PageSpeed: 5MB ảnh portfolio 1920x10000 đổ về trước cả ảnh hero, LCP 15
        // giây). Nên đổi src/srcset thành data-dawp-src/data-dawp-srcset + ảnh
        // giữ chỗ trong suốt cùng tỷ lệ; một đoạn JS nhỏ (IntersectionObserver
        // theo cả trục ngang) trả lại src khi slide sắp vào tầm. Không phụ thuộc
        // Flickity/Swiper/Slick — chạy với mọi slider.
        $eager_left = 2;
        $html = preg_replace_callback( '/<img\b([^>]*)>/is', function( $matches ) use ( &$eager_left ) {
            $img_attrs = $matches[1];
            $has_slash = false;
            if ( substr( rtrim( $img_attrs ), -1 ) === '/' ) {
                $img_attrs = rtrim( rtrim( $img_attrs ), '/' );
                $has_slash = true;
            }
            // Ảnh svg/data đã nhẹ: để nguyên
            if ( preg_match( '/\bsrc=["\'](?:data:|[^"\']*\.svg)/i', $img_attrs ) ) {
                return $matches[0];
            }

            if ( $eager_left > 0 ) {
                $eager_left--;
                if ( strpos( $img_attrs, 'data-no-lazy' ) === false ) {
                    $img_attrs .= ' data-no-lazy="1"';
                }
                // Không ép fetchpriority="high" cho slider (tranh băng thông với LCP)
                $img_attrs = preg_replace( '/\s+fetchpriority=["\']high["\']/i', '', $img_attrs );
                $img_attrs = preg_replace( '/\s+loading=["\']lazy["\']/i', '', $img_attrs );
                return '<img' . $img_attrs . ( $has_slash ? ' /' : '' ) . '>';
            }

            // Slide thứ 3+: hoãn thật sự
            if ( strpos( $img_attrs, 'data-dawp-src' ) !== false || ! preg_match( '/\bsrc=["\']([^"\']+)["\']/i', $img_attrs, $sm ) ) {
                return $matches[0];
            }
            $w = preg_match( '/\bwidth=["\']?(\d+)/i', $img_attrs, $wm ) ? (int) $wm[1] : 0;
            $h = preg_match( '/\bheight=["\']?(\d+)/i', $img_attrs, $hm ) ? (int) $hm[1] : 0;
            $placeholder = 'data:image/svg+xml,' . rawurlencode( '<svg xmlns="http://www.w3.org/2000/svg" width="' . max( 1, $w ) . '" height="' . max( 1, $h ) . '"></svg>' );
            $img_attrs = preg_replace( '/\bsrc=(["\'])[^"\']+\1/i', 'src="' . $placeholder . '" data-dawp-src="' . esc_attr( html_entity_decode( $sm[1] ) ) . '"', $img_attrs, 1 );
            $img_attrs = preg_replace( '/\bsrcset=/i', 'data-dawp-srcset=', $img_attrs, 1 );
            $img_attrs = preg_replace( '/\bsizes=/i', 'data-dawp-sizes=', $img_attrs, 1 );
            $img_attrs = preg_replace( '/\s+fetchpriority=["\']high["\']/i', '', $img_attrs );
            $img_attrs = preg_replace( '/\s+loading=["\']lazy["\']/i', '', $img_attrs );
            if ( strpos( $img_attrs, 'data-no-lazy' ) === false ) {
                $img_attrs .= ' data-no-lazy="1"'; // để bộ tiêm lazy phía sau không đụng vào nữa
            }
            $img_attrs .= ' data-dawp-slide-lazy="1"';
            return '<img' . $img_attrs . ( $has_slash ? ' /' : '' ) . '>';
        }, $html );

        // Bộ nạp: in một lần, ở cuối slider đầu tiên được xử lý
        if ( strpos( $html, 'data-dawp-slide-lazy' ) !== false && ! $this->slide_lazy_loader_printed ) {
            $this->slide_lazy_loader_printed = true;
            add_action( 'wp_footer', [ $this, 'print_slide_lazy_loader' ], 5 );
        }
        return $html;
    }

    /** JS nạp ảnh slide bị hoãn — quan sát theo cả 2 trục, biên 600px, không phụ thuộc thư viện slider */
    public function print_slide_lazy_loader() {
        ?>
<script data-dawp-keep="1">(function(){var d=document;function load(i){if(i.getAttribute("data-dawp-srcset")){i.setAttribute("srcset",i.getAttribute("data-dawp-srcset"));i.removeAttribute("data-dawp-srcset");}if(i.getAttribute("data-dawp-sizes")){i.setAttribute("sizes",i.getAttribute("data-dawp-sizes"));i.removeAttribute("data-dawp-sizes");}i.setAttribute("src",i.getAttribute("data-dawp-src"));i.removeAttribute("data-dawp-src");i.removeAttribute("data-dawp-slide-lazy");}
var q=function(){return d.querySelectorAll("img[data-dawp-src]");};
if(!("IntersectionObserver" in window)){q().forEach(load);return;}
var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){io.unobserve(e.target);load(e.target);}});},{rootMargin:"600px 600px 600px 600px"});
function arm(){q().forEach(function(i){io.observe(i);});}
arm();
/* Dự phòng 1: người dùng chạm/cuộn → nạp hết sau 1,5s. Dự phòng 2: trang đã tải xong và yên 3s → nạp dần từng ảnh cách 400ms (LCP đã chốt từ lâu, băng thông rảnh). Nhờ vậy ảnh slide luôn sẵn khi người dùng lướt tới, dù slider dùng transform hay IO không bắn. */
var ev=["pointerdown","touchstart","keydown","wheel"];function onFirst(){ev.forEach(function(x){window.removeEventListener(x,onFirst,{passive:true});});setTimeout(function(){q().forEach(load);},1500);}
ev.forEach(function(x){window.addEventListener(x,onFirst,{passive:true});});
function drain(){var l=q();if(!l.length)return;load(l[0]);setTimeout(drain,400);}
if(d.readyState==="complete"){setTimeout(drain,3000);}else{window.addEventListener("load",function(){setTimeout(drain,3000);});}
})();</script>
        <?php
    }


    /**
     * Gỡ bỏ jquery-migrate khỏi dependencies của jquery ở frontend
     */
    public function remove_jquery_migrate( $scripts ) {
        if ( is_admin() ) {
            return;
        }
        if ( isset( $scripts->registered['jquery'] ) ) {
            $jquery = $scripts->registered['jquery'];
            if ( ! empty( $jquery->deps ) ) {
                $jquery->deps = array_diff( $jquery->deps, [ 'jquery-migrate' ] );
            }
        }
    }

    /**
     * In các thẻ preconnect và dns-prefetch cấu hình thêm trong Head
     */
    public function inject_preconnect_domains() {
        if ( is_admin() ) {
            return;
        }
        $options = get_option( 'dawp_settings', [] );
        $domains_str = isset( $options['ps_preconnect_domains'] ) ? trim( $options['ps_preconnect_domains'] ) : '';
        if ( empty( $domains_str ) ) {
            return;
        }
        $domains = array_filter( array_map( 'trim', explode( "\n", $domains_str ) ) );
        foreach ( $domains as $domain ) {
            if ( empty( $domain ) ) {
                continue;
            }
            // Chuẩn hóa thành URL đầy đủ nếu thiếu schema
            if ( strpos( $domain, '//' ) === false ) {
                $domain = 'https://' . $domain;
            }
            $clean_url = esc_url( $domain );
            echo '<link rel="preconnect" href="' . $clean_url . '" crossorigin>' . "\n";
            echo '<link rel="dns-prefetch" href="' . $clean_url . '">' . "\n";
        }
    }

    /**
     * In cấu hình Speculation Rules API cho trình duyệt Chrome để prerender liên kết
     */
    public function inject_speculation_rules() {
        if ( is_admin() || is_user_logged_in() ) {
            return;
        }
        ?>
        <script type="speculationrules">
        {
          "prerender": [
            {
              "source": "document",
              "where": {
                "and": [
                  { "href_matches": "/*" },
                  { "not": { "href_matches": [
                    "/wp-admin/*",
                    "/*/wp-admin/*",
                    "*\\?*",
                    "*#*",
                    "/cart",
                    "/*/cart",
                    "/cart/*",
                    "/*/cart/*",
                    "/checkout",
                    "/*/checkout",
                    "/checkout/*",
                    "/*/checkout/*",
                    "/gio-hang",
                    "/*/gio-hang",
                    "/gio-hang/*",
                    "/*/gio-hang/*",
                    "/thanh-toan",
                    "/*/thanh-toan",
                    "/thanh-toan/*",
                    "/*/thanh-toan/*"
                  ]}}
                ]
              },
              "eagerness": "moderate"
            }
          ]
        }
        </script>
        <?php
    }

    /**
     * Khởi chạy output buffer để lọc iframe
     */
    public function start_pagespeed_buffer() {
        if ( is_admin() ) {
            return;
        }
        // Tránh chạy trong các context đặc biệt
        if ( is_feed() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) || ( defined( 'XMLRPC_REQUEST' ) && XMLRPC_REQUEST ) ) {
            return;
        }
        // Kiểm tra builder context
        if ( class_exists( 'DAWP_Multilingual' ) && DAWP_Multilingual::is_builder_context() ) {
            return;
        }
        
        ob_start( [ $this, 'filter_pagespeed_html' ] );
    }

    /**
     * Callback xử lý HTML để tối ưu iframe & chèn JS hỗ trợ
     */
    public function filter_pagespeed_html( $html ) {
        if ( empty( $html ) ) {
            return $html;
        }

        $saved_options = get_option( 'dawp_settings', [] );
        $ps_lazy_iframe = ! isset( $saved_options['ps_lazy_iframe'] ) || ! empty( $saved_options['ps_lazy_iframe'] );
        $ps_video_facade = ! empty( $saved_options['ps_video_facade'] );

        if ( ( $ps_lazy_iframe || $ps_video_facade ) && stripos( $html, '<iframe' ) !== false ) {
            // Đếm số lượng iframe đã xử lý
            $iframe_count = 0;
            $has_facade = false;
            $has_lazy_iframe = false;

            // Callback thay thế iframe
            $html = preg_replace_callback( '/<iframe\b([^>]*)>(.*?)<\/iframe>/is', function( $matches ) use ( &$iframe_count, &$has_facade, &$has_lazy_iframe, $ps_lazy_iframe, $ps_video_facade ) {
                $iframe_html = $matches[0];
                $attrs_str = $matches[1];
                
                $iframe_count++;

                // Trích xuất src
                $src = '';
                if ( preg_match( '/\bsrc=["\']([^"\']+)["\']/i', $attrs_str, $src_match ) ) {
                    $src = $src_match[1];
                }

                // 1. Nếu bật Facade và là YouTube hoặc Google Maps
                if ( $ps_video_facade && ! empty( $src ) ) {
                    $is_youtube = false;
                    $is_maps = false;
                    $video_id = '';

                    if ( stripos( $src, 'youtube.com/embed/' ) !== false ) {
                        $is_youtube = true;
                        if ( preg_match( '/\/embed\/([a-zA-Z0-9_-]+)/i', $src, $vid_match ) ) {
                            $video_id = $vid_match[1];
                        }
                    } elseif ( stripos( $src, 'youtu.be/' ) !== false ) {
                        $is_youtube = true;
                        $path = parse_url( $src, PHP_URL_PATH );
                        $video_id = trim( $path, '/' );
                    } elseif ( stripos( $src, 'google.com/maps/embed' ) !== false || stripos( $src, 'google.com/maps/' ) !== false ) {
                        $is_maps = true;
                    }

                    if ( $is_youtube && ! empty( $video_id ) ) {
                        $has_facade = true;
                        $encoded_iframe = rawurlencode( $iframe_html );
                        
                        // Trích xuất style, class, width, height
                        $style = '';
                        if ( preg_match( '/\bstyle=["\']([^"\']+)["\']/i', $attrs_str, $s_match ) ) {
                            $style = $s_match[1];
                        }
                        $width = '100%';
                        if ( preg_match( '/\bwidth=["\']([^"\']+)["\']/i', $attrs_str, $w_match ) ) {
                            $width = $w_match[1];
                            if ( is_numeric( $width ) ) $width .= 'px';
                        }
                        $height = '';
                        if ( preg_match( '/\bheight=["\']([^"\']+)["\']/i', $attrs_str, $h_match ) ) {
                            $height = $h_match[1];
                            if ( is_numeric( $height ) ) $height .= 'px';
                        }

                        $wrapper_style = "position:relative; max-width:100%; display:inline-block; vertical-align:middle; cursor:pointer;";
                        if ( ! empty( $style ) ) {
                            $wrapper_style .= ' ' . $style;
                        } else {
                            $wrapper_style .= " width:{$width}; aspect-ratio:16/9;";
                            if ( ! empty( $height ) ) {
                                $wrapper_style .= " height:{$height};";
                            }
                        }

                        return '<div class="dawp-facade-youtube" data-iframe="' . esc_attr( $encoded_iframe ) . '" style="' . esc_attr( $wrapper_style ) . '">
                            <img src="https://img.youtube.com/vi/' . esc_attr( $video_id ) . '/hqdefault.jpg" style="width:100%; height:100%; object-fit:cover; display:block; border:none; opacity:0.85;" alt="Play YouTube Video" />
                            <div class="dawp-youtube-play" style="position:absolute; top:50%; left:50%; transform:translate(-50%, -50%); width:68px; height:48px; background:rgba(255,0,0,0.9); border-radius:12px; display:flex; align-items:center; justify-content:center; box-shadow:0 4px 10px rgba(0,0,0,0.3); transition:all 0.2s ease;">
                                <svg viewBox="0 0 24 24" style="width:30px; height:30px; fill:#fff;"><path d="M8 5v14l11-7z"/></svg>
                            </div>
                        </div>';
                    }

                    if ( $is_maps ) {
                        $has_facade = true;
                        $encoded_iframe = rawurlencode( $iframe_html );

                        $style = '';
                        if ( preg_match( '/\bstyle=["\']([^"\']+)["\']/i', $attrs_str, $s_match ) ) {
                            $style = $s_match[1];
                        }
                        $width = '100%';
                        if ( preg_match( '/\bwidth=["\']([^"\']+)["\']/i', $attrs_str, $w_match ) ) {
                            $width = $w_match[1];
                            if ( is_numeric( $width ) ) $width .= 'px';
                        }
                        $height = '450px';
                        if ( preg_match( '/\bheight=["\']([^"\']+)["\']/i', $attrs_str, $h_match ) ) {
                            $height = $h_match[1];
                            if ( is_numeric( $height ) ) $height .= 'px';
                        }

                        $wrapper_style = "position:relative; max-width:100%; display:flex; flex-direction:column; align-items:center; justify-content:center; background:#e5e3df; border:1px solid #ccc; cursor:pointer; font-family:-apple-system,BlinkMacSystemFont,sans-serif;";
                        if ( ! empty( $style ) ) {
                            $wrapper_style .= ' ' . $style;
                        } else {
                            $wrapper_style .= " width:{$width}; height:{$height};";
                        }

                        return '<div class="dawp-facade-maps" data-iframe="' . esc_attr( $encoded_iframe ) . '" style="' . esc_attr( $wrapper_style ) . '">
                            <div style="text-align:center; padding:20px; pointer-events:none;">
                                <span style="font-size:48px;">📍</span>
                                <div style="margin-top:10px; font-weight:bold; color:#333; font-size:16px;">Bấm để xem bản đồ</div>
                                <div style="margin-top:5px; color:#666; font-size:12px;">Google Maps</div>
                            </div>
                        </div>';
                    }
                }

                // 2. Nếu bật lazy-load iframe và không phải iframe đầu tiên
                if ( $ps_lazy_iframe ) {
                    if ( $iframe_count > 1 ) {
                        $has_lazy_iframe = true;
                        $attrs_str = preg_replace( '/\bsrc=["\']([^"\']+)["\']/i', 'src="about:blank" data-src="$1"', $attrs_str );
                        
                        if ( stripos( $attrs_str, 'loading=' ) === false ) {
                            $attrs_str .= ' loading="lazy"';
                        }
                        
                        if ( preg_match( '/\bclass=["\']([^"\']+)["\']/i', $attrs_str, $c_match ) ) {
                            $new_class = $c_match[1] . ' dawp-lazy-iframe';
                            $attrs_str = preg_replace( '/\bclass=["\']([^"\']+)["\']/i', 'class="' . esc_attr( $new_class ) . '"', $attrs_str );
                        } else {
                            $attrs_str .= ' class="dawp-lazy-iframe"';
                        }

                        return '<iframe' . $attrs_str . '>' . $matches[2] . '</iframe>';
                    } else {
                        if ( stripos( $attrs_str, 'loading=' ) === false ) {
                            $attrs_str .= ' loading="lazy"';
                            return '<iframe' . $attrs_str . '>' . $matches[2] . '</iframe>';
                        }
                    }
                }

                return $iframe_html;
            }, $html );

            // 3. Tiêm Script xử lý Facade & Lazy-load Iframe
            if ( $has_facade || $has_lazy_iframe ) {
                $js = "
<script>
document.addEventListener('DOMContentLoaded', function() {
    const clickHandler = function(e) {
        const placeholder = this;
        const encoded = placeholder.getAttribute('data-iframe');
        if (encoded) {
            let html = decodeURIComponent(encoded);
            if (placeholder.classList.contains('dawp-facade-youtube')) {
                html = html.replace(/src=\"([^\"]+)\"/i, function(m, url) {
                    const separator = url.indexOf('?') !== -1 ? '&' : '?';
                    return 'src=\"' + url + separator + 'autoplay=1\"';
                });
            }
            placeholder.outerHTML = html;
        }
    };

    document.querySelectorAll('.dawp-facade-youtube, .dawp-facade-maps').forEach(el => {
        el.addEventListener('click', clickHandler);
        if (el.classList.contains('dawp-facade-youtube')) {
            el.addEventListener('mouseenter', function() {
                const btn = this.querySelector('.dawp-youtube-play');
                if (btn) btn.style.transform = 'translate(-50%, -50%) scale(1.15)';
            });
            el.addEventListener('mouseleave', function() {
                const btn = this.querySelector('.dawp-youtube-play');
                if (btn) btn.style.transform = 'translate(-50%, -50%) scale(1)';
            });
        }
    });

    if ('IntersectionObserver' in window) {
        const iframeObserver = new IntersectionObserver(function(entries, observer) {
            entries.forEach(function(entry) {
                if (entry.isIntersecting) {
                    const iframe = entry.target;
                    const src = iframe.getAttribute('data-src');
                    if (src) {
                        iframe.setAttribute('src', src);
                        iframe.removeAttribute('data-src');
                    }
                    iframe.classList.remove('dawp-lazy-iframe');
                    observer.unobserve(iframe);
                }
            });
        }, {
            rootMargin: '300px 0px'
        });

        document.querySelectorAll('iframe.dawp-lazy-iframe').forEach(function(iframe) {
            iframeObserver.observe(iframe);
        });
    } else {
        document.querySelectorAll('iframe.dawp-lazy-iframe').forEach(function(iframe) {
            const src = iframe.getAttribute('data-src');
            if (src) {
                iframe.setAttribute('src', src);
                iframe.removeAttribute('data-src');
            }
        });
    }
});
</script>
";
                $pos = strripos( $html, '</body>' );
                if ( $pos !== false ) {
                    $html = substr_replace( $html, $js . '</body>', $pos, 7 );
                } else {
                    $html .= $js;
                }
            }
        }

        // 4. Tiêm Font Overrides (font-display: swap) cho các phông biểu tượng
        if ( ! empty( $saved_options['ps_icon_font_swap'] ) ) {
            $overrides = '';
            // Flatsome Icons
            if ( preg_match( '/href=["\']([^"\']+\/themes\/flatsome\/assets\/css\/)flatsome(?:-style)?\.css([^"\']*)["\']/i', $html, $matches ) ) {
                $flatsome_base = $matches[1];
                $overrides .= '@font-face { font-family: "fl-icons"; src: url("' . esc_url( $flatsome_base . 'icons/fl-icons.woff2' ) . '") format("woff2"), url("' . esc_url( $flatsome_base . 'icons/fl-icons.woff' ) . '") format("woff"); font-display: swap; }' . "\n";
            }
            // Font Awesome (CDN hoặc local)
            if ( preg_match( '/href=["\']([^"\']+\/(?:font-awesome|all|fontawesome)[^"\']+\/css\/)(?:all|fontawesome|font-awesome)(?:\.min)?\.css([^"\']*)["\']/i', $html, $matches ) ) {
                $fa_base = str_replace( '/css/', '/', $matches[1] );
                $overrides .= '@font-face { font-family: "Font Awesome 5 Free"; font-style: normal; font-weight: 900; src: url("' . esc_url( $fa_base . 'webfonts/fa-solid-900.woff2' ) . '") format("woff2"); font-display: swap; }' . "\n";
                $overrides .= '@font-face { font-family: "Font Awesome 5 Brands"; font-style: normal; font-weight: 400; src: url("' . esc_url( $fa_base . 'webfonts/fa-brands-400.woff2' ) . '") format("woff2"); font-display: swap; }' . "\n";
                $overrides .= '@font-face { font-family: "Font Awesome 6 Free"; font-style: normal; font-weight: 900; src: url("' . esc_url( $fa_base . 'webfonts/fa-solid-900.woff2' ) . '") format("woff2"); font-display: swap; }' . "\n";
                $overrides .= '@font-face { font-family: "Font Awesome 6 Brands"; font-style: normal; font-weight: 400; src: url("' . esc_url( $fa_base . 'webfonts/fa-brands-400.woff2' ) . '") format("woff2"); font-display: swap; }' . "\n";
            }

            if ( ! empty( $overrides ) ) {
                $css_tag = "\n" . '<style id="dawp-font-swap-override">' . $overrides . '</style>' . "\n";
                $pos = stripos( $html, '</head>' );
                if ( $pos !== false ) {
                    $html = substr_replace( $html, $css_tag . '</head>', $pos, 7 );
                } else {
                    $html .= $css_tag;
                }
            }
        }

        // 5. Tự động tiêm loading="lazy" cho tất cả các ảnh ngoài viewport đầu (generic, không hardcode)
        if ( ! empty( $saved_options['ps_lcp_opt'] ) ) {
            $logo_url = '';
            $custom_logo_id = get_theme_mod( 'custom_logo' );
            if ( $custom_logo_id ) {
                $logo_url = wp_get_attachment_image_url( $custom_logo_id, 'full' );
            }

            // Đếm số lượng ảnh để chừa n ảnh đầu (above fold).
            // Điện thoại: chỉ ảnh hero là chắc chắn trong màn hình đầu — ảnh 2, 3
            // nằm ngay dưới và TRANH BĂNG THÔNG 4G với ảnh LCP (đo được: lúc LCP
            // thắng 91 điểm, lúc thua 65). Native lazy trên Chrome mobile vẫn tải
            // trước khi cuộn tới ~1250px nên ảnh dưới hero không hề hiện muộn.
            $img_index = 0;
            $threshold = wp_is_mobile() ? 1 : 3;
            $threshold = (int) apply_filters( 'dawp_eager_image_count', $threshold );
            
            $html = preg_replace_callback( '/<img\b([^>]*)>/is', function( $matches ) use ( &$img_index, $threshold, $logo_url ) {
                $img_html = $matches[0];
                $attrs = $matches[1];
                
                // Kiểm tra và gỡ bỏ gạch chéo tự đóng ở cuối thuộc tính
                $has_slash = false;
                if ( substr( rtrim( $attrs ), -1 ) === '/' ) {
                    $attrs = rtrim( rtrim( $attrs ), '/' );
                    $has_slash = true;
                }
                
                // 1. Kiểm tra nếu là logo thì bỏ qua và đảm bảo có fetchpriority="high" + decoding="async" + không lazy
                $is_logo = false;
                if ( ! empty( $logo_url ) && strpos( $attrs, basename( $logo_url ) ) !== false ) {
                    $is_logo = true;
                }
                if ( strpos( $attrs, 'class=' ) !== false && ( strpos( $attrs, 'header-logo' ) !== false || strpos( $attrs, 'header_logo' ) !== false ) ) {
                    $is_logo = true;
                }
                
                if ( $is_logo ) {
                    // Thêm fetchpriority="high" và decoding="async"
                    $attrs = preg_replace( '/\s+loading=["\']lazy["\']/i', '', $attrs );
                    if ( strpos( $attrs, 'fetchpriority=' ) === false ) {
                        $attrs .= ' fetchpriority="high"';
                    }
                    if ( strpos( $attrs, 'decoding=' ) === false ) {
                        $attrs .= ' decoding="async"';
                    }
                    return '<img' . $attrs . ( $has_slash ? ' /' : '' ) . '>';
                }
                
                // 2. Kiểm tra nếu là ảnh trong slider hoặc đã bị tắt lazy
                if ( strpos( $attrs, 'data-no-lazy' ) !== false || strpos( $attrs, 'loading="eager"' ) !== false || strpos( $attrs, 'loading=\'eager\'' ) !== false ) {
                    return $img_html;
                }
                
                // 3. Đếm số lượng ảnh hợp lệ (loại trừ ảnh base64 hoặc quá nhỏ)
                if ( strpos( $attrs, 'data:image/' ) !== false ) {
                    return $img_html; // Bỏ qua ảnh base64
                }
                
                $img_index++;
                
                // 4. Nếu vượt quá threshold, tự động tiêm loading="lazy" nếu chưa có
                if ( $img_index > $threshold ) {
                    if ( strpos( $attrs, 'loading=' ) === false ) {
                        $attrs .= ' loading="lazy"';
                    }
                } else {
                    // Tránh lazy load cho các ảnh đầu trên màn
                    $attrs = preg_replace( '/\s+loading=["\']lazy["\']/i', '', $attrs );
                }
                
                return '<img' . $attrs . ( $has_slash ? ' /' : '' ) . '>';
            }, $html );
        }

        // Ảnh thiếu srcset (ảnh nền hero của page builder): bổ sung srcset/sizes để
        // điện thoại tải bản thu nhỏ thay vì ảnh gốc 4000px — thủ phạm LCP phổ biến nhất
        if ( ! isset( $saved_options['ps_img_srcset'] ) || ! empty( $saved_options['ps_img_srcset'] ) ) {
            $html = $this->add_missing_srcset( $html );
        }

        // Hoãn JS theo dõi tới khi người dùng tương tác (giảm TBT thật sự)
        if ( ! empty( $saved_options['ps_delay_js'] ) ) {
            $html = $this->process_delay_scripts( $html, $saved_options );
        }

        // Trì hoãn script chặn render (kể cả jQuery), bọc inline script phụ thuộc jQuery
        if ( ! empty( $saved_options['ps_defer_scripts'] ) ) {
            $html = $this->process_defer_scripts( $html, $saved_options );
        }

        // Gọn CSS + Critical CSS (chỉ can thiệp khi đã có kết quả phân tích ngầm)
        $html = DAWP_CSS_Slim::maybe_apply( $html );

        // Bỏ qua dựng hình phần dưới màn hình đầu (content-visibility) — cắt thẳng
        // chi phí Style/Layout/Paint trên CPU điện thoại chậm.
        if ( ! isset( $saved_options['ps_content_visibility'] ) || ! empty( $saved_options['ps_content_visibility'] ) ) {
            $html = $this->apply_content_visibility( $html );
        }

        // Tự preload ảnh LCP: cho trình duyệt tải ảnh màn hình đầu SONG SONG với
        // CSS ngay từ byte đầu tiên, thay vì đợi CSS xong → dựng DOM → mới thấy ảnh.
        // Trên 4G chậm đây là 1-3 giây LCP.
        if ( ! isset( $saved_options['ps_lcp_opt'] ) || ! empty( $saved_options['ps_lcp_opt'] ) ) {
            $html = $this->auto_preload_lcp_image( $html );
        }

        // Dấu vết chẩn đoán từ xa: bản plugin + công tắc nào đang bật + Slim CSS
        // đã áp dụng chưa. Chỉ là chú thích HTML, không ảnh hưởng hiển thị hay điểm.
        $flags = [];
        foreach ( [ 'ps_defer_scripts' => 'defer', 'ps_slim_css' => 'slim', 'ps_delay_js' => 'delay', 'ps_img_srcset' => 'srcset' ] as $k => $label ) {
            $on = isset( $saved_options[ $k ] ) ? ! empty( $saved_options[ $k ] ) : ( 'ps_img_srcset' === $k );
            $flags[] = $label . ( $on ? '+' : '-' );
        }
        $flags[] = 'slim-applied:' . ( false !== strpos( $html, 'id="dawp-slim-css"' ) ? 'yes' : 'no' . ( DAWP_CSS_Slim::$last_reason ? '(' . DAWP_CSS_Slim::$last_reason . ')' : '' ) );
        $marker  = "\n<!-- DAWP " . DAWP_VERSION . ' ' . implode( ' ', $flags ) . " -->\n";
        $body_pos = strripos( $html, '</body>' );
        $html = ( false !== $body_pos ) ? substr_replace( $html, $marker, $body_pos, 0 ) : $html . $marker;

        return $html;
    }

    /**
     * content-visibility: auto cho các section DƯỚI màn hình đầu.
     *
     * Trình duyệt bỏ qua style/layout/paint của các section đó cho tới khi cuộn
     * tới gần — trên Moto G giả lập, "Style & Layout 1s + Rendering 0,8s" của
     * trang 1.200 phần tử phần lớn nằm ở đây. Nội dung vẫn có trong DOM (SEO,
     * tìm kiếm trong trang, đọc màn hình đều nguyên). Chỉ nhận diện section cấp
     * trang của Flatsome (section.section) và Bricks (section.brxe-section);
     * bỏ qua 2 section đầu (hero + section kế) để LCP/FCP không bị đụng.
     * contain-intrinsic-size giữ chỗ chiều cao ước lượng để thanh cuộn không nhảy.
     */
    private function apply_content_visibility( $html ) {
        if ( false === stripos( $html, '<section' ) ) {
            return $html;
        }
        $skip = 2;
        $index = 0;
        $done = 0;
        $html = preg_replace_callback( '/<section\b([^>]*)>/i', function ( $m ) use ( &$index, &$done, $skip ) {
            $attrs = $m[1];
            // Chỉ section cấp trang của 2 theme
            if ( ! preg_match( '/\bclass=["\'][^"\']*\b(section|brxe-section)\b/i', $attrs ) ) {
                return $m[0];
            }
            $index++;
            if ( $index <= $skip ) {
                return $m[0];
            }
            // Đã có content-visibility (theme/plugin khác) → không chồng
            if ( false !== stripos( $attrs, 'content-visibility' ) ) {
                return $m[0];
            }
            $done++;
            $cv = 'content-visibility:auto;contain-intrinsic-size:auto 800px;';
            if ( preg_match( '/\bstyle=(["\'])(.*?)\1/i', $attrs, $sm ) ) {
                $new_style = rtrim( $sm[2], '; ' ) . ( '' !== trim( $sm[2] ) ? ';' : '' ) . $cv;
                $attrs = str_replace( $sm[0], 'style=' . $sm[1] . $new_style . $sm[1], $attrs );
            } else {
                $attrs .= ' style="' . $cv . '"';
            }
            return '<section' . $attrs . '>';
        }, $html );
        return $html;
    }

    /**
     * Tự phát hiện ảnh LCP và in <link rel="preload"> lên đầu <head>.
     *
     * Ứng viên (theo thứ tự ưu tiên): ảnh có fetchpriority="high" không phải
     * logo → ảnh nền hero (class chứa "bg" / "section-bg" / "hero" / "banner")
     * → ảnh có kích thước lớn đầu tiên trong <body>. Bỏ qua ảnh lazy, svg,
     * data-URI, logo (logo đã được preload riêng và thường nhỏ).
     * Mang theo imagesrcset/imagesizes để trình duyệt preload ĐÚNG bản cỡ
     * màn hình chứ không phải ảnh gốc.
     */
    private function auto_preload_lcp_image( $html ) {
        if ( false !== strpos( $html, 'data-dawp-lcp-preload' ) ) {
            return $html;
        }
        // Đã có preload ảnh do người dùng cấu hình tay (ps_preload_lcp_*) → không
        // chồng thêm, tránh tải hai ảnh lớn cùng lúc
        $saved = get_option( 'dawp_settings', [] );
        if ( ( wp_is_mobile() && ! empty( $saved['ps_preload_lcp_mobile'] ) ) || ( ! wp_is_mobile() && ! empty( $saved['ps_preload_lcp_desktop'] ) ) ) {
            return $html;
        }
        $body_pos = stripos( $html, '<body' );
        if ( false === $body_pos ) {
            return $html;
        }
        // Chỉ soi 60KB đầu của body — LCP không nằm ở cuối trang
        $top = substr( $html, $body_pos, 61440 );
        if ( ! preg_match_all( '/<img\b([^>]*)>/i', $top, $imgs ) ) {
            return $html;
        }

        $logo_url = '';
        $custom_logo_id = get_theme_mod( 'custom_logo' );
        if ( $custom_logo_id ) {
            $logo_url = (string) wp_get_attachment_image_url( $custom_logo_id, 'full' );
        }

        $best = null;
        $best_score = -1;
        foreach ( $imgs[1] as $attrs ) {
            if ( ! preg_match( '/\bsrc=["\']([^"\']+)["\']/i', $attrs, $sm ) ) {
                continue;
            }
            $src = html_entity_decode( $sm[1] );
            // Lazy kiểu placeholder (Bricks, Elementor, WP Rocket...): src là
            // data:image/svg giữ chỗ, ảnh thật nằm ở data-src / data-lazy-src
            if ( 0 === strpos( $src, 'data:' ) && preg_match( '/\bdata-(?:lazy-)?src=["\']([^"\']+)["\']/i', $attrs, $dm ) ) {
                $src = html_entity_decode( $dm[1] );
            }
            if ( false !== strpos( $src, 'data:' ) || preg_match( '/\.svg(\?|$)/i', $src ) ) {
                continue;
            }
            if ( preg_match( '/\bloading=["\']?lazy/i', $attrs ) ) {
                continue;
            }
            if ( '' !== $logo_url && false !== strpos( $src, basename( $logo_url ) ) ) {
                continue;
            }
            if ( preg_match( '/\bclass=["\'][^"\']*\b(logo|icon|avatar|emoji)\b/i', $attrs ) ) {
                continue;
            }
            $score = 0;
            if ( preg_match( '/\bfetchpriority=["\']?high/i', $attrs ) ) {
                $score += 100;
            }
            if ( preg_match( '/\bclass=["\'][^"\']*\b(bg|section-bg|hero|banner|slide|cover|featured|wp-post-image)\b/i', $attrs ) ) {
                $score += 50;
            }
            if ( preg_match( '/\bwidth=["\']?(\d+)/i', $attrs, $wm ) ) {
                $w = (int) $wm[1];
                if ( $w >= 600 ) { $score += 20; }
                if ( $w < 200 ) { $score -= 50; }
            }
            if ( $score > $best_score ) {
                $best_score = $score;
                $best = [ 'src' => $src, 'attrs' => $attrs ];
            }
            // Ảnh fetchpriority=high đầu tiên gần như chắc chắn là LCP → dừng
            if ( $score >= 100 ) {
                break;
            }
        }
        if ( ! $best || $best_score < 20 ) {
            return $html;
        }

        // Chỉ ảnh LCP (và logo) được giữ fetchpriority="high". Mọi ảnh khác mang
        // "high" (theme/slider đặt) bị hạ về "auto": trên PageSpeed đo được 10 ảnh
        // slider cùng "high" tranh băng thông với LCP làm LCP 14 giây dù ảnh LCP
        // chỉ 7KB. Trình duyệt tự xếp ưu tiên theo vị trí trong màn hình là đủ.
        $lcp_src   = $best['src'];
        $logo_name = '' !== $logo_url ? basename( $logo_url ) : '';
        $demoted   = 0;
        $html = preg_replace_callback( '/<img\b([^>]*)\bfetchpriority=["\']high["\']([^>]*)>/i', function ( $mm ) use ( $lcp_src, $logo_name, &$demoted ) {
            $all = $mm[1] . $mm[2];
            if ( false !== strpos( $all, $lcp_src ) ) {
                return $mm[0];
            }
            if ( '' !== $logo_name && false !== strpos( $all, $logo_name ) ) {
                return $mm[0];
            }
            if ( preg_match( '/\bclass=["\'][^"\']*\blogo\b/i', $all ) ) {
                return $mm[0];
            }
            $demoted++;
            return '<img' . $mm[1] . $mm[2] . '>';
        }, $html );

        $tag = '<link rel="preload" as="image" data-dawp-lcp-preload="1" href="' . esc_url( $best['src'] ) . '"';
        // srcset có thể là data-srcset (lazy placeholder). Bỏ qua nếu là data: giữ chỗ.
        if ( preg_match( '/\b(?:data-(?:lazy-)?)?srcset=["\']([^"\']+)["\']/i', $best['attrs'], $ss ) && 0 !== strpos( $ss[1], 'data:' ) ) {
            $tag .= ' imagesrcset="' . esc_attr( html_entity_decode( $ss[1] ) ) . '"';
            $sizes = preg_match( '/\bsizes=["\']([^"\']+)["\']/i', $best['attrs'], $sz ) ? $sz[1] : '100vw';
            $tag .= ' imagesizes="' . esc_attr( $sizes ) . '"';
        }
        $tag .= ' fetchpriority="high">';

        // Đặt càng sớm càng tốt: ngay sau <head ...> hoặc sau <meta charset>
        $head_pos = stripos( $html, '<head' );
        if ( false === $head_pos ) {
            return $html;
        }
        $head_end = strpos( $html, '>', $head_pos );
        if ( false === $head_end ) {
            return $html;
        }
        $insert_at = $head_end + 1;
        if ( preg_match( '/<meta\s+charset=[^>]*>/i', $html, $cm, PREG_OFFSET_CAPTURE, $insert_at ) && $cm[0][1] < $insert_at + 2048 ) {
            $insert_at = $cm[0][1] + strlen( $cm[0][0] );
        }
        return substr_replace( $html, "\n" . $tag . "\n", $insert_at, 0 );
    }

    /**
     * Bổ sung srcset/sizes cho ảnh nội bộ đang thiếu.
     *
     * Page builder (Flatsome "bg", Elementor background, Bricks...) hay in ảnh
     * nền bằng <img src="anh-goc.webp"> KHÔNG có srcset — điện thoại 400px
     * buộc phải tải và giải mã ảnh gốc 4000px, gây LCP hàng chục giây dù tệp
     * WebP nhỏ. Hàm này tra ngược tệp trong thư viện, ghép srcset chuẩn từ
     * các bản thu nhỏ WordPress đã tạo sẵn để trình duyệt tự chọn cỡ hợp lý.
     * Chỉ thêm thuộc tính, không đổi src — trình duyệt cũ vẫn dùng ảnh gốc.
     */
    private function add_missing_srcset( $html ) {
        if ( false === stripos( $html, '<img' ) ) {
            return $html;
        }

        $upload = wp_upload_dir();
        if ( empty( $upload['baseurl'] ) || empty( $upload['basedir'] ) ) {
            return $html;
        }
        $base_url = $upload['baseurl'];
        // Chấp nhận cả http/https và URL không giao thức
        $base_url_re = preg_quote( preg_replace( '#^https?:#i', '', $base_url ), '#' );
        $base_dir    = wp_normalize_path( $upload['basedir'] );

        // Cache theo lượt yêu cầu để cùng một ảnh lặp lại không tra lại nhiều lần
        static $cache = [];
        $touched = 0;

        $html = preg_replace_callback( '/<img\b([^>]*)>/i', function ( $m ) use ( $base_url_re, $base_dir, $base_url, &$cache, &$touched ) {
            $attrs = $m[1];
            if ( false !== stripos( $attrs, 'srcset=' ) ) {
                return $m[0];
            }
            // Ảnh do plugin/tùy chọn yêu cầu giữ nguyên
            if ( false !== stripos( $attrs, 'data-no-srcset' ) || false !== stripos( $attrs, 'data-dawp-skip' ) ) {
                return $m[0];
            }
            if ( ! preg_match( '/\bsrc=["\']([^"\']+)["\']/i', $attrs, $src_m ) ) {
                return $m[0];
            }
            $src = html_entity_decode( $src_m[1] );
            if ( false !== strpos( $src, 'data:' ) || false !== strpos( $src, '.svg' ) || false !== strpos( $src, '.gif' ) ) {
                return $m[0];
            }
            // Chỉ ảnh trong thư viện của chính site
            if ( ! preg_match( '#^(?:https?:)?' . $base_url_re . '/(.+)$#i', $src, $rel_m ) ) {
                return $m[0];
            }
            $rel = strtok( $rel_m[1], '?#' );
            if ( ! preg_match( '#^(.*?)(?:-\d+x\d+)?(\.[a-zA-Z0-9]+)$#', $rel, $parts ) ) {
                return $m[0];
            }
            $stem = $parts[1];
            $ext  = $parts[2];
            $key  = $stem . $ext;

            if ( ! isset( $cache[ $key ] ) ) {
                // Đọc đĩa (glob + getimagesize) tốn ~7ms/ảnh nên nhớ kết quả 1 ngày.
                // Khóa gắn với mtime ảnh gốc: thay ảnh là tự tính lại.
                $orig_path = $base_dir . '/' . $stem . $ext;
                $mtime     = @filemtime( $orig_path );
                $tkey      = 'dawp_srcset_' . md5( $key . '|' . $mtime );
                $stored    = $mtime ? get_transient( $tkey ) : false;
                if ( false === $stored || ! is_array( $stored ) ) {
                    $stored = $this->build_srcset_from_disk( $base_dir, $base_url, $stem, $ext );
                    if ( $mtime ) {
                        set_transient( $tkey, $stored, DAY_IN_SECONDS );
                    }
                }
                $cache[ $key ] = $stored;
            }
            $info = $cache[ $key ];
            if ( empty( $info ) ) {
                return $m[0];
            }
            $touched++;

            // sizes: mặc định "chiếm hết bề rộng màn hình" — đúng cho ảnh nền hero.
            // Nếu thẻ có width nhỏ hơn thì dùng width đó làm trần.
            $sizes = '100vw';
            if ( preg_match( '/\bwidth=["\']?(\d+)/i', $attrs, $w_m ) ) {
                $w = (int) $w_m[1];
                if ( $w > 0 && $w < 1200 ) {
                    $sizes = '(max-width: ' . $w . 'px) 100vw, ' . $w . 'px';
                }
            }
            // Giữ đúng kiểu đóng thẻ (<img ... /> hay <img ...>)
            $self_close = ( substr( rtrim( $attrs ), -1 ) === '/' );
            if ( $self_close ) {
                $attrs = rtrim( substr( rtrim( $attrs ), 0, -1 ) );
            }
            return '<img' . $attrs . ' srcset="' . esc_attr( $info['srcset'] ) . '" sizes="' . esc_attr( $sizes ) . '"' . ( $self_close ? ' />' : '>' );
        }, $html );

        return $html;
    }

    /**
     * Ghép srcset từ các bản thu nhỏ có thật trên đĩa (theo quy ước ten-WxH.ext
     * của WordPress) + ảnh gốc. Trả về mảng ['srcset' => '...'] hoặc [] nếu ảnh
     * gốc không có bản thu nhỏ nào (thì thêm srcset cũng vô ích).
     */
    private function build_srcset_from_disk( $base_dir, $base_url, $stem, $ext ) {
        $orig_path = $base_dir . '/' . $stem . $ext;
        if ( ! is_readable( $orig_path ) ) {
            return [];
        }
        $dir  = dirname( $orig_path );
        $name = basename( $stem );
        $glob = glob( $dir . '/' . $name . '-[0-9]*x[0-9]*' . $ext );
        if ( empty( $glob ) ) {
            return [];
        }

        $candidates = [];
        foreach ( $glob as $file ) {
            if ( preg_match( '/-(\d+)x(\d+)' . preg_quote( $ext, '/' ) . '$/', $file, $wm ) ) {
                $w = (int) $wm[1];
                // Bỏ các bản crop vuông/thumbnail nhỏ hơn 300px — không dùng cho hero
                if ( $w < 300 ) {
                    continue;
                }
                $candidates[ $w ] = $base_url . '/' . dirname( $stem ) . '/' . basename( $file );
            }
        }
        if ( empty( $candidates ) ) {
            return [];
        }

        // Ảnh gốc: chỉ đưa vào nếu đọc được kích thước, và cắt trần ở 2560px —
        // không màn hình phổ thông nào cần hơn, và đó chính là thứ giết LCP.
        $size = @getimagesize( $orig_path );
        if ( $size && ! empty( $size[0] ) && (int) $size[0] <= 2560 ) {
            $candidates[ (int) $size[0] ] = $base_url . '/' . $stem . $ext;
        }

        ksort( $candidates );
        $out = [];
        foreach ( $candidates as $w => $url ) {
            $out[] = str_replace( '/./', '/', $url ) . ' ' . $w . 'w';
        }
        return [ 'srcset' => implode( ', ', $out ) ];
    }

    /**
     * Quét thư viện tìm ảnh có bề rộng vượt ngưỡng (mặc định 2560px).
     * Ảnh 4000px làm nền hero khiến điện thoại giải mã hàng chục triệu điểm
     * ảnh — LCP 10-15 giây dù WebP nhẹ. Không màn hình phổ thông nào cần quá 2560px.
     */
    public function ajax_scan_big_images() {
        check_ajax_referer( 'dawp_big_images', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( 'Không đủ quyền.' );
        }
        $limit = 2560;
        $rows  = get_posts( [
            'post_type'      => 'attachment',
            'post_mime_type' => [ 'image/jpeg', 'image/png', 'image/webp' ],
            'post_status'    => 'inherit',
            'posts_per_page' => 500,
            'orderby'        => 'date',
            'order'          => 'DESC',
            'fields'         => 'ids',
        ] );
        $found = [];
        foreach ( $rows as $id ) {
            $meta = wp_get_attachment_metadata( $id );
            if ( empty( $meta['width'] ) || empty( $meta['height'] ) ) {
                continue;
            }
            // Chỉ xét BỀ RỘNG: ảnh chụp toàn trang (1920 x 10000) là hợp lệ,
            // thứ giết LCP là bề rộng 4000px trên màn hình 400px.
            if ( (int) $meta['width'] <= $limit ) {
                continue;
            }
            $file = get_attached_file( $id );
            $found[] = [
                'id'     => (int) $id,
                'ten'    => basename( (string) $file ),
                'w'      => (int) $meta['width'],
                'h'      => (int) $meta['height'],
                'kb'     => ( $file && file_exists( $file ) ) ? round( filesize( $file ) / 1024 ) : 0,
                'link'   => get_edit_post_link( $id, 'raw' ),
                'thumb'  => wp_get_attachment_image_url( $id, 'thumbnail' ),
            ];
        }
        wp_send_json_success( [ 'items' => $found, 'scanned' => count( $rows ), 'limit' => $limit ] );
    }

    /**
     * Thu nhỏ ảnh gốc về bề rộng tối đa 1920px, ghi đè tại chỗ rồi sinh lại
     * các bản thu nhỏ. Không thể hoàn tác — người dùng đã được cảnh báo trong UI.
     */
    public function ajax_shrink_image() {
        check_ajax_referer( 'dawp_big_images', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( 'Không đủ quyền.' );
        }
        $id   = isset( $_POST['id'] ) ? (int) $_POST['id'] : 0;
        $file = $id ? get_attached_file( $id ) : '';
        if ( ! $id || ! $file || ! file_exists( $file ) ) {
            wp_send_json_error( 'Không tìm thấy tệp ảnh.' );
        }
        $max    = 1920;
        $editor = wp_get_image_editor( $file );
        if ( is_wp_error( $editor ) ) {
            wp_send_json_error( 'Máy chủ không có thư viện xử lý ảnh (GD/Imagick): ' . $editor->get_error_message() );
        }
        $size = $editor->get_size();
        if ( empty( $size['width'] ) || $size['width'] <= $max ) {
            wp_send_json_error( 'Ảnh này đã nằm trong ngưỡng, không cần thu nhỏ.' );
        }
        // Thu theo BỀ RỘNG, chiều cao tự theo tỷ lệ (ảnh dài vẫn giữ nguyên độ dài tương ứng)
        $editor->resize( $max, null, false );
        $editor->set_quality( 85 );
        $saved = $editor->save( $file );
        if ( is_wp_error( $saved ) ) {
            wp_send_json_error( 'Không ghi được tệp: ' . $saved->get_error_message() );
        }
        // Sinh lại toàn bộ bản thu nhỏ theo kích thước mới
        require_once ABSPATH . 'wp-admin/includes/image.php';
        $meta = wp_generate_attachment_metadata( $id, $file );
        if ( ! is_wp_error( $meta ) && ! empty( $meta ) ) {
            wp_update_attachment_metadata( $id, $meta );
        }
        // Xóa cache srcset đã nhớ cho ảnh này (khóa gắn mtime nên tự lệch, nhưng dọn cho sạch)
        wp_send_json_success( [
            'id' => $id,
            'w'  => isset( $meta['width'] ) ? (int) $meta['width'] : 0,
            'h'  => isset( $meta['height'] ) ? (int) $meta['height'] : 0,
            'kb' => round( filesize( $file ) / 1024 ),
        ] );
    }

    /**
     * Hoãn JS theo dõi/quảng cáo tới khi người dùng tương tác.
     *
     * TỐI ƯU THẬT, KHÔNG GIAN LẬN: script vẫn chạy cho MỌI người dùng thật —
     * ngay khi họ chạm/cuộn/di chuột, hoặc muộn nhất sau số giây cấu hình.
     * Danh sách mặc định chỉ gồm các script VÔ HÌNH (đo lường, remarketing),
     * không đụng tới script vẽ giao diện để trang nhìn thấy gì vẫn y nguyên.
     */
    private function process_delay_scripts( $html, $options ) {
        if ( false === stripos( $html, '<script' ) ) {
            return $html;
        }

        // Các dấu hiệu nhận diện script đo lường/quảng cáo phổ biến
        $patterns = [
            'googletagmanager.com',
            'google-analytics.com',
            'gtag/js',
            'gtag(',
            'ga(\'create',
            'fbevents.js',
            'connect.facebook.net',
            'fbq(',
            'analytics.tiktok.com',
            'ttq.load',
            'ttq.page',
            'static.hotjar.com',
            'hj(',
            'clarity.ms',
            'clarity(',
        ];
        if ( ! empty( $options['ps_delay_js_custom'] ) ) {
            foreach ( preg_split( '/[\r\n]+/', (string) $options['ps_delay_js_custom'] ) as $line ) {
                $line = trim( $line );
                if ( '' !== $line ) {
                    $patterns[] = $line;
                }
            }
        }

        $excludes = [];
        if ( ! empty( $options['ps_delay_js_exclude'] ) ) {
            foreach ( preg_split( '/[\r\n]+/', (string) $options['ps_delay_js_exclude'] ) as $line ) {
                $line = trim( $line );
                if ( '' !== $line ) {
                    $excludes[] = $line;
                }
            }
        }

        $delayed = 0;

        $html = preg_replace_callback( '/<script\b([^>]*)>(.*?)<\/script>/is', function( $m ) use ( $patterns, $excludes, &$delayed ) {
            $attrs = $m[1];
            $body  = $m[2];

            // Script do chính plugin chèn hoặc đã xử lý rồi: bỏ qua
            if ( false !== stripos( $attrs, 'data-dawp-keep' ) || false !== stripos( $attrs, 'dawp/delay' ) ) {
                return $m[0];
            }
            // Chỉ xử lý JavaScript thường (bỏ qua module, template, application/ld+json...)
            if ( preg_match( '/\btype=["\']?([^"\'\s>]+)/i', $attrs, $type_m ) ) {
                $type = strtolower( $type_m[1] );
                if ( ! in_array( $type, [ 'text/javascript', 'application/javascript' ], true ) ) {
                    return $m[0];
                }
            }

            $src = '';
            if ( preg_match( '/\bsrc=["\']([^"\']+)["\']/i', $attrs, $src_m ) ) {
                $src = $src_m[1];
            }
            $subject = ( '' !== $src ) ? $src : $body;

            foreach ( $excludes as $pattern ) {
                if ( false !== stripos( $m[0], $pattern ) ) {
                    return $m[0];
                }
            }

            $match = false;
            foreach ( $patterns as $pattern ) {
                if ( false !== stripos( $subject, $pattern ) ) {
                    $match = true;
                    break;
                }
            }
            if ( ! $match ) {
                return $m[0];
            }

            $delayed++;
            if ( '' !== $src ) {
                // Đổi src thành data-dawp-src để trình duyệt không tải ngay
                $attrs = preg_replace( '/\bsrc=(["\'])' . preg_quote( $src, '/' ) . '\1/i', 'data-dawp-src=$1' . $src . '$1', $attrs );
            }
            // Gỡ type cũ (nếu có) rồi gắn type giữ chỗ
            $attrs = preg_replace( '/\btype=["\']?[^"\'\s>]+["\']?/i', '', $attrs );
            return '<script type="dawp/delay"' . $attrs . '>' . $body . '</script>';
        }, $html );

        if ( $delayed < 1 ) {
            return $html;
        }

        // Bộ nạp lại: chạy khi người dùng tương tác, hoặc muộn nhất sau N giây
        // (0 = chỉ chờ tương tác). Nạp tuần tự để giữ đúng thứ tự script.
        $timeout = isset( $options['ps_delay_js_timeout'] ) ? (int) $options['ps_delay_js_timeout'] : 10;
        $timeout = max( 0, min( 60, $timeout ) );

        $loader = '<script id="dawp-delay-js-loader" data-dawp-keep="1">'
            . '(function(){var d=document,done=false;'
            . 'function go(){if(done)return;done=true;'
            . 'var list=d.querySelectorAll(\'script[type="dawp/delay"]\'),i=0;'
            . 'function next(){if(i>=list.length){d.dispatchEvent(new CustomEvent("dawp:delayed-loaded"));return;}'
            . 'var o=list[i++],s=d.createElement("script"),a,k;'
            . 'for(k=0;k<o.attributes.length;k++){a=o.attributes[k];'
            . 'if(a.name==="type"||a.name==="data-dawp-src")continue;s.setAttribute(a.name,a.value);}'
            . 'if(o.getAttribute("data-dawp-src")){s.src=o.getAttribute("data-dawp-src");'
            . 's.onload=s.onerror=next;o.parentNode.replaceChild(s,o);}'
            . 'else{s.text=o.text;o.parentNode.replaceChild(s,o);next();}}'
            . 'next();}'
            . 'var e=["pointerdown","keydown","touchstart","wheel","mouseover"];'
            . 'function h(){e.forEach(function(x){window.removeEventListener(x,h,{passive:true});});go();}'
            . 'e.forEach(function(x){window.addEventListener(x,h,{passive:true});});'
            . ( $timeout > 0 ? 'setTimeout(go,' . ( $timeout * 1000 ) . ');' : '' )
            . '})();</script>';

        $body_pos = strripos( $html, '</body>' );
        if ( false !== $body_pos ) {
            $html = substr_replace( $html, $loader, $body_pos, 0 );
        } else {
            $html .= $loader;
        }

        return $html;
    }

    /**
     * Thêm kích thước (width/height) bị thiếu cho các thẻ img trong content
     */
    public function add_missing_image_dimensions( $content ) {
        if ( empty( $content ) ) {
            return $content;
        }

        return preg_replace_callback( '/<img\b([^>]*)>/is', function( $matches ) {
            $img_html = $matches[0];
            $attrs_str = $matches[1];

            // Nếu đã có cả width và height thì bỏ qua
            if ( preg_match( '/\bwidth=["\']/i', $attrs_str ) && preg_match( '/\bheight=["\']/i', $attrs_str ) ) {
                return $img_html;
            }

            // Trích xuất src
            $src = '';
            if ( preg_match( '/\bsrc=["\']([^"\']+)["\']/i', $attrs_str, $src_match ) ) {
                $src = $src_match[1];
            }

            if ( empty( $src ) ) {
                return $img_html;
            }

            $width = 0;
            $height = 0;

            // Thử phân tích từ tên file (vd: image-300x200.jpg)
            if ( preg_match( '/-([0-9]+)x([0-9]+)\.(?:jpg|jpeg|png|gif|webp|avif)/i', $src, $dim_match ) ) {
                $width = intval( $dim_match[1] );
                $height = intval( $dim_match[2] );
            }

            // Nếu không tìm thấy và là ảnh local, thử getimagesize
            if ( ( ! $width || ! $height ) && strpos( $src, content_url() ) !== false ) {
                $rel_path = str_replace( content_url(), '', $src );
                $file_path = WP_CONTENT_DIR . '/' . ltrim( $rel_path, '/' );
                $file_path = explode( '?', $file_path )[0];

                if ( file_exists( $file_path ) ) {
                    $imagesize = @getimagesize( $file_path );
                    if ( $imagesize ) {
                        $width = $imagesize[0];
                        $height = $imagesize[1];
                    }
                }
            }

            if ( $width && $height ) {
                if ( ! preg_match( '/\bwidth=["\']/i', $attrs_str ) ) {
                    $attrs_str .= ' width="' . intval( $width ) . '"';
                }
                if ( ! preg_match( '/\bheight=["\']/i', $attrs_str ) ) {
                    $attrs_str .= ' height="' . intval( $height ) . '"';
                }
                return '<img' . $attrs_str . '>';
            }

            return $img_html;
        }, $content );
    }

    /**
     * Trì hoãn script chặn render — TỐI ƯU THẬT cho mobile.
     *
     * Trên điện thoại (CPU chậm 4x so với PC) 10-15 script trong <head> không
     * defer là nguyên nhân số 1 khiến mobile 60 điểm trong khi PC 95+. Cách xử lý:
     * - Mọi <script src> thường → thêm defer (giữ nguyên thứ tự thực thi).
     * - jQuery cũng defer. Để không vỡ, mọi inline script có dùng jQuery/$ được
     *   bọc lại: chờ DOMContentLoaded (lúc đó script defer đã chạy xong) rồi mới
     *   chạy — kết quả y hệt trước, chỉ muộn vài trăm ms.
     * - Không đụng: script đã async/defer, type không phải JS, script bị hoãn
     *   bởi Delay JS, script trong danh sách loại trừ.
     */
    private function process_defer_scripts( $html, $options ) {
        if ( false === stripos( $html, '<script' ) ) {
            return $html;
        }

        $excludes = [];
        if ( ! empty( $options['ps_defer_exclude'] ) ) {
            foreach ( preg_split( '/[\r\n]+/', (string) $options['ps_defer_exclude'] ) as $line ) {
                $line = trim( $line );
                if ( '' !== $line ) {
                    $excludes[] = $line;
                }
            }
        }
        $excludes = apply_filters( 'dawp_defer_exclude_patterns', $excludes );

        $deferred = 0;
        $wrapped  = 0;
        $has_jquery_src = false;

        $html = preg_replace_callback( '/<script\b([^>]*)>(.*?)<\/script>/is', function ( $m ) use ( $excludes, &$deferred, &$wrapped, &$has_jquery_src ) {
            $attrs = $m[1];
            $body  = $m[2];

            if ( false !== stripos( $attrs, 'data-dawp-keep' ) ) {
                return $m[0];
            }
            // Bỏ qua type không phải JS (ld+json, template, module, dawp/delay...)
            if ( preg_match( '/\btype=["\']?([^"\'\s>]+)/i', $attrs, $type_m ) ) {
                $type = strtolower( $type_m[1] );
                if ( ! in_array( $type, [ 'text/javascript', 'application/javascript' ], true ) ) {
                    return $m[0];
                }
            }
            foreach ( $excludes as $pattern ) {
                if ( false !== stripos( $m[0], $pattern ) ) {
                    return $m[0];
                }
            }

            $has_src = (bool) preg_match( '/\bsrc=["\']([^"\']+)["\']/i', $attrs, $src_m );

            if ( $has_src ) {
                if ( false !== stripos( $src_m[1], '/jquery' ) ) {
                    $has_jquery_src = true;
                }
                // Chỉ nhận thuộc tính defer/async đứng độc lập. Không được dùng
                // \b(defer|async)\b vì nó khớp cả GIÁ TRỊ, ví dụ WordPress in ra
                // data-wp-strategy="defer" cho script mà nó KHÔNG defer thật (script
                // có inline phụ thuộc). Khớp nhầm ở đây khiến jquery.blockUI /
                // woocommerce.min.js bị bỏ qua, chạy đồng bộ TRƯỚC jQuery (đã defer)
                // và văng "jQuery is not defined".
                if ( preg_match( '/(?:^|\s)(?:defer|async)(?=[\s=\/>]|$)/i', $attrs ) ) {
                    return $m[0];
                }
                $deferred++;
                return '<script' . $attrs . ' defer>' . $body . '</script>';
            }

            // Inline script: chỉ bọc nếu có dùng jQuery/$ — vì jQuery giờ chạy muộn
            if ( '' === trim( $body ) ) {
                return $m[0];
            }
            if ( ! preg_match( '/\bjQuery\b|\$\s*\(|\$\.\w+/', $body ) ) {
                return $m[0];
            }
            // document.write không thể chạy muộn (sẽ xóa trắng trang) → để nguyên
            if ( false !== stripos( $body, 'document.write' ) ) {
                return $m[0];
            }
            $wrapped++;
            return '<script' . $attrs . '>' . 'window.dawpQ=window.dawpQ||[];dawpQ.push(function(){' . $body . "\n});" . '</script>';
        }, $html );

        if ( $deferred < 1 && $wrapped < 1 ) {
            return $html;
        }

        // Bộ chạy hàng đợi: đặt ở đầu <head> để định nghĩa dawpQ trước mọi inline
        // script; chạy hàng đợi khi DOMContentLoaded — thời điểm mọi script defer
        // (kể cả jQuery) đã thực thi xong theo đúng chuẩn HTML.
        if ( $wrapped > 0 ) {
            $runner = '<script data-dawp-keep="1">window.dawpQ=window.dawpQ||[];'
                . 'document.addEventListener("DOMContentLoaded",function(){'
                . 'var q=window.dawpQ,i;window.dawpQ={push:function(f){try{f()}catch(e){console&&console.error(e)}}};'
                . 'for(i=0;i<q.length;i++){try{q[i]()}catch(e){console&&console.error(e)}}});</script>';
            $head_pos = stripos( $html, '<head' );
            if ( false !== $head_pos ) {
                $head_end = strpos( $html, '>', $head_pos );
                if ( false !== $head_end ) {
                    $html = substr_replace( $html, $runner, $head_end + 1, 0 );
                }
            } else {
                $html = $runner . $html;
            }
        }

        return $html;
    }

}

