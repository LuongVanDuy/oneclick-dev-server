<?php
/**
 * Lọc HTML đầu ra: đổi URL .jpg/.png sang .webp khi bản WebP tồn tại.
 *
 * Đây là lớp bảo hiểm cho những chỗ URL cũ còn sót lại (theme hardcode, cache
 * HTML cũ, plugin lưu URL ở nơi lạ). Kết quả được cache trong bộ nhớ nên chi
 * phí gần như bằng không.
 *
 * @package duyanhweb
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DAWP_WebP_Rewriter {

	/**
	 * Cache kết quả kiểm tra file trong một request.
	 *
	 * @var array
	 */
	private static $lookup = array();

	/**
	 * @var string
	 */
	private $base_url = '';

	/**
	 * @var string
	 */
	private $base_dir = '';

	public function __construct() {
		if ( ! DAWP_WebP_Settings::get( 'enable_rewrite' ) ) {
			return;
		}

		$uploads        = wp_get_upload_dir();
		$this->base_url = trailingslashit( $uploads['baseurl'] );
		$this->base_dir = trailingslashit( $uploads['basedir'] );

		add_filter( 'the_content', array( $this, 'filter_html' ), 999 );
		add_filter( 'post_thumbnail_html', array( $this, 'filter_html' ), 999 );
		add_filter( 'widget_text', array( $this, 'filter_html' ), 999 );
		add_filter( 'wp_get_attachment_image_attributes', array( $this, 'filter_image_attributes' ), 999 );
		add_filter( 'wp_calculate_image_srcset', array( $this, 'filter_srcset' ), 999 );
		add_filter( 'wp_get_attachment_url', array( $this, 'filter_url' ), 999 );
	}

	/**
	 * Đổi URL ảnh trong một đoạn HTML.
	 *
	 * @param string $html HTML.
	 * @return string
	 */
	public function filter_html( $html ) {
		if ( ! is_string( $html ) || '' === $html || is_admin() ) {
			return $html;
		}

		if ( false === strpos( $html, $this->base_url ) ) {
			return $html;
		}

		$pattern = '#' . preg_quote( $this->base_url, '#' ) . '([^\s"\'\)\\\\]+?)\.(jpe?g|png)#i';

		return preg_replace_callback(
			$pattern,
			function ( $matches ) {
				$relative = $matches[1] . '.' . $matches[2];
				$webp     = $matches[1] . '.webp';

				if ( $this->webp_exists( $webp ) ) {
					return $this->base_url . $webp;
				}

				return $this->base_url . $relative;
			},
			$html
		);
	}

	/**
	 * Đổi một URL đơn lẻ.
	 *
	 * @param string $url URL.
	 * @return string
	 */
	public function filter_url( $url ) {
		if ( ! is_string( $url ) || is_admin() ) {
			return $url;
		}

		if ( 0 !== strpos( $url, $this->base_url ) ) {
			return $url;
		}

		if ( ! preg_match( '/\.(jpe?g|png)$/i', $url ) ) {
			return $url;
		}

		$relative = substr( $url, strlen( $this->base_url ) );
		$webp     = preg_replace( '/\.(jpe?g|png)$/i', '.webp', $relative );

		return $this->webp_exists( $webp ) ? $this->base_url . $webp : $url;
	}

	/**
	 * Đổi src trong thuộc tính thẻ img.
	 *
	 * @param array $attr Thuộc tính.
	 * @return array
	 */
	public function filter_image_attributes( $attr ) {
		if ( is_admin() ) {
			return $attr;
		}

		if ( ! empty( $attr['src'] ) ) {
			$attr['src'] = $this->filter_url( $attr['src'] );
		}

		if ( ! empty( $attr['srcset'] ) ) {
			$attr['srcset'] = $this->filter_html( $attr['srcset'] );
		}

		return $attr;
	}

	/**
	 * Đổi toàn bộ srcset responsive.
	 *
	 * @param array $sources Nguồn srcset.
	 * @return array
	 */
	public function filter_srcset( $sources ) {
		if ( ! is_array( $sources ) || is_admin() ) {
			return $sources;
		}

		foreach ( $sources as $width => $source ) {
			if ( ! empty( $source['url'] ) ) {
				$sources[ $width ]['url'] = $this->filter_url( $source['url'] );
			}
		}

		return $sources;
	}

	/**
	 * Kiểm tra bản WebP có tồn tại không (có cache).
	 *
	 * @param string $relative Đường dẫn tương đối trong uploads.
	 * @return bool
	 */
	private function webp_exists( $relative ) {
		if ( isset( self::$lookup[ $relative ] ) ) {
			return self::$lookup[ $relative ];
		}

		if ( false !== strpos( $relative, '..' ) ) {
			self::$lookup[ $relative ] = false;
			return false;
		}

		$exists                    = file_exists( $this->base_dir . $relative );
		self::$lookup[ $relative ] = $exists;

		return $exists;
	}
}

