<?php
/**
 * Plugin Name: Duy Anh Web Pro
 * Plugin URI:  https://duyanhweb.com.vn/
 * Description: Bộ giải pháp tối ưu hóa hiệu năng, tăng tốc độ tải trang thực tế vượt trội và bảo mật toàn diện tối thượng dành riêng cho WordPress được nghiên cứu & phát triển bởi Duy Anh Web. Tích hợp các tính năng cao cấp: Tối ưu cấu hình máy chủ Web, lưu bộ đệm tĩnh (Zero-JS Cache), cấu hình tài khoản gửi Mail gửi nhanh không bị spam, bảo mật hình ảnh véc-tơ chống mã độc, bộ nút liên hệ đa kênh Premium (Hotline, Zalo, Messenger, Bản đồ dẫn đường), dịch tự động đa ngôn ngữ đám mây và kích hoạt trình soạn thảo văn bản cổ điển.
 * Version:     1.2.3
 * Author:      Duy Anh Web
 * Author URI:  https://duyanhweb.com.vn/
 * Text Domain: duyanhwebpro
 * Domain Path: /languages
 */

defined( 'ABSPATH' ) || exit;


// [PHÒNG VỆ KÉP] Chống nạp trùng lặp.
if ( defined( 'DAWP_VERSION' ) || class_exists( 'DAWP_Init' ) ) {
    return;
}

if ( isset( $_SERVER['HTTP_X_FORWARDED_PROTO'] ) && strpos( $_SERVER['HTTP_X_FORWARDED_PROTO'], 'https' ) !== false ) {
    $_SERVER['HTTPS'] = 'on';
}
define( 'DAWP_VERSION', '1.2.3' );

// Fix lỗi Notice: ob_end_flush(): failed to send buffer of zlib output compression
remove_action( 'shutdown', 'wp_ob_end_flush_all', 1 );
define( 'DAWP_FILE', __FILE__ );
define( 'DAWP_DIR', plugin_dir_path( __FILE__ ) );
define( 'DAWP_URL', plugin_dir_url( __FILE__ ) );
define( 'DAWP_MODULES_DIR', DAWP_DIR . 'modules/' );
// Máy chủ cập nhật chính thức. Có thể ghi đè trong wp-config.php khi cần trỏ
// sang máy chủ thử nghiệm: define( 'DAWP_UPDATE_URL', 'https://.../info.json' );
if ( ! defined( 'DAWP_UPDATE_URL' ) ) {
    define( 'DAWP_UPDATE_URL', 'https://update.duyanhweb.com.vn/duyanhwebpro/info.json' );
}

// Tắt hoàn toàn kênh cập nhật cho site phát triển gốc: khai báo trong wp-config.php
// define( 'DAWP_DISABLE_UPDATE', true );

// Nạp các file nền tảng (Core files)
require_once DAWP_DIR . 'core/class-dawp-helpers.php';
require_once DAWP_DIR . 'core/class-dawp-updater.php';
require_once DAWP_DIR . 'core/class-dawp-init.php';

// Tự động Purge LiteSpeed Cache khi lưu cài đặt hoặc khi click nút Xóa Cache thủ công
add_action( 'admin_init', function() {
    $should_purge = false;
    if ( isset($_GET['page']) && $_GET['page'] === 'dawp-settings' && isset($_GET['settings-updated']) && $_GET['settings-updated'] == 'true' ) {
        $should_purge = true;
    }
    if ( isset($_GET['dawp_purge_cache']) && $_GET['dawp_purge_cache'] == '1' ) {
        if ( current_user_can('manage_options') && isset($_GET['_wpnonce']) && wp_verify_nonce($_GET['_wpnonce'], 'dawp_purge_cache_action') ) {
            $should_purge = true;
        } else {
            wp_die('Truy cập bị từ chối hoặc link bảo mật đã hết hạn. Vui lòng tải lại trang và thử lại!');
        }
    }
    if ( $should_purge ) {
        header('X-LiteSpeed-Purge: *');
        $optimization_file = DAWP_MODULES_DIR . 'optimization/class-optimization.php';
        if ( file_exists( $optimization_file ) ) {
            require_once $optimization_file;
            if ( class_exists( 'DAWP_Optimization' ) ) {
                $opt = new DAWP_Optimization();
                $opt->clear_static_cache();
            }
        }
        // Kích hoạt mồi cache tự động cho cả Desktop và Mobile
        wp_remote_get( home_url('/'), [
            'timeout'     => 0.1,
            'blocking'    => false,
            'sslverify'   => false,
            'headers'     => [
                'User-Agent' => 'DAWP-Auto-Preloader/1.0 (Desktop)'
            ]
        ] );
        wp_remote_get( home_url('/'), [
            'timeout'     => 0.1,
            'blocking'    => false,
            'sslverify'   => false,
            'headers'     => [
                'User-Agent' => 'DAWP-Auto-Preloader/1.0 (Mobile; Android)'
            ]
        ] );
        if ( isset($_GET['dawp_purge_cache']) ) {
            wp_redirect( admin_url('admin.php?page=dawp-settings&tab=optimization&purged=1') );
            exit;
        }
    }
});

// Khởi chạy Plugin
function dawp_run_plugin() {
    $plugin = new DAWP_Init();
    $plugin->run();
}
dawp_run_plugin();

// Hook kích hoạt plugin (Activation Hook)
register_activation_hook( __FILE__, 'dawp_activate_plugin' );
function dawp_activate_plugin() {
    $optimization_file = DAWP_MODULES_DIR . 'optimization/class-optimization.php';
    if ( file_exists( $optimization_file ) ) {
        require_once $optimization_file;
        if ( class_exists( 'DAWP_Optimization' ) ) {
            DAWP_Optimization::update_htaccess_rules();
        }
    }
    add_rewrite_rule( 'sitemap\.xml$', 'index.php?dawp_sitemap=1', 'top' );
    add_rewrite_rule( 'sitemap-stylesheet\.xsl$', 'index.php?dawp_sitemap_xsl=1', 'top' );
    add_rewrite_rule( '([a-f0-9]{32})\.txt$', 'index.php?dawp_indexnow_verify=$1', 'top' );
    flush_rewrite_rules();
}

// Hook hủy kích hoạt plugin (Deactivation Hook)
register_deactivation_hook( __FILE__, 'dawp_deactivate_plugin' );
function dawp_deactivate_plugin() {
    // Gỡ bỏ pre-wp cache drop-in nếu có
    $optimization_file = DAWP_MODULES_DIR . 'optimization/class-optimization.php';
    if ( file_exists( $optimization_file ) ) {
        require_once $optimization_file;
        if ( class_exists( 'DAWP_Optimization' ) ) {
            DAWP_Optimization::uninstall_pre_wp_cache();
        }
    }

    $htaccess_file = ABSPATH . '.htaccess';
    if ( file_exists( $htaccess_file ) && is_writable( $htaccess_file ) ) {
        $content = file_get_contents( $htaccess_file );
        $pattern = '/# BEGIN DAWP_OPTIMIZATIONS.*?# END DAWP_OPTIMIZATIONS/s';
        $content = preg_replace( $pattern, '', $content );
        $custom_pattern = '/# BEGIN DAWP_CUSTOM_SEO_RULES.*?# END DAWP_CUSTOM_SEO_RULES/s';
        $content = preg_replace( $custom_pattern, '', $content );
        $content = trim( $content );
        file_put_contents( $htaccess_file, $content );
    }
    flush_rewrite_rules();
}







