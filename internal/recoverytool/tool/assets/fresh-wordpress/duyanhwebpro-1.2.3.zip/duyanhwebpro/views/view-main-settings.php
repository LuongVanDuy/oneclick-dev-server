<?php
defined( 'ABSPATH' ) || exit;

$options = get_option( 'dawp_settings', [] );

// Cải tiến: Trả về mặc định nếu key chưa từng tồn tại (tính năng mới), ngược lại lấy giá trị đã lưu (0 hoặc 1)
$dawp_is_checked = function( $key, $default = 1 ) use ( $options ) {
    if ( !isset($options[$key]) ) return $default;
    return !empty( $options[$key] ) ? 1 : 0;
};

$active_tab = isset( $_GET['tab'] ) ? sanitize_text_field( $_GET['tab'] ) : 'smtp';
?>
<div class="wrap dawp-wrap">
    <h1><span class="dashicons dashicons-superhero" style="font-size: 32px; width: 32px; height: 32px; vertical-align: bottom;"></span> Duy Anh Web Pro - Bảng Điều Khiển</h1>
    <br>
    <h2 class="nav-tab-wrapper">
        <a href="?page=dawp-settings&tab=smtp" class="nav-tab <?php echo $active_tab == 'smtp' ? 'nav-tab-active' : ''; ?>">SMTP Mail</a>
        <a href="?page=dawp-settings&tab=contact" class="nav-tab <?php echo $active_tab == 'contact' ? 'nav-tab-active' : ''; ?>">Liên Hệ & Form</a>
        <a href="?page=dawp-settings&tab=seo" class="nav-tab <?php echo $active_tab == 'seo' ? 'nav-tab-active' : ''; ?>">Tối ưu SEO</a>
        <a href="?page=dawp-settings&tab=optimization" class="nav-tab <?php echo $active_tab == 'optimization' ? 'nav-tab-active' : ''; ?>">Tối ưu (Cache)</a>
        <a href="?page=dawp-settings&tab=security" class="nav-tab <?php echo $active_tab == 'security' ? 'nav-tab-active' : ''; ?>">Bảo mật</a>
        <a href="?page=dawp-settings&tab=pagespeed" class="nav-tab <?php echo $active_tab == 'pagespeed' ? 'nav-tab-active' : ''; ?>">Tốc độ (Speed UX)</a>
        <a href="?page=dawp-settings&tab=translate" class="nav-tab <?php echo $active_tab == 'translate' ? 'nav-tab-active' : ''; ?>">Dịch tự động</a>
        <a href="?page=dawp-settings&tab=multilingual" class="nav-tab <?php echo $active_tab == 'multilingual' ? 'nav-tab-active' : ''; ?>">Dịch tay</a>
        <a href="?page=dawp-settings&tab=woo-reviews" class="nav-tab <?php echo $active_tab == 'woo-reviews' ? 'nav-tab-active' : ''; ?>">Đánh giá sản phẩm</a>
        <a href="?page=dawp-settings&tab=social-share" class="nav-tab <?php echo $active_tab == 'social-share' ? 'nav-tab-active' : ''; ?>">Chia sẻ MXH</a>
        <a href="?page=dawp-settings&tab=font-awesome" class="nav-tab <?php echo $active_tab == 'font-awesome' ? 'nav-tab-active' : ''; ?>">Font Awesome</a>
        <a href="?page=dawp-settings&tab=maintenance" class="nav-tab <?php echo $active_tab == 'maintenance' ? 'nav-tab-active' : ''; ?>">Hệ thống & Bảo trì</a>
        <a href="?page=dawp-settings&tab=ai-remote" class="nav-tab <?php echo $active_tab == 'ai-remote' ? 'nav-tab-active' : ''; ?>">🤖 AI sửa web</a>
        <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=dawp-settings&dawp_purge_cache=1'), 'dawp_purge_cache_action'); ?>" class="nav-tab" style="background: #d63638; color: #fff; float: right; margin-left: auto;">🔥 Tự Động Xóa Cache</a>
    </h2>

    <?php if ( isset($_GET['purged']) && $_GET['purged'] == '1' ) : ?>
        <div class="notice notice-success is-dismissible" style="border-left-color: #d63638;">
            <p><strong>Thành công:</strong> Toàn bộ bộ nhớ đệm (Cache) của hệ thống máy chủ đã được dọn sạch tinh tươm! Website đã được làm mới 100%.</p>
        </div>
    <?php endif; ?>
    <?php if ( isset($_GET['settings-updated']) && $_GET['settings-updated'] == 'true' ) : ?>
        <div class="notice notice-success is-dismissible" style="border-left-color: #d63638;">
            <p><strong>Thành công:</strong> Hệ thống đã tự động lưu cài đặt và <strong>Tự động Xóa toàn bộ Cache Máy chủ (Purge All)</strong> giúp bạn! Không cần phải làm thủ công nữa.</p>
        </div>
    <?php endif; ?>

    <form method="post" action="options.php">
        <?php settings_fields( 'dawp_option_group' ); ?>
        
        <!-- SMTP TAB -->
        <div style="<?php echo $active_tab == 'smtp' ? '' : 'display: none;'; ?>">
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">Bật SMTP Mail</th>
                    <td>
                        <input type="hidden" name="dawp_settings[smtp_active]" value="0" />
                        <input type="checkbox" name="dawp_settings[smtp_active]" value="1" <?php checked( 1, $dawp_is_checked('smtp_active', 0) ); ?> />
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">SMTP Host</th>
                    <td><input type="text" name="dawp_settings[smtp_host]" class="regular-text" value="<?php echo esc_attr( isset($options['smtp_host']) ? $options['smtp_host'] : '' ); ?>" placeholder="vd: smtp.gmail.com" /></td>
                </tr>
                <tr valign="top">
                    <th scope="row">SMTP Port</th>
                    <td><input type="text" name="dawp_settings[smtp_port]" class="small-text" value="<?php echo esc_attr( isset($options['smtp_port']) ? $options['smtp_port'] : '465' ); ?>" placeholder="465" /></td>
                </tr>
                <tr valign="top">
                    <th scope="row">SMTP Username</th>
                    <td><input type="text" name="dawp_settings[smtp_user]" class="regular-text" value="<?php echo esc_attr( isset($options['smtp_user']) ? $options['smtp_user'] : '' ); ?>" placeholder="Email của bạn" /></td>
                </tr>
                <tr valign="top">
                    <th scope="row">SMTP Password / App Password</th>
                    <td>
                        <input type="password" name="dawp_settings[smtp_pass]" class="regular-text" value="" autocomplete="new-password" placeholder="<?php echo ! empty( $options['smtp_pass'] ) ? 'Đã lưu mật khẩu — để trống nếu không đổi' : 'Nhập App Password'; ?>" />
                        <?php if ( ! empty( $options['smtp_pass'] ) ) : ?>
                            <p class="description">Mật khẩu đang được lưu và không hiển thị lại vì lý do bảo mật. Chỉ nhập khi cần thay đổi.</p>
                        <?php endif; ?>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Mã hóa (TLS/SSL)</th>
                    <td>
                        <select name="dawp_settings[smtp_enc]">
                            <option value="ssl" <?php selected( 'ssl', isset($options['smtp_enc']) ? $options['smtp_enc'] : 'ssl' ); ?>>SSL</option>
                            <option value="tls" <?php selected( 'tls', isset($options['smtp_enc']) ? $options['smtp_enc'] : '' ); ?>>TLS</option>
                        </select>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Tên người gửi</th>
                    <td><input type="text" name="dawp_settings[smtp_from_name]" class="regular-text" value="<?php echo esc_attr( isset($options['smtp_from_name']) ? $options['smtp_from_name'] : get_bloginfo('name') ); ?>" /></td>
                </tr>
                <tr valign="top">
                    <th scope="row">Bỏ qua xác thực SSL</th>
                    <td>
                        <label>
                            <input type="checkbox" name="dawp_settings[smtp_insecure]" value="1" <?php checked( ! empty( $options['smtp_insecure'] ) ); ?> />
                            Chỉ bật khi gửi mail lỗi trên localhost/Laragon hoặc máy chủ thiếu bộ CA certificate
                        </label>
                        <p class="description" style="color: #b32d2e;">⚠️ Tùy chọn này tắt kiểm tra chứng chỉ TLS khi kết nối SMTP — giảm bảo mật, không khuyến nghị bật trên website thật.</p>
                    </td>
                </tr>
                <tr valign="top" style="border-top: 1px solid #e5e5e5; background: #fafafa;">
                    <th scope="row">🧪 Kiểm thử SMTP</th>
                    <td>
                        <div style="display: flex; gap: 10px; align-items: center; max-width: 600px;">
                            <input type="email" id="dawp_test_email" class="regular-text" placeholder="Nhập email nhận thử nghiệm..." style="margin: 0; padding: 6px 10px;" />
                            <button type="button" id="dawp_test_smtp_btn" onclick="return dawpTestSmtp();" class="button button-secondary" style="height: auto; padding: 6px 15px; display: inline-flex; align-items: center;">Gửi thử Email</button>
                        </div>
                        <p class="description" style="margin-top: 5px;">Hệ thống sẽ tạm thời sử dụng các thông số đang hiển thị trên form để gửi thử (Không cần phải Lưu thay đổi trước khi thử).</p>
                        <div id="dawp_test_smtp_result" style="margin-top: 12px; font-family: -apple-system, BlinkMacSystemFont, sans-serif;"></div>
                    </td>
                </tr>
            </table>
        </div>

        <!-- CONTACT TAB -->
        <div style="<?php echo $active_tab == 'contact' ? '' : 'display: none;'; ?>">
            <!-- 1. Zalo Hotline Settings Card -->
            <div class="dawp-card" style="background: #fff; border-radius: 12px; padding: 25px; box-shadow: 0 4px 20px rgba(0,0,0,0.04); border: 1px solid #e1e8ed; margin-bottom: 30px;">
                <h3 style="margin-top: 0; color: #1d2327; font-size: 16px; border-bottom: 1px solid #f0f0f1; padding-bottom: 12px; display: flex; align-items: center; gap: 8px;">
                    <span class="dashicons dashicons-phone" style="color: #0068ff;"></span> Nút Liên Hệ Nổi (Zalo & Hotline)
                </h3>
                <table class="form-table">
                    <tr valign="top">
                        <th scope="row">Bật Nút Liên Hệ (Frontend)</th>
                        <td>
                            <input type="hidden" name="dawp_settings[contact_buttons_active]" value="0" />
                            <input type="checkbox" name="dawp_settings[contact_buttons_active]" value="1" <?php checked( 1, $dawp_is_checked('contact_buttons_active', 1) ); ?> />
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row">Số Hotline (Di động)</th>
                        <td>
                            <input type="text" name="dawp_settings[hotline_number]" value="<?php echo esc_attr( isset($options['hotline_number']) ? $options['hotline_number'] : '' ); ?>" placeholder="0911111111, 0922222222" class="regular-text" />
                            <p class="description">Nhập tối đa 5 số điện thoại (cách nhau bởi dấu phẩy).</p>
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row">Số điện thoại Zalo</th>
                        <td>
                            <input type="text" name="dawp_settings[zalo_link]" value="<?php echo esc_attr( isset($options['zalo_link']) ? $options['zalo_link'] : '' ); ?>" placeholder="0911111111, 0922222222" class="regular-text" />
                            <p class="description">Nhập tối đa 5 số điện thoại Zalo (cách nhau bởi dấu phẩy). Hệ thống sẽ tự động tạo link Zalo.</p>
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row">Số điện thoại Whatsapp</th>
                        <td>
                            <input type="text" name="dawp_settings[whatsapp_number]" value="<?php echo esc_attr( isset($options['whatsapp_number']) ? $options['whatsapp_number'] : '' ); ?>" placeholder="84911111111, 84922222222" class="regular-text" />
                            <p class="description">Nhập tối đa 5 số điện thoại Whatsapp (cách nhau bởi dấu phẩy, bao gồm mã quốc gia không có dấu +). Hệ thống sẽ tự động tạo link Whatsapp.</p>
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row">Đường dẫn Messenger</th>
                        <td>
                            <input type="text" name="dawp_settings[messenger_link]" value="<?php echo esc_attr( isset($options['messenger_link']) ? $options['messenger_link'] : '' ); ?>" placeholder="https://m.me/username" class="regular-text" />
                            <p class="description">Đường dẫn chat Facebook Messenger (ví dụ: https://m.me/yourpage).</p>
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row">Bản đồ (Map link)</th>
                        <td>
                            <input type="text" name="dawp_settings[map_link]" value="<?php echo esc_attr( isset($options['map_link']) ? $options['map_link'] : '' ); ?>" placeholder="https://maps.google.com/..." class="regular-text" />
                            <p class="description">Đường dẫn chỉ đường bản đồ (ví dụ: link Google Maps chia sẻ hoặc trang địa chỉ của bạn).</p>
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row">Kiểu hiển thị (Style)</th>
                        <td>
                            <select name="dawp_settings[contact_buttons_style]" style="min-width: 250px;">
                                <option value="classic" <?php selected( 'classic', isset($options['contact_buttons_style']) ? $options['contact_buttons_style'] : 'classic' ); ?>>Classic - Nút tròn nổi dọc</option>
                                <option value="classic_horizontal" <?php selected( 'classic_horizontal', isset($options['contact_buttons_style']) ? $options['contact_buttons_style'] : '' ); ?>>Classic Horizontal - Nút tròn nổi ngang</option>
                                <option value="pill" <?php selected( 'pill', isset($options['contact_buttons_style']) ? $options['contact_buttons_style'] : '' ); ?>>Pill - Nút dài kèm nhãn phát sáng</option>
                                <option value="expand" <?php selected( 'expand', isset($options['contact_buttons_style']) ? $options['contact_buttons_style'] : '' ); ?>>Expand - Nút mở rộng/thu gọn thông minh</option>
                                <option value="sticky_bar" <?php selected( 'sticky_bar', isset($options['contact_buttons_style']) ? $options['contact_buttons_style'] : '' ); ?>>Sticky Bar - Thanh dính chân trang (Mobile) & Dock (Desktop)</option>
                            </select>
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row">Vị trí hiển thị</th>
                        <td>
                            <select name="dawp_settings[contact_buttons_position]" style="min-width: 250px;">
                                <option value="left" <?php selected( 'left', isset($options['contact_buttons_position']) ? $options['contact_buttons_position'] : 'left' ); ?>>Bên trái màn hình (Bottom Left)</option>
                                <option value="right" <?php selected( 'right', isset($options['contact_buttons_position']) ? $options['contact_buttons_position'] : '' ); ?>>Bên phải màn hình (Bottom Right)</option>
                            </select>
                            <p class="description">Áp dụng cho các kiểu hiển thị nổi (Classic, Pill, Expand).</p>
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row">Màu sắc các nút</th>
                        <td>
                            <div style="display: flex; gap: 20px; align-items: center; flex-wrap: wrap;">
                                <label style="display: flex; align-items: center; gap: 8px; font-weight: 500;">
                                    <span>Hotline:</span>
                                    <input type="color" name="dawp_settings[hotline_color]" value="<?php echo esc_attr( isset($options['hotline_color']) ? $options['hotline_color'] : '#f44336' ); ?>" style="border: none; padding: 0; background: transparent; cursor: pointer; width: 32px; height: 32px;" />
                                </label>
                                <label style="display: flex; align-items: center; gap: 8px; font-weight: 500;">
                                    <span>Zalo:</span>
                                    <input type="color" name="dawp_settings[zalo_color]" value="<?php echo esc_attr( isset($options['zalo_color']) ? $options['zalo_color'] : '#0068ff' ); ?>" style="border: none; padding: 0; background: transparent; cursor: pointer; width: 32px; height: 32px;" />
                                </label>
                                <label style="display: flex; align-items: center; gap: 8px; font-weight: 500;">
                                    <span>Whatsapp:</span>
                                    <input type="color" name="dawp_settings[whatsapp_color]" value="<?php echo esc_attr( isset($options['whatsapp_color']) ? $options['whatsapp_color'] : '#25d366' ); ?>" style="border: none; padding: 0; background: transparent; cursor: pointer; width: 32px; height: 32px;" />
                                </label>
                                <label style="display: flex; align-items: center; gap: 8px; font-weight: 500;">
                                    <span>Messenger:</span>
                                    <input type="color" name="dawp_settings[messenger_color]" value="<?php echo esc_attr( isset($options['messenger_color']) ? $options['messenger_color'] : '#0084ff' ); ?>" style="border: none; padding: 0; background: transparent; cursor: pointer; width: 32px; height: 32px;" />
                                </label>
                                <label style="display: flex; align-items: center; gap: 8px; font-weight: 500;">
                                    <span>Bản đồ:</span>
                                    <input type="color" name="dawp_settings[map_color]" value="<?php echo esc_attr( isset($options['map_color']) ? $options['map_color'] : '#4caf50' ); ?>" style="border: none; padding: 0; background: transparent; cursor: pointer; width: 32px; height: 32px;" />
                                </label>
                            </div>
                        </td>
                    </tr>
                </table>
            </div>

            <!-- 2. Form Builder Card -->
            <div class="dawp-card" style="background: #fff; border-radius: 12px; padding: 25px; box-shadow: 0 4px 20px rgba(0,0,0,0.04); border: 1px solid #e1e8ed; margin-bottom: 30px;">
                <h3 style="margin-top: 0; color: #1d2327; font-size: 16px; border-bottom: 1px solid #f0f0f1; padding-bottom: 12px; display: flex; align-items: center; gap: 8px;">
                    <span class="dashicons dashicons-email" style="color: #0068ff;"></span> Form Liên Hệ Siêu Nhẹ (Shortcode)
                </h3>
                <table class="form-table">
                    <tr valign="top">
                        <th scope="row">Bật Form Liên Hệ</th>
                        <td>
                            <input type="hidden" name="dawp_settings[contact_form_active]" value="0" />
                            <input type="checkbox" name="dawp_settings[contact_form_active]" value="1" <?php checked( 1, $dawp_is_checked('contact_form_active', 1) ); ?> />
                            <label>Kích hoạt shortcode <code>[dawp_contact_form]</code> để hiển thị form liên hệ gửi AJAX siêu tốc.</label>
                        </td>
                    </tr>
                    <?php if ( !isset($options['contact_form_active']) || !empty($options['contact_form_active']) ) : ?>
                    <tr valign="top">
                        <th scope="row">Quản lý các Form</th>
                        <td>
                            <div style="background: #f8fafc; padding: 15px; border-radius: 8px; border: 1px solid #e2e8f0; max-width: 800px; box-sizing: border-box;">
                                <p style="margin: 0 0 10px 0; font-weight: 600; color: #1e293b; font-size: 14px;">🚀 Đã chuyển sang chế độ Đa biểu mẫu (Multi-Form)!</p>
                                <p style="margin: 0 0 12px 0; color: #64748b; font-size: 13px; line-height: 1.5;">Giờ đây bạn có thể tạo và quản lý không giới hạn các Form liên hệ khác nhau. Mỗi Form sẽ có mã shortcode chèn riêng, giao diện chèn nhanh Preset, và cấu hình nhận thư riêng biệt.</p>
                                <a href="<?php echo admin_url('edit.php?post_type=dawp_contact_form'); ?>" class="button button-primary" style="background: #0068ff; border-color: #0068ff; color: #fff; text-decoration: none;">👉 Đi tới trang Quản lý Form Liên Hệ</a>
                                <a href="<?php echo admin_url('post-new.php?post_type=dawp_contact_form'); ?>" class="button button-secondary" style="margin-left: 10px; text-decoration: none;">➕ Thêm Form Mới</a>
                            </div>
                        </td>
                    </tr>
                    <?php endif; ?>
                </table>
            </div>

            <!-- 3. Lead Database Table Card -->
            <div class="dawp-card" style="background: #fff; border-radius: 12px; padding: 25px; box-shadow: 0 4px 20px rgba(0,0,0,0.04); border: 1px solid #e1e8ed;">
                <h3 style="margin-top: 0; color: #1d2327; font-size: 16px; border-bottom: 1px solid #f0f0f1; padding-bottom: 12px; display: flex; align-items: center; justify-content: space-between; gap: 8px; flex-wrap: wrap;">
                    <span style="display: flex; align-items: center; gap: 8px;">
                        <span class="dashicons dashicons-groups" style="color: #0068ff;"></span> Danh sách Khách hàng Liên hệ (Database)
                    </span>
                    <span style="display: flex; gap: 10px; margin-left: auto;">
                        <input type="text" id="dawp_search_leads" placeholder="Tìm tên hoặc SĐT..." style="padding: 4px 10px; font-size: 13px; border-radius: 4px; border: 1px solid #ccc; font-weight: normal;" />
                        <a href="<?php echo wp_nonce_url( admin_url('admin.php?page=dawp-settings&dawp_export_csv=1'), 'dawp_export_csv_action' ); ?>" class="button button-primary" style="height: auto; padding: 3px 12px; line-height: 1.8;">📥 Xuất file Excel (CSV)</a>
                        <button type="button" id="dawp_clear_leads_btn" onclick="return dawpClearLeads();" class="button" style="height: auto; padding: 3px 12px; line-height: 1.8; color: #d63638; border-color: #d63638;">🗑️ Xóa Sạch Data</button>
                    </span>
                </h3>

                <div style="overflow-x: auto; margin-top: 15px;">
                    <table class="wp-list-table widefat fixed striped table-view-list" id="dawp_leads_table">
                        <thead>
                            <tr>
                                <th style="width: 120px; font-weight: 600;">Ngày gửi</th>
                                <th style="width: 150px; font-weight: 600;">Form gửi</th>
                                <th style="width: 130px; font-weight: 600;">Họ và tên</th>
                                <th style="width: 110px; font-weight: 600;">Số điện thoại</th>
                                <th style="width: 160px; font-weight: 600;">Email</th>
                                <th style="font-weight: 600;">Nội dung lời nhắn</th>
                                <th style="width: 110px; font-weight: 600;">Địa chỉ IP</th>
                                <th style="width: 80px; font-weight: 600; text-align: center;">Hành động</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            global $wpdb;
                            $table_name = $wpdb->prefix . 'dawp_contacts';
                            $leads = [];
                            if ( $wpdb->get_var("SHOW TABLES LIKE '$table_name'") == $table_name ) {
                                $leads = $wpdb->get_results( "SELECT * FROM $table_name ORDER BY id DESC LIMIT 100" );
                            }
                            
                            if ( empty($leads) ) :
                            ?>
                                <tr class="no-leads-row">
                                    <td colspan="8" style="text-align: center; color: #666; padding: 20px;">Chưa có yêu cầu liên hệ nào được ghi nhận.</td>
                                </tr>
                            <?php else : foreach ( $leads as $lead ) : ?>
                                <tr class="lead-row" data-id="<?php echo $lead->id; ?>" data-search="<?php echo esc_attr(strtolower($lead->name . ' ' . $lead->phone . ' ' . $lead->form_title)); ?>">
                                    <td><?php echo date('d/m/Y H:i', strtotime($lead->created_at)); ?></td>
                                    <td style="color: #64748b; font-weight: 500;"><?php echo esc_html($lead->form_title ? $lead->form_title : 'Không rõ'); ?></td>
                                    <td style="font-weight: 500; color: #000;"><?php echo esc_html($lead->name); ?></td>
                                    <td><strong><?php echo esc_html($lead->phone); ?></strong></td>
                                    <td><?php echo esc_html($lead->email); ?></td>
                                    <td><?php echo nl2br(esc_html($lead->message)); ?></td>
                                    <td><code style="font-size: 11px;"><?php echo esc_html($lead->ip_address); ?></code></td>
                                    <td style="text-align: center;">
                                        <button type="button" class="dawp-delete-lead-btn" data-id="<?php echo $lead->id; ?>" onclick="return dawpDeleteLead(<?php echo $lead->id; ?>, this);" style="background: none; border: none; padding: 0; color: #d63638; cursor: pointer;" title="Xóa liên hệ này"><span class="dashicons dashicons-trash"></span></button>
                                    </td>
                                </tr>
                            <?php endforeach; endif; ?>
                        </tbody>
                    </table>
                </div>
                <div id="dawp_action_result" style="margin-top: 10px;"></div>
                <script data-cfasync="false">
                /* DAW Pro - Contact Delete (Self-contained, vanilla JS, không phụ thuộc jQuery) */
                (function(){
                    var ajaxUrl = '<?php echo esc_url(admin_url("admin-ajax.php")); ?>';
                    var nonce   = '<?php echo wp_create_nonce("dawp_contact_actions_nonce"); ?>';
                    var resEl   = document.getElementById('dawp_action_result');

                    function showMsg(html){ if(resEl) resEl.innerHTML = html; }

                    function doAjax(data, onOk, onFail){
                        var params = [];
                        for(var k in data) params.push(encodeURIComponent(k)+'='+encodeURIComponent(data[k]));
                        var xhr = new XMLHttpRequest();
                        xhr.open('POST', ajaxUrl, true);
                        xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
                        xhr.onreadystatechange = function(){
                            if(xhr.readyState !== 4) return;
                            if(xhr.status === 200){
                                try{ var r = JSON.parse(xhr.responseText); onOk(r); }
                                catch(e){ onFail('Phản hồi server không hợp lệ'); }
                            } else { onFail('HTTP ' + xhr.status); }
                        };
                        xhr.send(params.join('&'));
                    }

                    window.dawpDeleteLead = function(id, btn){
                        if(!id) return false;
                        if(!confirm('Bạn có chắc chắn muốn xóa liên hệ #' + id + ' không?')) return false;
                        showMsg('<span style="color:#666">⏳ Đang xóa liên hệ...</span>');
                        doAjax({action:'dawp_delete_contact', nonce:nonce, id:id}, function(r){
                            if(r.success){
                                showMsg('<span style="color:#46b450">✅ ' + (r.data && r.data.message ? r.data.message : 'Đã xóa!') + '</span>');
                                var row = btn; while(row && row.tagName !== 'TR') row = row.parentNode;
                                if(row) row.style.display = 'none';
                            } else {
                                showMsg('<span style="color:#d63638">❌ ' + (r.data && r.data.message ? r.data.message : 'Lỗi xóa') + '</span>');
                            }
                        }, function(err){ showMsg('<span style="color:#d63638">❌ Lỗi: ' + err + '</span>'); });
                        return false;
                    };

                    window.dawpClearLeads = function(){
                        if(!confirm('⚠️ Bạn có chắc chắn muốn XÓA TOÀN BỘ dữ liệu liên hệ? Hành động này không thể hoàn tác!')) return false;
                        showMsg('<span style="color:#666">⏳ Đang xóa toàn bộ dữ liệu...</span>');
                        doAjax({action:'dawp_clear_all_contacts', nonce:nonce}, function(r){
                            if(r.success){
                                showMsg('<span style="color:#46b450">✅ ' + (r.data && r.data.message ? r.data.message : 'Đã xóa sạch!') + '</span>');
                                var tb = document.querySelector('#dawp_leads_table tbody');
                                if(tb) tb.innerHTML = '<tr><td colspan="8" style="text-align:center;color:#666;padding:20px">Chưa có yêu cầu liên hệ nào được ghi nhận.</td></tr>';
                            } else {
                                showMsg('<span style="color:#d63638">❌ ' + (r.data && r.data.message ? r.data.message : 'Lỗi xóa') + '</span>');
                            }
                        }, function(err){ showMsg('<span style="color:#d63638">❌ Lỗi: ' + err + '</span>'); });
                        return false;
                    };
                })();
                </script>
            </div>
        </div>

        <!-- SEO TAB -->
        <div style="<?php echo $active_tab == 'seo' ? '' : 'display: none;'; ?>">
            <!-- 1. Kích hoạt SEO Card -->
            <div class="dawp-card" style="background: #fff; border-radius: 12px; padding: 25px; box-shadow: 0 4px 20px rgba(0,0,0,0.04); border: 1px solid #e1e8ed; margin-bottom: 30px;">
                <h3 style="margin-top: 0; color: #1d2327; font-size: 16px; border-bottom: 1px solid #f0f0f1; padding-bottom: 12px; display: flex; align-items: center; gap: 8px;">
                    <span class="dashicons dashicons-admin-site" style="color: #0068ff;"></span> Bật/Tắt Phân Hệ DAW Pro SEO & Redirect
                </h3>
                <table class="form-table">
                    <tr valign="top">
                        <th scope="row">Bật Module SEO & Redirect</th>
                        <td>
                            <input type="hidden" name="dawp_settings[seo_active]" value="0" />
                            <input type="checkbox" name="dawp_settings[seo_active]" value="1" <?php checked( 1, $dawp_is_checked('seo_active', 1) ); ?> />
                            <label>Kích hoạt toàn bộ bộ công cụ SEO bản quyền, Sitemap, Redirect 301, Local Business Schema, FAQ và Auto Alt.</label>
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row">Tự động tối ưu mô tả ảnh (Auto Alt)</th>
                        <td>
                            <input type="hidden" name="dawp_settings[seo_auto_alt_active]" value="0" />
                            <input type="checkbox" name="dawp_settings[seo_auto_alt_active]" value="1" <?php checked( 1, $dawp_is_checked('seo_auto_alt_active', 1) ); ?> />
                            <label>Tự động lấy tiêu đề bài viết làm thẻ <code>alt</code> cho các hình ảnh bị trống mô tả.</label>
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row">Tự động thêm rel="nofollow" cho link ngoài</th>
                        <td>
                            <input type="hidden" name="dawp_settings[seo_external_nofollow]" value="0" />
                            <input type="checkbox" name="dawp_settings[seo_external_nofollow]" value="1" <?php checked( 1, $dawp_is_checked('seo_external_nofollow', 0) ); ?> />
                            <label>Tự động thêm thẻ <code>rel="nofollow noopener"</code> và <code>target="_blank"</code> cho tất cả liên kết trỏ ra ngoài website trong nội dung bài viết.</label>
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row">Tự động chuyển hướng lỗi 404</th>
                        <td>
                            <input type="hidden" name="dawp_settings[seo_404_redirect]" value="0" />
                            <input type="checkbox" name="dawp_settings[seo_404_redirect]" value="1" <?php checked( 1, $dawp_is_checked('seo_404_redirect', 0) ); ?> />
                            <label>Tự động chuyển hướng (Redirect 301) tất cả các truy cập bị lỗi 404 về Trang chủ để tránh mất điểm chất lượng SEO.</label>
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row">Tự động tối ưu tiêu đề ảnh (Auto Title)</th>
                        <td>
                            <input type="hidden" name="dawp_settings[seo_auto_image_title]" value="0" />
                            <input type="checkbox" name="dawp_settings[seo_auto_image_title]" value="1" <?php checked( 1, $dawp_is_checked('seo_auto_image_title', 0) ); ?> />
                            <label>Tự động chèn thuộc tính <code>title</code> cho hình ảnh trong bài viết dựa theo tiêu đề bài viết và số thứ tự ảnh nếu bị thiếu.</label>
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row">Tải trước liên kết (Link Prefetching)</th>
                        <td>
                            <input type="hidden" name="dawp_settings[seo_link_prefetch]" value="0" />
                            <input type="checkbox" name="dawp_settings[seo_link_prefetch]" value="1" <?php checked( 1, $dawp_is_checked('seo_link_prefetch', 0) ); ?> />
                            <label>Tự động tải trước nội dung trang đích khi người dùng di chuột qua liên kết nội bộ, giúp tăng tốc độ chuyển trang lên tức thì (0ms) cho người dùng thật.</label>
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row">Shortcode hiển thị Breadcrumbs</th>
                        <td>
                            <code style="background: #f1f5f9; padding: 4px 8px; border-radius: 4px; font-weight: 600; font-family: monospace; border: 1px solid #cbd5e1; color: #0f172a;">[dawp_breadcrumbs]</code>
                            <p class="description" style="margin-top: 5px;">Chèn shortcode này vào bất kỳ vị trí nào trong bài viết, trang hoặc tệp tin giao diện (Theme) để hiển thị thanh điều hướng Breadcrumbs chuẩn SEO.</p>
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row">Shortcode hiển thị Lượt xem bài viết</th>
                        <td>
                            <code style="background: #f1f5f9; padding: 4px 8px; border-radius: 4px; font-weight: 600; font-family: monospace; border: 1px solid #cbd5e1; color: #0f172a;">[dawp_post_views]</code>
                            <p class="description" style="margin-top: 5px;">Chèn shortcode này vào bài viết hoặc trang để hiển thị số lượng lượt xem bài viết thực tế (hỗ trợ tăng lượt xem tự động và an toàn kể cả khi sử dụng Cache tĩnh).</p>
                        </td>
                    </tr>
                </table>
            </div>

            <!-- 2. Homepage & LocalBusiness Schema Card -->
            <div class="dawp-card" style="background: #fff; border-radius: 12px; padding: 25px; box-shadow: 0 4px 20px rgba(0,0,0,0.04); border: 1px solid #e1e8ed; margin-bottom: 30px;">
                <h3 style="margin-top: 0; color: #1d2327; font-size: 16px; border-bottom: 1px solid #f0f0f1; padding-bottom: 12px; display: flex; align-items: center; gap: 8px;">
                    <span class="dashicons dashicons-store" style="color: #0068ff;"></span> Thông Tin Doanh Nghiệp (LocalBusiness) & Trang Chủ
                </h3>
                <table class="form-table">
                    <tr valign="top">
                        <th scope="row">Mô tả Meta Trang chủ</th>
                        <td>
                            <textarea name="dawp_settings[seo_home_desc]" rows="3" class="large-text" placeholder="Nhập mô tả ngắn hiển thị trên Google cho Trang chủ..."><?php echo esc_textarea( isset($options['seo_home_desc']) ? $options['seo_home_desc'] : '' ); ?></textarea>
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row">Ảnh chia sẻ mặc định</th>
                        <td>
                            <div style="display: flex; gap: 10px; max-width: 600px;">
                                <input type="text" name="dawp_settings[seo_default_og_image]" value="<?php echo esc_attr( isset($options['seo_default_og_image']) ? $options['seo_default_og_image'] : '' ); ?>" style="flex: 1;" placeholder="https://domain.com/default-share-image.png">
                                <button type="button" class="button dawp-seo-select-media">Chọn ảnh</button>
                            </div>
                            <p class="description">Ảnh mặc định khi chia sẻ link lên Facebook/Zalo nếu bài viết không có ảnh đại diện.</p>
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row">Tên doanh nghiệp</th>
                        <td><input type="text" name="dawp_settings[seo_local_name]" value="<?php echo esc_attr( isset($options['seo_local_name']) ? $options['seo_local_name'] : '' ); ?>" class="regular-text" /></td>
                    </tr>
                    <tr valign="top">
                        <th scope="row">Số điện thoại doanh nghiệp</th>
                        <td><input type="text" name="dawp_settings[seo_local_phone]" value="<?php echo esc_attr( isset($options['seo_local_phone']) ? $options['seo_local_phone'] : '' ); ?>" class="regular-text" /></td>
                    </tr>
                    <tr valign="top">
                        <th scope="row">Địa chỉ chi tiết</th>
                        <td><input type="text" name="dawp_settings[seo_local_address]" value="<?php echo esc_attr( isset($options['seo_local_address']) ? $options['seo_local_address'] : '' ); ?>" class="regular-text" /></td>
                    </tr>
                    <tr valign="top">
                        <th scope="row">Tỉnh / Thành phố</th>
                        <td>
                            <input type="text" name="dawp_settings[seo_local_city]" value="<?php echo esc_attr( isset($options['seo_local_city']) ? $options['seo_local_city'] : '' ); ?>" placeholder="vd: Đà Nẵng" class="regular-text" />
                            <p class="description">Khai với Google doanh nghiệp thuộc tỉnh/thành nào. Để trống thì schema bỏ qua mục này.</p>
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row">Mã quốc gia</th>
                        <td><input type="text" name="dawp_settings[seo_local_country]" value="<?php echo esc_attr( isset($options['seo_local_country']) ? $options['seo_local_country'] : 'VN' ); ?>" class="small-text" /> <span class="description">Mặc định VN.</span></td>
                    </tr>
                    <tr valign="top">
                        <th scope="row">Logo doanh nghiệp</th>
                        <td>
                            <div style="display: flex; gap: 10px; max-width: 600px;">
                                <input type="text" name="dawp_settings[seo_local_logo]" value="<?php echo esc_attr( isset($options['seo_local_logo']) ? $options['seo_local_logo'] : '' ); ?>" style="flex: 1;" placeholder="https://domain.com/logo.png">
                                <button type="button" class="button dawp-seo-select-media">Chọn ảnh</button>
                            </div>
                        </td>
                    </tr>
                </table>
            </div>

            <!-- WooCommerce Product Schema Card -->
            <div class="dawp-card" style="background: #fff; border-radius: 12px; padding: 25px; box-shadow: 0 4px 20px rgba(0,0,0,0.04); border: 1px solid #e1e8ed; margin-bottom: 30px;">
                <h3 style="margin-top: 0; color: #1d2327; font-size: 16px; border-bottom: 1px solid #f0f0f1; padding-bottom: 12px; display: flex; align-items: center; gap: 8px;">
                    <span class="dashicons dashicons-cart" style="color: #0068ff;"></span> Cấu Hình Schema Sản Phẩm (WooCommerce Merchant Listings)
                </h3>
                <table class="form-table">
                    <tr valign="top">
                        <th scope="row">Thương hiệu mặc định (Brand)</th>
                        <td>
                            <input type="text" name="dawp_settings[seo_product_brand]" value="<?php echo esc_attr( isset($options['seo_product_brand']) ? $options['seo_product_brand'] : '' ); ?>" class="regular-text" placeholder="Ví dụ: Duy Anh Web" />
                            <p class="description">Tên thương hiệu mặc định gán cho các sản phẩm. Nếu trống, hệ thống sẽ tự động quét lấy từ danh mục thương hiệu (nếu có) hoặc dùng tên doanh nghiệp/website.</p>
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row">Quốc gia áp dụng đổi trả & vận chuyển</th>
                        <td>
                            <input type="text" name="dawp_settings[seo_product_shipping_country]" value="<?php echo esc_attr( isset($options['seo_product_shipping_country']) ? $options['seo_product_shipping_country'] : 'VN' ); ?>" class="small-text" style="width: 60px;" placeholder="VN" />
                            <p class="description">Mã quốc gia ISO 2 chữ cái (ví dụ: VN, US).</p>
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row">Phí vận chuyển mặc định</th>
                        <td>
                            <input type="number" step="any" name="dawp_settings[seo_product_shipping_cost]" value="<?php echo esc_attr( isset($options['seo_product_shipping_cost']) ? $options['seo_product_shipping_cost'] : '0' ); ?>" class="regular-text" placeholder="0" />
                            <p class="description">Nhập phí vận chuyển mặc định (ví dụ: 0 cho miễn phí vận chuyển, hoặc 30000 cho 30.000đ).</p>
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row">Thời gian xử lý đơn hàng (Handling Time)</th>
                        <td>
                            <input type="number" min="0" name="dawp_settings[seo_product_shipping_handling_min]" value="<?php echo esc_attr( isset($options['seo_product_shipping_handling_min']) ? $options['seo_product_shipping_handling_min'] : '0' ); ?>" style="width: 60px;" /> 
                            đến 
                            <input type="number" min="0" name="dawp_settings[seo_product_shipping_handling_max]" value="<?php echo esc_attr( isset($options['seo_product_shipping_handling_max']) ? $options['seo_product_shipping_handling_max'] : '1' ); ?>" style="width: 60px;" /> ngày
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row">Thời gian vận chuyển (Transit Time)</th>
                        <td>
                            <input type="number" min="0" name="dawp_settings[seo_product_shipping_transit_min]" value="<?php echo esc_attr( isset($options['seo_product_shipping_transit_min']) ? $options['seo_product_shipping_transit_min'] : '1' ); ?>" style="width: 60px;" /> 
                            đến 
                            <input type="number" min="0" name="dawp_settings[seo_product_shipping_transit_max]" value="<?php echo esc_attr( isset($options['seo_product_shipping_transit_max']) ? $options['seo_product_shipping_transit_max'] : '3' ); ?>" style="width: 60px;" /> ngày
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row">Chính sách đổi trả (Return Policy)</th>
                        <td>
                            <select name="dawp_settings[seo_product_return_category]">
                                <option value="https://schema.org/MerchantReturnFiniteReturnWindow" <?php selected( 'https://schema.org/MerchantReturnFiniteReturnWindow', isset($options['seo_product_return_category']) ? $options['seo_product_return_category'] : 'https://schema.org/MerchantReturnFiniteReturnWindow' ); ?>>Cho phép đổi trả trong số ngày giới hạn</option>
                                <option value="https://schema.org/MerchantReturnNotPermitted" <?php selected( 'https://schema.org/MerchantReturnNotPermitted', isset($options['seo_product_return_category']) ? $options['seo_product_return_category'] : '' ); ?>>Không cho phép đổi trả (No Returns)</option>
                            </select>
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row">Số ngày cho phép đổi trả</th>
                        <td>
                            <input type="number" min="0" name="dawp_settings[seo_product_return_days]" value="<?php echo esc_attr( isset($options['seo_product_return_days']) ? $options['seo_product_return_days'] : '30' ); ?>" class="small-text" style="width: 80px;" /> ngày
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row">Phí đổi trả hàng</th>
                        <td>
                            <select name="dawp_settings[seo_product_return_fees]">
                                <option value="https://schema.org/FreeReturn" <?php selected( 'https://schema.org/FreeReturn', isset($options['seo_product_return_fees']) ? $options['seo_product_return_fees'] : 'https://schema.org/FreeReturn' ); ?>>Miễn phí đổi trả (Free Return)</option>
                                <option value="https://schema.org/ReturnFeesCustomerPaying" <?php selected( 'https://schema.org/ReturnFeesCustomerPaying', isset($options['seo_product_return_fees']) ? $options['seo_product_return_fees'] : '' ); ?>>Khách tự trả phí ship đổi trả (Customer Pays)</option>
                            </select>
                        </td>
                    </tr>
                </table>
            </div>

            <!-- Chèn Mã Theo Dõi Card -->
            <div class="dawp-card" style="background: #fff; border-radius: 12px; padding: 25px; box-shadow: 0 4px 20px rgba(0,0,0,0.04); border: 1px solid #e1e8ed; margin-bottom: 30px;">
                <h3 style="margin-top: 0; color: #1d2327; font-size: 16px; border-bottom: 1px solid #f0f0f1; padding-bottom: 12px; display: flex; align-items: center; gap: 8px;">
                    <span class="dashicons dashicons-code-standards" style="color: #0068ff;"></span> Chèn Mã Theo Dõi & Xác Minh (Google Analytics, Facebook Pixel, Ads...)
                </h3>
                <table class="form-table">
                    <tr valign="top">
                        <th scope="row">Mã chèn vào Header (&lt;head&gt;)</th>
                        <td>
                            <textarea name="dawp_settings[seo_header_code]" rows="5" class="large-text" style="font-family: monospace; font-size: 13px;" placeholder="Ví dụ: &lt;script&gt;...&lt;/script&gt; hoặc mã xác minh Google Search Console &lt;meta name=&quot;google-site-verification&quot; content=&quot;...&quot; /&gt;"><?php echo esc_textarea( isset($options['seo_header_code']) ? $options['seo_header_code'] : '' ); ?></textarea>
                            <p class="description">Được tiêm tự động vào thẻ <code>&lt;head&gt;&lt;/head&gt;</code> của trang ngoài frontend. Phù hợp cho mã GA4, Facebook Pixel, Google Ads Conversion.</p>
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row">Mã chèn sau thẻ mở Body (&lt;body&gt;)</th>
                        <td>
                            <textarea name="dawp_settings[seo_body_code]" rows="4" class="large-text" style="font-family: monospace; font-size: 13px;" placeholder="Ví dụ: &lt;noscript&gt;&lt;iframe src=&quot;https://www.googletagmanager.com/ns.html?id=...&quot;&gt;&lt;/iframe&gt;&lt;/noscript&gt;"><?php echo esc_textarea( isset($options['seo_body_code']) ? $options['seo_body_code'] : '' ); ?></textarea>
                            <p class="description">Được tiêm tự động ngay sau thẻ mở <code>&lt;body&gt;</code> của trang (chỉ hỗ trợ các giao diện tương thích với hàm <code>wp_body_open()</code> của WordPress). Phù hợp cho mã GTM noscript.</p>
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row">Mã chèn trước thẻ đóng Body (Footer)</th>
                        <td>
                            <textarea name="dawp_settings[seo_footer_code]" rows="5" class="large-text" style="font-family: monospace; font-size: 13px;" placeholder="Ví dụ: &lt;!-- Live Chat Code --&gt;"><?php echo esc_textarea( isset($options['seo_footer_code']) ? $options['seo_footer_code'] : '' ); ?></textarea>
                            <p class="description">Được tiêm tự động vào cuối trang trước thẻ đóng <code>&lt;/body&gt;</code> (qua hook <code>wp_footer</code>). Phù hợp cho các script Live Chat, Zalo chat, Tawk.to, Remarketing.</p>
                        </td>
                    </tr>
                </table>
            </div>

            <!-- 3. Redirect 301 Manager Card -->
            <div class="dawp-card" style="background: #fff; border-radius: 12px; padding: 25px; box-shadow: 0 4px 20px rgba(0,0,0,0.04); border: 1px solid #e1e8ed; margin-bottom: 30px;">
                <h3 style="margin-top: 0; color: #1d2327; font-size: 16px; border-bottom: 1px solid #f0f0f1; padding-bottom: 12px; display: flex; align-items: center; gap: 8px;">
                    <span class="dashicons dashicons-redo" style="color: #0068ff;"></span> Trình Quản Lý Chuyển Hướng (Redirect 301)
                </h3>
                
                <!-- Form thêm Redirect -->
                <div style="background: #f8fafc; padding: 15px; border-radius: 8px; border: 1px solid #e2e8f0; margin-bottom: 20px;">
                    <p style="margin: 0 0 12px 0; font-weight: 600; color: #1e293b; font-size: 13.5px;">➕ Thêm đường dẫn chuyển hướng mới:</p>
                    <div style="display: flex; gap: 15px; flex-wrap: wrap; align-items: center;">
                        <div style="flex: 1; min-width: 250px;">
                            <label style="display:block; font-size: 12px; color: #64748b; margin-bottom: 4px;">Đường dẫn cũ (cần chuyển hướng - vd: /link-cu/):</label>
                            <input type="text" id="dawp_redirect_old" style="width: 100%; padding: 6px 10px;" placeholder="/url-cu-muon-chuyen-huong" />
                        </div>
                        <div style="flex: 1; min-width: 250px;">
                            <label style="display:block; font-size: 12px; color: #64748b; margin-bottom: 4px;">Đường dẫn mới (đích đến - vd: /link-moi/):</label>
                            <input type="text" id="dawp_redirect_new" style="width: 100%; padding: 6px 10px;" placeholder="/url-dich-den-moi" />
                        </div>
                        <button type="button" id="dawp_add_redirect_btn" class="button button-primary" style="margin-top: 20px; padding: 3px 15px;">Thêm Chuyển Hướng</button>
                    </div>
                </div>

                <!-- Bảng danh sách Redirects -->
                <div style="max-height: 350px; overflow-y: auto;">
                    <table class="wp-list-table widefat fixed striped table-view-list" id="dawp_redirects_table">
                        <thead>
                            <tr>
                                <th style="font-weight: 600;">Link Cũ (Request Path)</th>
                                <th style="font-weight: 600;">Link Mới (Target URL)</th>
                                <th style="width: 100px; font-weight: 600;">Loại</th>
                                <th style="width: 80px; font-weight: 600; text-align: center;">Hành động</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            global $wpdb;
                            $table_redirects = $wpdb->prefix . 'dawp_redirects';
                            $redirects = [];
                            if ( $wpdb->get_var("SHOW TABLES LIKE '$table_redirects'") === $table_redirects ) {
                                $redirects = $wpdb->get_results( "SELECT * FROM $table_redirects ORDER BY id DESC" );
                            }
                            if ( empty($redirects) ) :
                            ?>
                                <tr class="no-redirects-row">
                                    <td colspan="4" style="text-align: center; color: #666; padding: 20px;">Chưa có chuyển hướng 301 nào được cấu hình.</td>
                                </tr>
                            <?php else : foreach ( $redirects as $redir ) : ?>
                                <tr class="redirect-row" data-id="<?php echo $redir->id; ?>">
                                    <td style="font-weight: 500;"><?php echo esc_html($redir->old_url); ?></td>
                                    <td><a href="<?php echo esc_url($redir->new_url); ?>" target="_blank"><?php echo esc_html($redir->new_url); ?></a></td>
                                    <td style="color: #64748b; font-weight: 500;"><?php echo esc_html($redir->type); ?></td>
                                    <td style="text-align: center;">
                                        <button type="button" class="dawp-delete-redirect-btn" data-id="<?php echo $redir->id; ?>" style="background: none; border: none; padding: 0; color: #d63638; cursor: pointer;" title="Xóa"><span class="dashicons dashicons-trash"></span></button>
                                    </td>
                                </tr>
                            <?php endforeach; endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- 3.5 Quét lại Điểm SEO & Dễ đọc -->
            <div class="dawp-card" style="background: #fff; border-radius: 12px; padding: 25px; box-shadow: 0 4px 20px rgba(0,0,0,0.04); border: 1px solid #e1e8ed; margin-bottom: 30px;">
                <h3 style="margin-top: 0; color: #1d2327; font-size: 16px; border-bottom: 1px solid #f0f0f1; padding-bottom: 12px; display: flex; align-items: center; gap: 8px;">
                    <span class="dashicons dashicons-chart-bar" style="color: #0068ff;"></span> Chấm điểm SEO &amp; Dễ đọc toàn bộ bài viết
                </h3>
                <p class="description" style="margin: 4px 0 15px;">Tính và lưu <strong>điểm SEO</strong> + <strong>điểm dễ đọc</strong> cho tất cả bài viết/trang/sản phẩm hiện có, để hiển thị chấm màu ngoài danh sách và cho phép <strong>lọc theo điểm</strong> + <strong>đếm trạng thái</strong>. Bài mới lưu sau này sẽ tự chấm. Nên chạy 1 lần sau khi cập nhật.</p>
                <div style="display: flex; align-items: center; gap: 12px; flex-wrap: wrap;">
                    <button type="button" id="dawp_rescan_scores_btn" class="button button-primary" style="background: #0068ff; border-color: #0068ff; height: auto; padding: 6px 16px; font-weight: 600;" data-nonce="<?php echo esc_attr( wp_create_nonce('dawp_rescan_scores_nonce') ); ?>">🔍 Quét &amp; Chấm điểm toàn bộ</button>
                    <span id="dawp_rescan_status" style="font-size: 13px; color: #50575e;"></span>
                </div>
                <div id="dawp_rescan_progress" style="display: none; height: 20px; background: #f0f0f1; border-radius: 10px; overflow: hidden; margin-top: 14px; max-width: 600px;">
                    <div id="dawp_rescan_bar" style="height: 100%; width: 0%; background: linear-gradient(90deg,#0068ff,#3ca0e7); transition: width 0.2s;"></div>
                </div>
            </div>

            <!-- 4. 404 Monitor Card -->
            <div class="dawp-card" style="background: #fff; border-radius: 12px; padding: 25px; box-shadow: 0 4px 20px rgba(0,0,0,0.04); border: 1px solid #e1e8ed; margin-bottom: 30px;">
                <h3 style="margin-top: 0; color: #1d2327; font-size: 16px; border-bottom: 1px solid #f0f0f1; padding-bottom: 12px; display: flex; align-items: center; justify-content: space-between; gap: 8px;">
                    <span style="display: flex; align-items: center; gap: 8px;">
                        <span class="dashicons dashicons-warning" style="color: #ea580c;"></span> Bộ Theo Dõi Lỗi 404 (404 Monitor)
                    </span>
                    <button type="button" id="dawp_clear_404_btn" class="button" style="height: auto; padding: 3px 12px; line-height: 1.8; color: #d63638; border-color: #d63638; margin-left: auto;">🗑️ Dọn Sạch Lịch Sử 404</button>
                </h3>
                
                <div style="max-height: 350px; overflow-y: auto; margin-top: 15px;">
                    <table class="wp-list-table widefat fixed striped table-view-list" id="dawp_404_table">
                        <thead>
                            <tr>
                                <th style="font-weight: 600;">Link Bị Lỗi 404</th>
                                <th style="width: 120px; font-weight: 600; text-align: center;">Số Lần Truy Cập</th>
                                <th style="width: 140px; font-weight: 600;">Thời Gian Cuối</th>
                                <th style="width: 250px; font-weight: 600;">IP & User Agent Cuối</th>
                                <th style="width: 150px; font-weight: 600; text-align: center;">Hành động</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $table_404 = $wpdb->prefix . 'dawp_404_logs';
                            $logs_404 = [];
                            if ( $wpdb->get_var("SHOW TABLES LIKE '$table_404'") === $table_404 ) {
                                $logs_404 = $wpdb->get_results( "SELECT * FROM $table_404 ORDER BY last_accessed DESC LIMIT 50" );
                            }
                            if ( empty($logs_404) ) :
                            ?>
                                <tr class="no-404-row">
                                    <td colspan="5" style="text-align: center; color: #666; padding: 20px;">Chưa có lịch sử lỗi 404 nào được ghi nhận.</td>
                                </tr>
                            <?php else : foreach ( $logs_404 as $log ) : ?>
                                <tr class="404-row" data-id="<?php echo $log->id; ?>">
                                    <td style="font-weight: 600; color: #ef4444;"><?php echo esc_html($log->url); ?></td>
                                    <td style="text-align: center;"><strong><?php echo (int)$log->access_count; ?></strong></td>
                                    <td><?php echo date('d/m/Y H:i', strtotime($log->last_accessed)); ?></td>
                                    <td style="font-size: 11px; line-height: 1.4; color: #64748b;">
                                        <code>IP: <?php echo esc_html($log->ip_address); ?></code><br/>
                                        <span style="display:inline-block; max-width:230px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;" title="<?php echo esc_attr($log->user_agent); ?>"><?php echo esc_html($log->user_agent); ?></span>
                                    </td>
                                    <td style="text-align: center;">
                                        <button type="button" class="button button-small dawp-quick-redirect-btn" data-url="<?php echo esc_attr($log->url); ?>" style="color:#0068ff; border-color:#0068ff;" title="Tạo chuyển hướng 301">↪️ Redirect 301</button>
                                        <button type="button" class="dawp-delete-404-btn" data-id="<?php echo $log->id; ?>" style="background: none; border: none; padding: 0; color: #d63638; cursor: pointer; margin-left: 8px; vertical-align: middle;" title="Xóa"><span class="dashicons dashicons-trash"></span></button>
                                    </td>
                                </tr>
                            <?php endforeach; endif; ?>
                        </tbody>
                    </table>
                </div>
                <div id="dawp_seo_action_result" style="margin-top: 10px;"></div>
            </div>

            <!-- 5. Files Editor Card -->
            <div class="dawp-card" style="background: #fff; border-radius: 12px; padding: 25px; box-shadow: 0 4px 20px rgba(0,0,0,0.04); border: 1px solid #e1e8ed; margin-bottom: 30px;">
                <h3 style="margin-top: 0; color: #1d2327; font-size: 16px; border-bottom: 1px solid #f0f0f1; padding-bottom: 12px; display: flex; align-items: center; gap: 8px;">
                    <span class="dashicons dashicons-editor-code" style="color: #0068ff;"></span> Cấu hình Robots.txt & .htaccess (Tùy biến máy chủ)
                </h3>
                <table class="form-table">
                    <tr valign="top">
                        <th scope="row">Nội dung Robots.txt</th>
                        <td>
                            <textarea name="dawp_settings[seo_robots_txt]" rows="6" class="large-text" style="font-family: monospace; font-size: 13px;" placeholder="User-agent: *&#10;Disallow: /wp-admin/"><?php echo esc_textarea( isset($options['seo_robots_txt']) ? $options['seo_robots_txt'] : "User-agent: *\nDisallow: /wp-admin/\nAllow: /wp-admin/admin-ajax.php" ); ?></textarea>
                            <p class="description">Được ghi đè động vào đường dẫn <code>/robots.txt</code> của site (Tự động thêm sitemap).</p>
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row">Dòng lệnh .htaccess Custom</th>
                        <td>
                            <textarea name="dawp_settings[seo_htaccess]" rows="6" class="large-text" style="font-family: monospace; font-size: 13px;" placeholder="# Thêm luật tùy biến của bạn ở đây..."><?php echo esc_textarea( isset($options['seo_htaccess']) ? $options['seo_htaccess'] : "" ); ?></textarea>
                            <p class="description">Các dòng lệnh tùy biến của bạn sẽ được tự động ghi vào tệp tin <code>.htaccess</code> thực tế ngoài thư mục gốc.</p>
                        </td>
                    </tr>
                </table>
            </div>

            <!-- 6. SEO Migration Card -->
            <div class="dawp-card" style="background: #fff; border-radius: 12px; padding: 25px; box-shadow: 0 4px 20px rgba(0,0,0,0.04); border: 1px solid #e1e8ed; margin-bottom: 30px;">
                <h3 style="margin-top: 0; color: #1d2327; font-size: 16px; border-bottom: 1px solid #f0f0f1; padding-bottom: 12px; display: flex; align-items: center; gap: 8px;">
                    <span class="dashicons dashicons-database-export" style="color: #0068ff;"></span> Nhập Dữ Liệu SEO từ Plugin SEO cũ
                </h3>
                <div style="background: #f8fafc; padding: 20px; border-radius: 8px; border: 1px solid #e2e8f0; margin-bottom: 20px;">
                    <p style="margin: 0 0 10px 0; font-weight: 600; color: #1e293b; font-size: 13.5px;">Công cụ chuyển đổi dữ liệu SEO tự động:</p>
                    <p style="margin: 0 0 15px 0; color: #64748b; font-size: 13px; line-height: 1.5;">
                        Hệ thống sẽ tự động quét cơ sở dữ liệu và sao chép các thông tin SEO (Tiêu đề, Mô tả, Canonical, Robots, Từ khóa, Share Facebook/Zalo) từ plugin cũ sang định dạng của <strong>Duy Anh Web Pro</strong>. 
                        Trong quá trình nhập, các thẻ dynamic placeholder (như <code>%%title%%</code>, <code>%sep%</code>...) sẽ được tự động biên dịch thành văn bản tĩnh để dễ dàng chỉnh sửa.
                    </p>
                    
                    <div id="dawp-migration-stats" style="margin-bottom: 15px; font-size: 13px; font-weight: 500; color: #334155;">
                        ⏳ Đang quét cơ sở dữ liệu tìm dữ liệu SEO cũ...
                    </div>

                    <div style="display: flex; gap: 20px; align-items: center; flex-wrap: wrap; margin-bottom: 15px;">
                        <div>
                            <label style="font-weight: 600; font-size: 13px; color: #1e293b; margin-right: 8px;">Chọn nguồn nhập:</label>
                            <select id="dawp_migration_source" style="padding: 5px 10px; border-radius: 4px; border: 1px solid #cbd5e1;">
                                <option value="yoast">Plugin SEO cũ (Loại 1)</option>
                                <option value="rank_math">Plugin SEO cũ (Loại 2)</option>
                            </select>
                        </div>
                        <div>
                            <label style="display: inline-flex; align-items: center; gap: 6px; cursor: pointer; font-size: 13px; font-weight: 600; color: #1e293b;">
                                <input type="checkbox" id="dawp_migration_overwrite" value="1">
                                Ghi đè dữ liệu DAW Pro SEO hiện có
                            </label>
                        </div>
                        <button type="button" id="dawp_start_migration_btn" class="button button-primary" style="padding: 3px 15px; background: #0068ff; border-color: #0068ff; height: auto; font-weight: 600;">Bắt Đầu Nhập Dữ Liệu</button>
                    </div>
                    
                    <!-- Progress Section -->
                    <div id="dawp-migration-progress-wrapper" style="display: none; margin-top: 20px;">
                        <div style="display: flex; justify-content: space-between; font-size: 12.5px; font-weight: 600; color: #1e293b; margin-bottom: 5px;">
                            <span>Đang xử lý di chuyển...</span>
                            <span id="dawp-migration-progress-percent">0%</span>
                        </div>
                        <div style="height: 8px; width: 100%; background: #e2e8f0; border-radius: 4px; overflow: hidden; margin-bottom: 15px;">
                            <div id="dawp-migration-progress-bar" style="height: 100%; width: 0%; background: #0068ff; transition: width 0.2s;"></div>
                        </div>
                        
                        <!-- Console Log Area -->
                        <div id="dawp-migration-log" style="background: #0f172a; color: #38bdf8; font-family: monospace; font-size: 12px; padding: 15px; border-radius: 6px; max-height: 150px; overflow-y: auto; line-height: 1.6; border: 1px solid #1e293b;">
                            [Khởi động bảng log di chuyển...]
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- OPTIMIZATION TAB -->
        <div style="<?php echo $active_tab == 'optimization' ? '' : 'display: none;'; ?>">
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">Bật Module Tối Ưu (Zero-Overhead)</th>
                    <td>
                        <input type="hidden" name="dawp_settings[optimization_active]" value="0" />
                        <input type="checkbox" name="dawp_settings[optimization_active]" value="1" <?php checked( 1, $dawp_is_checked('optimization_active', 1) ); ?> />
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Bộ nhớ đệm máy chủ (Server Cache)</th>
                    <td>
                        <input type="hidden" name="dawp_settings[opt_litespeed]" value="0" />
                        <input type="checkbox" name="dawp_settings[opt_litespeed]" value="1" <?php checked( 1, $dawp_is_checked('opt_litespeed', 1) ); ?> />
                        <label>Gửi HTTP Cache Header cho khách (Guest). Tự động Bypass giỏ hàng và Admin.</label>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Tối ưu Cache Tĩnh (Static HTML Cache)</th>
                    <td>
                        <input type="hidden" name="dawp_settings[opt_static_cache]" value="0" />
                        <input type="checkbox" name="dawp_settings[opt_static_cache]" value="1" <?php checked( 1, $dawp_is_checked('opt_static_cache', 1) ); ?> />
                        <label>Lưu trữ nội dung trang thành file HTML tĩnh và tải trực tiếp trong 1-3ms cho khách truy cập, bỏ qua 100% PHP/Database. Thích hợp cho mọi loại Hosting (kể cả Apache, Nginx không hỗ trợ Server Cache).</label>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Cache siêu tốc trước-WordPress</th>
                    <td>
                        <input type="hidden" name="dawp_settings[opt_pre_wp_cache]" value="0" />
                        <input type="checkbox" name="dawp_settings[opt_pre_wp_cache]" value="1" <?php checked( 1, $dawp_is_checked('opt_pre_wp_cache', 0) ); ?> />
                        <label>Bật bộ đọc cache siêu tốc chạy ngay trước khi WordPress tải (Drop-in advanced-cache.php) để đạt tốc độ phục vụ tối đa (~sub-50ms). <strong>Lưu ý:</strong> Yêu cầu quyền ghi tệp tin <code>wp-config.php</code> và thư mục <code>wp-content/</code>.</label>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Giới hạn Heartbeat API</th>
                    <td>
                        <input type="hidden" name="dawp_settings[opt_heartbeat]" value="0" />
                        <input type="checkbox" name="dawp_settings[opt_heartbeat]" value="1" <?php checked( 1, $dawp_is_checked('opt_heartbeat', 1) ); ?> />
                        <label>Giảm xung nhịp admin-ajax.php chống treo máy chủ.</label>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Force HTTPS & HSTS</th>
                    <td>
                        <input type="hidden" name="dawp_settings[opt_ssl]" value="0" />
                        <input type="checkbox" name="dawp_settings[opt_ssl]" value="1" <?php checked( 1, $dawp_is_checked('opt_ssl', 1) ); ?> />
                        <label>Ép bảo mật SSL và tự động gắn header Strict-Transport-Security giúp giảm TTFB.</label>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Tối ưu hóa cấp Máy chủ (.htaccess)</th>
                    <td>
                        <input type="hidden" name="dawp_settings[opt_htaccess]" value="0" />
                        <input type="checkbox" name="dawp_settings[opt_htaccess]" value="1" <?php checked( 1, $dawp_is_checked('opt_htaccess', 1) ); ?> />
                        <label>Tự động ghi cấu hình Gzip, Browser Cache (ảnh/font 1 năm, CSS/JS 7 ngày + must-revalidate) và các Header bảo mật vào file <code>.htaccess</code>. Khuyên dùng cho mọi cấu hình máy chủ.</label>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Tăng tốc Admin (Admin Speed Boost)</th>
                    <td>
                        <input type="hidden" name="dawp_settings[opt_admin_speed]" value="0" />
                        <input type="checkbox" name="dawp_settings[opt_admin_speed]" value="1" <?php checked( 1, $dawp_is_checked('opt_admin_speed', 1) ); ?> />
                        <label>Chặn WordPress tự động kiểm tra phiên bản ngầm và tắt giao diện Analytics của WooCommerce. Rất hiệu quả cho web cũ.</label>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Tối ưu Cart Fragments (WooCommerce)</th>
                    <td>
                        <input type="hidden" name="dawp_settings[opt_wc_cart_fragments]" value="0" />
                        <input type="checkbox" name="dawp_settings[opt_wc_cart_fragments]" value="1" <?php checked( 1, $dawp_is_checked('opt_wc_cart_fragments', 1) ); ?> />
                        <label>Tắt tập lệnh <code>wc-cart-fragments</code> trên các trang thường. Ngăn chặn triệt để cuộc gọi AJAX <code>/?wc-ajax=get_refreshed_fragments</code> gây quá tải CPU của hosting yếu khi tải trang.</label>
                    </td>
                </tr>
            </table>
        </div>

        <!-- SECURITY TAB -->
        <div style="<?php echo $active_tab == 'security' ? '' : 'display: none;'; ?>">
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">Bật Module Security</th>
                    <td>
                        <input type="hidden" name="dawp_settings[security_active]" value="0" />
                        <input type="checkbox" name="dawp_settings[security_active]" value="1" <?php checked( 1, $dawp_is_checked('security_active', 1) ); ?> />
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Khóa XML-RPC</th>
                    <td>
                        <input type="hidden" name="dawp_settings[sec_xmlrpc]" value="0" />
                        <input type="checkbox" name="dawp_settings[sec_xmlrpc]" value="1" <?php checked( 1, $dawp_is_checked('sec_xmlrpc', 1) ); ?> />
                        <label>Chặn Bot DDoS vào file xmlrpc.php</label>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Ẩn Version WordPress</th>
                    <td>
                        <input type="hidden" name="dawp_settings[sec_hide_version]" value="0" />
                        <input type="checkbox" name="dawp_settings[sec_hide_version]" value="1" <?php checked( 1, $dawp_is_checked('sec_hide_version', 1) ); ?> />
                        <label>Gỡ mã phiên bản WP trên mã nguồn</label>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Hỗ trợ tải lên ảnh SVG</th>
                    <td>
                        <input type="hidden" name="dawp_settings[sec_svg]" value="0" />
                        <input type="checkbox" name="dawp_settings[sec_svg]" value="1" <?php checked( 1, $dawp_is_checked('sec_svg', 1) ); ?> />
                        <label>Cho phép đăng SVG (Đã bao gồm cơ chế lọc mã độc)</label>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Tắt Bình Luận (Disable Comments)</th>
                    <td>
                        <input type="hidden" name="dawp_settings[sec_disable_comments]" value="0" />
                        <input type="checkbox" name="dawp_settings[sec_disable_comments]" value="1" <?php checked( 1, $dawp_is_checked('sec_disable_comments', 1) ); ?> />
                        <label>Khóa tính năng bình luận, xóa menu Phản hồi và ẩn bình luận cũ.</label>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Bật Math CAPTCHA cho Bình Luận</th>
                    <td>
                        <input type="hidden" name="dawp_settings[sec_comment_captcha]" value="0" />
                        <input type="checkbox" name="dawp_settings[sec_comment_captcha]" value="1" <?php checked( 1, $dawp_is_checked('sec_comment_captcha', 1) ); ?> />
                        <label>Hiển thị phép tính ngẫu nhiên chống bình luận rác (Anti-Spam) cho khách vãng lai.</label>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Chế độ Website Demo (Chặn Tuyệt Đối Index)</th>
                    <td>
                        <input type="hidden" name="dawp_settings[sec_demo_mode]" value="0" />
                        <input type="checkbox" name="dawp_settings[sec_demo_mode]" value="1" <?php checked( 1, $dawp_is_checked('sec_demo_mode', 0) ); ?> />
                        <label><strong>BẬT KHI ĐANG DỰNG WEB DEMO:</strong> Tự động cấu hình HTTP Header <code style="color: #d63638; background: #fdf2f2; padding: 2px 6px; border-radius: 4px;">X-Robots-Tag: noindex, nofollow</code>, thẻ meta robots và robots.txt để bảo vệ website không bị lập chỉ mục ngoài ý muốn. Khách hàng thật truy cập vẫn cực nhanh nhờ bộ lọc Zero-Overhead.</label>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Chặn mã độc từ trình duyệt (Chrome Ext. Sanitizer)</th>
                    <td>
                        <input type="hidden" name="dawp_settings[sec_chrome_cleaner]" value="0" />
                        <input type="checkbox" name="dawp_settings[sec_chrome_cleaner]" value="1" <?php checked( 1, $dawp_is_checked('sec_chrome_cleaner', 1) ); ?> />
                        <label>Tự động phát hiện và loại bỏ các thẻ script/iframe được tiêm nhiễm từ tiện ích mở rộng trình duyệt hoặc mã độc máy tính quản trị (như các chrome-extension:// script) ngay khi đăng hoặc sửa bài viết/sản phẩm.</label>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Chống ăn cắp Cookie (Session Hijacking Protection)</th>
                    <td>
                        <input type="hidden" name="dawp_settings[sec_lock_session]" value="0" />
                        <input type="checkbox" name="dawp_settings[sec_lock_session]" value="1" <?php checked( 1, $dawp_is_checked('sec_lock_session', 0) ); ?> />
                        <label>Khóa chặt phiên đăng nhập Admin với User-Agent và dải IP mạng ban đầu. Nếu mã độc trên máy Admin ăn cắp Cookie đăng nhập và gửi về cho hacker sử dụng từ thiết bị/IP khác, hệ thống sẽ lập tức hủy phiên đăng nhập để bảo vệ website.</label>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Vô hiệu hóa chỉnh sửa mã (Disable File Editor)</th>
                    <td>
                        <input type="hidden" name="dawp_settings[sec_disable_file_editor]" value="0" />
                        <input type="checkbox" name="dawp_settings[sec_disable_file_editor]" value="1" <?php checked( 1, $dawp_is_checked('sec_disable_file_editor', 1) ); ?> />
                        <label>Tắt trình chỉnh sửa tệp tin theme/plugin trực tiếp trong trang quản trị. Ngăn chặn hacker hoặc mã độc lợi dụng quyền admin để chèn mã độc vào file functions.php của giao diện.</label>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">🛡️ Tường lửa Bảo mật (Firewall / WAF)</th>
                    <td>
                        <input type="hidden" name="dawp_settings[sec_firewall]" value="0" />
                        <input type="checkbox" name="dawp_settings[sec_firewall]" value="1" <?php checked( 1, $dawp_is_checked('sec_firewall', 1) ); ?> />
                        <label>Tự động quét và chặn (403) các yêu cầu chứa dấu hiệu tấn công phổ biến khai thác lỗ hổng theme/plugin (như Flatsome): <strong>PHP Object Injection, phar://, XSS qua UX Builder, SQL Injection, chèn mã PHP, path traversal</strong>. Bỏ qua quản trị viên tin cậy nên không ảnh hưởng việc soạn thảo/dựng trang.</label>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">🔒 Chặn thực thi PHP trong thư mục Uploads</th>
                    <td>
                        <input type="hidden" name="dawp_settings[sec_uploads_noexec]" value="0" />
                        <input type="checkbox" name="dawp_settings[sec_uploads_noexec]" value="1" <?php checked( 1, $dawp_is_checked('sec_uploads_noexec', 1) ); ?> />
                        <label>Ghi quy tắc <code>.htaccess</code> vào thư mục <code>wp-content/uploads</code> để chặn chạy mọi file <code>.php</code>. Vô hiệu hóa web shell/backdoor mà hacker cố tình tải lên qua lỗ hổng (Apache/LiteSpeed).</label>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">🧱 Thêm HTTP Security Headers</th>
                    <td>
                        <input type="hidden" name="dawp_settings[sec_headers]" value="0" />
                        <input type="checkbox" name="dawp_settings[sec_headers]" value="1" <?php checked( 1, $dawp_is_checked('sec_headers', 1) ); ?> />
                        <label>Gửi kèm các header bảo mật chuẩn: <code>X-Content-Type-Options</code>, <code>X-Frame-Options</code> (chống nhúng iframe/clickjacking), <code>Referrer-Policy</code>, <code>Permissions-Policy</code>. Giảm rủi ro XSS và rò rỉ thông tin.</label>
                    </td>
                </tr>
                <tr valign="top" style="border-top: 1px solid #e5e5e5; background: #fdfdfd;">
                    <th scope="row">🧹 Quét & Làm sạch Database (Database Security Cleaner)</th>
                    <td>
                        <button type="button" id="dawp_scan_db_btn" class="button button-secondary" style="height: auto; padding: 6px 15px; margin-right: 10px;">Quét Mã Độc Database</button>
                        <button type="button" id="dawp_clean_db_btn" class="button button-primary" style="background: #46b450; border-color: #46b450; height: auto; padding: 6px 15px; display: none;">Làm Sạch Mã Độc</button>
                        <p class="description" style="margin-top: 5px;">Tự động quét toàn bộ bài viết trong cơ sở dữ liệu để phát hiện và làm sạch các mã độc chèn từ trình duyệt máy quản trị viên (chrome-extension script/iframe). Bảo đảm không chạy ngầm, không tốn tài nguyên.</p>
                        <div id="dawp_db_cleaner_result" style="margin-top: 12px; font-family: -apple-system, BlinkMacSystemFont, sans-serif; display: none; padding: 12px; border-radius: 4px; border-left: 4px solid #00a0d2; background: #f5f5f5; max-height: 250px; overflow-y: auto;"></div>
                    </td>
                </tr>
                <tr valign="top" style="border-top: 1px solid #e5e5e5; background: #fafafa;">
                    <th scope="row">🗑️ Dọn Dẹp Bình Luận</th>
                    <td>
                        <button type="button" id="dawp_clean_comments_btn" class="button button-secondary" style="background: #d63638; color: #fff; border-color: #d63638; height: auto; padding: 6px 15px;">Dọn dẹp Bình Luận Siêu Tốc</button>
                        <p class="description" style="margin-top: 5px; color: #d63638; font-weight: 500;">⚠️ Cảnh báo: Hành động này sử dụng TRUNCATE TABLE để xóa vĩnh viễn 100% bình luận và bình luận rác trong cơ sở dữ liệu ngay lập tức. Hãy sao lưu database trước khi thực hiện!</p>
                        <div id="dawp_clean_comments_result" style="margin-top: 12px; font-family: -apple-system, BlinkMacSystemFont, sans-serif;"></div>
                    </td>
                </tr>
            </table>
        </div>

        <!-- TRANSLATE TAB -->
        <div style="<?php echo $active_tab == 'translate' ? '' : 'display: none;'; ?>">
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">Bật Dịch Tự Động</th>
                    <td>
                        <input type="hidden" name="dawp_settings[google_translate_active]" value="0" />
                        <input type="checkbox" id="dawp_google_translate_active" name="dawp_settings[google_translate_active]" value="1" <?php checked( 1, $dawp_is_checked('google_translate_active', 0) ); ?> />
                        <label>Kích hoạt tính năng dịch tự động đa ngôn ngữ bằng công nghệ dịch thuật đám mây (Tự động tắt Dịch tay khi bật tính năng này).</label>
                    </td>
                </tr>
                <tr valign="top" class="dawp-translate-fields" style="<?php echo $dawp_is_checked('google_translate_active', 0) ? '' : 'display: none;'; ?>">
                    <th scope="row">Kiểu hiển thị (Layout Style)</th>
                    <td>
                        <select name="dawp_settings[google_translate_layout]" id="dawp_google_translate_layout" style="min-width: 250px;">
                            <option value="floating" <?php selected( 'floating', isset($options['google_translate_layout']) ? $options['google_translate_layout'] : 'floating' ); ?>>Nút nổi góc màn hình (Floating Widget)</option>
                            <option value="inline" <?php selected( 'inline', isset($options['google_translate_layout']) ? $options['google_translate_layout'] : '' ); ?>>Chèn thủ công (Bằng Shortcode [dawp_translate])</option>
                        </select>
                    </td>
                </tr>
                <tr valign="top" class="dawp-translate-fields" id="dawp_translate_inline_style_row" style="<?php echo (isset($options['google_translate_layout']) && $options['google_translate_layout'] === 'inline') ? '' : 'display: none;'; ?>">
                    <th scope="row">Kiểu dáng Shortcode (Inline Style)</th>
                    <td>
                        <select name="dawp_settings[google_translate_inline_style]" style="min-width: 250px;">
                            <option value="dropdown-pill" <?php selected( 'dropdown-pill', isset($options['google_translate_inline_style']) ? $options['google_translate_inline_style'] : 'dropdown-pill' ); ?>>Dạng thả xuống - Viên thuốc (Dropdown Pill)</option>
                            <option value="dropdown-flat" <?php selected( 'dropdown-flat', isset($options['google_translate_inline_style']) ? $options['google_translate_inline_style'] : '' ); ?>>Dạng thả xuống - Phẳng tối giản (Dropdown Flat)</option>
                            <option value="flags" <?php selected( 'flags', isset($options['google_translate_inline_style']) ? $options['google_translate_inline_style'] : '' ); ?>>Dạng cờ quốc gia nằm ngang (Horizontal Flags)</option>
                        </select>
                        <p class="description">Chọn kiểu dáng hiển thị của shortcode <code>[dawp_translate]</code> khi chèn vào Menu hoặc Header. (Có thể ghi đè trong shortcode: <code>[dawp_translate style="flags"]</code>)</p>
                    </td>
                </tr>
                <tr valign="top" class="dawp-translate-fields" id="dawp_translate_position_row" style="<?php echo (!isset($options['google_translate_layout']) || $options['google_translate_layout'] === 'floating') ? '' : 'display: none;'; ?>">
                    <th scope="row">Vị trí hiển thị (Nút nổi)</th>
                    <td>
                        <select name="dawp_settings[google_translate_position]" style="min-width: 250px;">
                            <option value="right" <?php selected( 'right', isset($options['google_translate_position']) ? $options['google_translate_position'] : 'right' ); ?>>Dưới bên Phải (Bottom Right)</option>
                            <option value="left" <?php selected( 'left', isset($options['google_translate_position']) ? $options['google_translate_position'] : '' ); ?>>Dưới bên Trái (Bottom Left)</option>
                        </select>
                    </td>
                </tr>
                <tr valign="top" class="dawp-translate-fields" style="<?php echo $dawp_is_checked('google_translate_active', 0) ? '' : 'display: none;'; ?>">
                    <th scope="row">Ngôn ngữ mặc định</th>
                    <td>
                        <select name="dawp_settings[google_translate_default_lang]" style="min-width: 250px;">
                            <?php
                            $default_langs = [
                                'vi' => 'Tiếng Việt',
                                'en' => 'English',
                                'zh' => '简体中文 (Chinese)',
                                'ja' => '日本語 (Japanese)',
                                'ko' => '한국어 (Korean)',
                                'fr' => 'Français (French)',
                                'de' => 'Deutsch (German)',
                                'ru' => 'Русский (Russian)',
                                'es' => 'Español (Spanish)',
                                'it' => 'Italiano (Italian)',
                                'pt' => 'Português (Portuguese)',
                                'th' => 'ไทย (Thai)',
                                'lo' => 'ລາວ (Lao)',
                                'km' => 'ភាសាខ្មែរ (Khmer)',
                                'my' => 'မြန်မာဘာသာ (Burmese)',
                                'id' => 'Bahasa Indonesia (Indonesian)',
                                'ms' => 'Bahasa Melayu (Malay)',
                                'ar' => 'العربية (Arabic)',
                                'hi' => 'हिन्दी (Hindi)',
                                'bn' => 'বাংলা (Bengali)',
                                'tr' => 'Türkçe (Turkish)',
                                'nl' => 'Nederlands (Dutch)',
                                'pl' => 'Polski (Polish)',
                                'sv' => 'Svenska (Swedish)',
                                'da' => 'Dansk (Danish)',
                                'fi' => 'Suomi (Finnish)',
                                'no' => 'Norsk (Norwegian)',
                                'el' => 'Ελληνικά (Greek)',
                                'he' => 'עברית (Hebrew)',
                                'cs' => 'Čeština (Czech)',
                                'hu' => 'Magyar (Hungarian)',
                                'ro' => 'Română (Romanian)',
                                'uk' => 'Українська (Ukrainian)',
                                'sk' => 'Slovenčina (Slovak)',
                            ];
                            $current_default = isset($options['google_translate_default_lang']) ? $options['google_translate_default_lang'] : 'vi';
                            foreach ($default_langs as $code => $name) {
                                echo '<option value="' . esc_attr($code) . '" ' . selected($code, $current_default, false) . '>' . esc_html($name) . '</option>';
                            }
                            ?>
                        </select>
                    </td>
                </tr>
                <tr valign="top" class="dawp-translate-fields" style="<?php echo $dawp_is_checked('google_translate_active', 0) ? '' : 'display: none;'; ?>">
                    <th scope="row">Danh sách các ngôn ngữ hỗ trợ</th>
                    <td>
                        <?php
                        // Đảm bảo nạp class dịch tự động dù module đang tắt, để luôn hiện đầy đủ danh sách cờ
                        if ( ! class_exists('DAWP_Google_Translate') ) {
                            $gt_module_file = DAWP_MODULES_DIR . 'google-translate/class-google-translate.php';
                            if ( file_exists( $gt_module_file ) ) {
                                require_once $gt_module_file;
                            }
                        }
                        $gt_langs = class_exists('DAWP_Google_Translate') ? (new DAWP_Google_Translate())->get_language_list() : [];
                        if (empty($gt_langs)) {
                            // Dự phòng
                            $gt_langs = [
                                'vi' => ['name' => 'Tiếng Việt', 'flag' => '🇻🇳', 'country' => 'vn'],
                                'en' => ['name' => 'English', 'flag' => '🇬🇧', 'country' => 'gb'],
                            ];
                        }
                        
                        $saved_val = isset($options['google_translate_languages']) ? $options['google_translate_languages'] : 'vi,en,zh-CN,ja,ko';
                        $saved_codes = is_array($saved_val) ? $saved_val : array_map('trim', explode(',', $saved_val));
                        
                        $total_langs = count($gt_langs);
                        $selected_count = 0;
                        foreach ($gt_langs as $code => $info) {
                            if (in_array($code, $saved_codes)) $selected_count++;
                        }
                        ?>
                        <style>
                            .dawp-lang-search-wrap { max-width: 900px; margin-bottom: 10px; }
                            #dawp-lang-search { width: 100%; padding: 9px 12px; border: 1px solid #ccd0d4; border-radius: 6px; font-size: 14px; box-sizing: border-box; }
                            #dawp-lang-search:focus { border-color: #2271b1; outline: none; box-shadow: 0 0 0 1px #2271b1; }
                            #dawp-lang-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(185px, 1fr)); gap: 10px; max-width: 900px; max-height: 380px; overflow-y: auto; padding: 12px; background: #fff; border: 1px solid #ccd0d4; border-radius: 6px; }
                            .dawp-lang-card { display: flex; align-items: center; gap: 9px; padding: 8px 10px; border: 2px solid #e2e4e7; border-radius: 8px; cursor: pointer; font-size: 13px; transition: all .15s ease; position: relative; background: #fbfbfc; user-select: none; }
                            .dawp-lang-card:hover { border-color: #a7c7e7; background: #f6faff; }
                            .dawp-lang-card.selected { border-color: #2271b1; background: #eef6fc; box-shadow: 0 1px 3px rgba(34,113,177,.15); }
                            .dawp-lang-card img { width: 24px; height: auto; box-shadow: 0 0 2px rgba(0,0,0,.35); border-radius: 2px; flex-shrink: 0; }
                            .dawp-lang-card .dawp-lang-name { flex: 1; color: #1e293b; font-weight: 500; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
                            .dawp-lang-card .dawp-lang-check { width: 18px; height: 18px; border-radius: 50%; background: #2271b1; color: #fff; font-size: 12px; line-height: 18px; text-align: center; flex-shrink: 0; opacity: 0; transform: scale(.5); transition: all .15s ease; }
                            .dawp-lang-card.selected .dawp-lang-check { opacity: 1; transform: scale(1); }
                            .dawp-lang-counter { margin-top: 8px; font-size: 13px; color: #50575e; }
                            .dawp-lang-counter b { color: #2271b1; }
                            #dawp-lang-empty { display: none; padding: 20px; text-align: center; color: #888; grid-column: 1 / -1; }
                            .dawp-lang-quick { margin: 8px 0 4px; }
                            .dawp-lang-quick button { font-size: 12px; margin-right: 8px; }
                        </style>

                        <div class="dawp-lang-search-wrap">
                            <input type="text" id="dawp-lang-search" placeholder="🔍 Tìm ngôn ngữ theo tên hoặc mã (vd: English, Nhật, fr, 中文...)">
                        </div>

                        <div class="dawp-lang-quick">
                            <button type="button" class="button button-small" id="dawp-lang-selectall">Chọn tất cả</button>
                            <button type="button" class="button button-small" id="dawp-lang-clearall">Bỏ chọn tất cả</button>
                        </div>

                        <?php // Khóa luôn có mặt trong POST kể cả khi bỏ chọn hết (checkbox không tick thì trình duyệt không gửi) ?>
                        <input type="hidden" name="dawp_settings[google_translate_languages][]" value="" />
                        <div id="dawp-lang-grid">
                            <?php foreach ($gt_langs as $code => $info) :
                                $is_checked = in_array($code, $saved_codes);
                                $search_key = strtolower( $info['name'] . ' ' . $code . ' ' . $info['country'] );
                            ?>
                            <label class="dawp-lang-card<?php echo $is_checked ? ' selected' : ''; ?>" data-search="<?php echo esc_attr($search_key); ?>">
                                <input type="checkbox" name="dawp_settings[google_translate_languages][]" value="<?php echo esc_attr($code); ?>" <?php checked($is_checked); ?> style="display: none;">
                                <img src="<?php echo esc_url( DAWP_URL . 'assets/flags/' . $info['country'] . '.png' ); ?>" alt="<?php echo esc_attr($info['name']); ?>" loading="lazy">
                                <span class="dawp-lang-name"><?php echo esc_html($info['name']); ?></span>
                                <span class="dawp-lang-check">✓</span>
                            </label>
                            <?php endforeach; ?>
                            <div id="dawp-lang-empty">Không tìm thấy ngôn ngữ nào khớp.</div>
                        </div>

                        <p class="dawp-lang-counter">Đã chọn <b id="dawp-lang-count"><?php echo (int)$selected_count; ?></b> / <?php echo (int)$total_langs; ?> ngôn ngữ.</p>
                        <p class="description">Bấm vào lá cờ để chọn/bỏ chọn ngôn ngữ hiển thị trên công cụ dịch tự động.</p>

                        <script>
                        (function() {
                            var grid = document.getElementById('dawp-lang-grid');
                            if (!grid || grid.dawpBound) return;
                            grid.dawpBound = true;

                            var search = document.getElementById('dawp-lang-search');
                            var counter = document.getElementById('dawp-lang-count');
                            var empty = document.getElementById('dawp-lang-empty');
                            var cards = Array.prototype.slice.call(grid.querySelectorAll('.dawp-lang-card'));

                            function updateCount() {
                                var n = grid.querySelectorAll('.dawp-lang-card input:checked').length;
                                if (counter) counter.textContent = n;
                            }

                            // Đồng bộ class 'selected' khi checkbox thay đổi
                            grid.addEventListener('change', function(e) {
                                if (e.target && e.target.type === 'checkbox') {
                                    e.target.closest('.dawp-lang-card').classList.toggle('selected', e.target.checked);
                                    updateCount();
                                }
                            });

                            // Lọc tìm kiếm
                            if (search) {
                                search.addEventListener('input', function() {
                                    var q = this.value.trim().toLowerCase();
                                    var visible = 0;
                                    cards.forEach(function(card) {
                                        var match = !q || card.getAttribute('data-search').indexOf(q) !== -1;
                                        card.style.display = match ? '' : 'none';
                                        if (match) visible++;
                                    });
                                    if (empty) empty.style.display = visible === 0 ? 'block' : 'none';
                                });
                            }

                            var selAll = document.getElementById('dawp-lang-selectall');
                            var clrAll = document.getElementById('dawp-lang-clearall');
                            if (selAll) selAll.addEventListener('click', function() {
                                cards.forEach(function(card) {
                                    if (card.style.display === 'none') return;
                                    var cb = card.querySelector('input'); cb.checked = true; card.classList.add('selected');
                                });
                                updateCount();
                            });
                            if (clrAll) clrAll.addEventListener('click', function() {
                                cards.forEach(function(card) {
                                    if (card.style.display === 'none') return;
                                    var cb = card.querySelector('input'); cb.checked = false; card.classList.remove('selected');
                                });
                                updateCount();
                            });
                        })();
                        </script>
                    </td>
                </tr>
            </table>
        </div>

        <!-- MULTILINGUAL TAB -->
        <div style="<?php echo $active_tab == 'multilingual' ? '' : 'display: none;'; ?>">
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">Bật Dịch Tay Đa Ngôn Ngữ</th>
                    <td>
                        <input type="hidden" name="dawp_settings[multilingual_active]" value="0" />
                        <input type="checkbox" id="dawp_multilingual_active" name="dawp_settings[multilingual_active]" value="1" <?php checked( 1, $dawp_is_checked('multilingual_active', 0) ); ?> />
                        <label>Kích hoạt hệ thống đa ngôn ngữ dịch tay chuyên nghiệp (Tự động tắt Dịch tự động Google khi bật tính năng này).</label>
                    </td>
                </tr>
                <tr valign="top" class="dawp-multilingual-fields" style="<?php echo $dawp_is_checked('multilingual_active', 0) ? '' : 'display: none;'; ?>">
                    <th scope="row">Ngôn ngữ mặc định (Gốc)</th>
                    <td>
                        <?php 
                        $default_lang = isset($options['multilingual_default']) ? $options['multilingual_default'] : 'vi'; 
                        $supported_langs = [];
                        if ( class_exists( 'DAWP_Multilingual' ) ) {
                            foreach ( DAWP_Multilingual::get_supported_languages() as $code => $info ) {
                                $supported_langs[ $code ] = $info['name'];
                            }
                        }
                        ?>
                        <select name="dawp_settings[multilingual_default]" id="dawp_multilingual_default" style="min-width: 250px;">
                            <?php foreach ( $supported_langs as $code => $name ) : ?>
                                <option value="<?php echo esc_attr( $code ); ?>" <?php selected( $default_lang, $code ); ?>><?php echo esc_html( $name ); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </td>
                </tr>
                <tr valign="top" class="dawp-multilingual-fields" style="<?php echo $dawp_is_checked('multilingual_active', 0) ? '' : 'display: none;'; ?>">
                    <th scope="row">Các ngôn ngữ phụ hoạt động</th>
                    <td>
                        <?php 
                        $saved_langs = isset($options['multilingual_langs']) ? $options['multilingual_langs'] : [];
                        if ( ! is_array( $saved_langs ) ) {
                            $saved_langs = [];
                        }
                        ?>
                        <div style="max-height: 250px; overflow-y: auto; border: 1px solid #e2e8f0; padding: 15px; border-radius: 8px; background: #fff; max-width: 800px; display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 10px; margin-bottom: 10px;">
                            <?php foreach ( $supported_langs as $code => $name ) : 
                                if ( $code === $default_lang ) {
                                    continue;
                                }
                            ?>
                                <label style="display: inline-flex; align-items: center; gap: 8px; cursor: pointer; user-select: none;">
                                    <input type="checkbox" name="dawp_settings[multilingual_langs][]" value="<?php echo esc_attr( $code ); ?>" <?php checked( true, in_array( $code, $saved_langs, true ) ); ?> />
                                    <?php echo esc_html( $name ); ?>
                                </label>
                            <?php endforeach; ?>
                        </div>
                        <p class="description">Chọn các ngôn ngữ phụ bạn muốn hỗ trợ dịch nội dung trên website.</p>
                    </td>
                </tr>
                <tr valign="top" class="dawp-multilingual-fields" style="<?php echo $dawp_is_checked('multilingual_active', 0) ? '' : 'display: none;'; ?>">
                    <th scope="row">Kiểu hiển thị (Layout Style)</th>
                    <td>
                        <select name="dawp_settings[multilingual_layout]" id="dawp_multilingual_layout" style="min-width: 250px;">
                            <option value="floating" <?php selected( 'floating', isset($options['multilingual_layout']) ? $options['multilingual_layout'] : 'floating' ); ?>>Nút nổi góc màn hình (Floating Widget)</option>
                            <option value="inline" <?php selected( 'inline', isset($options['multilingual_layout']) ? $options['multilingual_layout'] : '' ); ?>>Chèn thủ công (Bằng Shortcode [dawp_languages])</option>
                        </select>
                    </td>
                </tr>
                <tr valign="top" class="dawp-multilingual-fields" id="dawp_multilingual_inline_style_row" style="<?php echo (isset($options['multilingual_layout']) && $options['multilingual_layout'] === 'inline') ? '' : 'display: none;'; ?>">
                    <th scope="row">Kiểu dáng Shortcode (Inline Style)</th>
                    <td>
                        <select name="dawp_settings[multilingual_inline_style]" style="min-width: 250px;">
                            <option value="dropdown-pill" <?php selected( 'dropdown-pill', isset($options['multilingual_inline_style']) ? $options['multilingual_inline_style'] : 'dropdown-pill' ); ?>>Dạng thả xuống - Viên thuốc (Dropdown Pill)</option>
                            <option value="dropdown-flat" <?php selected( 'dropdown-flat', isset($options['multilingual_inline_style']) ? $options['multilingual_inline_style'] : '' ); ?>>Dạng thả xuống - Phẳng tối giản (Dropdown Flat)</option>
                            <option value="flags" <?php selected( 'flags', isset($options['multilingual_inline_style']) ? $options['multilingual_inline_style'] : '' ); ?>>Dạng cờ quốc gia nằm ngang (Horizontal Flags)</option>
                        </select>
                        <p class="description">Chọn kiểu dáng hiển thị của shortcode <code>[dawp_languages]</code> khi chèn vào Menu hoặc Header. (Có thể ghi đè trong shortcode: <code>[dawp_languages style="flags"]</code>)</p>
                    </td>
                </tr>
                <tr valign="top" class="dawp-multilingual-fields" id="dawp_multilingual_position_row" style="<?php echo (!isset($options['multilingual_layout']) || $options['multilingual_layout'] === 'floating') ? '' : 'display: none;'; ?>">
                    <th scope="row">Vị trí hiển thị (Nút nổi)</th>
                    <td>
                        <select name="dawp_settings[multilingual_position]" style="min-width: 250px;">
                            <option value="right" <?php selected( 'right', isset($options['multilingual_position']) ? $options['multilingual_position'] : 'right' ); ?>>Dưới bên Phải (Bottom Right)</option>
                            <option value="left" <?php selected( 'left', isset($options['multilingual_position']) ? $options['multilingual_position'] : '' ); ?>>Dưới bên Trái (Bottom Left)</option>
                        </select>
                    </td>
                </tr>

                <tr valign="top" class="dawp-multilingual-fields" style="<?php echo $dawp_is_checked('multilingual_active', 0) ? '' : 'display: none;'; ?>">
                    <th scope="row">Bộ chuyển đổi ngôn ngữ (Shortcode)</th>
                    <td>
                        <div style="background: #f0f7ff; border-left: 4px solid #0068ff; padding: 12px 16px; border-radius: 0 8px 8px 0; max-width: 600px; margin-bottom: 10px;">
                            <p style="margin: 0 0 8px 0; font-weight: 600; color: #0056b3; font-size: 13.5px; display: flex; align-items: center; gap: 6px;">
                                <span class="dashicons dashicons-editor-code" style="color: #0056b3; font-size: 18px; width: 18px; height: 18px;"></span>
                                Cú pháp Shortcode chuyển đổi ngôn ngữ:
                            </p>
                            <ul style="margin: 0; padding-left: 20px; list-style-type: disc; font-size: 13px; color: #334155; line-height: 1.6;">
                                <li>Hiển thị dạng danh sách cờ ngang: <code>[dawp_languages]</code> hoặc <code>[dawp_languages style="flags"]</code></li>
                                <li style="margin-top: 4px;">Hiển thị dạng trình đơn thả xuống (Dropdown): <code>[dawp_languages style="dropdown"]</code></li>
                            </ul>
                        </div>
                    </td>
                </tr>

                <?php 
                if ( ! empty( $saved_langs ) ) : 
                    foreach ( $saved_langs as $lang_code ) : 
                        if ( $lang_code === $default_lang || ! isset( $supported_langs[ $lang_code ] ) ) continue;
                        $lang_name = $supported_langs[ $lang_code ];
                ?>
                    <tr valign="top" class="dawp-multilingual-fields" style="<?php echo $dawp_is_checked('multilingual_active', 0) ? '' : 'display: none;'; ?>; border-top: 1px solid #e5e5e5; background: #fbfbfb;">
                        <th scope="row" colspan="2" style="padding-bottom: 0;">
                            <h4 style="margin: 10px 0 0 0; color: #0068ff; font-size: 15px; display: flex; align-items: center; gap: 6px;">
                                <span class="dashicons dashicons-translation" style="color: #0068ff;"></span> Dịch văn bản hệ thống sang tiếng: <?php echo esc_html( $lang_name ); ?> (<?php echo esc_html( strtoupper($lang_code) ); ?>)
                            </h4>
                        </th>
                    </tr>
                    <tr valign="top" class="dawp-multilingual-fields" style="<?php echo $dawp_is_checked('multilingual_active', 0) ? '' : 'display: none;'; ?>; background: #fbfbfb;">
                        <th scope="row" style="padding-left: 20px; font-weight: 600;">1. Cấu hình SEO Trang chủ</th>
                        <td>
                            <div style="margin-bottom: 10px;">
                                <label style="display: block; font-size: 12px; color: #64748b; margin-bottom: 4px;">Tiêu đề SEO Trang chủ (Home Meta Title):</label>
                                <input type="text" name="dawp_settings[trans_seo_home_title_<?php echo $lang_code; ?>]" value="<?php echo esc_attr( isset($options['trans_seo_home_title_' . $lang_code]) ? $options['trans_seo_home_title_' . $lang_code] : '' ); ?>" class="regular-text" style="width: 100%; margin: 0;" />
                            </div>
                            <div>
                                <label style="display: block; font-size: 12px; color: #64748b; margin-bottom: 4px;">Mô tả SEO Trang chủ (Home Meta Description):</label>
                                <textarea name="dawp_settings[trans_seo_home_desc_<?php echo $lang_code; ?>]" rows="3" class="large-text" style="width: 100%; margin: 0;"><?php echo esc_textarea( isset($options['trans_seo_home_desc_' . $lang_code]) ? $options['trans_seo_home_desc_' . $lang_code] : '' ); ?></textarea>
                            </div>
                        </td>
                    </tr>
                    <tr valign="top" class="dawp-multilingual-fields" style="<?php echo $dawp_is_checked('multilingual_active', 0) ? '' : 'display: none;'; ?>; background: #fbfbfb;">
                        <th scope="row" style="padding-left: 20px; font-weight: 600;">2. Logo Website</th>
                        <td>
                            <div style="margin-bottom: 10px;">
                                <label style="display: block; font-size: 12px; color: #64748b; margin-bottom: 4px;">Logo mặc định (Site Logo):</label>
                                <div style="display: flex; gap: 10px; max-width: 600px;">
                                    <input type="text" name="dawp_settings[trans_site_logo_<?php echo $lang_code; ?>]" value="<?php echo esc_attr( isset($options['trans_site_logo_' . $lang_code]) ? $options['trans_site_logo_' . $lang_code] : '' ); ?>" style="flex: 1;" placeholder="https://domain.com/logo.png">
                                    <button type="button" class="button dawp-seo-select-media">Chọn ảnh</button>
                                </div>
                            </div>
                            <div style="margin-bottom: 10px;">
                                <label style="display: block; font-size: 12px; color: #64748b; margin-bottom: 4px;">Logo Sticky (Sticky Header Logo):</label>
                                <div style="display: flex; gap: 10px; max-width: 600px;">
                                    <input type="text" name="dawp_settings[trans_site_logo_sticky_<?php echo $lang_code; ?>]" value="<?php echo esc_attr( isset($options['trans_site_logo_sticky_' . $lang_code]) ? $options['trans_site_logo_sticky_' . $lang_code] : '' ); ?>" style="flex: 1;" placeholder="https://domain.com/logo-sticky.png">
                                    <button type="button" class="button dawp-seo-select-media">Chọn ảnh</button>
                                </div>
                            </div>
                            <div>
                                <label style="display: block; font-size: 12px; color: #64748b; margin-bottom: 4px;">Logo Dark (Dark Scheme Logo):</label>
                                <div style="display: flex; gap: 10px; max-width: 600px;">
                                    <input type="text" name="dawp_settings[trans_site_logo_dark_<?php echo $lang_code; ?>]" value="<?php echo esc_attr( isset($options['trans_site_logo_dark_' . $lang_code]) ? $options['trans_site_logo_dark_' . $lang_code] : '' ); ?>" style="flex: 1;" placeholder="https://domain.com/logo-dark.png">
                                    <button type="button" class="button dawp-seo-select-media">Chọn ảnh</button>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr valign="top" class="dawp-multilingual-fields" style="<?php echo $dawp_is_checked('multilingual_active', 0) ? '' : 'display: none;'; ?>; background: #fbfbfb;">
                        <th scope="row" style="padding-left: 20px; font-weight: 600;">3. Hotline, Zalo, Messenger & Bản đồ</th>
                        <td>
                            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 15px;">
                                <div>
                                    <label style="display: block; font-size: 12px; color: #64748b; margin-bottom: 4px;">Số Hotline di động (cho ngôn ngữ này):</label>
                                    <input type="text" name="dawp_settings[trans_hotline_<?php echo $lang_code; ?>]" value="<?php echo esc_attr( isset($options['trans_hotline_' . $lang_code]) ? $options['trans_hotline_' . $lang_code] : '' ); ?>" class="regular-text" style="width: 100%; margin: 0; box-sizing: border-box;" placeholder="Nhập số điện thoại hotline..." />
                                </div>
                                <div>
                                    <label style="display: block; font-size: 12px; color: #64748b; margin-bottom: 4px;">Nhãn nút Hotline (ví dụ: Gọi điện, Call Us):</label>
                                    <input type="text" name="dawp_settings[trans_hotline_lbl_<?php echo $lang_code; ?>]" value="<?php echo esc_attr( isset($options['trans_hotline_lbl_' . $lang_code]) ? $options['trans_hotline_lbl_' . $lang_code] : '' ); ?>" class="regular-text" style="width: 100%; margin: 0; box-sizing: border-box;" placeholder="Mặc định: Gọi điện / Call Us" />
                                </div>
                            </div>
                            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 15px;">
                                <div>
                                    <label style="display: block; font-size: 12px; color: #64748b; margin-bottom: 4px;">Số điện thoại Zalo (cho ngôn ngữ này):</label>
                                    <input type="text" name="dawp_settings[trans_zalo_<?php echo $lang_code; ?>]" value="<?php echo esc_attr( isset($options['trans_zalo_' . $lang_code]) ? $options['trans_zalo_' . $lang_code] : '' ); ?>" class="regular-text" style="width: 100%; margin: 0; box-sizing: border-box;" placeholder="Nhập số điện thoại Zalo..." />
                                </div>
                                <div>
                                    <label style="display: block; font-size: 12px; color: #64748b; margin-bottom: 4px;">Nhãn nút Zalo (ví dụ: Nhắn Zalo, Chat Zalo):</label>
                                    <input type="text" name="dawp_settings[trans_zalo_lbl_<?php echo $lang_code; ?>]" value="<?php echo esc_attr( isset($options['trans_zalo_lbl_' . $lang_code]) ? $options['trans_zalo_lbl_' . $lang_code] : '' ); ?>" class="regular-text" style="width: 100%; margin: 0; box-sizing: border-box;" placeholder="Mặc định: Nhắn Zalo / Chat Zalo" />
                                </div>
                            </div>
                            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 15px;">
                                <div>
                                    <label style="display: block; font-size: 12px; color: #64748b; margin-bottom: 4px;">Số điện thoại Whatsapp (cho ngôn ngữ này):</label>
                                    <input type="text" name="dawp_settings[trans_whatsapp_<?php echo $lang_code; ?>]" value="<?php echo esc_attr( isset($options['trans_whatsapp_' . $lang_code]) ? $options['trans_whatsapp_' . $lang_code] : '' ); ?>" class="regular-text" style="width: 100%; margin: 0; box-sizing: border-box;" placeholder="Nhập số điện thoại Whatsapp..." />
                                </div>
                                <div>
                                    <label style="display: block; font-size: 12px; color: #64748b; margin-bottom: 4px;">Nhãn nút Whatsapp (ví dụ: Chat Whatsapp):</label>
                                    <input type="text" name="dawp_settings[trans_whatsapp_lbl_<?php echo $lang_code; ?>]" value="<?php echo esc_attr( isset($options['trans_whatsapp_lbl_' . $lang_code]) ? $options['trans_whatsapp_lbl_' . $lang_code] : '' ); ?>" class="regular-text" style="width: 100%; margin: 0; box-sizing: border-box;" placeholder="Mặc định: Chat Whatsapp" />
                                </div>
                            </div>
                            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 15px;">
                                <div>
                                    <label style="display: block; font-size: 12px; color: #64748b; margin-bottom: 4px;">Đường dẫn Messenger (cho ngôn ngữ này):</label>
                                    <input type="text" name="dawp_settings[trans_messenger_<?php echo $lang_code; ?>]" value="<?php echo esc_attr( isset($options['trans_messenger_' . $lang_code]) ? $options['trans_messenger_' . $lang_code] : '' ); ?>" class="regular-text" style="width: 100%; margin: 0; box-sizing: border-box;" placeholder="vd: https://m.me/yourpage" />
                                </div>
                                <div>
                                    <label style="display: block; font-size: 12px; color: #64748b; margin-bottom: 4px;">Nhãn nút Messenger (ví dụ: Messenger):</label>
                                    <input type="text" name="dawp_settings[trans_messenger_lbl_<?php echo $lang_code; ?>]" value="<?php echo esc_attr( isset($options['trans_messenger_lbl_' . $lang_code]) ? $options['trans_messenger_lbl_' . $lang_code] : '' ); ?>" class="regular-text" style="width: 100%; margin: 0; box-sizing: border-box;" placeholder="Mặc định: Messenger" />
                                </div>
                            </div>
                            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                                <div>
                                    <label style="display: block; font-size: 12px; color: #64748b; margin-bottom: 4px;">Đường dẫn Bản đồ (cho ngôn ngữ này):</label>
                                    <input type="text" name="dawp_settings[trans_map_<?php echo $lang_code; ?>]" value="<?php echo esc_attr( isset($options['trans_map_' . $lang_code]) ? $options['trans_map_' . $lang_code] : '' ); ?>" class="regular-text" style="width: 100%; margin: 0; box-sizing: border-box;" placeholder="vd: https://maps.google.com/..." />
                                </div>
                                <div>
                                    <label style="display: block; font-size: 12px; color: #64748b; margin-bottom: 4px;">Nhãn nút Bản đồ (ví dụ: Chỉ đường, Directions):</label>
                                    <input type="text" name="dawp_settings[trans_map_lbl_<?php echo $lang_code; ?>]" value="<?php echo esc_attr( isset($options['trans_map_lbl_' . $lang_code]) ? $options['trans_map_lbl_' . $lang_code] : '' ); ?>" class="regular-text" style="width: 100%; margin: 0; box-sizing: border-box;" placeholder="Mặc định: Chỉ đường / Directions" />
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr valign="top" class="dawp-multilingual-fields" style="<?php echo $dawp_is_checked('multilingual_active', 0) ? '' : 'display: none;'; ?>; background: #fbfbfb; border-bottom: 1px solid #e5e5e5;">
                        <th scope="row" style="padding-left: 20px; font-weight: 600;">4. Chế độ bảo trì (Maintenance)</th>
                        <td>
                            <div style="margin-bottom: 10px;">
                                <label style="display: block; font-size: 12px; color: #64748b; margin-bottom: 4px;">Tiêu đề trang Bảo trì (Maintenance Title Tag):</label>
                                <input type="text" name="dawp_settings[trans_maintenance_title_<?php echo $lang_code; ?>]" value="<?php echo esc_attr( isset($options['trans_maintenance_title_' . $lang_code]) ? $options['trans_maintenance_title_' . $lang_code] : '' ); ?>" placeholder="Mặc định: Bảo trì hệ thống / System Maintenance" class="regular-text" style="width: 100%; margin: 0;" />
                            </div>
                            <div>
                                <label style="display: block; font-size: 12px; color: #64748b; margin-bottom: 4px;">Nội dung trang Bảo trì (Hỗ trợ chèn Ảnh/HTML):</label>
                                <textarea name="dawp_settings[trans_maintenance_content_<?php echo $lang_code; ?>]" rows="4" class="large-text" style="width: 100%; font-family: monospace; font-size: 13px; margin: 0;"><?php echo esc_textarea( isset($options['trans_maintenance_content_' . $lang_code]) ? $options['trans_maintenance_content_' . $lang_code] : '' ); ?></textarea>
                            </div>
                        </td>
                    </tr>
                <?php 
                    endforeach;
                endif; 
                ?>
                <tr valign="top" class="dawp-multilingual-fields" style="<?php echo $dawp_is_checked('multilingual_active', 0) ? '' : 'display: none;'; ?>; border-top: 1px solid #e5e5e5; background: #fff;">
                    <th scope="row" colspan="2" style="padding-top: 20px;">
                        <h4 style="margin: 0 0 10px 0; color: #0068ff; font-size: 15px; display: flex; align-items: center; gap: 6px;">
                            <span class="dashicons dashicons-editor-paragraph" style="color: #0068ff;"></span> 5. Dịch chuỗi tĩnh (Theme & Plugin Strings)
                        </h4>
                        <p class="description" style="margin-bottom: 15px;">Dịch các chuỗi chữ tĩnh trên giao diện (như các nút bấm, widget, tiêu đề tĩnh của theme...) bằng cách nhập chuỗi gốc tiếng Việt và bản dịch tương ứng.</p>
                        
                        <table class="widefat striped" id="dawp-multilingual-strings-table" style="max-width: 800px; margin-bottom: 10px;">
                            <thead>
                                <tr>
                                    <th style="font-weight: 600;">Chuỗi gốc tiếng Việt (Original String)</th>
                                    <?php foreach ( $saved_langs as $lang_code ) : 
                                        if ( $lang_code === $default_lang || ! isset( $supported_langs[ $lang_code ] ) ) continue;
                                    ?>
                                        <th style="font-weight: 600;">Bản dịch sang: <?php echo esc_html( $supported_langs[ $lang_code ] ); ?> (<?php echo esc_html( strtoupper($lang_code) ); ?>)</th>
                                    <?php endforeach; ?>
                                    <th style="width: 50px;"></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $saved_strings = isset($options['multilingual_strings']) ? (array)$options['multilingual_strings'] : [];
                                $row_index = 0;
                                foreach ( $saved_strings as $item ) : 
                                    if ( empty( $item['original'] ) ) continue;
                                ?>
                                    <tr data-index="<?php echo $row_index; ?>">
                                        <td>
                                            <input type="text" name="dawp_settings[multilingual_strings][<?php echo $row_index; ?>][original]" value="<?php echo esc_attr( $item['original'] ); ?>" style="width: 100%;" />
                                        </td>
                                        <?php foreach ( $saved_langs as $lang_code ) : 
                                            if ( $lang_code === $default_lang || ! isset( $supported_langs[ $lang_code ] ) ) continue;
                                            $val = isset( $item['translations'][ $lang_code ] ) ? $item['translations'][ $lang_code ] : '';
                                        ?>
                                            <td>
                                                <input type="text" name="dawp_settings[multilingual_strings][<?php echo $row_index; ?>][translations][<?php echo $lang_code; ?>]" value="<?php echo esc_attr( $val ); ?>" style="width: 100%;" />
                                            </td>
                                        <?php endforeach; ?>
                                        <td>
                                            <button type="button" class="button dawp-remove-string-row" style="color: #b32d2e; border-color: #b32d2e;"><span class="dashicons dashicons-no-alt" style="margin-top: 3px;"></span></button>
                                        </td>
                                    </tr>
                                <?php 
                                    $row_index++;
                                endforeach; 
                                ?>
                            </tbody>
                        </table>
                        <button type="button" class="button button-secondary" id="dawp-add-string-row" style="margin-top: 10px;">
                            <span class="dashicons dashicons-plus" style="margin-top: 3px; font-size: 16px;"></span> Thêm chuỗi cần dịch
                        </button>
                    </th>
                </tr>
            </table>
        </div>

        <!-- WOO COMMERCE REVIEWS TAB -->
        <div style="<?php echo $active_tab == 'woo-reviews' ? '' : 'display: none;'; ?>">
            <!-- 1. Review settings Card -->
            <div class="dawp-card" style="background: #fff; border-radius: 12px; padding: 25px; box-shadow: 0 4px 20px rgba(0,0,0,0.04); border: 1px solid #e1e8ed; margin-bottom: 30px;">
                <h3 style="margin-top: 0; color: #1d2327; font-size: 16px; border-bottom: 1px solid #f0f0f1; padding-bottom: 12px; display: flex; align-items: center; gap: 8px;">
                    <span class="dashicons dashicons-star-filled" style="color: #0068ff;"></span> Cấu hình Đánh giá sản phẩm thông minh
                </h3>
                <table class="form-table">
                    <tr valign="top">
                        <th scope="row">Bật Đánh giá sản phẩm</th>
                        <td>
                            <input type="hidden" name="dawp_settings[woo_reviews_active]" value="0" />
                            <input type="checkbox" name="dawp_settings[woo_reviews_active]" value="1" <?php checked( 1, $dawp_is_checked('woo_reviews_active', 0) ); ?> />
                            <p class="description">Thay thế tab đánh giá mặc định của WooCommerce bằng hệ thống đánh giá Premium siêu nhẹ, hỗ trợ đính kèm hình ảnh và nén WebP ngay tại trình duyệt client.</p>
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row">Tự động duyệt đánh giá</th>
                        <td>
                            <input type="hidden" name="dawp_settings[woo_reviews_auto_approve]" value="0" />
                            <input type="checkbox" name="dawp_settings[woo_reviews_auto_approve]" value="1" <?php checked( 1, $dawp_is_checked('woo_reviews_auto_approve', 1) ); ?> />
                            <p class="description">Nếu bật, đánh giá của khách hàng sẽ được hiển thị ngay lập tức. Nếu tắt, đánh giá sẽ hiển thị ở trạng thái Chờ duyệt.</p>
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row">Số ảnh đính kèm tối đa</th>
                        <td>
                            <select name="dawp_settings[woo_reviews_max_images]">
                                <?php
                                $max_img = (int) (isset($options['woo_reviews_max_images']) ? $options['woo_reviews_max_images'] : 3);
                                for ($i = 1; $i <= 10; $i++) {
                                    echo '<option value="' . $i . '" ' . selected($i, $max_img, false) . '>' . $i . ' ảnh</option>';
                                }
                                ?>
                            </select>
                            <p class="description">Giới hạn số lượng ảnh khách hàng có thể chọn tải lên trong một đánh giá.</p>
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row">Hệ thống lưu trữ đánh giá</th>
                        <td>
                            <?php
                            $db_type = isset($options['woo_reviews_database_type']) ? $options['woo_reviews_database_type'] : 'native';
                            ?>
                            <select name="dawp_settings[woo_reviews_database_type]">
                                <option value="native" <?php selected('native', $db_type); ?>>WordPress Gốc (Native - Khuyên dùng)</option>
                                <option value="custom" <?php selected('custom', $db_type); ?>>Bảng Tùy biến (Custom Table)</option>
                            </select>
                            <p class="description">Lựa chọn cách thức lưu trữ dữ liệu đánh giá sản phẩm. WordPress Gốc (Native) giúp đảm bảo tương thích 100% với các plugin tích điểm, đồng bộ, báo cáo doanh thu từ bên thứ ba.</p>
                        </td>
                    </tr>
                </table>
            </div>

            <!-- 2. Reviews Management Card -->
            <?php
            $is_reviews_active = $dawp_is_checked('woo_reviews_active', 0);
            ?>
            <div class="dawp-card" style="background: #fff; border-radius: 12px; padding: 25px; box-shadow: 0 4px 20px rgba(0,0,0,0.04); border: 1px solid #e1e8ed; position: relative;">
                <h3 style="margin-top: 0; color: #1d2327; font-size: 16px; border-bottom: 1px solid #f0f0f1; padding-bottom: 12px; display: flex; align-items: center; justify-content: space-between; gap: 8px; flex-wrap: wrap;">
                    <span style="display: flex; align-items: center; gap: 8px;">
                        <span class="dashicons dashicons-admin-comments" style="color: #0068ff;"></span> Quản lý các Đánh giá sản phẩm (Database riêng)
                    </span>
                    <?php if ( $is_reviews_active ) : ?>
                    <span style="display: flex; gap: 10px; margin-left: auto;">
                        <input type="text" id="dawp_search_reviews" placeholder="Tìm tên, email, nội dung..." style="padding: 4px 10px; font-size: 13px; border-radius: 4px; border: 1px solid #ccc; font-weight: normal;" />
                        <button type="button" id="dawp_clear_reviews_btn" class="button" style="height: auto; padding: 3px 12px; line-height: 1.8; color: #d63638; border-color: #d63638;">🗑️ Xóa sạch Đánh giá</button>
                    </span>
                    <?php endif; ?>
                </h3>

                <?php if ( ! $is_reviews_active ) : ?>
                    <div style="padding: 30px; text-align: center; color: #64748b; font-size: 14px; font-weight: 500;">
                        <span class="dashicons dashicons-warning" style="font-size: 36px; width: 36px; height: 36px; color: #fbbf24; margin-bottom: 10px; display: block; margin-left: auto; margin-right: auto;"></span>
                        Vui lòng kích hoạt và lưu cài đặt "Bật Đánh giá sản phẩm" phía trên để bắt đầu quản lý các đánh giá sản phẩm của bạn.
                    </div>
                <?php else : ?>
                    <!-- AJAX Action Result Alert -->
                    <div id="dawp_review_action_result" style="margin-bottom: 15px; font-weight: 500; font-size: 13px;"></div>

                    <div style="overflow-x: auto; margin-top: 15px;">
                        <table class="wp-list-table widefat fixed striped table-view-list" id="dawp_admin_reviews_table">
                            <thead>
                                <tr>
                                    <th style="width: 130px; font-weight: 600;">Ngày gửi</th>
                                    <th style="width: 150px; font-weight: 600;">Sản phẩm</th>
                                    <th style="width: 130px; font-weight: 600;">Họ tên / Email</th>
                                    <th style="width: 80px; font-weight: 600; text-align: center;">Số sao</th>
                                    <th style="font-weight: 600;">Nội dung đánh giá / Phản hồi</th>
                                    <th style="width: 120px; font-weight: 600;">Hình ảnh</th>
                                    <th style="width: 90px; font-weight: 600; text-align: center;">Trạng thái</th>
                                    <th style="width: 150px; font-weight: 600; text-align: center;">Hành động</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                global $wpdb;
                                $db_type = DAWP_Helpers::get_setting( 'woo_reviews_database_type', 'native' );
                                $admin_reviews = [];

                                if ( $db_type === 'native' ) {
                                    $results = $wpdb->get_results( 
                                        "SELECT c.comment_ID as id, 
                                                c.comment_post_ID as product_id,
                                                c.comment_author as name,
                                                c.comment_author_email as email,
                                                c.comment_content as content,
                                                c.comment_date as created_at,
                                                c.comment_approved as approved
                                         FROM {$wpdb->comments} c 
                                         WHERE c.comment_type = 'review' 
                                         ORDER BY c.comment_ID DESC LIMIT 200" 
                                    );
                                    
                                    foreach ( $results as $row ) {
                                        $comment_id = $row->id;
                                        $rating = get_comment_meta( $comment_id, 'rating', true );
                                        $images = get_comment_meta( $comment_id, 'dawp_images', true );
                                        
                                        $reply = $wpdb->get_row( $wpdb->prepare(
                                            "SELECT comment_content, comment_date FROM {$wpdb->comments} 
                                             WHERE comment_parent = %d AND comment_approved = '1' 
                                             ORDER BY comment_date ASC LIMIT 1",
                                            $comment_id
                                        ) );
                                        
                                        $row->rating = $rating ? (int)$rating : 5;
                                        $row->images = $images ? $images : '';
                                        $row->reply_content = $reply ? $reply->comment_content : '';
                                        $row->reply_date = $reply ? $reply->comment_date : '';
                                        $row->status = $row->approved === '1' ? 'approved' : 'pending';
                                        
                                        $admin_reviews[] = $row;
                                    }
                                } else {
                                    $reviews_table = $wpdb->prefix . 'dawp_reviews';
                                    if ( $wpdb->get_var("SHOW TABLES LIKE '$reviews_table'") == $reviews_table ) {
                                        $admin_reviews = $wpdb->get_results( "SELECT * FROM $reviews_table ORDER BY id DESC LIMIT 200" );
                                    }
                                }
                                
                                if ( empty($admin_reviews) ) :
                                ?>
                                    <tr class="no-reviews-row">
                                        <td colspan="8" style="text-align: center; color: #666; padding: 20px;">Chưa có đánh giá nào được ghi nhận.</td>
                                    </tr>
                                <?php else : foreach ( $admin_reviews as $r ) : 
                                    $p_title = get_the_title($r->product_id);
                                    $p_link = get_edit_post_link($r->product_id);
                                    $r_images = [];
                                    if ( ! empty($r->images) ) {
                                        $r_images = json_decode($r->images, true);
                                    }
                                    if ( ! is_array($r_images) ) $r_images = [];
                                ?>
                                    <tr class="review-row" data-id="<?php echo $r->id; ?>" data-search="<?php echo esc_attr(strtolower($r->name . ' ' . $r->email . ' ' . $r->content . ' ' . $p_title)); ?>">
                                        <td><?php echo date('d/m/Y H:i', strtotime($r->created_at)); ?></td>
                                        <td>
                                            <a href="<?php echo esc_url($p_link); ?>" target="_blank" style="font-weight: 600; text-decoration: none;">
                                                <?php echo esc_html($p_title ? $p_title : '#' . $r->product_id); ?>
                                            </a>
                                        </td>
                                        <td>
                                            <strong><?php echo esc_html($r->name); ?></strong><br>
                                            <span style="font-size: 11px; color: #64748b;"><?php echo esc_html($r->email); ?></span>
                                        </td>
                                        <td style="text-align: center; font-weight: bold; color: #fbbf24; font-size: 14px;">
                                            <?php echo $r->rating; ?> ★
                                        </td>
                                        <td>
                                            <div class="review-content-text" style="word-break: break-word; line-height: 1.4;"><?php echo nl2br(esc_html($r->content)); ?></div>
                                            
                                            <!-- Response Display -->
                                            <div class="review-reply-display" style="<?php echo empty($r->reply_content) ? 'display: none;' : ''; ?> background: #f1f5f9; border-left: 3px solid #64748b; padding: 6px 10px; margin-top: 8px; border-radius: 0 4px 4px 0; font-size: 12px; color: #475569;">
                                                <strong>Phản hồi:</strong> <span class="reply-text"><?php echo esc_html($r->reply_content); ?></span>
                                            </div>
                                            
                                            <!-- Response Form Box -->
                                            <div class="review-reply-form" style="display: none; margin-top: 10px;">
                                                <textarea class="reply-textarea" rows="2" style="width: 100%; font-size: 12px; padding: 5px; border-radius: 4px;" placeholder="Nhập câu trả lời phản hồi khách hàng..."><?php echo esc_textarea($r->reply_content); ?></textarea>
                                                <div style="margin-top: 5px; display: flex; gap: 5px;">
                                                    <button type="button" class="button button-primary button-small save-reply-btn">Lưu</button>
                                                    <button type="button" class="button button-secondary button-small cancel-reply-btn">Hủy</button>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <?php if ( ! empty($r_images) ) : ?>
                                                <div style="display: flex; flex-wrap: wrap; gap: 4px;">
                                                    <?php foreach ( $r_images as $img ) : ?>
                                                        <a href="<?php echo esc_url($img['url']); ?>" target="_blank" style="width: 35px; height: 35px; border: 1px solid #ddd; border-radius: 4px; overflow: hidden; display: block;">
                                                            <img src="<?php echo esc_url($img['url']); ?>" style="width: 100%; height: 100%; object-fit: cover;" />
                                                        </a>
                                                    <?php endforeach; ?>
                                                </div>
                                            <?php else : ?>
                                                <span style="color: #94a3b8; font-size: 11px;">Không có ảnh</span>
                                            <?php endif; ?>
                                        </td>
                                        <td style="text-align: center;">
                                            <span class="status-badge" style="display: inline-block; padding: 2px 8px; border-radius: 4px; font-size: 11px; font-weight: 600; <?php echo $r->status === 'approved' ? 'background: #ecfdf5; color: #065f46;' : 'background: #fffbeb; color: #92400e;'; ?>">
                                                <?php echo $r->status === 'approved' ? 'Đã duyệt' : 'Chờ duyệt'; ?>
                                            </span>
                                        </td>
                                        <td>
                                            <div style="display: flex; flex-wrap: wrap; gap: 5px; justify-content: center;">
                                                <button type="button" class="button button-small toggle-status-btn" style="min-width: 65px;"><?php echo $r->status === 'approved' ? 'Ẩn' : 'Duyệt'; ?></button>
                                                <button type="button" class="button button-small reply-btn">Trả lời</button>
                                                <button type="button" class="button button-small delete-review-btn" style="color: #d63638; border-color: #d63638;">Xóa</button>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; endif; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <!-- FONT AWESOME TAB -->
        <div style="<?php echo $active_tab == 'font-awesome' ? '' : 'display: none;'; ?>">
            <div class="dawp-card" style="background: #fff; border-radius: 12px; padding: 25px; box-shadow: 0 4px 20px rgba(0,0,0,0.04); border: 1px solid #e1e8ed; margin-bottom: 30px;">
                <h3 style="margin-top: 0; color: #1d2327; font-size: 16px; border-bottom: 1px solid #f0f0f1; padding-bottom: 12px; display: flex; align-items: center; gap: 8px;">
                    <span class="dashicons dashicons-editor-customchar" style="color: #0068ff;"></span> Tích hợp Thư viện Icon Font Awesome (Offline)
                </h3>
                <table class="form-table">
                    <tr valign="top">
                        <th scope="row">Bật Font Awesome 7</th>
                        <td>
                            <input type="hidden" name="dawp_settings[font_awesome_active]" value="0" />
                            <input type="checkbox" name="dawp_settings[font_awesome_active]" value="1" <?php checked( 1, $dawp_is_checked('font_awesome_active', 1) ); ?> />
                            <label>Tải và nạp thư viện biểu tượng Font Awesome 7 Free Web dạng Offline (lưu cục bộ trên host của bạn) giúp hiển thị biểu tượng mượt mà, độc lập 100% không sợ đứt cáp.</label>
                        </td>
                    </tr>
                </table>
            </div>

            <!-- Hướng dẫn sử dụng Card -->
            <div class="dawp-card" style="background: #fff; border-radius: 12px; padding: 25px; box-shadow: 0 4px 20px rgba(0,0,0,0.04); border: 1px solid #e1e8ed;">
                <h3 style="margin-top: 0; color: #1d2327; font-size: 16px; border-bottom: 1px solid #f0f0f1; padding-bottom: 12px; display: flex; align-items: center; gap: 8px;">
                    <span class="dashicons dashicons-editor-help" style="color: #0068ff;"></span> Hướng dẫn sử dụng Icon Font Awesome
                </h3>
                <div style="font-size: 13.5px; line-height: 1.6; color: #475569;">
                    <p>Khi Font Awesome đã được kích hoạt, bạn có thể dễ dàng chèn bất kỳ biểu tượng nào vào bài viết, trang, Flatsome UX Builder hoặc các mục Menu điều hướng (Giao diện -> Menu) bằng cách sử dụng các thẻ HTML của Font Awesome.</p>
                    
                    <h4 style="color: #1e293b; margin-top: 20px; margin-bottom: 8px; font-weight: 600;">Cú pháp cơ bản:</h4>
                    <pre style="background: #f1f5f9; padding: 10px 15px; border-radius: 6px; font-family: monospace; font-size: 13px; color: #0f172a; overflow-x: auto;">&lt;i class="fa-solid fa-[tên-icon]"&gt;&lt;/i&gt;</pre>
                    
                    <h4 style="color: #1e293b; margin-top: 20px; margin-bottom: 8px; font-weight: 600;">Các ví dụ phổ biến thường dùng:</h4>
                    <table class="wp-list-table widefat fixed striped table-view-list" style="margin-top: 10px;">
                        <thead>
                            <tr>
                                <th style="width: 80px; font-weight: 600;">Hiển thị</th>
                                <th style="width: 250px; font-weight: 600;">Đoạn mã HTML chèn</th>
                                <th style="font-weight: 600;">Ứng dụng phù hợp</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td><i class="fa-solid fa-house" style="color: #0068ff; font-size: 16px;"></i></td>
                                <td><code>&lt;i class="fa-solid fa-house"&gt;&lt;/i&gt; Trang chủ</code></td>
                                <td>Chèn vào nút Trang chủ trên Menu chính</td>
                            </tr>
                            <tr>
                                <td><i class="fa-solid fa-phone" style="color: #16a34a; font-size: 16px;"></i></td>
                                <td><code>&lt;i class="fa-solid fa-phone"&gt;&lt;/i&gt; Liên hệ</code></td>
                                <td>Chèn cạnh chữ Liên hệ / Số điện thoại</td>
                            </tr>
                            <tr>
                                <td><i class="fa-solid fa-envelope" style="color: #ea580c; font-size: 16px;"></i></td>
                                <td><code>&lt;i class="fa-solid fa-envelope"&gt;&lt;/i&gt; Email</code></td>
                                <td>Chèn cạnh địa chỉ hòm thư điện tử</td>
                            </tr>
                            <tr>
                                <td><i class="fa-solid fa-location-dot" style="color: #dc2626; font-size: 16px;"></i></td>
                                <td><code>&lt;i class="fa-solid fa-location-dot"&gt;&lt;/i&gt; Bản đồ</code></td>
                                <td>Chèn cạnh địa chỉ văn phòng, cửa hàng</td>
                            </tr>
                            <tr>
                                <td><i class="fa-solid fa-star" style="color: #eab308; font-size: 16px;"></i></td>
                                <td><code>&lt;i class="fa-solid fa-star"&gt;&lt;/i&gt; Đánh giá</code></td>
                                <td>Biểu tượng ngôi sao xếp hạng</td>
                            </tr>
                            <tr>
                                <td><i class="fa-brands fa-facebook" style="color: #1877f2; font-size: 16px;"></i></td>
                                <td><code>&lt;i class="fa-brands fa-facebook"&gt;&lt;/i&gt; Facebook</code></td>
                                <td>Biểu tượng mạng xã hội Facebook (Brands)</td>
                            </tr>
                            <tr>
                                <td><i class="fa-brands fa-youtube" style="color: #ff0000; font-size: 16px;"></i></td>
                                <td><code>&lt;i class="fa-brands fa-youtube"&gt;&lt;/i&gt; Youtube</code></td>
                                <td>Biểu tượng mạng xã hội Youtube (Brands)</td>
                            </tr>
                        </tbody>
                    </table>
                    
                    <p style="margin-top: 15px; font-weight: 500;">💡 <strong>Mẹo tìm thêm Icon khác:</strong> Bạn có thể truy cập trang chủ của <a href="https://fontawesome.com/search?o=r&m=free" target="_blank" rel="noopener noreferrer">Font Awesome Free Search</a> để tìm thêm hàng ngàn icon miễn phí khác và copy đoạn mã của chúng.</p>
                </div>
            </div>
        </div>

        <!-- MAINTENANCE TAB -->
        <div style="<?php echo $active_tab == 'maintenance' ? '' : 'display: none;'; ?>">
            <!-- 1. Trình Soạn Thảo Cổ Điển -->
            <div class="dawp-card" style="background: #fff; border-radius: 12px; padding: 25px; box-shadow: 0 4px 20px rgba(0,0,0,0.04); border: 1px solid #e1e8ed; margin-bottom: 30px;">
                <h3 style="margin-top: 0; color: #1d2327; font-size: 16px; border-bottom: 1px solid #f0f0f1; padding-bottom: 12px; display: flex; align-items: center; gap: 8px;">
                    <span class="dashicons dashicons-editor-customchar" style="color: #0068ff;"></span> Cấu hình Trình soạn thảo trực quan nâng cao
                </h3>
                <table class="form-table">
                    <tr valign="top">
                        <th scope="row">Bật Trình soạn thảo DAW Pro (Soạn thảo nâng cao)</th>
                        <td>
                            <input type="hidden" name="dawp_settings[classic_editor_active]" value="0" />
                            <input type="checkbox" name="dawp_settings[classic_editor_active]" value="1" <?php checked( 1, $dawp_is_checked('classic_editor_active', 1) ); ?> />
                            <label>Tắt Block Editor mặc định, kích hoạt trình soạn thảo trực quan nâng cao kèm đầy đủ bộ công cụ định dạng (bảng, font, màu sắc, dãn dòng).</label>
                        </td>
                    </tr>
                </table>
            </div>

            <!-- 2. Chế Độ Bảo Trì -->
            <div class="dawp-card" style="background: #fff; border-radius: 12px; padding: 25px; box-shadow: 0 4px 20px rgba(0,0,0,0.04); border: 1px solid #e1e8ed;">
                <h3 style="margin-top: 0; color: #1d2327; font-size: 16px; border-bottom: 1px solid #f0f0f1; padding-bottom: 12px; display: flex; align-items: center; gap: 8px;">
                    <span class="dashicons dashicons-hammer" style="color: #0068ff;"></span> Chế độ Bảo trì Website
                </h3>
                <table class="form-table">
                    <tr valign="top">
                        <th scope="row">Bật Chế độ Bảo trì</th>
                        <td>
                            <input type="hidden" name="dawp_settings[maintenance_active]" value="0" />
                            <input type="checkbox" name="dawp_settings[maintenance_active]" value="1" <?php checked( 1, $dawp_is_checked('maintenance_active', 0) ); ?> />
                            <label>Kích hoạt Màn hình Bảo trì. Khách truy cập sẽ nhìn thấy nội dung thông báo bên dưới, còn Admin vẫn có thể vào web bình thường.</label>
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row">Nội dung thông báo (Hỗ trợ chèn Ảnh/HTML)</th>
                        <td>
                            <?php
                            $maintenance_content = isset( $options['maintenance_content'] ) ? $options['maintenance_content'] : "<h1>Website đang bảo trì</h1>\n<p>Chúng tôi đang tiến hành nâng cấp hệ thống. Vui lòng quay lại sau ít phút.</p>";
                            ?>
                            <textarea name="dawp_settings[maintenance_content]" rows="6" class="large-text" style="width: 100%; max-width: 800px;"><?php echo esc_textarea( $maintenance_content ); ?></textarea>
                            <p class="description">Bạn có thể dùng HTML (như thẻ &lt;h1&gt;, &lt;p&gt;, &lt;img&gt;) để tự trang trí nội dung. Hoặc đơn giản là cứ gõ văn bản bình thường vào đây.</p>
                        </td>
                    </tr>
                </table>
            </div>

        </div>

        <!-- PAGESPEED TAB -->
        <div style="<?php echo $active_tab == 'pagespeed' ? '' : 'display: none;'; ?>">
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">Bật Module Tốc độ</th>
                    <td>
                        <input type="hidden" name="dawp_settings[pagespeed_active]" value="0" />
                        <input type="checkbox" name="dawp_settings[pagespeed_active]" value="1" <?php checked( 1, $dawp_is_checked('pagespeed_active', 1) ); ?> />
                        <label>Kích hoạt các thuật toán tối ưu tốc độ tải thực tế và trải nghiệm người dùng.</label>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Tối ưu LCP (Tải trước ảnh chính)</th>
                    <td>
                        <input type="hidden" name="dawp_settings[ps_lcp_opt]" value="0" />
                        <input type="checkbox" name="dawp_settings[ps_lcp_opt]" value="1" <?php checked( 1, $dawp_is_checked('ps_lcp_opt', 1) ); ?> />
                        <label>Tự động preload (tải trước) ảnh LCP đầu tiên và tắt lazy-load cho 3 ảnh trên cùng bằng API gốc của WordPress. Giúp trang hiển thị nội dung chính siêu tốc.</label>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Tải Font nội bộ (Local Fonts)</th>
                    <td>
                        <input type="hidden" name="dawp_settings[ps_local_fonts]" value="0" />
                        <input type="checkbox" name="dawp_settings[ps_local_fonts]" value="1" <?php checked( 1, $dawp_is_checked('ps_local_fonts', 1) ); ?> />
                        <label>Tải các tệp Google Fonts về lưu trữ cục bộ trên máy chủ. Tự động thêm <code>font-display: swap</code> giúp giải quyết triệt để lỗi chặn hiển thị chữ và cải thiện TTFB.</label>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Chuyển đổi WebP Máy khách</th>
                    <td>
                        <input type="hidden" name="dawp_settings[ps_client_webp]" value="0" />
                        <input type="checkbox" name="dawp_settings[ps_client_webp]" value="1" <?php checked( 1, $dawp_is_checked('ps_client_webp', 1) ); ?> />
                        <label>Tự động nén và chuyển đổi hình ảnh JPG/PNG thành WebP ngay trên trình duyệt của máy khách (Client-side) trước khi tải lên. Giúp tiết kiệm băng thông upload và giải phóng 100% tài nguyên xử lý nén của máy chủ.</label>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Chất lượng nén WebP</th>
                    <td>
                        <?php $ps_webp_quality = isset($options['ps_webp_quality']) ? $options['ps_webp_quality'] : 'high'; ?>
                        <select name="dawp_settings[ps_webp_quality]">
                            <option value="high" <?php selected( $ps_webp_quality, 'high' ); ?>>Sắc nét (Chất lượng cao - Mặc định)</option>
                            <option value="ultra" <?php selected( $ps_webp_quality, 'ultra' ); ?>>Cực sắc nét (Chất lượng cực cao)</option>
                            <option value="super" <?php selected( $ps_webp_quality, 'super' ); ?>>Siêu sắc nét (Chất lượng siêu cao/Giữ gốc)</option>
                        </select>
                        <br/>
                        <label class="description">Điều chỉnh mức độ nén và độ nét của ảnh khi chuyển đổi ở máy khách. Mặc định là Sắc nét. Chọn các cấp độ cao hơn nếu bạn hoặc khách hàng yêu cầu ảnh hiển thị cực kỳ sắc nét.</label>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Nén PDF Máy khách</th>
                    <td>
                        <input type="hidden" name="dawp_settings[ps_client_pdf]" value="0" />
                        <input type="checkbox" name="dawp_settings[ps_client_pdf]" value="1" <?php checked( 1, $dawp_is_checked('ps_client_pdf', 1) ); ?> />
                        <label>Tự động trích xuất và nén hình ảnh nhúng bên trong tệp PDF (giữ nguyên cấu trúc chữ và link liên kết) tại trình duyệt máy khách trước khi tải lên. Giúp giảm dung lượng PDF cực kỳ nhiều mà không làm nặng máy chủ.</label>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Xóa rác Emojis</th>
                    <td>
                        <input type="hidden" name="dawp_settings[ps_remove_emojis]" value="0" />
                        <input type="checkbox" name="dawp_settings[ps_remove_emojis]" value="1" <?php checked( 1, $dawp_is_checked('ps_remove_emojis', 1) ); ?> />
                        <label>Ngăn chặn tải tệp wp-emoji-release.min.js không cần thiết, giải phóng đường truyền mạng.</label>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Dọn dẹp thẻ Header (Clean Head)</th>
                    <td>
                        <input type="hidden" name="dawp_settings[ps_clean_header]" value="0" />
                        <input type="checkbox" name="dawp_settings[ps_clean_header]" value="1" <?php checked( 1, $dawp_is_checked('ps_clean_header', 1) ); ?> />
                        <label>Xóa các thẻ metadata rác trong phần <code>&lt;head&gt;</code> của mã HTML giúp trình duyệt parse DOM nhanh hơn.</label>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Khử trùng lặp Font Awesome</th>
                    <td>
                        <input type="hidden" name="dawp_settings[ps_dedupe_fa]" value="0" />
                        <input type="checkbox" name="dawp_settings[ps_dedupe_fa]" value="1" <?php checked( 1, $dawp_is_checked('ps_dedupe_fa', 1) ); ?> />
                        <label>Tự động phát hiện và loại bỏ các file CSS Font Awesome trùng lặp được nạp đồng thời từ nhiều plugin.</label>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Giới hạn Timeout HTTP ngoại vi</th>
                    <td>
                        <input type="hidden" name="dawp_settings[ps_http_timeout]" value="0" />
                        <input type="checkbox" name="dawp_settings[ps_http_timeout]" value="1" <?php checked( 1, $dawp_is_checked('ps_http_timeout', 1) ); ?> />
                        <label>Ép thời gian chờ (Timeout) tối đa khi kết nối gọi API bên ngoài là 3 giây. Ngăn chặn việc website bị treo khi các API bên thứ ba bị nghẽn mạng.</label>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Chống kẹt Preloader (Failsafe)</th>
                    <td>
                        <input type="hidden" name="dawp_settings[ps_failsafe]" value="0" />
                        <input type="checkbox" name="dawp_settings[ps_failsafe]" value="1" <?php checked( 1, $dawp_is_checked('ps_failsafe', 1) ); ?> />
                        <label>Tự động giải phóng màn hình và hiển thị trang web sau 2.5 giây nếu hiệu ứng xoay tròn tải trang (Preloader của Flatsome hoặc các plugin khác) bị kẹt do lỗi JS hoặc tải chậm.</label>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Số ảnh bỏ qua Lazyload (Above Fold)</th>
                    <td>
                        <input type="number" name="dawp_settings[ps_skip_img_count]" value="<?php echo esc_attr( isset($options['ps_skip_img_count']) ? $options['ps_skip_img_count'] : '3' ); ?>" class="small-text" style="width: 80px;" min="0" /> ảnh
                        <p class="description">Số lượng hình ảnh đầu tiên ở thân bài viết (body) sẽ tự động được bỏ qua lazyload. Mặc định là 3 ảnh (Khuyên dùng: 3 - 5).</p>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Ảnh LCP cần Preload (Desktop)</th>
                    <td>
                        <input type="text" name="dawp_settings[ps_preload_lcp_desktop]" value="<?php echo esc_attr( isset($options['ps_preload_lcp_desktop']) ? $options['ps_preload_lcp_desktop'] : '' ); ?>" class="regular-text" placeholder="Tự động phát hiện nếu bỏ trống..." />
                        <p class="description"><strong>(Tự động phát hiện)</strong> Bạn có thể bỏ trống, hệ thống DAW Pro sẽ tự động phát hiện hình ảnh nổi bật/banner đầu tiên của website để preload trên máy tính. Chỉ điền khi bạn muốn ép buộc tải một ảnh cụ thể.</p>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Ảnh LCP cần Preload (Mobile)</th>
                    <td>
                        <input type="text" name="dawp_settings[ps_preload_lcp_mobile]" value="<?php echo esc_attr( isset($options['ps_preload_lcp_mobile']) ? $options['ps_preload_lcp_mobile'] : '' ); ?>" class="regular-text" placeholder="Tự động phát hiện nếu bỏ trống..." />
                        <p class="description"><strong>(Tự động phát hiện)</strong> Tương tự như Desktop, hệ thống sẽ tự động phát hiện ảnh LCP trên điện thoại. Chỉ điền khi bạn muốn chỉ định đường dẫn ảnh cụ thể cho di động.</p>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Từ khóa bỏ qua Lazyload ảnh</th>
                    <td>
                        <textarea name="dawp_settings[ps_lazy_exclude]" rows="3" class="large-text" placeholder="Ví dụ: my-custom-class, specific-banner.jpg (mỗi từ khóa 1 dòng)"><?php echo esc_textarea( isset($options['ps_lazy_exclude']) ? $options['ps_lazy_exclude'] : '' ); ?></textarea>
                        <p class="description"><strong>(Tự động loại trừ)</strong> Các từ khóa logo, icon, avatar, brand, loader, preloader, cart, payment, v.v. đã được hệ thống tự động loại trừ khỏi lazyload để tránh lỗi giao diện. Bạn chỉ cần điền thêm từ khóa tùy chỉnh của riêng bạn nếu cần.</p>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Lazy-load Iframe (Nhúng sớm)</th>
                    <td>
                        <input type="hidden" name="dawp_settings[ps_lazy_iframe]" value="0" />
                        <input type="checkbox" name="dawp_settings[ps_lazy_iframe]" value="1" <?php checked( 1, $dawp_is_checked('ps_lazy_iframe', 1) ); ?> />
                        <label>Tự động thêm <code>loading="lazy"</code> cho các thẻ iframe và trì hoãn tải các iframe nằm ngoài màn hình đầu tiên (above-the-fold) bằng công nghệ IntersectionObserver. Giúp tăng điểm hiển thị nội dung chính.</label>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Facade YouTube/Google Maps</th>
                    <td>
                        <input type="hidden" name="dawp_settings[ps_video_facade]" value="0" />
                        <input type="checkbox" name="dawp_settings[ps_video_facade]" value="1" <?php checked( 1, $dawp_is_checked('ps_video_facade', 0) ); ?> />
                        <label>Thay thế các iframe YouTube hoặc Google Maps nặng nề bằng ảnh đại diện (thumbnail) hoặc nút nhấp nhẹ. Chỉ khi người dùng nhấp vào thì mới tải iframe thật. Giúp giảm tới 90% lượng tải ban đầu.</label>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Nén Brotli cấu hình máy chủ</th>
                    <td>
                        <input type="hidden" name="dawp_settings[ps_brotli]" value="0" />
                        <input type="checkbox" name="dawp_settings[ps_brotli]" value="1" <?php checked( 1, $dawp_is_checked('ps_brotli', 1) ); ?> />
                        <label>Tự động chèn cấu hình nén Brotli vào tệp tin <code>.htaccess</code> (nếu máy chủ hỗ trợ). Brotli nén dung lượng text (HTML, CSS, JS) nhỏ hơn 20-30% so với Gzip truyền thống.</label>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Gỡ bỏ jQuery Migrate</th>
                    <td>
                        <input type="hidden" name="dawp_settings[ps_remove_jquery_migrate]" value="0" />
                        <input type="checkbox" name="dawp_settings[ps_remove_jquery_migrate]" value="1" <?php checked( 1, $dawp_is_checked('ps_remove_jquery_migrate', 0) ); ?> />
                        <label>Gỡ bỏ tệp tin <code>jquery-migrate.min.js</code> ngoài frontend. Lưu ý: Chỉ bật khi theme/plugin của bạn không sử dụng các hàm jQuery cũ (kiểm tra Console để tránh lỗi).</label>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Tải trước thông minh (Speculation Rules)</th>
                    <td>
                        <input type="hidden" name="dawp_settings[ps_speculation]" value="0" />
                        <input type="checkbox" name="dawp_settings[ps_speculation]" value="1" <?php checked( 1, $dawp_is_checked('ps_speculation', 1) ); ?> />
                        <label>Kích hoạt Speculation Rules API mới của Google Chrome, tự động chạy prerender (tải trước và dựng sẵn trang ngầm) khi người dùng di chuột chuẩn bị nhấp liên kết, đem lại tốc độ mở trang 0ms thực tế. Tự động loại trừ các trang nhạy cảm như giỏ hàng, thanh toán và quản trị viên.</label>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Domain preconnect thêm</th>
                    <td>
                        <textarea name="dawp_settings[ps_preconnect_domains]" rows="3" class="large-text" placeholder="Ví dụ: https://www.google-analytics.com, https://fonts.googleapis.com (mỗi domain 1 dòng)"><?php echo esc_textarea( isset($options['ps_preconnect_domains']) ? $options['ps_preconnect_domains'] : '' ); ?></textarea>
                        <p class="description">Các domain bên thứ ba mà website của bạn thực sự kết nối tới (Maps, Analytics, Fonts...). Hệ thống sẽ in thẻ <code>&lt;link rel="preconnect"&gt;</code> giúp trình duyệt tối ưu phân giải DNS và bắt tay kết nối trước khi tải tài nguyên.</p>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Bật font-display: swap cho Font biểu tượng</th>
                    <td>
                        <input type="hidden" name="dawp_settings[ps_icon_font_swap]" value="0" />
                        <input type="checkbox" name="dawp_settings[ps_icon_font_swap]" value="1" <?php checked( 1, $dawp_is_checked('ps_icon_font_swap', 1) ); ?> />
                        <label>Tự động thêm thuộc tính <code>font-display: swap</code> vào các phông biểu tượng phổ biến (như Flatsome Icons, Font Awesome) để hiển thị văn bản ngay lập tức, khắc phục triệt để lỗi FCP và chặn kết xuất chữ (FOIT).</label>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Nén gọn mã CSS Inline (Minify Inline CSS)</th>
                    <td>
                        <input type="hidden" name="dawp_settings[ps_minify_inline]" value="0" />
                        <input type="checkbox" name="dawp_settings[ps_minify_inline]" value="1" <?php checked( 1, $dawp_is_checked('ps_minify_inline', 1) ); ?> />
                        <label>Tự động loại bỏ chú thích, khoảng trắng và thu gọn các mã CSS inline do chính plugin Duy Anh Web Pro sinh ra trước khi kết xuất, giúp tối ưu hóa dung lượng HTML.</label>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Trì hoãn tải Scripts thông minh (Smart Defer)</th>
                    <td>
                        <input type="hidden" name="dawp_settings[ps_defer_scripts]" value="0" />
                        <input type="checkbox" name="dawp_settings[ps_defer_scripts]" value="1" <?php checked( 1, $dawp_is_checked('ps_defer_scripts', 0) ); ?> />
                        <label>Thêm <code>defer</code> cho <strong>mọi</strong> script chặn kết xuất — kể cả jQuery và WooCommerce — để trang hiện chữ và ảnh trước, script chạy sau. Đây là thứ tách biệt điểm mobile với desktop: trên điện thoại (CPU chậm 4 lần) 10-15 script trong <code>&lt;head&gt;</code> tốn 2-3 giây trước khi thấy gì. Mọi đoạn mã inline có dùng <code>jQuery</code>/<code>$</code> được tự bọc lại để chờ jQuery sẵn sàng, nên theme cũ vẫn chạy đúng. Sau khi bật hãy duyệt thử menu, slider, giỏ hàng.</label>
                        <p style="margin-top:8px;"><strong>Loại trừ</strong> (script khớp dòng nào dưới đây giữ nguyên, không defer — dùng khi một script cụ thể cần chạy ngay):</p>
                        <textarea name="dawp_settings[ps_defer_exclude]" rows="2" class="large-text" placeholder="Ví dụ: ten-script-can-chay-ngay.js"><?php echo esc_textarea( isset($options['ps_defer_exclude']) ? $options['ps_defer_exclude'] : '' ); ?></textarea>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Tự bổ sung srcset cho ảnh nền / hero</th>
                    <td>
                        <input type="hidden" name="dawp_settings[ps_img_srcset]" value="0" />
                        <input type="checkbox" name="dawp_settings[ps_img_srcset]" value="1" <?php checked( 1, $dawp_is_checked('ps_img_srcset', 1) ); ?> />
                        <label>Page builder (Flatsome, Elementor, Bricks...) hay in ảnh nền hero bằng thẻ <code>&lt;img&gt;</code> <strong>không có srcset</strong> — điện thoại 400px buộc phải tải và giải mã ảnh gốc 4000px, gây LCP hàng chục giây dù tệp WebP rất nhẹ. Tính năng này tự tra thư viện và ghép <code>srcset</code>/<code>sizes</code> từ các bản thu nhỏ WordPress đã tạo, để trình duyệt tự chọn cỡ vừa màn hình. Chỉ thêm thuộc tính, không đổi ảnh gốc, không thay đổi hình hiển thị.</label>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Bỏ qua dựng hình phần dưới màn hình đầu</th>
                    <td>
                        <input type="hidden" name="dawp_settings[ps_content_visibility]" value="0" />
                        <input type="checkbox" name="dawp_settings[ps_content_visibility]" value="1" <?php checked( 1, $dawp_is_checked('ps_content_visibility', 1) ); ?> />
                        <label>Gắn <code>content-visibility: auto</code> cho các section từ thứ 3 trở đi (Flatsome <code>section.section</code>, Bricks <code>section.brxe-section</code>): trình duyệt bỏ qua tính toán style/layout/vẽ của phần dưới màn hình đầu cho tới khi cuộn tới gần — cắt thẳng 1-2 giây "Style &amp; Layout" trên điện thoại. Nội dung vẫn nguyên trong HTML (SEO, tìm kiếm, đọc màn hình không ảnh hưởng). Tắt nếu trang có hiệu ứng cuộn đặc biệt bị lệch.</label>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Ảnh quá khổ trong thư viện</th>
                    <td>
                        <p class="description" style="margin-top:0;">Ảnh <strong>rộng hơn 2560px</strong> chẳng có ích gì cho web nhưng làm điện thoại giải mã rất chậm khi được dùng làm ảnh nền/hero. Quét để tìm và thu về bề rộng 1920px (giữ nguyên tỷ lệ, chất lượng 85 — ảnh chụp toàn trang dài vẫn nguyên độ dài tương ứng). <strong style="color:#b32d2e;">Thu nhỏ là ghi đè ảnh gốc, không hoàn tác được</strong> — hãy chắc chắn anh không cần bản in khổ lớn của ảnh đó.</p>
                        <p>
                            <button type="button" class="button" id="dawp-bigimg-scan" data-nonce="<?php echo esc_attr( wp_create_nonce( 'dawp_big_images' ) ); ?>">Quét ảnh quá khổ</button>
                            <span id="dawp-bigimg-status" style="margin-left:8px;color:#666;"></span>
                        </p>
                        <div id="dawp-bigimg-list"></div>
                        <script>
                        (function(){
                            var scan = document.getElementById('dawp-bigimg-scan');
                            if (!scan) return;
                            var status = document.getElementById('dawp-bigimg-status');
                            var list = document.getElementById('dawp-bigimg-list');
                            var nonce = scan.getAttribute('data-nonce');
                            function post(action, data){
                                var fd = new FormData(); fd.append('action', action); fd.append('nonce', nonce);
                                Object.keys(data||{}).forEach(function(k){ fd.append(k, data[k]); });
                                return fetch(ajaxurl, {method:'POST', body:fd, credentials:'same-origin'}).then(function(r){ return r.json(); });
                            }
                            function esc(s){ return String(s).replace(/[&<>"']/g, function(c){ return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); }
                            scan.addEventListener('click', function(){
                                scan.disabled = true; status.textContent = 'Đang quét thư viện…'; list.innerHTML = '';
                                post('dawp_scan_big_images').then(function(res){
                                    scan.disabled = false;
                                    if (!res || !res.success) { status.textContent = 'Lỗi: ' + (res && res.data ? res.data : 'không rõ'); return; }
                                    var it = res.data.items;
                                    status.textContent = 'Đã quét ' + res.data.scanned + ' ảnh gần nhất, thấy ' + it.length + ' ảnh vượt ' + res.data.limit + 'px.';
                                    if (!it.length) return;
                                    var h = '<table class="widefat striped" style="max-width:900px;margin-top:8px;"><thead><tr><th style="width:60px"></th><th>Tệp</th><th>Kích thước</th><th>Dung lượng</th><th style="width:170px"></th></tr></thead><tbody>';
                                    it.forEach(function(x){
                                        h += '<tr id="dawp-bigimg-'+x.id+'"><td>' + (x.thumb ? '<img src="'+esc(x.thumb)+'" style="width:50px;height:50px;object-fit:cover;border-radius:4px;">' : '') + '</td>'
                                           + '<td><a href="'+esc(x.link)+'" target="_blank">'+esc(x.ten)+'</a></td>'
                                           + '<td class="dawp-dim">'+x.w+' × '+x.h+' px</td><td class="dawp-kb">'+x.kb+' KB</td>'
                                           + '<td><button type="button" class="button button-small dawp-shrink" data-id="'+x.id+'">Thu về rộng 1920px</button></td></tr>';
                                    });
                                    h += '</tbody></table>';
                                    list.innerHTML = h;
                                });
                            });
                            list.addEventListener('click', function(ev){
                                var b = ev.target.closest('.dawp-shrink'); if (!b) return;
                                if (!confirm('Ghi đè ảnh gốc bằng bản rộng 1920px? Không hoàn tác được.')) return;
                                b.disabled = true; b.textContent = 'Đang xử lý…';
                                var id = b.getAttribute('data-id');
                                post('dawp_shrink_image', {id:id}).then(function(res){
                                    var row = document.getElementById('dawp-bigimg-'+id);
                                    if (res && res.success) {
                                        row.querySelector('.dawp-dim').textContent = res.data.w + ' × ' + res.data.h + ' px';
                                        row.querySelector('.dawp-kb').textContent = res.data.kb + ' KB';
                                        b.textContent = 'Đã thu nhỏ ✓'; b.classList.add('button-disabled');
                                    } else {
                                        b.disabled = false; b.textContent = 'Thu về rộng 1920px';
                                        alert('Không thu nhỏ được: ' + (res && res.data ? res.data : 'lỗi không rõ'));
                                    }
                                });
                            });
                        })();
                        </script>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Hoãn JS đo lường tới khi tương tác (Delay JS)</th>
                    <td>
                        <input type="hidden" name="dawp_settings[ps_delay_js]" value="0" />
                        <input type="checkbox" name="dawp_settings[ps_delay_js]" value="1" <?php checked( 1, $dawp_is_checked('ps_delay_js', 0) ); ?> />
                        <label>Giữ lại các script đo lường/quảng cáo <strong>vô hình</strong> (Google Analytics, Tag Manager, Facebook Pixel, TikTok, Hotjar, Clarity) và chỉ nạp khi người dùng chạm/cuộn/di chuột — cách giảm Total Blocking Time hiệu quả nhất. Script <strong>vẫn chạy đầy đủ cho mọi người dùng thật</strong> nên số liệu Analytics không mất; chỉ có bot đo điểm (vốn không tương tác) là không phải chờ chúng. Không đụng tới script vẽ giao diện.</label>
                        <p style="margin-top:8px;">
                            Muộn nhất sau
                            <input type="number" name="dawp_settings[ps_delay_js_timeout]" value="<?php echo esc_attr( isset($options['ps_delay_js_timeout']) ? (int) $options['ps_delay_js_timeout'] : 10 ); ?>" min="0" max="60" style="width:70px;" />
                            giây thì tự nạp dù chưa tương tác (0 = chỉ chờ tương tác).
                        </p>
                        <p style="margin-top:8px;"><strong>Hoãn thêm script khác</strong> (mỗi dòng một dấu hiệu nhận diện trong <code>src</code> hoặc nội dung script — ví dụ <code>chat-widget.js</code>). Cẩn trọng: script có hiển thị giao diện sẽ xuất hiện trễ.</p>
                        <textarea name="dawp_settings[ps_delay_js_custom]" rows="2" class="large-text" placeholder="Ví dụ: tawk.to"><?php echo esc_textarea( isset($options['ps_delay_js_custom']) ? $options['ps_delay_js_custom'] : '' ); ?></textarea>
                        <p style="margin-top:8px;"><strong>Loại trừ</strong> (script khớp dòng nào dưới đây sẽ KHÔNG bị hoãn):</p>
                        <textarea name="dawp_settings[ps_delay_js_exclude]" rows="2" class="large-text" placeholder="Ví dụ: gtag-quan-trong.js"><?php echo esc_textarea( isset($options['ps_delay_js_exclude']) ? $options['ps_delay_js_exclude'] : '' ); ?></textarea>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Gọn CSS + Critical CSS (CSS Slim)</th>
                    <td>
                        <input type="hidden" name="dawp_settings[ps_slim_css]" value="0" />
                        <input type="checkbox" name="dawp_settings[ps_slim_css]" value="1" <?php checked( 1, $dawp_is_checked('ps_slim_css', 0) ); ?> />
                        <label>Phân tích HTML thật của từng trang để chỉ giữ đúng các luật CSS trang đó dùng, rồi nhúng thẳng vào <code>&lt;head&gt;</code> — xóa bỏ CSS chặn kết xuất, thường là thứ kéo điểm mobile lên mạnh nhất. Việc phân tích chạy ngầm qua WP-Cron nên <strong>không làm chậm khách truy cập</strong>; khi chưa phân tích xong, trang được trả về nguyên trạng. Đã có sẵn danh sách an toàn cho các class động (menu mở, slider, popup, hover...) và <code>&lt;noscript&gt;</code> dự phòng. Sau khi bật, hãy duyệt thử các trang chính bằng cửa sổ ẩn danh để kiểm tra giao diện.</label>
                        <p style="margin-top:8px;">
                            <input type="hidden" name="dawp_settings[ps_slim_css_fallback]" value="0" />
                            <input type="checkbox" name="dawp_settings[ps_slim_css_fallback]" value="1" <?php checked( 1, $dawp_is_checked('ps_slim_css_fallback', 1) ); ?> />
                            <label><strong>Lưới an toàn:</strong> nạp lại toàn bộ CSS gốc ngay khi người dùng tương tác — nếu có luật nào lỡ bị loại nhầm, giao diện tự trở về đúng 100% bản gốc. Khuyên luôn bật.</label>
                        </p>
                        <p style="margin-top:8px;"><strong>Danh sách an toàn thêm</strong> (mỗi dòng một từ khóa class cần giữ — dành cho class do JavaScript của theme thêm vào sau khi tải trang):</p>
                        <textarea name="dawp_settings[ps_slim_css_safelist]" rows="2" class="large-text" placeholder="Ví dụ: ten-class-dac-biet"><?php echo esc_textarea( isset($options['ps_slim_css_safelist']) ? $options['ps_slim_css_safelist'] : '' ); ?></textarea>
                        <p style="margin-top:8px;"><strong>Loại trừ tệp CSS</strong> (tệp khớp dòng nào dưới đây sẽ giữ nguyên, không bị gọn):</p>
                        <textarea name="dawp_settings[ps_slim_css_exclude]" rows="2" class="large-text" placeholder="Ví dụ: ten-tep-can-giu.css"><?php echo esc_textarea( isset($options['ps_slim_css_exclude']) ? $options['ps_slim_css_exclude'] : '' ); ?></textarea>
                        <?php if ( class_exists( 'DAWP_CSS_Slim' ) ) : $dawp_slim_status = DAWP_CSS_Slim::status(); ?>
                        <p style="margin-top:10px;">
                            <button type="button" class="button" id="dawp-slimcss-clear" data-nonce="<?php echo esc_attr( wp_create_nonce( 'dawp_slim_css' ) ); ?>">Xóa cache CSS đã phân tích</button>
                            <span id="dawp-slimcss-status" style="margin-left:8px;color:#666;">Đang lưu <?php echo (int) $dawp_slim_status['count']; ?> trang (<?php echo esc_html( size_format( $dawp_slim_status['size'] ) ); ?>). Trang sẽ được phân tích lại tự động ở lượt truy cập kế tiếp.</span>
                        </p>
                        <script>
                        (function(){
                            var btn = document.getElementById('dawp-slimcss-clear');
                            if (!btn) return;
                            btn.addEventListener('click', function(){
                                btn.disabled = true;
                                var fd = new FormData();
                                fd.append('action', 'dawp_slim_css_clear');
                                fd.append('_ajax_nonce', btn.getAttribute('data-nonce'));
                                fetch(ajaxurl, { method: 'POST', body: fd, credentials: 'same-origin' })
                                    .then(function(r){ return r.json(); })
                                    .then(function(res){
                                        btn.disabled = false;
                                        var el = document.getElementById('dawp-slimcss-status');
                                        if (res && res.success) {
                                            el.textContent = 'Đã xóa ' + res.data.deleted + ' tệp. Các trang sẽ được phân tích lại tự động.';
                                        } else {
                                            el.textContent = 'Không xóa được: ' + (res && res.data ? res.data : 'lỗi không rõ');
                                        }
                                    })
                                    .catch(function(){ btn.disabled = false; });
                            });
                        })();
                        </script>
                        <?php endif; ?>
                    </td>
                </tr>
            </table>

        </div>

        <!-- SOCIAL SHARE TAB -->
        <div style="<?php echo $active_tab == 'social-share' ? '' : 'display: none;'; ?>">
            <div class="dawp-card" style="background: #fff; border-radius: 12px; padding: 25px; box-shadow: 0 4px 20px rgba(0,0,0,0.04); border: 1px solid #e1e8ed; margin-bottom: 30px;">
                <h3 style="margin-top: 0; color: #1d2327; font-size: 16px; border-bottom: 1px solid #f0f0f1; padding-bottom: 12px; display: flex; align-items: center; gap: 8px;">
                    <span class="dashicons dashicons-share" style="color: #0068ff;"></span> Cấu hình Nút Chia Sẻ Mạng Xã Hội Siêu Nhẹ
                </h3>
                <table class="form-table">
                    <tr valign="top">
                        <th scope="row">Kích hoạt nút chia sẻ</th>
                        <td>
                            <input type="hidden" name="dawp_settings[social_share_active]" value="0" />
                            <input type="checkbox" name="dawp_settings[social_share_active]" value="1" <?php checked( 1, $dawp_is_checked('social_share_active', 1) ); ?> />
                            <label>Bật cụm nút chia sẻ bài viết, trang tĩnh và trang chi tiết sản phẩm WooCommerce.</label>
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row">Tiêu đề vùng chia sẻ</th>
                        <td>
                            <input type="text" name="dawp_settings[social_share_title]" value="<?php echo esc_attr( isset($options['social_share_title']) ? $options['social_share_title'] : 'Chia sẻ bài viết này:' ); ?>" class="regular-text" />
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row">Các mạng xã hội hiển thị</th>
                        <td>
                            <div style="display: flex; flex-direction: column; gap: 8px;">
                                <input type="hidden" name="dawp_settings[social_share_facebook]" value="0" />
                                <label><input type="checkbox" name="dawp_settings[social_share_facebook]" value="1" <?php checked( 1, $dawp_is_checked('social_share_facebook', 1) ); ?> /> Facebook</label>
                                
                                <input type="hidden" name="dawp_settings[social_share_zalo]" value="0" />
                                <label><input type="checkbox" name="dawp_settings[social_share_zalo]" value="1" <?php checked( 1, $dawp_is_checked('social_share_zalo', 1) ); ?> /> Zalo</label>
                                
                                <input type="hidden" name="dawp_settings[social_share_twitter]" value="0" />
                                <label><input type="checkbox" name="dawp_settings[social_share_twitter]" value="1" <?php checked( 1, $dawp_is_checked('social_share_twitter', 1) ); ?> /> Twitter / X</label>
                                
                                <input type="hidden" name="dawp_settings[social_share_telegram]" value="0" />
                                <label><input type="checkbox" name="dawp_settings[social_share_telegram]" value="1" <?php checked( 1, $dawp_is_checked('social_share_telegram', 1) ); ?> /> Telegram</label>

                                <input type="hidden" name="dawp_settings[social_share_pinterest]" value="0" />
                                <label><input type="checkbox" name="dawp_settings[social_share_pinterest]" value="1" <?php checked( 1, $dawp_is_checked('social_share_pinterest', 1) ); ?> /> Pinterest</label>

                                <input type="hidden" name="dawp_settings[social_share_linkedin]" value="0" />
                                <label><input type="checkbox" name="dawp_settings[social_share_linkedin]" value="1" <?php checked( 1, $dawp_is_checked('social_share_linkedin', 1) ); ?> /> LinkedIn</label>

                                <input type="hidden" name="dawp_settings[social_share_copy]" value="0" />
                                <label><input type="checkbox" name="dawp_settings[social_share_copy]" value="1" <?php checked( 1, $dawp_is_checked('social_share_copy', 1) ); ?> /> Sao chép liên kết (Copy Link)</label>
                            </div>
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row">Vị trí tự động hiển thị</th>
                        <td>
                            <div style="display: flex; flex-direction: column; gap: 8px;">
                                <input type="hidden" name="dawp_settings[social_share_on_post]" value="0" />
                                <label><input type="checkbox" name="dawp_settings[social_share_on_post]" value="1" <?php checked( 1, $dawp_is_checked('social_share_on_post', 1) ); ?> /> Dưới bài viết (Single Posts)</label>

                                <input type="hidden" name="dawp_settings[social_share_on_page]" value="0" />
                                <label><input type="checkbox" name="dawp_settings[social_share_on_page]" value="1" <?php checked( 1, $dawp_is_checked('social_share_on_page', 0) ); ?> /> Dưới trang tĩnh (Single Pages)</label>

                                <input type="hidden" name="dawp_settings[social_share_on_product]" value="0" />
                                <label><input type="checkbox" name="dawp_settings[social_share_on_product]" value="1" <?php checked( 1, $dawp_is_checked('social_share_on_product', 1) ); ?> /> Dưới mô tả ngắn sản phẩm (WooCommerce Products)</label>
                            </div>
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row">Kiểu thiết kế giao diện</th>
                        <td>
                            <select name="dawp_settings[social_share_style]" style="min-width: 250px;">
                                <option value="minimal" <?php selected( 'minimal', isset($options['social_share_style']) ? $options['social_share_style'] : 'minimal' ); ?>>Biểu tượng tròn màu thương hiệu</option>
                                <option value="brand_outline" <?php selected( 'brand_outline', isset($options['social_share_style']) ? $options['social_share_style'] : '' ); ?>>Biểu tượng viền tròn, trong suốt</option>
                                <option value="classic_rect" <?php selected( 'classic_rect', isset($options['social_share_style']) ? $options['social_share_style'] : '' ); ?>>Nút chữ nhật bo góc kèm chữ</option>
                                <option value="glassmorphism" <?php selected( 'glassmorphism', isset($options['social_share_style']) ? $options['social_share_style'] : '' ); ?>>Hiệu ứng kính mờ (Glassmorphism)</option>
                            </select>
                        </td>
                    </tr>
                </table>
            </div>
        </div>

        <?php if ( $active_tab !== 'ai-remote' ) submit_button('Lưu thay đổi'); ?>
    </form>

    <!-- AI REMOTE TAB (dùng AJAX riêng, nằm ngoài form cài đặt) -->
    <div style="<?php echo $active_tab == 'ai-remote' ? '' : 'display: none;'; ?>">
        <?php
        $dawp_ai_session = get_option( 'dawp_ai_remote_session' );
        $dawp_ai_open    = is_array( $dawp_ai_session ) && ! empty( $dawp_ai_session['token_hash'] ) && time() < (int) $dawp_ai_session['expires'];
        $dawp_ai_left    = $dawp_ai_open ? max( 0, (int) $dawp_ai_session['expires'] - time() ) : 0;
        $dawp_ai_base    = esc_url( rest_url( 'dawp/v1/ai-remote' ) );
        ?>
        <div class="dawp-air">
            <!-- Hero header -->
            <div class="dawp-air-hero">
                <div class="dawp-air-hero-icon">🤖</div>
                <div>
                    <h2>AI sửa web từ xa</h2>
                    <p>Mở một phiên <strong>có thời hạn</strong> để Claude Code / Antigravity đọc, sửa file và chạy mã ngay trên hosting thật — vá giao diện vỡ mà khỏi tải site về máy. <strong>Không phải cửa hậu:</strong> chưa mở phiên thì mọi yêu cầu bị từ chối, token chỉ hiện một lần, hết giờ tự khóa.</p>
                </div>
            </div>

            <!-- Cards: trạng thái + điều khiển -->
            <div class="dawp-air-grid">
                <div class="dawp-air-card">
                    <div class="dawp-air-card-h">Trạng thái phiên</div>
                    <div id="dawp-ai-pill" class="dawp-air-pill <?php echo $dawp_ai_open ? 'is-open' : 'is-safe'; ?>">
                        <span class="dawp-air-dot"></span>
                        <span id="dawp-ai-pill-text">
                            <?php echo $dawp_ai_open ? 'ĐANG MỞ — còn ' : 'AN TOÀN — chưa có phiên'; ?><strong id="dawp-ai-countdown"><?php echo $dawp_ai_open ? esc_html( sprintf( '%02d:%02d', floor( $dawp_ai_left / 60 ), $dawp_ai_left % 60 ) ) : ''; ?></strong>
                        </span>
                    </div>
                    <p class="dawp-air-hint" id="dawp-ai-hint"><?php echo $dawp_ai_open ? 'Cửa sửa web đang mở. Xong việc hãy đóng ngay.' : 'Website đang đóng hoàn toàn với AI. Không ai vào được khi chưa mở phiên.'; ?></p>
                </div>

                <div class="dawp-air-card">
                    <div class="dawp-air-card-h">Điều khiển</div>
                    <div id="dawp-ai-controls" style="<?php echo $dawp_ai_open ? 'display:none;' : ''; ?>">
                        <label class="dawp-air-lbl">Thời hạn phiên</label>
                        <div class="dawp-air-seg">
                            <input type="radio" id="dawp-air-m15" name="dawp_ai_minutes" value="15" checked><label for="dawp-air-m15">15 phút</label>
                            <input type="radio" id="dawp-air-m30" name="dawp_ai_minutes" value="30"><label for="dawp-air-m30">30 phút</label>
                            <input type="radio" id="dawp-air-m60" name="dawp_ai_minutes" value="60"><label for="dawp-air-m60">60 phút</label>
                        </div>
                        <button type="button" class="dawp-air-btn dawp-air-btn-go" id="dawp-ai-open-btn">🔓 Mở phiên cho AI</button>
                    </div>
                    <div id="dawp-ai-active" style="<?php echo $dawp_ai_open ? '' : 'display:none;'; ?>">
                        <button type="button" class="dawp-air-btn dawp-air-btn-stop" id="dawp-ai-close-btn">🔒 Đóng phiên ngay</button>
                        <p class="dawp-air-hint">Đóng là token vô hiệu tức thì và nhật ký được xóa sạch cho nhẹ hosting.</p>
                    </div>
                </div>
            </div>

            <!-- Hộp token -->
            <div id="dawp-ai-token-box" class="dawp-air-term" style="display:none;">
                <div class="dawp-air-term-warn">⚠️ Token chỉ hiện <strong>MỘT LẦN</strong>. Copy ngay rồi dán cho AI — đóng trang là mất, phải mở phiên mới.</div>
                <div class="dawp-air-term-lbl">Endpoint</div>
                <div class="dawp-air-term-val"><?php echo $dawp_ai_base; ?></div>
                <div class="dawp-air-term-lbl">Token · gửi ở header <code>X-DAWP-AI-Key</code></div>
                <div class="dawp-air-term-val dawp-air-token" id="dawp-ai-token-value"></div>
                <div class="dawp-air-term-lbl">Dán nguyên khối này cho AI</div>
                <textarea id="dawp-ai-paste" readonly></textarea>
                <button type="button" class="dawp-air-btn dawp-air-btn-copy" id="dawp-ai-copy-btn">📋 Copy khối hướng dẫn</button>
            </div>

            <!-- Nhật ký -->
            <div class="dawp-air-card" style="margin-top:18px;">
                <div class="dawp-air-card-h" style="display:flex; align-items:center; justify-content:space-between;">
                    <span>📜 Nhật ký hoạt động</span>
                    <span id="dawp-ai-live" class="dawp-air-live" style="<?php echo $dawp_ai_open ? '' : 'display:none;'; ?>"><span class="dawp-air-live-dot"></span> LIVE</span>
                </div>
                <div class="dawp-air-tbl-wrap">
                    <table class="dawp-air-tbl">
                        <thead><tr><th style="width:150px;">Thời gian</th><th style="width:110px;">Việc</th><th style="width:120px;">IP</th><th>Chi tiết</th></tr></thead>
                        <tbody id="dawp-ai-log-body">
                        <?php
                        $dawp_ai_log = class_exists( 'DAWP_Ai_Remote' ) ? DAWP_Ai_Remote::get_log() : [];
                        if ( empty( $dawp_ai_log ) ) {
                            echo '<tr class="dawp-air-empty"><td colspan="4">Chưa có hoạt động nào.</td></tr>';
                        } else {
                            foreach ( array_slice( $dawp_ai_log, 0, 50 ) as $row ) {
                                echo '<tr>';
                                echo '<td class="dawp-air-time">' . esc_html( date_i18n( 'H:i:s d/m/Y', (int) $row['time'] + ( (int) get_option('gmt_offset') * 3600 ) ) ) . '</td>';
                                echo '<td><span class="dawp-air-tag">' . esc_html( $row['action'] ) . '</span></td>';
                                echo '<td class="dawp-air-time">' . esc_html( $row['ip'] ) . '</td>';
                                echo '<td class="dawp-air-detail">' . esc_html( ( $row['path'] ? $row['path'] . ' ' : '' ) . $row['note'] ) . '</td>';
                                echo '</tr>';
                            }
                        }
                        ?>
                        </tbody>
                    </table>
                </div>
                <p class="dawp-air-hint">Nhật ký tự động xóa khi phiên kết thúc để không nặng hosting.</p>
            </div>
        </div>

        <style>
        .dawp-air{max-width:960px;margin-top:16px;font-size:13.5px;color:#1d2327;}
        .dawp-air-hero{display:flex;gap:18px;align-items:center;background:linear-gradient(120deg,#6d28d9 0%,#4f46e5 55%,#2563eb 100%);color:#fff;padding:22px 26px;border-radius:14px;box-shadow:0 8px 24px rgba(79,70,229,.25);}
        .dawp-air-hero-icon{font-size:40px;line-height:1;filter:drop-shadow(0 2px 6px rgba(0,0,0,.2));}
        .dawp-air-hero h2{margin:0 0 4px;color:#fff;font-size:20px;}
        .dawp-air-hero p{margin:0;color:#e9e7ff;line-height:1.6;font-size:13px;}
        .dawp-air-grid{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-top:16px;}
        @media(max-width:782px){.dawp-air-grid{grid-template-columns:1fr;}}
        .dawp-air-card{background:#fff;border:1px solid #e2e4e9;border-radius:12px;padding:18px 20px;box-shadow:0 1px 3px rgba(0,0,0,.04);}
        .dawp-air-card-h{font-weight:600;font-size:13px;color:#3c434a;margin-bottom:14px;text-transform:uppercase;letter-spacing:.4px;}
        .dawp-air-pill{display:inline-flex;align-items:center;gap:9px;padding:9px 16px;border-radius:999px;font-weight:700;font-size:13.5px;}
        .dawp-air-pill.is-safe{background:#e7f7ee;color:#0f7b3f;}
        .dawp-air-pill.is-open{background:#fdeaea;color:#c8232c;}
        .dawp-air-dot{width:9px;height:9px;border-radius:50%;background:currentColor;}
        .dawp-air-pill.is-open .dawp-air-dot{animation:dawp-air-pulse 1.4s infinite;}
        @keyframes dawp-air-pulse{0%{box-shadow:0 0 0 0 rgba(200,35,44,.5);}70%{box-shadow:0 0 0 8px rgba(200,35,44,0);}100%{box-shadow:0 0 0 0 rgba(200,35,44,0);}}
        #dawp-ai-countdown{font-variant-numeric:tabular-nums;margin-left:4px;}
        .dawp-air-hint{color:#787c82;font-size:12.5px;line-height:1.6;margin:12px 0 0;}
        .dawp-air-lbl{display:block;font-weight:600;color:#3c434a;margin-bottom:8px;font-size:12.5px;}
        .dawp-air-seg{display:inline-flex;background:#f0f0f2;border-radius:10px;padding:4px;margin-bottom:16px;}
        .dawp-air-seg input{position:absolute;opacity:0;pointer-events:none;}
        .dawp-air-seg label{padding:7px 16px;border-radius:7px;cursor:pointer;font-weight:600;font-size:13px;color:#50575e;transition:.15s;margin:0;}
        .dawp-air-seg input:checked+label{background:#fff;color:#4f46e5;box-shadow:0 1px 3px rgba(0,0,0,.12);}
        .dawp-air-btn{display:inline-block;border:none;border-radius:10px;padding:12px 22px;font-weight:700;font-size:14px;cursor:pointer;transition:.15s;color:#fff;}
        .dawp-air-btn:hover{transform:translateY(-1px);filter:brightness(1.05);}
        .dawp-air-btn-go{background:linear-gradient(120deg,#4f46e5,#2563eb);box-shadow:0 4px 12px rgba(79,70,229,.3);display:block;width:100%;}
        .dawp-air-btn-stop{background:linear-gradient(120deg,#e11d48,#d63638);box-shadow:0 4px 12px rgba(214,54,56,.3);display:block;width:100%;}
        .dawp-air-btn-copy{background:#3c434a;margin-top:12px;padding:9px 18px;font-size:13px;}
        .dawp-air-term{margin-top:16px;background:#161b22;border:1px solid #30363d;border-radius:12px;padding:18px 20px;color:#c9d1d9;font-family:Consolas,Monaco,monospace;font-size:12.5px;line-height:1.6;box-shadow:0 8px 24px rgba(0,0,0,.18);}
        .dawp-air-term-warn{background:rgba(255,185,0,.12);border:1px solid rgba(255,185,0,.35);color:#ffcf4d;padding:10px 12px;border-radius:8px;margin-bottom:14px;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;}
        .dawp-air-term-lbl{color:#8b949e;margin:12px 0 5px;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;font-size:12px;}
        .dawp-air-term-lbl code{background:#30363d;color:#e6edf3;padding:1px 6px;border-radius:4px;}
        .dawp-air-term-val{background:#0d1117;border:1px solid #30363d;padding:9px 12px;border-radius:7px;word-break:break-all;}
        .dawp-air-token{color:#3fb950;font-weight:600;}
        .dawp-air-term textarea{width:100%;box-sizing:border-box;height:170px;background:#0d1117;color:#c9d1d9;border:1px solid #30363d;border-radius:7px;padding:12px;font-family:inherit;font-size:12px;margin-top:4px;resize:vertical;}
        .dawp-air-live{display:inline-flex;align-items:center;gap:6px;color:#c8232c;font-size:11px;font-weight:800;letter-spacing:.6px;}
        .dawp-air-live-dot{width:7px;height:7px;border-radius:50%;background:#c8232c;animation:dawp-air-pulse 1.4s infinite;}
        .dawp-air-tbl-wrap{overflow-x:auto;border:1px solid #e2e4e9;border-radius:10px;}
        .dawp-air-tbl{width:100%;border-collapse:collapse;font-size:12.5px;}
        .dawp-air-tbl th{text-align:left;background:#f6f7f9;color:#50575e;font-weight:600;padding:10px 12px;border-bottom:1px solid #e2e4e9;font-size:11.5px;text-transform:uppercase;letter-spacing:.3px;}
        .dawp-air-tbl td{padding:9px 12px;border-bottom:1px solid #f0f0f2;vertical-align:top;}
        .dawp-air-tbl tr:last-child td{border-bottom:none;}
        .dawp-air-tbl tbody tr:hover{background:#fafbfc;}
        .dawp-air-time{color:#787c82;white-space:nowrap;font-variant-numeric:tabular-nums;}
        .dawp-air-tag{display:inline-block;background:#eef2ff;color:#4f46e5;padding:2px 9px;border-radius:6px;font-weight:600;font-size:11.5px;}
        .dawp-air-detail{color:#3c434a;font-family:Consolas,Monaco,monospace;font-size:11.5px;word-break:break-all;max-width:420px;}
        .dawp-air-empty td{text-align:center;color:#a7aaad;padding:18px!important;}
        .dawp-air-row-new{animation:dawp-air-flash 1s ease;}
        @keyframes dawp-air-flash{0%{background:#fff8e1;}100%{background:transparent;}}
        </style>

        <script data-cfasync="false">
        (function($){
            var nonce = '<?php echo wp_create_nonce( 'dawp_ai_remote_nonce' ); ?>';
            var base  = '<?php echo $dawp_ai_base; ?>';
            var site  = '<?php echo esc_js( home_url() ); ?>';
            var countdownTimer = null, pollTimer = null, lastCount = 0;

            function esc(s){ return $('<div>').text(s == null ? '' : s).html(); }
            function fmt(sec){ var m=Math.floor(sec/60),s=sec%60; return (m<10?'0':'')+m+':'+(s<10?'0':'')+s; }

            function startCountdown(sec){
                var el = document.getElementById('dawp-ai-countdown');
                if(countdownTimer) clearInterval(countdownTimer);
                countdownTimer = setInterval(function(){
                    sec--;
                    if(sec<0){ clearInterval(countdownTimer); location.reload(); return; }
                    if(el){ el.textContent=fmt(sec); }
                },1000);
            }

            function renderLog(rows){
                var $body = $('#dawp-ai-log-body');
                if(!rows || !rows.length){
                    $body.html('<tr class="dawp-air-empty"><td colspan="4">Chưa có hoạt động nào.</td></tr>');
                    return;
                }
                var isNew = rows.length !== lastCount;
                lastCount = rows.length;
                var html='';
                rows.forEach(function(r,i){
                    var cls = (isNew && i===0) ? ' class="dawp-air-row-new"' : '';
                    html += '<tr'+cls+'><td class="dawp-air-time">'+esc(r.time)+'</td>'
                          + '<td><span class="dawp-air-tag">'+esc(r.action)+'</span></td>'
                          + '<td class="dawp-air-time">'+esc(r.ip)+'</td>'
                          + '<td class="dawp-air-detail">'+esc(r.detail)+'</td></tr>';
                });
                $body.html(html);
            }

            function startPolling(){
                if(pollTimer) clearInterval(pollTimer);
                pollTimer = setInterval(function(){
                    $.post(ajaxurl, {action:'dawp_ai_remote_status', nonce:nonce}, function(r){
                        if(!r.success) return;
                        if(!r.data.dang_mo){ clearInterval(pollTimer); location.reload(); return; }
                        renderLog(r.data.nhat_ky);
                    });
                }, 3000);
            }

            <?php if ( $dawp_ai_open ) : ?>
            lastCount = <?php echo count( $dawp_ai_log ); ?>;
            startCountdown(<?php echo (int) $dawp_ai_left; ?>);
            startPolling();
            <?php endif; ?>

            $('#dawp-ai-open-btn').on('click', function(){
                var mins = $('input[name=dawp_ai_minutes]:checked').val();
                var $btn = $(this).prop('disabled', true).text('Đang mở...');
                $.post(ajaxurl, {action:'dawp_ai_remote_open', nonce:nonce, minutes:mins}, function(r){
                    $btn.prop('disabled', false).html('🔓 Mở phiên cho AI');
                    if(!r.success){ alert(r.data && r.data.message ? r.data.message : 'Lỗi mở phiên'); return; }
                    var t = r.data.token;
                    $('#dawp-ai-token-value').text(t);
                    var paste = 'Tôi cho phép bạn sửa website đang chạy tại '+site+' qua REST API của plugin Duy Anh Web Pro.\n'
                      + 'Endpoint gốc: '+r.data.base+'\n'
                      + 'Xác thực: gửi header  X-DAWP-AI-Key: '+t+'  trong mọi request.\n'
                      + 'Phiên hết hạn sau '+r.data.minutes+' phút.\n\n'
                      + 'Các API (POST, body JSON) — tất cả đường dẫn giới hạn trong thư mục WordPress:\n'
                      + '  GET  '+r.data.base+'/trangthai            -> kiểm tra phiên còn bao lâu\n'
                      + '  POST '+r.data.base+'/liet-ke   {"path":"wp-content/themes"}        -> liệt kê thư mục\n'
                      + '  POST '+r.data.base+'/doc       {"path":"wp-content/themes/.../style.css"} -> đọc file (trả noi_dung + sha256)\n'
                      + '  POST '+r.data.base+'/ghi       {"path":"...","noi_dung":"..."}     -> ghi file (tự sao lưu .dawpbak)\n'
                      + '  POST '+r.data.base+'/chay-php  {"code":"return get_bloginfo(\'version\');"} -> chạy PHP tùy ý\n\n'
                      + 'Hãy bắt đầu bằng cách gọi /trangthai để xác nhận kết nối.';
                    $('#dawp-ai-paste').val(paste);
                    $('#dawp-ai-controls').slideUp();
                    $('#dawp-ai-token-box').slideDown();
                    $('#dawp-ai-active').show();
                    $('#dawp-ai-live').show();
                    $('#dawp-ai-pill').removeClass('is-safe').addClass('is-open');
                    $('#dawp-ai-pill-text').html('ĐANG MỞ — còn <strong id="dawp-ai-countdown">'+fmt(r.data.con_lai)+'</strong>');
                    $('#dawp-ai-hint').text('Cửa sửa web đang mở. Xong việc hãy đóng ngay.');
                    lastCount = 0;
                    startCountdown(r.data.con_lai);
                    startPolling();
                });
            });

            $('#dawp-ai-close-btn').on('click', function(){
                if(!confirm('Đóng phiên ngay? Token hiện tại sẽ vô hiệu lập tức và nhật ký sẽ bị xóa.')) return;
                $.post(ajaxurl, {action:'dawp_ai_remote_close', nonce:nonce}, function(r){
                    location.reload();
                });
            });

            $('#dawp-ai-copy-btn').on('click', function(){
                var ta = document.getElementById('dawp-ai-paste');
                ta.select(); document.execCommand('copy');
                $(this).text('✅ Đã copy!');
                var self=this; setTimeout(function(){ $(self).text('📋 Copy khối hướng dẫn'); },2000);
            });
        })(jQuery);
        </script>
    </div>
</div>

<script data-cfasync="false">
/* Định nghĩa hàm toàn cục gửi test SMTP tránh kẹt ready queue */
window.dawpTestSmtp = function() {
    var emailInput = document.getElementById('dawp_test_email');
    if (!emailInput) return false;
    var email = emailInput.value;
    if (!email) {
        alert('Vui lòng nhập email nhận thử nghiệm!');
        return false;
    }

    var btn = document.getElementById('dawp_test_smtp_btn');
    var result = document.getElementById('dawp_test_smtp_result');

    if (btn) {
        btn.disabled = true;
        btn.innerText = 'Đang gửi thử...';
    }
    if (result) {
        result.innerHTML = '<span style="color: #666; font-weight: 600;">⏳ Đang thiết lập kết nối SMTP và gửi thư, vui lòng đợi...</span>';
    }

    var formData = new FormData();
    formData.append('action', 'dawp_test_smtp');
    formData.append('nonce', '<?php echo wp_create_nonce("dawp_test_smtp_nonce"); ?>');
    formData.append('email', email);
    
    var hostInput = document.querySelector('input[name="dawp_settings[smtp_host]"]');
    var portInput = document.querySelector('input[name="dawp_settings[smtp_port]"]');
    var userInput = document.querySelector('input[name="dawp_settings[smtp_user]"]');
    var passInput = document.querySelector('input[name="dawp_settings[smtp_pass]"]');
    var encInput  = document.querySelector('select[name="dawp_settings[smtp_enc]"]');
    var fromInput = document.querySelector('input[name="dawp_settings[smtp_from_name]"]');

    formData.append('host', hostInput ? hostInput.value : '');
    formData.append('port', portInput ? portInput.value : '');
    formData.append('user', userInput ? userInput.value : '');
    formData.append('pass', passInput ? passInput.value : '');
    formData.append('enc', encInput ? encInput.value : '');
    formData.append('from_name', fromInput ? fromInput.value : '');

    var fetchUrl = (typeof ajaxurl !== 'undefined') ? ajaxurl : '/wp-admin/admin-ajax.php';

    fetch(fetchUrl, {
        method: 'POST',
        body: formData
    })
    .then(function(response) {
        return response.json();
    })
    .then(function(res) {
        if (btn) {
            btn.disabled = false;
            btn.innerText = 'Gửi thử Email';
        }
        if (result) {
            if (res.success) {
                result.innerHTML = '<span style="color: #46b450; display: inline-block; padding: 10px 15px; background: #ecf7ed; border-left: 4px solid #46b450; border-radius: 4px; font-weight: 500; box-shadow: 0 2px 4px rgba(0,0,0,0.02); line-height: 1.5;">✅ ' + (res.data && res.data.message ? res.data.message : 'Thành công!') + '</span>';
            } else {
                result.innerHTML = '<span style="color: #dc3232; display: inline-block; padding: 10px 15px; background: #fdf2f2; border-left: 4px solid #dc3232; border-radius: 4px; font-weight: 500; box-shadow: 0 2px 4px rgba(0,0,0,0.02); line-height: 1.5;">❌ ' + (res.data && res.data.message ? res.data.message : 'Thất bại!') + '</span>';
            }
        }
    })
    .catch(function(error) {
        if (btn) {
            btn.disabled = false;
            btn.innerText = 'Gửi thử Email';
        }
        if (result) {
            result.innerHTML = '<span style="color: #dc3232; font-weight: 600;">❌ Đã xảy ra lỗi hệ thống hoặc máy chủ không phản hồi. Vui lòng thử lại!</span>';
        }
    });
    
    return false;
};

jQuery(document).ready(function($) {

    $('#dawp_clean_comments_btn').on('click', function(e) {
        e.preventDefault();
        
        if (!confirm('CẢNH BÁO CỰC KỲ QUAN TRỌNG:\n\nBạn có chắc chắn muốn XÓA VĨNH VIỄN TOÀN BỘ bình luận trên website? Hành động này không thể hoàn tác!')) {
            return;
        }

        var $btn = $(this);
        var $result = $('#dawp_clean_comments_result');

        $btn.prop('disabled', true).text('Đang dọn dẹp...');
        $result.html('<span style="color: #666; font-weight: 600;">⏳ Đang thực hiện làm sạch dữ liệu bình luận, vui lòng đợi...</span>');

        $.post(ajaxurl, {
            action: 'dawp_clean_comments',
            nonce: '<?php echo wp_create_nonce("dawp_clean_comments_nonce"); ?>'
        }, function(response) {
            $btn.prop('disabled', false).text('Dọn dẹp Bình Luận Siêu Tốc');
            if (response.success) {
                $result.html('<span style="color: #46b450; display: inline-block; padding: 10px 15px; background: #ecf7ed; border-left: 4px solid #46b450; border-radius: 4px; font-weight: 500;">✅ ' + response.data.message + '</span>');
            } else {
                $result.html('<span style="color: #dc3232; display: inline-block; padding: 10px 15px; background: #fdf2f2; border-left: 4px solid #dc3232; border-radius: 4px; font-weight: 500;">❌ ' + response.data.message + '</span>');
            }
        }).fail(function() {
            $btn.prop('disabled', false).text('Dọn dẹp Bình Luận Siêu Tốc');
            $result.html('<span style="color: #dc3232; font-weight: 600;">❌ Đã xảy ra lỗi hệ thống. Vui lòng thử lại!</span>');
        });
    });

    // Quét Database tìm mã độc
    $('#dawp_scan_db_btn').on('click', function(e) {
        e.preventDefault();
        
        var $btn = $(this);
        var $cleanBtn = $('#dawp_clean_db_btn');
        var $result = $('#dawp_db_cleaner_result');

        $btn.prop('disabled', true).text('⏳ Đang quét...');
        $cleanBtn.hide();
        $result.show().html('<span style="color: #666; font-weight: 500;">⏳ Hệ thống đang quét toàn bộ bài viết trong cơ sở dữ liệu, vui lòng đợi...</span>');

        $.post(ajaxurl, {
            action: 'dawp_scan_db',
            nonce: '<?php echo wp_create_nonce("dawp_db_cleaner_nonce"); ?>'
        }, function(response) {
            $btn.prop('disabled', false).text('Quét Mã Độc Database');
            if (response.success) {
                var count = response.data.count;
                if (count > 0) {
                    var html = '<span style="color: #d63638; font-weight: 600; display: block; margin-bottom: 8px;">⚠️ Phát hiện ' + count + ' bài viết bị nhiễm mã độc chèn từ trình duyệt máy quản trị:</span>';
                    html += '<ul style="margin: 0 0 12px 18px; list-style-type: decimal; padding: 0;">';
                    response.data.posts.forEach(function(post) {
                        html += '<li style="margin-bottom: 3px; font-size: 13px;">[ID: ' + post.ID + '] ' + post.post_title + ' (' + post.post_type + ')</li>';
                    });
                    html += '</ul>';
                    html += '<p style="margin: 0; font-size: 13px; color: #666;">Vui lòng bấm nút <strong>"Làm Sạch Mã Độc"</strong> màu xanh để tiến hành loại bỏ tự động.</p>';
                    $result.css('border-left-color', '#d63638').html(html);
                    $cleanBtn.fadeIn();
                } else {
                    $result.css('border-left-color', '#46b450').html('<span style="color: #46b450; font-weight: 600;">✅ Tuyệt vời! Không phát hiện bài viết nào bị nhiễm mã độc trong cơ sở dữ liệu. Website của bạn 100% sạch!</span>');
                }
            } else {
                $result.css('border-left-color', '#d63638').html('<span style="color: #d63638; font-weight: 600;">❌ Lỗi: ' + response.data.message + '</span>');
            }
        }).fail(function() {
            $btn.prop('disabled', false).text('Quét Mã Độc Database');
            $result.css('border-left-color', '#d63638').html('<span style="color: #d63638; font-weight: 600;">❌ Đã xảy ra lỗi kết nối với máy chủ. Vui lòng thử lại!</span>');
        });
    });

    // Làm sạch Database mã độc
    $('#dawp_clean_db_btn').on('click', function(e) {
        e.preventDefault();

        if (!confirm('Bạn có chắc chắn muốn làm sạch toàn bộ các mã độc được phát hiện? Hệ thống sẽ tự động bóc tách các thẻ script/iframe độc hại khỏi bài viết.')) {
            return;
        }

        var $btn = $(this);
        var $scanBtn = $('#dawp_scan_db_btn');
        var $result = $('#dawp_db_cleaner_result');

        $btn.prop('disabled', true).text('⏳ Đang làm sạch...');
        $scanBtn.prop('disabled', true);

        $.post(ajaxurl, {
            action: 'dawp_clean_db',
            nonce: '<?php echo wp_create_nonce("dawp_db_cleaner_nonce"); ?>'
        }, function(response) {
            $btn.prop('disabled', false).hide();
            $scanBtn.prop('disabled', false);
            if (response.success) {
                var html = '<span style="color: #46b450; font-weight: 600; display: block; margin-bottom: 8px;">✅ ' + response.data.message + '</span>';
                if (response.data.count > 0) {
                    html += '<ul style="margin: 0; list-style-type: disc; padding-left: 18px;">';
                    response.data.cleaned.forEach(function(post) {
                        html += '<li style="font-size: 13px;">Đã làm sạch bài viết: [ID: ' + post.id + '] ' + post.title + '</li>';
                    });
                    html += '</ul>';
                }
                $result.css('border-left-color', '#46b450').html(html);
            } else {
                $result.css('border-left-color', '#d63638').html('<span style="color: #d63638; font-weight: 600;">❌ Lỗi: ' + response.data.message + '</span>');
            }
        }).fail(function() {
            $btn.prop('disabled', false).text('Làm Sạch Mã Độc');
            $scanBtn.prop('disabled', false);
            $result.css('border-left-color', '#d63638').html('<span style="color: #d63638; font-weight: 600;">❌ Đã xảy ra lỗi hệ thống khi làm sạch. Vui lòng thử lại!</span>');
        });
    });

    // Bộ lọc tìm kiếm khách hàng liên hệ
    $('#dawp_search_leads').on('keyup', function() {
        var val = $(this).val().toLowerCase();
        $('#dawp_leads_table tbody tr.lead-row').filter(function() {
            $(this).toggle($(this).attr('data-search').indexOf(val) > -1);
        });
    });


    // --- SEO & REDIRECT & 404 LOGS JAVASCRIPT ---
    // Chọn ảnh LocalBusiness Logo & Default Share Image
    $('.dawp-seo-select-media').on('click', function(e) {
        e.preventDefault();
        var $btn = $(this);
        var $input = $btn.prev('input');
        
        var frame = wp.media({
            title: 'Chọn hình ảnh',
            multiple: false,
            library: { type: 'image' },
            button: { text: 'Sử dụng ảnh này' }
        });
        
        frame.on('select', function() {
            var attachment = frame.state().get('selection').first().toJSON();
            $input.val(attachment.url);
        });
        
        frame.open();
    });

    // Thêm Redirect 301 qua AJAX
    $('#dawp_add_redirect_btn').on('click', function(e) {
        e.preventDefault();
        var oldUrl = $('#dawp_redirect_old').val();
        var newUrl = $('#dawp_redirect_new').val();
        if (!oldUrl || !newUrl) {
            alert('Vui lòng nhập đầy đủ link cũ và link mới!');
            return;
        }

        var $btn = $(this);
        var $result = $('#dawp_seo_action_result');
        $btn.prop('disabled', true).text('Đang thêm...');

        $.post(ajaxurl, {
            action: 'dawp_add_redirect',
            nonce: '<?php echo wp_create_nonce("dawp_seo_actions_nonce"); ?>',
            old_url: oldUrl,
            new_url: newUrl
        }, function(response) {
            $btn.prop('disabled', false).text('Thêm Chuyển Hướng');
            if (response.success) {
                $('#dawp_redirect_old').val('');
                $('#dawp_redirect_new').val('');
                
                // Thêm hàng mới vào bảng
                var newRow = '<tr class="redirect-row" data-id="' + response.data.id + '">' +
                             '  <td style="font-weight: 500;">' + oldUrl + '</td>' +
                             '  <td><a href="' + newUrl + '" target="_blank">' + newUrl + '</a></td>' +
                             '  <td style="color: #64748b; font-weight: 500;">301</td>' +
                             '  <td style="text-align: center;"><button type="button" class="dawp-delete-redirect-btn" data-id="' + response.data.id + '" style="background:none; border:none; padding:0; color:#d63638; cursor:pointer;"><span class="dashicons dashicons-trash"></span></button></td>' +
                             '</tr>';
                
                $('.no-redirects-row').remove();
                $('#dawp_redirects_table tbody').prepend(newRow);
                $result.html('<span style="color: #46b450; font-weight: 500;">✅ ' + response.data.message + '</span>');
                setTimeout(function() { $result.empty(); }, 3000);
            } else {
                $result.html('<span style="color: #dc3232; font-weight: 500;">❌ ' + response.data.message + '</span>');
                setTimeout(function() { $result.empty(); }, 3000);
            }
        }).fail(function() {
            $btn.prop('disabled', false).text('Thêm Chuyển Hướng');
            $result.html('<span style="color: #dc3232; font-weight: 500;">❌ Lỗi hệ thống, vui lòng thử lại!</span>');
        });
    });

    // Xóa từng chuyển hướng 301
    $(document).on('click', '.dawp-delete-redirect-btn', function(e) {
        e.preventDefault();
        var $btn = $(this);
        var id = $btn.data('id');
        if (!id) return;
        if (!confirm('Bạn có chắc chắn muốn xóa chuyển hướng này?')) return;

        var $row = $btn.closest('tr');
        var $result = $('#dawp_seo_action_result');

        $.post(ajaxurl, {
            action: 'dawp_delete_redirect',
            nonce: '<?php echo wp_create_nonce("dawp_seo_actions_nonce"); ?>',
            id: id
        }, function(response) {
            if (response.success) {
                $row.fadeOut(300, function() {
                    $row.remove();
                    if ($('#dawp_redirects_table tbody tr.redirect-row').length === 0) {
                        $('#dawp_redirects_table tbody').append('<tr class="no-redirects-row"><td colspan="4" style="text-align: center; color: #666; padding: 20px;">Chưa có chuyển hướng 301 nào được cấu hình.</td></tr>');
                    }
                });
                $result.html('<span style="color: #46b450; font-weight: 500;">✅ ' + response.data.message + '</span>');
                setTimeout(function() { $result.empty(); }, 3000);
            } else {
                alert(response.data.message);
            }
        });
    });

    // Xóa từng log 404
    $(document).on('click', '.dawp-delete-404-btn', function(e) {
        e.preventDefault();
        var $btn = $(this);
        var id = $btn.data('id');
        if (!id) return;
        if (!confirm('Xóa bản ghi lỗi 404 này?')) return;

        var $row = $btn.closest('tr');
        var $result = $('#dawp_seo_action_result');

        $.post(ajaxurl, {
            action: 'dawp_delete_404',
            nonce: '<?php echo wp_create_nonce("dawp_seo_actions_nonce"); ?>',
            id: id
        }, function(response) {
            if (response.success) {
                $row.fadeOut(300, function() {
                    $row.remove();
                    if ($('#dawp_404_table tbody tr.404-row').length === 0) {
                        $('#dawp_404_table tbody').html('<tr class="no-404-row"><td colspan="5" style="text-align: center; color: #666; padding: 20px;">Chưa có lịch sử lỗi 404 nào được ghi nhận.</td></tr>');
                    }
                });
                $result.html('<span style="color: #46b450; font-weight: 500;">✅ ' + response.data.message + '</span>');
                setTimeout(function() { $result.empty(); }, 3000);
            } else {
                alert(response.data.message);
            }
        });
    });

    // Dọn sạch bảng 404 logs
    // Quét & chấm điểm SEO/Dễ đọc toàn bộ bài viết theo lô
    $('#dawp_rescan_scores_btn').on('click', function(e) {
        e.preventDefault();
        var $btn = $(this);
        var nonce = $btn.data('nonce');
        var $status = $('#dawp_rescan_status');
        var $progress = $('#dawp_rescan_progress');
        var $bar = $('#dawp_rescan_bar');

        $btn.prop('disabled', true);
        $progress.show();
        $bar.css('width', '0%');
        $status.css('color', '#50575e').text('Đang quét...');

        function runBatch(offset) {
            $.post(ajaxurl, {
                action: 'dawp_rescan_scores',
                nonce: nonce,
                offset: offset
            }, function(res) {
                if (!res || !res.success) {
                    $status.css('color', '#d63638').text('Lỗi: ' + ((res && res.data && res.data.message) ? res.data.message : 'không xác định'));
                    $btn.prop('disabled', false);
                    return;
                }
                var d = res.data;
                var pct = d.total ? Math.min(100, Math.round(d.processed / d.total * 100)) : 100;
                $bar.css('width', pct + '%');
                $status.text('Đã chấm ' + d.processed + ' / ' + d.total + ' bài (' + pct + '%)');
                if (d.done) {
                    $status.css('color', '#008a20').text('✅ Hoàn tất! Đã chấm điểm ' + d.processed + ' bài. Tải lại danh sách bài viết để xem.');
                    $btn.prop('disabled', false);
                } else {
                    runBatch(d.processed);
                }
            }).fail(function() {
                $status.css('color', '#d63638').text('Lỗi kết nối máy chủ.');
                $btn.prop('disabled', false);
            });
        }
        runBatch(0);
    });

    $('#dawp_clear_404_btn').on('click', function(e) {
        e.preventDefault();
        if (!confirm('Bạn có chắc chắn muốn dọn sạch lịch sử lỗi 404?')) return;

        var $result = $('#dawp_seo_action_result');
        $.post(ajaxurl, {
            action: 'dawp_clear_404',
            nonce: '<?php echo wp_create_nonce("dawp_seo_actions_nonce"); ?>'
        }, function(response) {
            if (response.success) {
                $('#dawp_404_table tbody').html('<tr class="no-404-row"><td colspan="5" style="text-align: center; color: #666; padding: 20px;">Chưa có lịch sử lỗi 404 nào được ghi nhận.</td></tr>');
                $result.html('<span style="color: #46b450; font-weight: 500;">✅ ' + response.data.message + '</span>');
                setTimeout(function() { $result.empty(); }, 3000);
            } else {
                alert(response.data.message);
            }
        });
    });

    // Tạo nhanh chuyển hướng 301 từ log 404
    $(document).on('click', '.dawp-quick-redirect-btn', function(e) {
        e.preventDefault();
        var url = $(this).data('url');
        $('#dawp_redirect_old').val(url);
        $('#dawp_redirect_new').val('/').focus();
        
        // Cuộn lên phần biểu mẫu thêm redirect
        $('html, body').animate({
            scrollTop: $('#dawp_redirect_old').offset().top - 150
        }, 500);
    });

    // --- SEO MIGRATION TOOL JAVASCRIPT ---
    function dawp_get_migration_stats() {
        var $stats = $('#dawp-migration-stats');
        $.post(ajaxurl, {
            action: 'dawp_get_migration_stats',
            nonce: '<?php echo wp_create_nonce("dawp_seo_migration_nonce"); ?>'
        }, function(response) {
            if (response.success) {
                var yoast = response.data.yoast_count;
                var rm = response.data.rm_count;
                
                var html = '📊 Phát hiện trong cơ sở dữ liệu: ';
                html += '<span style="color:#0068ff; font-weight:bold;">' + yoast + ' bài viết</span> có dữ liệu SEO cũ (Loại 1)';
                html += ' và <span style="color:#0068ff; font-weight:bold;">' + rm + ' bài viết</span> có dữ liệu SEO cũ (Loại 2).';
                
                $stats.html(html);
                
                // Select default source based on what has more data
                if (rm > yoast) {
                    $('#dawp_migration_source').val('rank_math');
                } else {
                    $('#dawp_migration_source').val('yoast');
                }
            } else {
                $stats.html('<span style="color:#dc3232;">❌ Không thể tải thông tin thống kê dữ liệu cũ!</span>');
            }
        });
    }

    // Call stats on page load
    dawp_get_migration_stats();

    var migration_offset = 0;
    var migration_batch_size = 100;
    var migration_total = 0;
    var migration_source = '';
    var migration_overwrite = false;
    var migration_migrated_count = 0;

    $('#dawp_start_migration_btn').on('click', function(e) {
        e.preventDefault();
        
        migration_source = $('#dawp_migration_source').val();
        migration_overwrite = $('#dawp_migration_overwrite').is(':checked');
        
        var confirm_msg = 'Bạn có chắc chắn muốn nhập dữ liệu SEO từ ' + (migration_source === 'yoast' ? 'Plugin SEO cũ (Loại 1)' : 'Plugin SEO cũ (Loại 2)') + '?\n';
        if (migration_overwrite) {
            confirm_msg += '⚠️ Cảnh báo: Dữ liệu DAW Pro SEO hiện tại trên các bài viết bị trùng lặp SẼ BỊ GHI ĐÈ!';
        } else {
            confirm_msg += 'Hệ thống chỉ nhập cho những bài viết chưa được thiết lập dữ liệu DAW Pro SEO.';
        }
        
        if (!confirm(confirm_msg)) {
            return;
        }

        // Initialize UI
        var $btn = $(this);
        var $source = $('#dawp_migration_source');
        var $overwrite = $('#dawp_migration_overwrite');
        
        $btn.prop('disabled', true).text('Đang di chuyển...');
        $source.prop('disabled', true);
        $overwrite.prop('disabled', true);
        
        $('#dawp-migration-progress-wrapper').fadeIn();
        var $log = $('#dawp-migration-log');
        $log.html('');
        dawp_log_msg('Khởi động quá trình di chuyển dữ liệu...');
        
        migration_offset = 0;
        migration_migrated_count = 0;
        
        // Fetch total count based on selected source
        $.post(ajaxurl, {
            action: 'dawp_get_migration_stats'
        }, function(response) {
            if (response.success) {
                migration_total = migration_source === 'yoast' ? response.data.yoast_count : response.data.rm_count;
                if (migration_total === 0) {
                    dawp_log_msg('❌ Không phát hiện dữ liệu SEO cũ cần nhập từ nguồn này!');
                    $btn.prop('disabled', false).text('Bắt Đầu Nhập Dữ Liệu');
                    $source.prop('disabled', false);
                    $overwrite.prop('disabled', false);
                    return;
                }
                dawp_log_msg('Tổng số bài viết cần xử lý: ' + migration_total);
                dawp_execute_migration_batch();
            } else {
                dawp_log_msg('❌ Lỗi kết nối cơ sở dữ liệu để lấy tổng số bài viết!');
                $btn.prop('disabled', false).text('Bắt Đầu Nhập Dữ Liệu');
                $source.prop('disabled', false);
                $overwrite.prop('disabled', false);
            }
        });
    });

    function dawp_log_msg(msg) {
        var $log = $('#dawp-migration-log');
        $log.append('<div>[' + new Date().toLocaleTimeString() + '] ' + msg + '</div>');
        $log.scrollTop($log[0].scrollHeight);
    }

    function dawp_execute_migration_batch() {
        var $bar = $('#dawp-migration-progress-bar');
        var $percent = $('#dawp-migration-progress-percent');
        
        dawp_log_msg('Đang xử lý nhóm bài viết từ offset ' + migration_offset + ' (kích thước nhóm: ' + migration_batch_size + ')...');
        
        $.post(ajaxurl, {
            action: 'dawp_migrate_seo',
            nonce: '<?php echo wp_create_nonce("dawp_seo_migration_nonce"); ?>',
            source: migration_source,
            offset: migration_offset,
            batch_size: migration_batch_size,
            overwrite: migration_overwrite
        }, function(response) {
            if (response.success) {
                if (response.data.completed || response.data.processed === 0) {
                    migration_migrated_count += response.data.migrated;
                    
                    $bar.css('width', '100%');
                    $percent.text('100%');
                    
                    dawp_log_msg('🎉 Hoàn thành di chuyển dữ liệu SEO!');
                    dawp_log_msg('Tổng số bài viết đã được nhập thành công: ' + migration_migrated_count + '/' + migration_total);
                    
                    $('#dawp_start_migration_btn').prop('disabled', false).text('Bắt Đầu Nhập Dữ Liệu');
                    $('#dawp_migration_source').prop('disabled', false);
                    $('#dawp_migration_overwrite').prop('disabled', false);
                    
                    // Refresh stats after migration
                    dawp_get_migration_stats();
                } else {
                    migration_migrated_count += response.data.migrated;
                    migration_offset += migration_batch_size;
                    
                    var progress = Math.min(100, Math.round((migration_offset / migration_total) * 100));
                    $bar.css('width', progress + '%');
                    $percent.text(progress + '%');
                    
                    dawp_log_msg('Đã nhập thành công ' + response.data.migrated + ' bài viết trong nhóm này. Chuyển sang nhóm tiếp theo...');
                    
                    // Call next batch
                    setTimeout(dawp_execute_migration_batch, 200);
                }
            } else {
                dawp_log_msg('❌ Lỗi xử lý nhóm bài viết: ' + response.data.message);
                $('#dawp_start_migration_btn').prop('disabled', false).text('Bắt Đầu Nhập Dữ Liệu');
                $('#dawp_migration_source').prop('disabled', false);
                $('#dawp_migration_overwrite').prop('disabled', false);
            }
        }).fail(function() {
            dawp_log_msg('❌ Lỗi kết nối mạng hoặc máy chủ phản hồi lỗi 500!');
            $('#dawp_start_migration_btn').prop('disabled', false).text('Bắt Đầu Nhập Dữ Liệu');
            $('#dawp_migration_source').prop('disabled', false);
            $('#dawp_migration_overwrite').prop('disabled', false);
        });
    }

    // --- GOOGLE TRANSLATE & MULTILINGUAL SETTINGS JS ---
    // Toggle Translate setting fields dynamically based on Layout selection
    $('#dawp_google_translate_layout').on('change', function() {
        var val = $(this).val();
        if (val === 'inline') {
            $('#dawp_translate_inline_style_row').show();
            $('#dawp_translate_position_row').hide();
        } else {
            $('#dawp_translate_inline_style_row').hide();
            $('#dawp_translate_position_row').show();
        }
    });
    $('#dawp_google_translate_layout').trigger('change');

    // Toggle Multilingual setting fields dynamically based on Layout selection
    $('#dawp_multilingual_layout').on('change', function() {
        var val = $(this).val();
        if (val === 'inline') {
            $('#dawp_multilingual_inline_style_row').show();
            $('#dawp_multilingual_position_row').hide();
        } else {
            $('#dawp_multilingual_inline_style_row').hide();
            $('#dawp_multilingual_position_row').show();
        }
    });
    $('#dawp_multilingual_layout').trigger('change');

    // Toggle độc lập giữa Dịch tự động Google và Dịch tay đa ngôn ngữ
    $('#dawp_multilingual_active').on('change', function() {
        if ($(this).is(':checked')) {
            // Tắt dịch tự động
            $('#dawp_google_translate_active').prop('checked', false).trigger('change');
            $('.dawp-multilingual-fields').slideDown();
            $('.dawp-translate-fields').slideUp();
        } else {
            $('.dawp-multilingual-fields').slideUp();
        }
    });

    $('#dawp_google_translate_active').on('change', function() {
        if ($(this).is(':checked')) {
            // Tắt dịch tay và ẩn các trường của nó đi
            $('#dawp_multilingual_active').prop('checked', false).trigger('change');
            $('.dawp-translate-fields').slideDown();
            $('.dawp-multilingual-fields').slideUp();
        } else {
            $('.dawp-translate-fields').slideUp();
        }
    });

    // Ẩn/hiện checkbox ngôn ngữ phụ dựa trên thay đổi ngôn ngữ mặc định
    $('#dawp_multilingual_default').on('change', function() {
        var defaultLang = $(this).val();
        $('input[name="dawp_settings[multilingual_langs][]"]').each(function() {
            var $label = $(this).closest('label');
            if ($(this).val() === defaultLang) {
                $(this).prop('checked', false);
                $label.hide();
            } else {
                $label.show();
            }
        });
    });
    // Khởi chạy kích hoạt cờ ẩn/hiện lúc nạp trang
    $('#dawp_multilingual_default').trigger('change');

    // Thêm dòng mới cho bảng dịch chuỗi
    $('#dawp-add-string-row').on('click', function(e) {
        e.preventDefault();
        var $tbody = $('#dawp-multilingual-strings-table tbody');
        var index = $tbody.find('tr').length;
        var html = '<tr data-index="' + index + '">';
        
        // Cột original string
        html += '<td><input type="text" name="dawp_settings[multilingual_strings][' + index + '][original]" value="" style="width: 100%;" placeholder="vd: Xem thêm" /></td>';
        
        // Cột bản dịch
        <?php
        if ( class_exists( 'DAWP_Multilingual' ) ) :
            $active_langs = DAWP_Multilingual::get_active_languages();
            $default_lang = DAWP_Multilingual::get_default_language();
            foreach ( $active_langs as $code => $lang ) :
                if ( $code === $default_lang ) continue;
        ?>
            html += '<td><input type="text" name="dawp_settings[multilingual_strings][' + index + '][translations][<?php echo $code; ?>]" value="" style="width: 100%;" placeholder="vd: Read more" /></td>';
        <?php
            endforeach;
        endif;
        ?>
        
        // Cột nút xóa
        html += '<td><button type="button" class="button dawp-remove-string-row" style="color: #b32d2e; border-color: #b32d2e;"><span class="dashicons dashicons-no-alt" style="margin-top: 3px;"></span></button></td>';
        html += '</tr>';
        
        $tbody.append(html);
    });

    // Xóa dòng dịch chuỗi
    $(document).on('click', '.dawp-remove-string-row', function(e) {
        e.preventDefault();
        $(this).closest('tr').remove();
        
        // Đánh lại số thứ tự index để tránh mất dữ liệu khi lưu
        $('#dawp-multilingual-strings-table tbody tr').each(function(index) {
            $(this).attr('data-index', index);
            $(this).find('input').each(function() {
                var name = $(this).attr('name');
                if (name) {
                    name = name.replace(/multilingual_strings\]\[\d+\]/, 'multilingual_strings][' + index + ']');
                    $(this).attr('name', name);
                }
            });
        });
    });


    // Mở/Đóng form trả lời đánh giá
    $('.reply-btn').on('click', function(e) {
        e.preventDefault();
        var $row = $(this).closest('tr');
        $row.find('.review-reply-form').slideToggle();
    });

    // Hủy trả lời
    $('.cancel-reply-btn').on('click', function(e) {
        e.preventDefault();
        var $row = $(this).closest('tr');
        $row.find('.review-reply-form').slideUp();
    });

    // Lưu phản hồi đánh giá
    $('.save-reply-btn').on('click', function(e) {
        e.preventDefault();
        var $btn = $(this);
        var $row = $btn.closest('tr');
        var id = $row.data('id');
        var reply = $row.find('.reply-textarea').val().trim();
        var $replyDisplay = $row.find('.review-reply-display');
        var $replyText = $row.find('.reply-text');
        var $form = $row.find('.review-reply-form');
        var $result = $('#dawp_review_action_result');

        $result.html('<span style="color: #666;">⏳ Đang gửi phản hồi...</span>');
        $btn.prop('disabled', true);

        $.post(ajaxurl, {
            action: 'dawp_woo_reviews_reply',
            nonce: '<?php echo wp_create_nonce("dawp_admin_reviews_nonce"); ?>',
            id: id,
            reply: reply
        }, function(response) {
            $btn.prop('disabled', false);
            if (response.success) {
                if (reply) {
                    $replyText.text(reply);
                    $replyDisplay.show();
                } else {
                    $replyDisplay.hide();
                }
                $form.slideUp();
                $result.html('<span style="color: #46b450; font-weight: 500;">✅ ' + response.data.message + '</span>');
                setTimeout(function() { $result.empty(); }, 3000);
            } else {
                $result.html('<span style="color: #dc3232; font-weight: 500;">❌ ' + response.data.message + '</span>');
            }
        }).fail(function() {
            $btn.prop('disabled', false);
            $result.html('<span style="color: #dc3232; font-weight: 500;">❌ Lỗi hệ thống, vui lòng thử lại!</span>');
        });
    });

    // Xóa đánh giá sản phẩm
    $('.delete-review-btn').on('click', function(e) {
        e.preventDefault();
        var $btn = $(this);
        var $row = $btn.closest('tr');
        var id = $row.data('id');
        var $result = $('#dawp_review_action_result');

        if (!confirm('Bạn có chắc chắn muốn xóa đánh giá này? Tất cả hình ảnh đính kèm tương ứng trên hosting cũng sẽ bị xóa vĩnh viễn.')) {
            return;
        }

        $result.html('<span style="color: #666;">⏳ Đang xóa đánh giá...</span>');

        $.post(ajaxurl, {
            action: 'dawp_woo_reviews_delete',
            nonce: '<?php echo wp_create_nonce("dawp_admin_reviews_nonce"); ?>',
            id: id
        }, function(response) {
            if (response.success) {
                $row.fadeOut(300, function() {
                    $row.remove();
                    if ($('#dawp_admin_reviews_table tbody tr.review-row').length === 0) {
                        $('#dawp_admin_reviews_table tbody').html('<tr class="no-reviews-row"><td colspan="8" style="text-align: center; color: #666; padding: 20px;">Chưa có đánh giá nào được ghi nhận.</td></tr>');
                    }
                });
                $result.html('<span style="color: #46b450; font-weight: 500;">✅ ' + response.data.message + '</span>');
                setTimeout(function() { $result.empty(); }, 3000);
            } else {
                $result.html('<span style="color: #dc3232; font-weight: 500;">❌ ' + response.data.message + '</span>');
            }
        }).fail(function() {
            $result.html('<span style="color: #dc3232; font-weight: 500;">❌ Lỗi hệ thống, vui lòng thử lại!</span>');
        });
    });

    // Xóa sạch toàn bộ đánh giá sản phẩm
    $('#dawp_clear_reviews_btn').on('click', function(e) {
        e.preventDefault();
        var $result = $('#dawp_review_action_result');

        if (!confirm('⚠️ CẢNH BÁO QUAN TRỌNG:\n\nBạn có thực sự muốn XÓA SẠCH TOÀN BỘ dữ liệu đánh giá sản phẩm trong CSDL? Mọi tệp ảnh đính kèm cũng sẽ bị xóa vĩnh viễn khỏi hosting. Hành động này không thể hoàn tác!')) {
            return;
        }

        $result.html('<span style="color: #666;">⏳ Đang làm sạch bảng đánh giá...</span>');

        $.post(ajaxurl, {
            action: 'dawp_woo_reviews_clear_all',
            nonce: '<?php echo wp_create_nonce("dawp_admin_reviews_nonce"); ?>'
        }, function(response) {
            if (response.success) {
                $('#dawp_admin_reviews_table tbody tr.review-row').remove();
                $('#dawp_admin_reviews_table tbody').html('<tr class="no-reviews-row"><td colspan="8" style="text-align: center; color: #666; padding: 20px;">Chưa có đánh giá nào được ghi nhận.</td></tr>');
                $result.html('<span style="color: #46b450; font-weight: 500;">✅ ' + response.data.message + '</span>');
                setTimeout(function() { $result.empty(); }, 3000);
            } else {
                $result.html('<span style="color: #dc3232; font-weight: 500;">❌ ' + response.data.message + '</span>');
            }
        }).fail(function() {
            $result.html('<span style="color: #dc3232; font-weight: 500;">❌ Lỗi hệ thống, vui lòng thử lại!</span>');
        });
    });
});
</script>
