<?php
/**
 * REST API: cầu nối giữa trình duyệt (nơi nén ảnh) và máy chủ (nơi lưu file).
 *
 * @package duyanhweb
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DAWP_WebP_REST {

	public function __construct() {
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
	}

	/**
	 * Đăng ký các endpoint.
	 */
	public function register_routes() {
		$permission = array( $this, 'check_permission' );

		// Trạng thái tổng quan + tiến độ.
		register_rest_route(
			DAWP_WebP_REST_NS,
			'/status',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_status' ),
				'permission_callback' => $permission,
			)
		);

		// Lấy lô ID ảnh cần nén tiếp theo.
		register_rest_route(
			DAWP_WebP_REST_NS,
			'/queue',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_queue' ),
				'permission_callback' => $permission,
				'args'                => array(
					'limit' => array(
						'type'              => 'integer',
						'default'           => 20,
						'sanitize_callback' => 'absint',
					),
				),
			)
		);

		// Chi tiết một ảnh: danh sách file cần nén.
		register_rest_route(
			DAWP_WebP_REST_NS,
			'/item/(?P<id>\d+)',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_item' ),
				'permission_callback' => $permission,
			)
		);

		// Nhận ảnh WebP đã nén và commit (ghi file + đổi DB) cho ĐÚNG MỘT ảnh.
		register_rest_route(
			DAWP_WebP_REST_NS,
			'/commit',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'post_commit' ),
				'permission_callback' => $permission,
			)
		);

		// Sửa metadata bị lệch (ảnh 404 sau khi nén).
		register_rest_route(
			DAWP_WebP_REST_NS,
			'/repair',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'post_repair' ),
				'permission_callback' => $permission,
				'args'                => array(
					'offset' => array(
						'type'              => 'integer',
						'default'           => 0,
						'sanitize_callback' => 'absint',
					),
				),
			)
		);

		// Đánh dấu bỏ qua một ảnh bị lỗi để hàng đợi không bị tắc.
		register_rest_route(
			DAWP_WebP_REST_NS,
			'/skip',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'post_skip' ),
				'permission_callback' => $permission,
			)
		);

		// Đưa toàn bộ ảnh lỗi tạm thời trở lại hàng đợi (gọi đầu mỗi lần chạy).
		register_rest_route(
			DAWP_WebP_REST_NS,
			'/reset-errors',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'post_reset_errors' ),
				'permission_callback' => $permission,
			)
		);

		// Dọn sạch URL cũ trong toàn bộ database (chuẩn bị gỡ plugin).
		register_rest_route(
			DAWP_WebP_REST_NS,
			'/sweep',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'post_sweep' ),
				'permission_callback' => $permission,
			)
		);
	}

	/**
	 * Chỉ quản trị viên có quyền quản lý media mới được dùng.
	 *
	 * @return bool|WP_Error
	 */
	public function check_permission() {
		if ( ! current_user_can( 'upload_files' ) || ! current_user_can( 'manage_options' ) ) {
			return new WP_Error(
				'DAWP_WebP_forbidden',
				__( 'Bạn không có quyền thực hiện thao tác này.', 'duyanhwebpro' ),
				array( 'status' => 403 )
			);
		}
		return true;
	}

	/**
	 * Trạng thái tổng quan.
	 *
	 * @return WP_REST_Response
	 */
	public function get_status() {
		$pending = DAWP_WebP_Scanner::count_pending();
		$total   = DAWP_WebP_Scanner::count_total();
		$stats   = DAWP_WebP_DB::stats();

		return rest_ensure_response(
			array(
				'pending'  => $pending,
				'total'    => $total,
				'done'     => max( 0, $total - $pending ),
				'stats'    => $stats,
				'settings' => DAWP_WebP_Settings::all(),
			)
		);
	}

	/**
	 * Lô ID tiếp theo.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public function get_queue( $request ) {
		$limit = $request->get_param( 'limit' );
		$ids   = DAWP_WebP_Scanner::next_batch( $limit ? $limit : 20 );

		return rest_ensure_response(
			array(
				'ids'       => $ids,
				'remaining' => DAWP_WebP_Scanner::count_pending(),
			)
		);
	}

	/**
	 * Chi tiết một ảnh.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function get_item( $request ) {
		$id   = absint( $request['id'] );
		$data = DAWP_WebP_Scanner::describe( $id );

		if ( is_wp_error( $data ) ) {
			$data->add_data( array( 'status' => 404 ) );
			return $data;
		}

		return rest_ensure_response( $data );
	}

	/**
	 * Nhận các file WebP đã nén trong trình duyệt và commit cho một ảnh.
	 *
	 * Body là multipart/form-data:
	 *   - attachment_id : int
	 *   - dims          : JSON { "<key>": { "w": int, "h": int } }
	 *   - file_<key>    : Blob WebP
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function post_commit( $request ) {
		$attachment_id = absint( $request->get_param( 'attachment_id' ) );

		if ( ! $attachment_id ) {
			return new WP_Error(
				'DAWP_WebP_bad_request',
				__( 'Thiếu ID ảnh.', 'duyanhwebpro' ),
				array( 'status' => 400 )
			);
		}

		$files = $request->get_file_params();

		if ( empty( $files ) ) {
			return new WP_Error(
				'DAWP_WebP_no_files',
				__( 'Không nhận được file WebP nào từ trình duyệt.', 'duyanhwebpro' ),
				array( 'status' => 400 )
			);
		}

		$dims = json_decode( (string) $request->get_param( 'dims' ), true );
		$dims = is_array( $dims ) ? $dims : array();

		$incoming = array();

		foreach ( $files as $field => $file ) {
			if ( 0 !== strpos( $field, 'file_' ) ) {
				continue;
			}

			if ( ! isset( $file['error'] ) || UPLOAD_ERR_OK !== (int) $file['error'] ) {
				return new WP_Error(
					'DAWP_WebP_upload_error',
					sprintf(
						/* translators: %s: tên trường file */
						__( 'Lỗi tải lên ở phần %s. Có thể do giới hạn upload_max_filesize của PHP.', 'duyanhwebpro' ),
						$field
					),
					array( 'status' => 400 )
				);
			}

			if ( ! is_uploaded_file( $file['tmp_name'] ) ) {
				return new WP_Error(
					'DAWP_WebP_upload_invalid',
					__( 'File tải lên không hợp lệ.', 'duyanhwebpro' ),
					array( 'status' => 400 )
				);
			}

			$key = substr( $field, 5 );

			$incoming[ $key ] = array(
				'tmp'    => $file['tmp_name'],
				'width'  => isset( $dims[ $key ]['w'] ) ? (int) $dims[ $key ]['w'] : 0,
				'height' => isset( $dims[ $key ]['h'] ) ? (int) $dims[ $key ]['h'] : 0,
			);
		}

		if ( empty( $incoming ) ) {
			return new WP_Error(
				'DAWP_WebP_no_files',
				__( 'Không có file hợp lệ để xử lý.', 'duyanhwebpro' ),
				array( 'status' => 400 )
			);
		}

		// Một ảnh nhiều kích thước được gửi làm nhiều lượt; chỉ lượt cuối mới
		// đánh dấu hoàn tất.
		$is_final = (bool) $request->get_param( 'is_final' );
		$token    = sanitize_text_field( (string) $request->get_param( 'token' ) );

		$result = DAWP_WebP_Engine::commit( $attachment_id, $incoming, $is_final, $token );

		if ( is_wp_error( $result ) ) {
			$result->add_data( array( 'status' => 500 ) );
			return $result;
		}

		$result['remaining'] = DAWP_WebP_Scanner::count_pending();

		return rest_ensure_response( $result );
	}

	/**
	 * Quét và sửa metadata còn trỏ tới file đã bị xoá.
	 *
	 * Chỉ đọc đĩa và sửa metadata, không đụng tới file ảnh, nên chạy lại bao
	 * nhiêu lần cũng an toàn.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public function post_repair( $request ) {
		$offset = absint( $request->get_param( 'offset' ) );
		$ids    = DAWP_WebP_Repair::batch( $offset, 50 );

		$fixed   = 0;
		$details = array();

		foreach ( $ids as $id ) {
			$result = DAWP_WebP_Repair::fix( $id );

			if ( $result['fixed'] > 0 ) {
				$fixed    += $result['fixed'];
				$details[] = array(
					'id'    => $id,
					'fixed' => $result['fixed'],
					'notes' => $result['notes'],
				);
			}
		}

		return rest_ensure_response(
			array(
				'offset'    => $offset + count( $ids ),
				'processed' => count( $ids ),
				'total'     => DAWP_WebP_Repair::count_all(),
				'fixed'     => $fixed,
				'details'   => $details,
				'done'      => count( $ids ) < 50,
			)
		);
	}

	/**
	 * Bỏ qua một ảnh.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public function post_skip( $request ) {
		$attachment_id = absint( $request->get_param( 'attachment_id' ) );
		$reason        = sanitize_text_field( (string) $request->get_param( 'reason' ) );

		// retry=1: lỗi TẠM THỜI — chỉ loại khỏi lần chạy này, lần sau thử lại.
		// retry=0: bỏ qua VĨNH VIỄN (ảnh quá nhỏ, đã tối ưu sẵn...).
		$retry = (bool) $request->get_param( 'retry' );

		if ( $attachment_id ) {
			if ( $retry ) {
				DAWP_WebP_Scanner::mark_error( $attachment_id, $reason );
			} else {
				DAWP_WebP_Scanner::mark_skipped( $attachment_id, $reason );
			}

			DAWP_WebP_DB::log(
				array(
					'attachment_id' => $attachment_id,
					'status'        => $retry ? 'error' : 'skipped',
					'message'       => $reason,
				)
			);
		}

		return rest_ensure_response(
			array(
				'skipped'   => $attachment_id,
				'retry'     => $retry,
				'remaining' => DAWP_WebP_Scanner::count_pending(),
			)
		);
	}

	/**
	 * Đưa toàn bộ ảnh lỗi tạm thời trở lại hàng đợi.
	 *
	 * @return WP_REST_Response
	 */
	public function post_reset_errors() {
		$requeued = DAWP_WebP_Scanner::reset_errors();

		return rest_ensure_response(
			array(
				'requeued' => $requeued,
				'pending'  => DAWP_WebP_Scanner::count_pending(),
			)
		);
	}

	/**
	 * Dọn URL .jpg/.png cũ còn sót trong database, theo từng lô.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public function post_sweep( $request ) {
		$table   = absint( $request->get_param( 'table' ) );
		$last_pk = absint( $request->get_param( 'last_pk' ) );

		$result = DAWP_WebP_Replacer::sweep_batch( $table, $last_pk, 200 );

		return rest_ensure_response( $result );
	}
}


