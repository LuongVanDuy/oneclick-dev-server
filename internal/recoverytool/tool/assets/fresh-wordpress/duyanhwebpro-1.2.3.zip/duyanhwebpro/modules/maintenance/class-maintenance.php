<?php
defined( 'ABSPATH' ) || exit;

class DAWP_Maintenance {
    public function __construct() {
        $options = get_option( 'dawp_settings', [] );
        
        // Nếu module bảo trì được kích hoạt
        if ( !empty($options['maintenance_active']) ) {
            add_action( 'template_redirect', [ $this, 'maintenance_mode' ] );
        }
    }

    public function maintenance_mode() {
        // Bỏ qua nếu là Admin có quyền hoặc đang truy cập trang quản trị/đăng nhập
        if ( current_user_can( 'manage_options' ) || is_admin() || ( isset( $GLOBALS['pagenow'] ) && in_array( $GLOBALS['pagenow'], array( 'wp-login.php', 'wp-register.php' ), true ) ) ) {
            return;
        }

        $options = get_option( 'dawp_settings', [] );
        $content = isset( $options['maintenance_content'] ) ? wp_kses_post( $options['maintenance_content'] ) : '<h1>Website đang bảo trì</h1><p>Vui lòng quay lại sau.</p>';
        $title   = 'Bảo trì hệ thống';

        if ( class_exists( 'DAWP_Multilingual' ) ) {
            $lang = DAWP_Multilingual::get_current_language();
            $default_lang = DAWP_Multilingual::get_default_language();
            if ( $lang !== $default_lang ) {
                // Lấy tiêu đề bảo trì dịch tay
                $trans_title = isset( $options['trans_maintenance_title_' . $lang] ) ? trim( $options['trans_maintenance_title_' . $lang] ) : '';
                if ( ! empty( $trans_title ) ) {
                    $title = $trans_title;
                } else {
                    $title_translations = [
                        'en' => 'System Maintenance',
                        'ja' => 'システムメンテナンス',
                        'zh' => '系统维护',
                        'ko' => '시스템 점검',
                        'fr' => 'Maintenance du système',
                        'de' => 'Systemwartung',
                        'ru' => 'Техническое обслуживание'
                    ];
                    if ( isset( $title_translations[ $lang ] ) ) {
                        $title = $title_translations[ $lang ];
                    }
                }

                // Lấy nội dung bảo trì dịch tay
                $trans_content = isset( $options['trans_maintenance_content_' . $lang] ) ? wp_kses_post( $options['trans_maintenance_content_' . $lang] ) : '';
                if ( ! empty( trim( strip_tags( $trans_content ) ) ) || ! empty( trim( $trans_content ) ) ) {
                    $content = $trans_content;
                } else {
                    // Fallback mặc định tiếng Anh nếu nội dung trống
                    $content = '<h1>System under maintenance</h1><p>We are upgrading our system. Please check back later.</p>';
                }
            }
        }

        if ( empty( trim( strip_tags( $content ) ) ) && empty( trim( $content ) ) ) {
            $content = '<h1>Website đang bảo trì</h1><p>Vui lòng quay lại sau.</p>';
        }

        // Đặt header 503 để SEO không bị ảnh hưởng (Google sẽ biết là tạm thời)
        header('HTTP/1.1 503 Service Temporarily Unavailable');
        header('Status: 503 Service Temporarily Unavailable');
        header('Retry-After: 3600');

        ?>
        <!DOCTYPE html>
        <html <?php language_attributes(); ?>>
        <head>
            <meta charset="<?php bloginfo( 'charset' ); ?>">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <title><?php echo esc_html( $title ); ?> - <?php echo esc_html( get_bloginfo( 'name' ) ); ?></title>
            <style>
                body {
                    margin: 0;
                    padding: 0;
                    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;
                    background-color: #f8fafc;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    min-height: 100vh;
                    color: #333;
                }
                .dawp-maintenance-box {
                    background: #fff;
                    padding: 40px;
                    border-radius: 12px;
                    box-shadow: 0 10px 30px rgba(0,0,0,0.05);
                    max-width: 800px;
                    width: 90%;
                    text-align: center;
                }
                .dawp-maintenance-box img {
                    max-width: 100%;
                    height: auto;
                    border-radius: 8px;
                    margin-bottom: 20px;
                }
                h1, h2, h3 { color: #111; }
            </style>
        </head>
        <body>
            <div class="dawp-maintenance-box">
                <?php echo do_shortcode( $content ); ?>
            </div>
        </body>
        </html>
        <?php
        exit;
    }
}
