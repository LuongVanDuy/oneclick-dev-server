<?php
defined( 'ABSPATH' ) || exit;

class DAWP_Optimization {
    private $cache_dir;
    private $cache_file;
    private $should_cache = false;
    private $slim_enabled = false;
    private $request_has_query = false;
    private static $preload_queue = [];
    private static $shutdown_registered = false;

    public function __construct() {
        $options = get_option( 'dawp_settings', false );
        if ( $options === false ) {
            $options = [
                'opt_litespeed' => 1,
                'opt_heartbeat' => 1,
                'opt_ssl' => 1,
                'opt_admin_speed' => 1,
                'opt_wc_cart_fragments' => 1,
                'opt_static_cache' => 1
            ];
        }

        // 0. Bộ lọc Cache Tĩnh (Static HTML Cache) cho mọi loại Hosting (Bắt đầu cực sớm để bypass PHP/DB)
        $this->cache_dir = WP_CONTENT_DIR . '/cache/dawp-cache/';
        if ( !empty($options['opt_static_cache']) ) {
            $this->init_static_cache();
        }

        // Dọn rác cache định kỳ — file quá TTL trước đây không bao giờ bị xóa nên
        // thư mục cache chỉ phình chứ không teo. Đăng ký cả khi cache đang tắt
        // để dọn nốt file tồn đọng từ trước.
        add_action( 'dawp_static_cache_gc', [ $this, 'gc_static_cache' ] );
        add_action( 'init', [ $this, 'schedule_cache_gc' ] );

        // 1. LiteSpeed Cache (OpenLiteSpeed Free)
        if ( !empty($options['opt_litespeed']) ) {
            add_action( 'template_redirect', [ $this, 'send_lscache_headers' ], 2 );
            
            // Tự động Purge cache khi có thay đổi nội dung (Thay thế hoàn toàn LSCache Plugin)
            add_action( 'save_post',         [ $this, 'purge_lscache' ] );
            add_action( 'deleted_post',      [ $this, 'purge_lscache' ] );
            add_action( 'comment_post',      [ $this, 'purge_lscache' ] );
            add_action( 'edit_comment',      [ $this, 'purge_lscache' ] );
            add_action( 'delete_comment',    [ $this, 'purge_lscache' ] );
            add_action( 'wp_update_nav_menu',[ $this, 'purge_lscache' ] );
            add_action( 'edited_term',       [ $this, 'purge_lscache' ] );
            add_action( 'delete_term',       [ $this, 'purge_lscache' ] );
            add_action( 'switch_theme',      [ $this, 'purge_lscache' ] );
            add_action( 'customize_save_after', [ $this, 'purge_lscache' ] );
            
            // WooCommerce: Purge khi sản phẩm thay đổi (Không xoá cache khi có đơn hàng mới tránh làm rớt điểm)
            add_action( 'woocommerce_update_product', [ $this, 'purge_lscache' ] );

            // Browser Cache: Gắn thời hạn lưu trữ tĩnh trên trình duyệt khách
            add_action( 'send_headers', [ $this, 'send_browser_cache_headers' ] );
        }

        // 2. Heartbeat API Control
        if ( !empty($options['opt_heartbeat']) ) {
            add_action( 'init', [ $this, 'control_heartbeat' ], 1 );
        }

        // 3. Force SSL & HSTS
        if ( !empty($options['opt_ssl']) ) {
            add_action( 'template_redirect', [ $this, 'force_ssl_hsts' ], 1 );
        }

        // 4. Tăng tốc Admin (Admin Speed Boost)
        if ( !empty($options['opt_admin_speed']) ) {
            add_action( 'admin_init', [ $this, 'boost_admin_speed' ], 1 );
            // Tắt hoàn toàn WooCommerce Admin (Giao diện React Analytics cực nặng của Woo)
            add_filter( 'woocommerce_admin_disabled', '__return_true' );
            // Tắt WooCommerce Marketing Hub
            add_filter( 'woocommerce_marketing_menu_items', '__return_empty_array' );
        }

        // 4.5. Tối ưu hóa WooCommerce Cart Fragments (Tắt tải giỏ hàng động trên trang thường)
        if ( !empty($options['opt_wc_cart_fragments']) ) {
            add_action( 'wp_enqueue_scripts', [ $this, 'disable_wc_cart_fragments' ], 99 );
        }

        // 5. Giới hạn số bản nháp (Revisions) để bảo vệ Database (Zero-Overhead)
        add_filter( 'wp_revisions_to_keep', [ $this, 'limit_revisions' ], 10, 2 );

        // 6. Dynamic Versioning (Smart Cache-Busting cho CSS & JS nội bộ theo thời gian sửa file thực tế)
        add_filter( 'style_loader_src', [ $this, 'add_dynamic_versioning' ], 20 );
        add_filter( 'script_loader_src', [ $this, 'add_dynamic_versioning' ], 20 );

        // 7. Hook sync drop-in cache config & install/uninstall
        add_action( 'update_option_dawp_settings', [ 'DAWP_Optimization', 'handle_pre_wp_cache_toggle' ], 10, 2 );
        add_action( 'add_option_dawp_settings', [ 'DAWP_Optimization', 'handle_pre_wp_cache_toggle' ], 10, 2 );
    }

    public function send_lscache_headers() {
        // Bỏ qua cache cho quản trị viên (Admin)
        if ( is_user_logged_in() ) return;
        
        // Bỏ qua cache cho trang Thanh toán, Giỏ hàng, Tài khoản (WooCommerce)
        if ( function_exists('is_woocommerce') && ( is_cart() || is_checkout() || is_account_page() ) ) return;
        
        // Hủy kích hoạt LiteSpeed cache để sử dụng DAWP Static Cache (đã phân tách di động/máy tính)
        header('X-LiteSpeed-Cache-Control: no-cache');
    }

    public function purge_lscache( $id = 0 ) {
        // Debounce: Chỉ thực hiện xóa cache vật lý và gửi header một lần duy nhất trong request
        static $static_cache_cleared = false;
        if ( ! $static_cache_cleared ) {
            if ( ! headers_sent() ) {
                header('X-LiteSpeed-Purge: *');
            }
            $this->clear_static_cache();
            $static_cache_cleared = true;
        }

        // Gom các URL cần mồi vào hàng đợi
        if ( class_exists( 'DAWP_Helpers' ) ) {
            $home = home_url('/');
            if ( ! in_array( $home, self::$preload_queue ) ) {
                self::$preload_queue[] = $home;
            }

            $post_id = 0;
            // Nếu là comment_post (truyền comment_id)
            if ( current_filter() === 'comment_post' && $id ) {
                $comment = get_comment( $id );
                if ( $comment ) {
                    $post_id = $comment->comment_post_ID;
                }
            } 
            // Nếu là các hook post/product khác
            elseif ( $id && ! wp_is_post_revision( $id ) ) {
                $post_id = $id;
            }

            if ( $post_id ) {
                $url = get_permalink( $post_id );
                if ( $url && ! in_array( $url, self::$preload_queue ) ) {
                    self::$preload_queue[] = $url;
                }
            }

            // Đăng ký hook shutdown để chạy nền bất đồng bộ
            if ( ! self::$shutdown_registered ) {
                add_action( 'shutdown', [ $this, 'process_preload_queue' ], 999 );
                self::$shutdown_registered = true;
            }
        }
    }

    public function process_preload_queue() {
        if ( empty( self::$preload_queue ) ) {
            return;
        }

        // Ngắt kết nối với trình duyệt ngay lập tức (Nếu chạy PHP-FPM / FastCGI) để giải phóng client
        if ( function_exists( 'fastcgi_finish_request' ) ) {
            fastcgi_finish_request();
        }

        // Thực hiện mồi cache bất đồng bộ (Chỉ mồi cho ngôn ngữ mặc định gốc để giảm tải requests)
        foreach ( self::$preload_queue as $url ) {
            DAWP_Helpers::preload_url( $url, true );
        }

        // Giải phóng hàng đợi
        self::$preload_queue = [];
    }

    public function send_browser_cache_headers() {
        // Browser Cache: Hướng dẫn trình duyệt xác thực lại mỗi lần truy cập
        if ( is_admin() || is_user_logged_in() ) return;

        // Vary header cho nén Gzip/Brotli và phân mảnh theo Cookie ngôn ngữ
        header('Vary: Accept-Encoding, Cookie');
        
        // Hướng dẫn trình duyệt xác thực lại mỗi lần truy cập (Thiết lập public để cho phép OpenLiteSpeed nén Gzip tài nguyên HTML động)
        header('Cache-Control: public, max-age=0, must-revalidate');
    }

    /**
     * Tự động tạo phiên bản động (Cache-Busting) cho CSS và JS nội bộ dựa trên thời gian sửa đổi file vật lý
     */
    public function add_dynamic_versioning( $src ) {
        if ( is_admin() || ! is_string( $src ) || empty( $src ) ) return $src;
        
        $site_url = site_url();
        // Chỉ xử lý các file nội bộ (local files)
        if ( strpos( $src, $site_url ) === 0 ) {
            // Chuyển URL thành đường dẫn vật lý trên ổ cứng
            $clean_url = strtok( $src, '?' );
            $relative_path = str_replace( $site_url, '', $clean_url );
            $file_path = ABSPATH . ltrim( $relative_path, '/' );
            
            if ( file_exists( $file_path ) ) {
                $mtime = filemtime( $file_path );
                $src = add_query_arg( 'ver', $mtime, $clean_url );
            }
        }
        return $src;
    }

    public function control_heartbeat() {
        // Giảm nhịp đập xuống tối đa (1 phút/lần) hoặc tắt hẳn ở frontend
        add_filter( 'heartbeat_settings', function( $settings ) {
            $settings['interval'] = 60; // Chậm nhất có thể để tiết kiệm CPU
            return $settings;
        });
    }

    public function force_ssl_hsts() {
        // Ép HTTPS
        if ( ! is_ssl() && ( ! isset( $_SERVER['HTTP_X_FORWARDED_PROTO'] ) || 'https' !== $_SERVER['HTTP_X_FORWARDED_PROTO'] ) ) {
            // Chống Host Header Injection bằng cách sử dụng domain chính thức được cấu hình trong WP
            $host = wp_parse_url( home_url(), PHP_URL_HOST );
            $request_uri = isset( $_SERVER['REQUEST_URI'] ) ? esc_url_raw( $_SERVER['REQUEST_URI'] ) : '';
            wp_redirect( 'https://' . $host . $request_uri, 301 );
            exit;
        }
        // Gửi Header HSTS giúp trình duyệt giảm 1 vòng lặp redirect
        header( 'Strict-Transport-Security: max-age=31536000; includeSubDomains; preload' );
    }

    public function boost_admin_speed() {
        if ( ! is_admin() ) return;

        global $pagenow;
        
        // 1. Tắt các lệnh kiểm tra cập nhật đồng bộ gây treo Admin (Để lại cho WP Cron tự chạy ngầm)
        if ( $pagenow !== 'update-core.php' && $pagenow !== 'plugins.php' && $pagenow !== 'update.php' ) {
            remove_action( 'admin_init', '_maybe_update_core' );
            remove_action( 'admin_init', '_maybe_update_plugins' );
            remove_action( 'admin_init', '_maybe_update_themes' );
        }

        // 2. Tắt Heartbeat script trong Admin ngoại trừ khi viết bài/sửa bài để giảm tải CPU máy chủ tối đa
        add_action( 'admin_enqueue_scripts', function() {
            global $pagenow;
            if ( $pagenow !== 'post.php' && $pagenow !== 'post-new.php' ) {
                wp_dequeue_script('heartbeat');
            }
        }, 99 );

        // 4. Loại bỏ các widget tin tức rác ngoài Dashboard gây làm chậm truy vấn tải trang
        add_action( 'wp_dashboard_setup', function() {
            remove_meta_box( 'wp_dashboard_primary', 'dashboard', 'side' );      // Tin tức WordPress
            remove_meta_box( 'wp_dashboard_quick_press', 'dashboard', 'side' );   // Bản nháp nhanh
        } );

        // 5. Tắt kiểm tra tự động cập nhật ngôn ngữ để không nghẽn đường truyền kết nối ngoài
        add_filter( 'auto_update_translation', '__return_false' );

        // 6. Tắt Emoji trong admin để tránh tải script/style thừa
        remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
        remove_action( 'admin_print_styles', 'print_emoji_styles' );

        // 7. Dequeue Gutenberg block library CSS trong admin nếu classic editor đang hoạt động
        add_action( 'admin_enqueue_scripts', function() {
            $classic_active = false;
            if ( class_exists( 'DAWP_Classic_Editor' ) || has_filter( 'use_block_editor_for_post', '__return_false' ) ) {
                $classic_active = true;
            }
            if ( $classic_active ) {
                wp_dequeue_style( 'wp-block-library' );
                wp_dequeue_style( 'wp-block-library-theme' );
                wp_dequeue_style( 'wc-blocks-style' );
            }
        }, 999 );

        // 8. Tăng AUTOSAVE_INTERVAL lên tối thiểu 60s nếu chưa được định nghĩa
        if ( ! defined( 'AUTOSAVE_INTERVAL' ) ) {
            define( 'AUTOSAVE_INTERVAL', 60 );
        }
    }

    public function limit_revisions( $num, $post = null ) {
        return 5; // Giới hạn tối đa 5 bản nháp
    }

    public function disable_wc_cart_fragments() {
        if ( function_exists( 'is_cart' ) && function_exists( 'is_checkout' ) ) {
            if ( ! is_cart() && ! is_checkout() ) {
                wp_dequeue_script( 'wc-cart-fragments' );
            }
        }
    }

    /**
     * Sao lưu file cấu hình nhạy cảm (wp-config.php, .htaccess) vào thư mục
     * wp-content/dawp-backups được chặn truy cập web, thay vì để bản sao dạng
     * text ngay web root — bản sao ở web root cho phép tải trực tiếp qua URL
     * và lộ toàn bộ DB credentials + AUTH salts.
     */
    public static function backup_sensitive_file( $source_file, $slug ) {
        $content = @file_get_contents( $source_file );
        if ( false === $content ) {
            return false;
        }

        $backup_dir = WP_CONTENT_DIR . '/dawp-backups';
        if ( ! is_dir( $backup_dir ) && ! wp_mkdir_p( $backup_dir ) ) {
            return false;
        }

        // Lớp 1: chặn truy cập qua .htaccess (Apache/LiteSpeed)
        if ( ! file_exists( $backup_dir . '/.htaccess' ) ) {
            $deny = "<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\nOrder deny,allow\nDeny from all\n</IfModule>\n";
            @file_put_contents( $backup_dir . '/.htaccess', $deny );
        }
        if ( ! file_exists( $backup_dir . '/index.php' ) ) {
            @file_put_contents( $backup_dir . '/index.php', "<?php // Silence is golden.\n" );
        }

        // Lớp 2: đuôi .php + dòng exit đầu file — server không đọc .htaccess (Nginx)
        // thì request trực tiếp cũng chỉ thực thi exit, không lộ nội dung.
        // Khi cần khôi phục thủ công: xóa dòng đầu tiên của file backup.
        $target = $backup_dir . '/' . sanitize_file_name( $slug ) . '-backup.php';
        return @file_put_contents( $target, "<?php exit; // DAWP backup - remove this line to restore ?>\n" . $content ) !== false;
    }

    /**
     * Di dời các bản sao lưu của phiên bản plugin cũ đang nằm lộ ở web root
     * vào thư mục backup được bảo vệ.
     */
    public static function cleanup_legacy_backups() {
        $legacy = [
            ABSPATH . '.htaccess.backup'                     => 'htaccess-legacy',
            ABSPATH . 'wp-config.php.dawp_backup'            => 'wp-config-legacy',
            dirname( ABSPATH ) . '/wp-config.php.dawp_backup' => 'wp-config-legacy',
        ];
        foreach ( $legacy as $old_file => $slug ) {
            if ( file_exists( $old_file ) && self::backup_sensitive_file( $old_file, $slug ) ) {
                @unlink( $old_file );
            }
        }
    }

    /**
     * Tự động ghi/xóa cấu hình tối ưu hóa vào file .htaccess ở thư mục gốc WordPress
     */
    public static function update_htaccess_rules() {
        self::cleanup_legacy_backups();
        $htaccess_file = ABSPATH . '.htaccess';
        
        // 1. Lấy cấu hình hiện tại
        $options = get_option( 'dawp_settings', [] );
        $opt_htaccess = ! isset( $options['opt_htaccess'] ) || ! empty( $options['opt_htaccess'] );
        $optimization_active = ! isset( $options['optimization_active'] ) || ! empty( $options['optimization_active'] );
        $ps_brotli = ! isset( $options['ps_brotli'] ) || ! empty( $options['ps_brotli'] );
        
        if ( file_exists( $htaccess_file ) ) {
            $content = file_get_contents( $htaccess_file );
            if ( ! empty( $content ) ) {
                self::backup_sensitive_file( $htaccess_file, 'htaccess' );
            }
        } else {
            if ( ! is_writable( ABSPATH ) ) {
                return false;
            }
            touch( $htaccess_file );
            $content = '';
        }

        if ( ! is_writable( $htaccess_file ) ) {
            return false;
        }

        $pattern = '/# BEGIN DAWP_OPTIMIZATIONS.*?# END DAWP_OPTIMIZATIONS/s';
        $content = preg_replace( $pattern, '', $content );
        $custom_pattern = '/# BEGIN DAWP_CUSTOM_SEO_RULES.*?# END DAWP_CUSTOM_SEO_RULES/s';
        $content = preg_replace( $custom_pattern, '', $content );
        $content = trim( $content );

        if ( $optimization_active && $opt_htaccess ) {
            $brotli_block = "";
            if ( $ps_brotli ) {
                $brotli_block = "
# ----------------------------------------------------------------------
# | Nén Brotli tài nguyên để giảm dung lượng tải (mod_brotli)
# ----------------------------------------------------------------------
<IfModule mod_brotli.c>
    AddOutputFilterByType BROTLI_COMPRESS text/html text/plain text/xml text/css text/javascript application/javascript application/x-javascript application/xml application/xhtml+xml application/json application/svg+xml image/svg+xml font/ttf font/otf font/woff font/woff2
</IfModule>
";
            }

            $rules = "\n\n# BEGIN DAWP_OPTIMIZATIONS
# ----------------------------------------------------------------------
# | Tự động phân tách bộ nhớ đệm LiteSpeed cho di động và máy tính
# ----------------------------------------------------------------------
<IfModule LiteSpeed>
    RewriteEngine On
    RewriteCond %{HTTP_USER_AGENT} (Mobile|Android|iPhone|iPad|iPod|Windows\ Phone|Silk/|Kindle|BlackBerry|Opera\ Mini|Opera\ Mobi) [NC]
    RewriteRule .* - [E=Cache-Vary:is_mobile]
</IfModule>
" . $brotli_block . "
# ----------------------------------------------------------------------
# | Nén Gzip tài nguyên để giảm băng thông (mod_deflate)
# ----------------------------------------------------------------------
<IfModule mod_deflate.c>
    AddOutputFilterByType DEFLATE text/html text/plain text/xml text/css text/javascript application/javascript application/x-javascript application/xml application/xhtml+xml application/json application/svg+xml image/svg+xml font/ttf font/otf font/woff font/woff2
</IfModule>

# ----------------------------------------------------------------------
# | Cấu hình Cache trình duyệt sâu cho ảnh và fonts (mod_expires)
# ----------------------------------------------------------------------
<IfModule mod_expires.c>
    ExpiresActive On
    ExpiresDefault \"access plus 1 month\"
    
    # Cache ảnh & fonts 1 năm (Rất an toàn vì đổi ảnh sẽ đổi tên file)
    ExpiresByType image/jpg \"access plus 1 year\"
    ExpiresByType image/jpeg \"access plus 1 year\"
    ExpiresByType image/png \"access plus 1 year\"
    ExpiresByType image/gif \"access plus 1 year\"
    ExpiresByType image/webp \"access plus 1 year\"
    ExpiresByType image/svg+xml \"access plus 1 year\"
    ExpiresByType image/x-icon \"access plus 1 year\"
    ExpiresByType font/ttf \"access plus 1 year\"
    ExpiresByType font/otf \"access plus 1 year\"
    ExpiresByType font/woff \"access plus 1 year\"
    ExpiresByType font/woff2 \"access plus 1 year\"
    
    # Cache CSS & JS 7 ngày (Ngăn kẹt cache sâu khi sửa code giao diện)
    ExpiresByType text/css \"access plus 7 days\"
    ExpiresByType text/javascript \"access plus 7 days\"
    ExpiresByType application/javascript \"access plus 7 days\"
</IfModule>

# ----------------------------------------------------------------------
# | Tăng bảo mật & cấu hình kiểm soát Cache
# ----------------------------------------------------------------------
<IfModule mod_headers.c>
    # Thêm chỉ thị must-revalidate ép trình duyệt kiểm tra ETag/mtime với máy chủ khi hết 7 ngày
    <FilesMatch \"\.(css|js)$\">
        Header set Cache-Control \"max-age=604800, public, must-revalidate\"
    </FilesMatch>
    Header set X-Content-Type-Options \"nosniff\"
    Header set X-Frame-Options \"SAMEORIGIN\"
    Header set X-XSS-Protection \"1; mode=block\"
</IfModule>

# Ngăn chặn duyệt thư mục trực tiếp bảo vệ mã nguồn (Bỏ dấu # ở dòng dưới nếu hosting của bạn hỗ trợ AllowOverride Options)
# Options -Indexes

# Tránh WordPress khởi động để xử lý 404 của tệp tĩnh bị thiếu (Tiết kiệm tối đa CPU/RAM)
<IfModule mod_rewrite.c>
    RewriteEngine On
    RewriteCond %{REQUEST_FILENAME} !-f
    RewriteCond %{REQUEST_FILENAME} !-d
    RewriteCond %{REQUEST_URI} /(wp-content|wp-includes)/ [NC]
    RewriteCond %{REQUEST_URI} \.(css|js|jpe?g|gif|png|webp|ico|svg|woff2?|map)$ [NC]
    RewriteRule . - [R=404,L]
</IfModule>
# END DAWP_OPTIMIZATIONS\n";
            $content .= $rules;
        }

        // Ghi luật chuyển hướng / cấu hình máy chủ tùy biến từ CSDL vào .htaccess
        $custom_rules = isset( $options['seo_htaccess'] ) ? trim( $options['seo_htaccess'] ) : '';
        if ( ! empty( $custom_rules ) ) {
            $content .= "\n\n# BEGIN DAWP_CUSTOM_SEO_RULES\n" . $custom_rules . "\n# END DAWP_CUSTOM_SEO_RULES\n";
        }

        return file_put_contents( $htaccess_file, $content ) !== false;
    }

    /**
     * Thuật toán Cache Tĩnh (Static HTML Caching) - WP Rocket Style (Zero-Overhead)
     */
    private function init_static_cache() {
        // Không cache khi đang ở Chế độ Bảo trì
        $options = get_option( 'dawp_settings', [] );
        if ( ! empty( $options['maintenance_active'] ) ) {
            return;
        }

        // Tạo config sidecar tự động nếu tuỳ chọn pre-wp cache đang mở mà chưa có file cấu hình
        if ( ! empty( $options['opt_pre_wp_cache'] ) ) {
            if ( ! file_exists( $this->cache_dir . '_dropin_config.php' ) ) {
                self::write_dropin_config( true );
            }

            // Tự làm mới drop-in advanced-cache.php khi template trong plugin thay đổi
            // (cập nhật plugin không tự đụng tới file drop-in đã copy ra wp-content).
            // Chỉ so sánh khi vào admin để không tốn I/O cho khách vãng lai.
            if ( is_admin() && defined( 'DAWP_DIR' ) ) {
                $dropin_template = DAWP_DIR . 'tools/templates/advanced-cache.php';
                $dropin_target   = WP_CONTENT_DIR . '/advanced-cache.php';
                if ( file_exists( $dropin_template ) && file_exists( $dropin_target )
                    && md5_file( $dropin_template ) !== md5_file( $dropin_target ) ) {
                    @copy( $dropin_template, $dropin_target );
                }
            }
        }

        if ( is_admin() || wp_doing_ajax() || wp_doing_cron() ) {
            return;
        }

        // Chỉ cache GET request
        if ( isset($_SERVER['REQUEST_METHOD']) && $_SERVER['REQUEST_METHOD'] !== 'GET' ) {
            return;
        }

        // Bỏ qua nếu có cookie đăng nhập hoặc giỏ hàng có hàng
        if ( !empty($_COOKIE) ) {
            foreach ( $_COOKIE as $key => $val ) {
                if ( preg_match('/wordpress_logged_in_|wp-postpass_|woocommerce_items_in_cart|comment_author_/', $key) ) {
                    return;
                }
                // Bỏ qua cache tĩnh nếu trang đang được xem bằng ngôn ngữ dịch thuật
                if ( $key === 'googtrans' ) {
                    $parts = explode('/', trim($val, '/'));
                    if ( count($parts) === 2 && $parts[0] !== $parts[1] ) {
                        return;
                    }
                }
            }
        }

        // Bỏ qua các trang giỏ hàng, thanh toán, tài khoản bằng cách quét URI
        $request_uri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
        if ( preg_match('/\/(gio-hang|cart|thanh-toan|checkout|tai-khoan|my-account|wp-admin|wp-login)/i', $request_uri) ) {
            return;
        }

        // Chuẩn hóa URI cho khóa cache: BỎ tham số tracking (utm_*, fbclid, gclid...)
        // khỏi khóa vì nội dung trang không đổi; query còn lại (search, filter,
        // add-to-cart...) thì KHÔNG cache. Trước đây khóa dùng nguyên REQUEST_URI
        // nên mỗi biến thể query của quảng cáo/bot sinh 1 file mới không giới hạn,
        // khiến thư mục cache phình nhiều GB.
        $uri_parts = explode( '?', $request_uri, 2 );
        $uri_path  = $uri_parts[0];
        if ( isset( $uri_parts[1] ) && '' !== $uri_parts[1] ) {
            parse_str( $uri_parts[1], $query_vars );
            foreach ( array_keys( $query_vars ) as $qk ) {
                if ( self::is_tracking_param( $qk ) ) {
                    unset( $query_vars[ $qk ] );
                }
            }
            if ( ! empty( $query_vars ) ) {
                return;
            }
        }

        $host = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '';
        $is_mobile = preg_match( '/(Mobile|Android|Silk\/|Kindle|BlackBerry|Opera Mini|Opera Mobi)/i', $_SERVER['HTTP_USER_AGENT'] ?? '' ) ? '-mobile' : '-desktop';

        // Phân mảnh theo ngôn ngữ: làm sạch cookie đồng bộ với drop-in và chỉ nhận
        // mã ngôn ngữ đang kích hoạt — cookie tùy biến không nhân bản được khóa cache
        $lang = '';
        if ( isset( $_COOKIE['dawp_lang'] ) ) {
            $lang = substr( preg_replace( '/[^a-zA-Z_\-]/', '', $_COOKIE['dawp_lang'] ), 0, 10 );
        }
        if ( class_exists( 'DAWP_Multilingual' ) ) {
            if ( '' === $lang || ! array_key_exists( $lang, DAWP_Multilingual::get_active_languages() ) ) {
                $lang = DAWP_Multilingual::get_default_language();
            }
        } elseif ( '' === $lang ) {
            $lang = 'vi';
        }

        $cache_key = md5( $host . $uri_path . $lang . $is_mobile );
        $this->cache_file = $this->cache_dir . $cache_key . '.html';

        // 1. Nếu file cache tồn tại và chưa quá 12 tiếng (43200s), xuất ra màn hình và dừng lại ngay lập tức
        if ( file_exists( $this->cache_file ) ) {
            $mtime = filemtime( $this->cache_file );
            if ( ( time() - $mtime ) < 43200 ) {
                $etag = '"' . md5( $mtime . $this->cache_file ) . '"';
                $last_modified = gmdate( 'D, d M Y H:i:s', $mtime ) . ' GMT';
                
                header( 'Cache-Control: public, max-age=0, must-revalidate' );
                header( 'Last-Modified: ' . $last_modified );
                header( 'ETag: ' . $etag );
                header( 'Vary: Accept-Encoding, Cookie' );

                $if_none_match = isset( $_SERVER['HTTP_IF_NONE_MATCH'] ) ? trim( $_SERVER['HTTP_IF_NONE_MATCH'] ) : '';
                $if_modified_since = isset( $_SERVER['HTTP_IF_MODIFIED_SINCE'] ) ? trim( $_SERVER['HTTP_IF_MODIFIED_SINCE'] ) : '';

                if ( $if_none_match === $etag || ( $if_modified_since && strtotime( $if_modified_since ) >= $mtime ) ) {
                    if ( ob_get_length() ) ob_clean();
                    if ( function_exists( 'status_header' ) ) {
                        status_header( 304 );
                    } else {
                        header( 'HTTP/1.1 304 Not Modified' );
                    }
                    header( 'X-DAWP-Cache: Hit (Static HTML 304)' );
                    exit;
                }

                $content = file_get_contents( $this->cache_file );
                if ( $content ) {
                    if ( ob_get_length() ) ob_clean();
                    if ( function_exists( 'status_header' ) ) {
                        status_header( 200 );
                    } else {
                        header( 'HTTP/1.1 200 OK' );
                    }
                    header( 'X-DAWP-Cache: Hit (Static HTML)' );
                    
                    // Kích hoạt nén GZIP cho static cache hit để tối ưu hóa truyền tải trên di động
                    if ( ! headers_sent() && extension_loaded('zlib') && !ini_get('zlib.output_compression') ) {
                        ob_start('ob_gzhandler');
                    }
                    
                    echo $content;
                    echo "\n<!-- DAWP Static Cache Hit (" . date('Y-m-d H:i:s', $mtime) . ") -->";
                    
                    if ( ob_get_length() ) {
                        @ob_end_flush();
                    }
                    exit;
                }
            }
        }

        // 2. Nếu chưa có cache, khởi động Output Buffering và ghi lại
        // Ghi nhớ trạng thái để buffer_callback biết có nên đóng băng trang này
        // không: Gọn CSS có đang bật, và lượt này có mang query string (utm...) —
        // lượt có query bị Gọn CSS cố ý bỏ qua nên KHÔNG được ghi đè khóa URL gốc.
        $this->slim_enabled      = ! empty( $options['ps_slim_css'] );
        $this->request_has_query = isset( $uri_parts[1] ) && '' !== $uri_parts[1];

        $this->should_cache = true;
        ob_start( [ $this, 'buffer_callback' ] );

        // Ngăn WordPress tự động flush buffer gây lỗi Notice với zlib
        remove_action( 'shutdown', 'wp_ob_end_flush_all', 1 );
    }

    /**
     * Tham số tracking không làm đổi nội dung trang — loại khỏi khóa cache
     * để mọi biến thể quảng cáo dùng chung 1 file.
     */
    private static function is_tracking_param( $param ) {
        $param = strtolower( (string) $param );
        if ( 0 === strpos( $param, 'utm_' ) ) {
            return true;
        }
        return in_array( $param, [ 'fbclid', 'gclid', 'gbraid', 'wbraid', 'msclkid', 'yclid', 'ttclid', 'zarsrc', 'srsltid', 'mc_cid', 'mc_eid', '_ga', '_gl', 'ref' ], true );
    }

    public function buffer_callback( $buffer ) {

        // KHÔNG đóng băng trạng thái CHƯA Gọn CSS vào cache tĩnh. Nếu ghi nhằm lúc
        // CSS Slim chưa áp dụng, mọi cache hit sau đó phục vụ bản CSS chặn hiển thị
        // (300KB+) cho TẤT CẢ khách, mà cache hit thì PHP không chạy nên slim không
        // bao giờ được phân tích lại — trạng thái chưa tối ưu bị kẹt vĩnh viễn. Hai
        // trường hợp cần né:
        //  (1) slim đang chờ phân tích lại (đổi theme/sửa CSS → sig-mismatch, no-meta,
        //      css-unreadable): DAWP_CSS_Slim::$last_reason khác rỗng.
        //  (2) lượt có query string (utm/fbclid...): slim cố ý bỏ qua URL có tham số
        //      nên HTML chưa gọn, trong khi khóa cache lại quy về URL gốc → sẽ đưa
        //      bản chưa gọn cho cả khách vào URL sạch.
        // Chỉ đọc trạng thái (static property + marker) của DAWP_CSS_Slim, không gọi
        // ngược lại — không tạo phụ thuộc vòng. Nhường lượt sau (khách vào URL sạch,
        // meta đã sẵn) tự tạo cache ở trạng thái đã tối ưu.
        if ( $this->slim_enabled && class_exists( 'DAWP_CSS_Slim' ) ) {
            $chua_gon = ( '' !== DAWP_CSS_Slim::$last_reason )
                || ( $this->request_has_query && false === strpos( $buffer, 'id="dawp-slim-css"' ) );
            if ( $chua_gon ) {
                return $buffer;
            }
        }

        // Chỉ lưu cache khi nội dung hợp lệ, trang load trọn vẹn (</html>) và trả
        // về 200 — không cache trang 404/lỗi, kẻo mỗi URL rác bot quét thành 1 file
        if ( $this->should_cache && !empty($buffer) && strpos($buffer, '</html>') !== false
            && ! is_404() && 200 === http_response_code() ) {
            if ( ! file_exists( $this->cache_dir ) ) {
                wp_mkdir_p( $this->cache_dir );
                @file_put_contents( $this->cache_dir . 'index.php', '<?php // Silence is golden' );
            }
            // Ghi file cache tĩnh nguyên tử (Atomic Write) tránh xung đột khi ghi đồng thời
            $temp_file = $this->cache_file . '.' . uniqid('', true) . '.tmp';
            if ( @file_put_contents( $temp_file, $buffer ) !== false ) {
                @rename( $temp_file, $this->cache_file );

                // ~2% số lần ghi: soi tổng dung lượng, vượt trần 500MB thì hẹn GC dọn ngay
                if ( 1 === mt_rand( 1, 50 ) ) {
                    $this->maybe_trim_cache();
                }
            }
        }
        return $buffer;
    }

    public function schedule_cache_gc() {
        // Chỉ kiểm tra/bootstrap lịch khi vào admin — sự kiện recurring của WP-Cron
        // tự gia hạn sau mỗi lần chạy nên frontend không cần soi lịch, tiết kiệm
        // 1 lần quét mảng cron cho mọi request của khách
        if ( ! is_admin() ) {
            return;
        }
        if ( ! wp_next_scheduled( 'dawp_static_cache_gc' ) ) {
            wp_schedule_event( time() + HOUR_IN_SECONDS, 'twicedaily', 'dawp_static_cache_gc' );
        }
    }

    /**
     * Trần dung lượng thư mục cache tĩnh (mặc định 500MB/site).
     * Tùy biến qua filter: add_filter( 'dawp_cache_max_bytes', fn() => 300 * MB_IN_BYTES );
     * Trả về 0 = không giới hạn.
     */
    private static function cache_max_bytes() {
        return (int) apply_filters( 'dawp_cache_max_bytes', 500 * MB_IN_BYTES );
    }

    /**
     * Xóa file cache đã quá TTL 12 tiếng và file .tmp mồ côi do ghi dở, sau đó
     * áp trần dung lượng: nếu tổng còn lại vượt trần thì xóa dần file CŨ NHẤT
     * (gần hết hạn nhất, sẽ phải render lại sớm nhất) cho tới khi xuống dưới trần.
     * Chạy 2 lần/ngày qua WP-Cron, và được kích thêm bất đồng bộ từ
     * maybe_trim_cache() khi phát hiện vượt trần giữa 2 lần cron.
     */
    public function gc_static_cache() {
        $files = glob( $this->cache_dir . '*' );
        if ( ! is_array( $files ) ) {
            return;
        }
        $now   = time();
        $kept  = [];
        $total = 0;
        foreach ( $files as $file ) {
            $name = basename( $file );
            if ( 'index.php' === $name || '_dropin_config.php' === $name || ! is_file( $file ) ) {
                continue;
            }
            $mtime = @filemtime( $file );
            if ( false === $mtime || ( $now - $mtime ) > 43200 ) {
                @unlink( $file );
                continue;
            }
            $size   = (int) @filesize( $file );
            $total += $size;
            $kept[] = [ $file, $mtime, $size ];
        }

        $max = self::cache_max_bytes();
        if ( $max > 0 && $total > $max ) {
            usort( $kept, function ( $a, $b ) {
                return $a[1] <=> $b[1];
            } );
            foreach ( $kept as $item ) {
                if ( $total <= $max ) {
                    break;
                }
                if ( @unlink( $item[0] ) ) {
                    $total -= $item[2];
                }
            }
        }
    }

    /**
     * Kiểm tra trần dung lượng ngoài chu kỳ cron: được gọi theo xác suất nhỏ sau
     * mỗi lần ghi cache. Chỉ đo tổng dung lượng tối đa 1 lần/10 phút (transient
     * chặn đo lặp), phát hiện vượt trần thì hẹn GC chạy bất đồng bộ ngay qua
     * WP-Cron — không tốn I/O dọn dẹp trong request của khách.
     */
    private function maybe_trim_cache() {
        if ( false !== get_transient( 'dawp_cache_size_checked' ) ) {
            return;
        }
        set_transient( 'dawp_cache_size_checked', 1, 10 * MINUTE_IN_SECONDS );

        $max = self::cache_max_bytes();
        if ( $max <= 0 ) {
            return;
        }

        $total = 0;
        foreach ( (array) glob( $this->cache_dir . '*.html' ) as $file ) {
            $total += (int) @filesize( $file );
        }

        if ( $total > $max ) {
            wp_schedule_single_event( time(), 'dawp_static_cache_gc' );
        }
    }

    public function clear_static_cache() {
        if ( file_exists( $this->cache_dir ) ) {
            $files = glob( $this->cache_dir . '*' );
            if ( is_array($files) ) {
                foreach ( $files as $file ) {
                    if ( is_file( $file ) ) {
                        @unlink( $file );
                    }
                }
            }
        }
    }

    public static function write_dropin_config( $enabled = true ) {
        $cache_dir = WP_CONTENT_DIR . '/cache/dawp-cache/';
        if ( ! file_exists( $cache_dir ) ) {
            wp_mkdir_p( $cache_dir );
            @file_put_contents( $cache_dir . 'index.php', '<?php // Silence is golden' );
        }
        $config_file = $cache_dir . '_dropin_config.php';
        
        $default_lang = 'vi';
        if ( class_exists( 'DAWP_Multilingual' ) ) {
            $default_lang = DAWP_Multilingual::get_default_language();
        }
        
        $config_data = [
            'enabled'      => $enabled,
            'default_lang' => $default_lang,
            'ttl'          => 43200
        ];
        
        $content = "<?php\n// DAWP Drop-in Configuration\nreturn " . var_export( $config_data, true ) . ";\n";
        @file_put_contents( $config_file, $content );
    }

    public static function install_pre_wp_cache() {
        $template_file = DAWP_DIR . 'tools/templates/advanced-cache.php';
        $target_file = WP_CONTENT_DIR . '/advanced-cache.php';
        
        if ( ! file_exists( $template_file ) ) {
            return false;
        }
        
        // 1. Copy advanced-cache.php to wp-content
        $copied = @copy( $template_file, $target_file );
        if ( ! $copied ) {
            return false;
        }
        
        // 2. Write dropin config
        self::write_dropin_config( true );
        
        // 3. Edit wp-config.php to enable WP_CACHE
        $wp_config_file = ABSPATH . 'wp-config.php';
        if ( ! file_exists( $wp_config_file ) || ! is_writable( $wp_config_file ) ) {
            $wp_config_file = dirname( ABSPATH ) . '/wp-config.php';
            if ( ! file_exists( $wp_config_file ) || ! is_writable( $wp_config_file ) ) {
                return false;
            }
        }
        
        $content = file_get_contents( $wp_config_file );
        if ( strpos( $content, 'WP_CACHE' ) === false ) {
            self::backup_sensitive_file( $wp_config_file, 'wp-config' );
            $pos = strpos( $content, '<?php' );
            if ( $pos !== false ) {
                $inserted = substr_replace( $content, "<?php\n\n// Added by DAWP Pro\ndefine('WP_CACHE', true);\n", $pos, 5 );
                @file_put_contents( $wp_config_file, $inserted );
            }
        } else {
            if ( preg_match( "/define\(\s*['\"]WP_CACHE['\"]\s*,\s*false\s*\)/i", $content ) ) {
                self::backup_sensitive_file( $wp_config_file, 'wp-config' );
                $replaced = preg_replace( "/define\(\s*['\"]WP_CACHE['\"]\s*,\s*false\s*\)/i", "define('WP_CACHE', true)", $content );
                @file_put_contents( $wp_config_file, $replaced );
            }
        }
        
        return true;
    }

    public static function uninstall_pre_wp_cache() {
        // 1. Remove advanced-cache.php
        $target_file = WP_CONTENT_DIR . '/advanced-cache.php';
        if ( file_exists( $target_file ) ) {
            @unlink( $target_file );
        }
        
        // 2. Disable dropin config
        self::write_dropin_config( false );
        
        // 3. Disable WP_CACHE in wp-config.php
        $wp_config_file = ABSPATH . 'wp-config.php';
        if ( ! file_exists( $wp_config_file ) || ! is_writable( $wp_config_file ) ) {
            $wp_config_file = dirname( ABSPATH ) . '/wp-config.php';
            if ( ! file_exists( $wp_config_file ) || ! is_writable( $wp_config_file ) ) {
                return false;
            }
        }
        
        $content = file_get_contents( $wp_config_file );
        if ( strpos( $content, 'WP_CACHE' ) !== false ) {
            self::backup_sensitive_file( $wp_config_file, 'wp-config' );
            $cleaned = preg_replace( "/\/\/ Added by DAWP Pro\s*define\(\s*['\"]WP_CACHE['\"]\s*,\s*true\s*\);\s*/i", "", $content );
            $cleaned = preg_replace( "/define\(\s*['\"]WP_CACHE['\"]\s*,\s*true\s*\)/i", "define('WP_CACHE', false)", $cleaned );
            @file_put_contents( $wp_config_file, $cleaned );
        }
        
        return true;
    }

    public static function handle_pre_wp_cache_toggle( $old_value_or_option, $new_value_or_value = null ) {
        $old_value = [];
        $new_value = [];
        
        if ( current_filter() === 'add_option_dawp_settings' ) {
            $new_value = $new_value_or_value;
        } else {
            $old_value = $old_value_or_option;
            $new_value = $new_value_or_value;
        }
        
        if ( ! is_array( $new_value ) ) {
            return;
        }
        
        $old_active = ( ! empty( $old_value['optimization_active'] ) && ! empty( $old_value['opt_static_cache'] ) && ! empty( $old_value['opt_pre_wp_cache'] ) ) ? 1 : 0;
        $new_active = ( ! empty( $new_value['optimization_active'] ) && ! empty( $new_value['opt_static_cache'] ) && ! empty( $new_value['opt_pre_wp_cache'] ) ) ? 1 : 0;
        
        if ( $old_active === $new_active ) {
            if ( $new_active ) {
                self::write_dropin_config( true );
            }
            return;
        }
        
        if ( $new_active ) {
            self::install_pre_wp_cache();
        } else {
            self::uninstall_pre_wp_cache();
        }
    }
}
