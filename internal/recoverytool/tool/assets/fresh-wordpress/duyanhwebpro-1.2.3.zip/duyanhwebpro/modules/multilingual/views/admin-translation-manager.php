<?php
if ( ! defined( 'ABSPATH' ) ) exit;

global $wpdb;

// Lấy tất cả bài viết/trang (chỉ tiếng Việt vì giờ không còn bài nhân bản)
$query = "
    SELECT p.ID, p.post_title, p.post_type, p.post_date 
    FROM {$wpdb->posts} p 
    WHERE p.post_status = 'publish' 
    AND p.post_type IN ('page', 'post', 'product', 'blocks') 
    ORDER BY p.post_date DESC
";
$posts = $wpdb->get_results( $query );
$active_langs = DAWP_Multilingual::get_active_languages();
?>
<div class="wrap">
    <h1 class="wp-heading-inline">Quản lý Bản dịch (Translation Manager)</h1>
    <p>Chức năng giúp nhân viên dễ dàng quản lý và chỉnh sửa bản dịch siêu tốc với giao diện chia đôi màn hình.</p>
    
    <table class="wp-list-table widefat fixed striped table-view-list posts">
        <thead>
            <tr>
                <th style="width: 50px;">ID</th>
                <th>Tiêu đề (Tiếng Việt)</th>
                <th style="width: 100px;">Loại</th>
                <?php foreach ( $active_langs as $code => $info ) : 
                    if ( $code === 'vi' ) continue;
                ?>
                <th style="width: 120px; text-align: center;">
                    <img src="https://flagcdn.com/w40/<?php echo esc_attr( $info['flag'] ); ?>.png" width="20" style="vertical-align:middle; border-radius:3px;"> 
                    <?php echo esc_html( $info['name'] ); ?>
                </th>
                <?php endforeach; ?>
            </tr>
        </thead>
        <tbody>
            <?php if ( empty( $posts ) ) : ?>
                <tr><td colspan="5">Không tìm thấy bài viết nào.</td></tr>
            <?php else : foreach ( $posts as $p ) : ?>
                <tr>
                    <td><?php echo esc_html( $p->ID ); ?></td>
                    <td>
                        <strong><a href="<?php echo esc_url( get_edit_post_link( $p->ID ) ); ?>" target="_blank"><?php echo esc_html( $p->post_title ); ?></a></strong>
                    </td>
                    <td><?php echo esc_html( ucfirst( $p->post_type ) ); ?></td>
                    
                    <?php foreach ( $active_langs as $code => $info ) : 
                        if ( $code === 'vi' ) continue;
                        $trans_title = get_post_meta( $p->ID, "_dawp_trans_{$code}_title", true );
                        $has_translation = ! empty( $trans_title );
                    ?>
                    <td style="text-align: center;">
                        <?php if ( $has_translation ) : ?>
                            <a href="#" class="button dawp-quick-translate-btn" data-id="<?php echo $p->ID; ?>" data-lang="<?php echo $code; ?>" title="Sửa bản dịch">
                                <span class="dashicons dashicons-yes" style="color: #46b450; line-height: 26px;"></span> Sửa
                            </a>
                        <?php else : ?>
                            <a href="#" class="button button-primary dawp-quick-translate-btn" data-id="<?php echo $p->ID; ?>" data-lang="<?php echo $code; ?>" title="Thêm bản dịch">
                                <span class="dashicons dashicons-plus" style="line-height: 26px;"></span> Thêm
                            </a>
                        <?php endif; ?>
                    </td>
                    <?php endforeach; ?>
                </tr>
            <?php endforeach; endif; ?>
        </tbody>
    </table>
</div>

<!-- Modal Dịch Nhanh -->
<div id="dawp-translation-modal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.7); z-index: 99999;">
    <div style="position: absolute; top: 5%; left: 5%; width: 90%; height: 90%; background: #fff; border-radius: 8px; display: flex; flex-direction: column; overflow: hidden; box-shadow: 0 5px 15px rgba(0,0,0,0.3);">
        
        <div style="padding: 15px 20px; background: #f0f0f1; border-bottom: 1px solid #ccd0d4; display: flex; justify-content: space-between; align-items: center;">
            <h2 style="margin: 0;" id="dawp-modal-title">Dịch bài viết</h2>
            <button id="dawp-modal-close" class="button"><span class="dashicons dashicons-no" style="line-height: 26px;"></span> Đóng</button>
        </div>

        <div style="display: flex; flex: 1; overflow: hidden;">
            <!-- Cột Tiếng Việt (Bản Gốc) -->
            <div style="flex: 1; border-right: 1px solid #ccd0d4; padding: 20px; overflow-y: auto; background: #fafafa;">
                <h3 style="margin-top: 0;">Bản gốc (Tiếng Việt)</h3>
                <div style="margin-bottom: 15px;">
                    <label><strong>Tiêu đề:</strong></label>
                    <input type="text" id="dawp_orig_title" readonly style="width: 100%; background: #eee; padding: 8px; margin-top: 5px;">
                </div>
                <div>
                    <label><strong>Nội dung:</strong></label>
                    <textarea id="dawp_orig_content" readonly style="width: 100%; height: 400px; background: #eee; padding: 8px; margin-top: 5px;"></textarea>
                </div>
            </div>

            <!-- Cột Bản Dịch -->
            <div style="flex: 1; padding: 20px; overflow-y: auto;">
                <h3 style="margin-top: 0;" id="dawp-target-lang-title">Bản dịch</h3>
                <form id="dawp-translation-form">
                    <input type="hidden" id="dawp_source_post_id" name="source_post_id">
                    <input type="hidden" id="dawp_trans_lang" name="lang">
                    <input type="hidden" name="action" value="dawp_save_translation_data">
                    <input type="hidden" name="nonce" value="<?php echo wp_create_nonce('dawp_translation_ajax'); ?>">

                    <div style="margin-bottom: 15px;">
                        <label><strong>Tiêu đề:</strong> <span style="color:red;">*</span></label>
                        <input type="text" id="dawp_target_title" name="title" required style="width: 100%; padding: 8px; margin-top: 5px;" placeholder="Nhập tiêu đề bản dịch...">
                    </div>
                    <div>
                        <label><strong>Nội dung:</strong></label>
                        <textarea id="dawp_target_content" name="content" style="width: 100%; height: 400px; padding: 8px; margin-top: 5px;" placeholder="Nhập nội dung bản dịch..."></textarea>
                    </div>
                </form>
            </div>
        </div>

        <div style="padding: 15px 20px; background: #f0f0f1; border-top: 1px solid #ccd0d4; text-align: right;">
            <span id="dawp-translation-status" style="display: none; margin-right: 15px; font-weight: bold;"></span>
            <button id="dawp-translation-save" class="button button-primary button-hero"><span class="dashicons dashicons-saved" style="line-height: 26px;"></span> LƯU BẢN DỊCH</button>
        </div>

    </div>
</div>

<script>
jQuery(document).ready(function($) {
    var $modal = $('#dawp-translation-modal');
    var $status = $('#dawp-translation-status');
    var isSaving = false;

    $('.dawp-quick-translate-btn').click(function(e) {
        e.preventDefault();
        var postId = $(this).data('id');
        var lang = $(this).data('lang');
        var langName = lang === 'en' ? 'Tiếng Anh (English)' : 'Tiếng Trung (中文)';

        $('#dawp-modal-title').text('Dịch bài viết #' + postId + ' sang ' + langName);
        $('#dawp-target-lang-title').text('Bản dịch ' + langName);
        $('#dawp_source_post_id').val(postId);
        $('#dawp_trans_lang').val(lang);

        $status.hide();
        $('#dawp_orig_title, #dawp_orig_content, #dawp_target_title, #dawp_target_content').val('Đang tải dữ liệu...');
        $modal.fadeIn();

        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'dawp_get_translation_data',
                nonce: '<?php echo wp_create_nonce('dawp_translation_ajax'); ?>',
                post_id: postId,
                lang: lang
            },
            success: function(response) {
                if (response.success) {
                    var data = response.data;
                    $('#dawp_orig_title').val(data.orig_title);
                    $('#dawp_orig_content').val(data.orig_content);
                    $('#dawp_target_title').val(data.target_title);
                    $('#dawp_target_content').val(data.target_content);
                } else {
                    alert('Lỗi tải dữ liệu: ' + response.data);
                    $modal.fadeOut();
                }
            }
        });
    });

    $('#dawp-modal-close').click(function() {
        if (isSaving) return;
        $modal.fadeOut();
    });

    $('#dawp-translation-save').click(function(e) {
        e.preventDefault();
        if (isSaving) return;

        var title = $('#dawp_target_title').val().trim();
        if (!title) {
            alert('Vui lòng nhập tiêu đề!');
            $('#dawp_target_title').focus();
            return;
        }

        isSaving = true;
        var $btn = $(this);
        $btn.addClass('updating-message').prop('disabled', true);
        $status.text('Đang lưu...').css('color', '#000').show();

        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: $('#dawp-translation-form').serialize(),
            success: function(response) {
                if (response.success) {
                    $status.text('Đã lưu thành công!').css('color', '#46b450');
                    setTimeout(function() {
                        location.reload(); // Tải lại trang để cập nhật icon check xanh
                    }, 1000);
                } else {
                    $status.text('Lỗi: ' + response.data).css('color', '#dc3232');
                    isSaving = false;
                    $btn.removeClass('updating-message').prop('disabled', false);
                }
            },
            error: function() {
                $status.text('Lỗi kết nối máy chủ!').css('color', '#dc3232');
                isSaving = false;
                $btn.removeClass('updating-message').prop('disabled', false);
            }
        });
    });
});
</script>
