<?php
defined( 'ABSPATH' ) || exit;

/**
 * Module: Kích hoạt Bricks từ xa (Remote Bricks License)
 *
 * Nhận key bản quyền Bricks do tool "kichhoatbricks" chạy trên PC của Duy Anh Web
 * đẩy xuống qua REST API rồi tự kích hoạt với my.bricksbuilder.io — thay cho việc
 * phải UltraViewer vào máy khách gõ key bằng tay.
 *
 * Nguyên tắc an toàn:
 * - Key chỉ đi MỘT CHIỀU: tool -> web. Không có endpoint nào trả key ra ngoài.
 * - Xác thực bằng CHỮ KÝ SỐ RSA: file này chỉ chứa KHÓA CÔNG KHAI (chỉ dùng để
 *   kiểm tra chữ ký). Khóa riêng để ký lệnh nằm duy nhất trong tool trên PC của
 *   Duy Anh Web, nên ai đọc được toàn bộ mã nguồn plugin cũng không giả mạo được
 *   lệnh kích hoạt/thu hồi, càng không lấy được key (plugin không chứa key).
 * - Chữ ký ôm cả domain đích + mốc thời gian (hạn 15 phút): bắt được gói tin
 *   cũng không phát lại được sang web khác hay dùng lại về sau.
 * - Key chỉ được lưu vào database khi máy chủ Bricks xác nhận kích hoạt thành công.
 * - Trang Bricks > License giữ nguyên như mặc định của Bricks, không ẩn đi, để còn
 *   tự kiểm tra và xử lý tay khi cần.
 */
class DAWP_Bricks_License {

    // Khóa công khai RSA 2048 — cặp với khóa riêng trong tool kichhoatbricks trên PC
    const PUBLIC_KEY = '-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA9ZtB4o+HDeNyPk156XLd
CfNob1Ju1eyEVzpEC5Nl/6mP6Kvfzdp8RapKi9j2TnSGGI0saAW+2WMkoyMACTNd
fGONc9pdUYGQQPX5eCWXC7rdZfHDPiZ6O91o990c4+7I1YvG+wsYNrwAgYesnddO
hegsc/LtRsy86Oxx+9s1hRC0NVTjSyIqdopzloVj1e581yNA9gS9W8BmjjbH1to9
nko6sJRCo8m46SAAaCYYi732CPXaHzvmfTuSpxY3Ps8jMtjCwIWXw26VJsHPc4EL
/mtQSmZQ29PLuHaYowCbKqpH3MdTAWgQpqfZmith3/N/6+fQxjOUDtSkU76PzWr0
/wIDAQAB
-----END PUBLIC KEY-----';

    // Lệnh ký chỉ có hiệu lực trong 15 phút (chống phát lại)
    const SIGN_TTL = 900;

    // API bản quyền chính thức của Bricks (giống hệt themes/bricks/includes/license.php)
    const REMOTE_BASE_URL = 'https://my.bricksbuilder.io/api/commerce/';

    public function __construct() {
        add_action( 'rest_api_init', [ $this, 'register_routes' ] );
    }

    public function register_routes() {
        register_rest_route( 'dawp/v1', '/bricks-kichhoat', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'handle_activate' ],
            'permission_callback' => '__return_true',
        ] );

        register_rest_route( 'dawp/v1', '/bricks-trangthai', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'handle_status' ],
            'permission_callback' => '__return_true',
        ] );

        register_rest_route( 'dawp/v1', '/bricks-thuhoi', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'handle_revoke' ],
            'permission_callback' => '__return_true',
        ] );
    }

    /**
     * Kiểm tra chữ ký số của lệnh + chặn dò (khóa IP 1 giờ sau 10 lần sai)
     *
     * Tool trên PC ký chuỗi: DAWP-BRICKS|{action}|{host}|{timestamp}|{sha256(license_key)}
     * bằng khóa riêng. Ở đây dựng lại chuỗi đó với host CỦA CHÍNH WEB NÀY rồi kiểm
     * bằng khóa công khai — chữ ký ký cho web khác hay đã quá hạn đều tự trượt.
     *
     * @param WP_REST_Request $request     Yêu cầu REST.
     * @param string          $action      kichhoat|trangthai|thuhoi.
     * @param string          $license_key Key nhận được (rỗng nếu lệnh không kèm key).
     *
     * @return true|WP_Error
     */
    private function verify_signature( WP_REST_Request $request, $action, $license_key = '' ) {
        $ip       = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( $_SERVER['REMOTE_ADDR'] ) : 'unknown';
        $lock_key = 'dawp_bricks_lock_' . md5( $ip );
        $fails    = (int) get_transient( $lock_key );

        if ( $fails >= 10 ) {
            return new WP_Error( 'dawp_locked', 'Quá nhiều lần thử sai. Vui lòng thử lại sau 1 giờ.', [ 'status' => 429 ] );
        }

        if ( ! function_exists( 'openssl_verify' ) ) {
            return new WP_Error( 'dawp_no_openssl', 'Máy chủ web này thiếu phần mở rộng OpenSSL của PHP.', [ 'status' => 500 ] );
        }

        $timestamp = (int) $request->get_param( 'timestamp' );
        $signature = base64_decode( (string) $request->get_param( 'sign' ), true );

        $that_fails = function ( $code, $message, $status ) use ( $lock_key, $fails ) {
            set_transient( $lock_key, $fails + 1, HOUR_IN_SECONDS );
            return new WP_Error( $code, $message, [ 'status' => $status ] );
        };

        if ( ! $timestamp || ! $signature ) {
            return $that_fails( 'dawp_missing_sign', 'Thiếu chữ ký hoặc mốc thời gian.', 403 );
        }

        if ( abs( time() - $timestamp ) > self::SIGN_TTL ) {
            return $that_fails( 'dawp_sign_expired', 'Chữ ký đã quá hạn (lệch quá 15 phút). Kiểm tra đồng hồ máy tính rồi thử lại.', 403 );
        }

        $host    = strtolower( (string) wp_parse_url( home_url(), PHP_URL_HOST ) );
        $message = 'DAWP-BRICKS|' . $action . '|' . $host . '|' . $timestamp . '|' . hash( 'sha256', (string) $license_key );

        if ( openssl_verify( $message, $signature, self::PUBLIC_KEY, OPENSSL_ALGO_SHA256 ) !== 1 ) {
            $error = $that_fails( 'dawp_bad_sign', 'Chữ ký không hợp lệ cho web này.', 403 );
            // Gửi kèm host web đang dùng để tool tự ký lại khi anh gõ domain khác host thật (vd thiếu www)
            $error->add_data( [ 'status' => 403, 'host' => $host ], 'dawp_bad_sign' );
            return $error;
        }

        delete_transient( $lock_key );

        return true;
    }

    /**
     * Lấy thông tin theme Bricks (kể cả khi đang dùng child theme)
     *
     * @return WP_Theme|false
     */
    private function get_bricks_theme() {
        $theme = wp_get_theme( 'bricks' );

        return $theme->exists() ? $theme : false;
    }

    /**
     * POST /wp-json/dawp/v1/bricks-kichhoat
     * Nhận key từ tool, kích hoạt với máy chủ Bricks, thành công mới lưu key.
     */
    public function handle_activate( WP_REST_Request $request ) {
        $verified = $this->verify_signature( $request, 'kichhoat', (string) $request->get_param( 'license_key' ) );
        if ( is_wp_error( $verified ) ) {
            return $verified;
        }

        $theme = $this->get_bricks_theme();
        if ( ! $theme ) {
            return new WP_Error( 'dawp_no_bricks', 'Web này chưa cài theme Bricks.', [ 'status' => 400 ] );
        }

        $license_key = sanitize_text_field( (string) $request->get_param( 'license_key' ) );
        $license_key = trim( wp_strip_all_tags( html_entity_decode( $license_key ) ) );

        if ( ! $license_key ) {
            return new WP_Error( 'dawp_no_key', 'Thiếu license key.', [ 'status' => 400 ] );
        }

        // Gửi yêu cầu kích hoạt y hệt trình tự trong themes/bricks/includes/license.php
        $response = wp_remote_post(
            self::REMOTE_BASE_URL . 'license/activate_license',
            [
                'sslverify' => false,
                'timeout'   => 30,
                'body'      => [
                    'license_key' => $license_key,
                    'site'        => get_site_url(),
                    'version'     => $theme->get( 'Version' ),
                ],
            ]
        );

        if ( is_wp_error( $response ) ) {
            return new WP_Error( 'dawp_remote_error', 'Không kết nối được máy chủ Bricks: ' . $response->get_error_message(), [ 'status' => 502 ] );
        }

        $response_code = wp_remote_retrieve_response_code( $response );
        $response_body = json_decode( wp_remote_retrieve_body( $response ), true );

        $license_status = false;

        if ( is_array( $response_body ) && isset( $response_body['status'] ) ) {
            $license_status = $response_body['status'];
        }

        // Bricks coi 403 (CloudFlare) và 415 (Imunify360) là kích hoạt thành công
        if ( ! $license_status && in_array( $response_code, [ 403, 415 ], true ) ) {
            $license_status = 'active';
        }

        // Máy chủ Bricks báo lỗi rõ ràng (key sai, bị khóa...)
        if ( is_array( $response_body ) && isset( $response_body['type'] ) && $response_body['type'] === 'error' ) {
            return new WP_Error(
                'dawp_bricks_error',
                'Máy chủ Bricks từ chối: ' . wp_strip_all_tags( $response_body['message'] ?? 'không rõ lý do' ),
                [ 'status' => 400 ]
            );
        }

        $valid_statuses = [ 'active', 'processed', 'canceled', 'past_due' ];

        if ( ! in_array( $license_status, $valid_statuses, true ) ) {
            return new WP_Error(
                'dawp_activate_failed',
                'Kích hoạt không thành công (mã phản hồi ' . $response_code . ', trạng thái: ' . ( $license_status ?: 'không có' ) . ').',
                [ 'status' => 400 ]
            );
        }

        // Kích hoạt thành công: lưu key + trạng thái đúng chỗ Bricks vẫn lưu
        update_option( 'bricks_license_key', $license_key );
        set_transient( 'bricks_license_status', $license_status, 168 * HOUR_IN_SECONDS );
        update_option( 'dawp_bricks_managed', 1 );

        return rest_ensure_response(
            [
                'ket_qua'        => 'ok',
                'status'         => $license_status,
                'site'           => get_site_url(),
                'bricks_version' => $theme->get( 'Version' ),
            ]
        );
    }

    /**
     * POST /wp-json/dawp/v1/bricks-trangthai
     * Trả về tình trạng license hiện tại. Không bao giờ trả về key.
     */
    public function handle_status( WP_REST_Request $request ) {
        $verified = $this->verify_signature( $request, 'trangthai' );
        if ( is_wp_error( $verified ) ) {
            return $verified;
        }

        $theme = $this->get_bricks_theme();

        return rest_ensure_response(
            [
                'ket_qua'        => 'ok',
                'site'           => get_site_url(),
                'co_bricks'      => (bool) $theme,
                'bricks_version' => $theme ? $theme->get( 'Version' ) : '',
                'da_co_key'      => (bool) get_option( 'bricks_license_key' ),
                'status'         => get_transient( 'bricks_license_status' ) ?: '',
                'tool_quan_ly'   => (bool) get_option( 'dawp_bricks_managed' ),
                'dawp_version'   => defined( 'DAWP_VERSION' ) ? DAWP_VERSION : '',
            ]
        );
    }

    /**
     * POST /wp-json/dawp/v1/bricks-thuhoi
     * Thu hồi key: báo máy chủ Bricks gỡ site này khỏi license rồi xóa key khỏi database.
     */
    public function handle_revoke( WP_REST_Request $request ) {
        $verified = $this->verify_signature( $request, 'thuhoi' );
        if ( is_wp_error( $verified ) ) {
            return $verified;
        }

        $license_key = get_option( 'bricks_license_key' );

        if ( $license_key ) {
            $theme = $this->get_bricks_theme();

            // Báo máy chủ Bricks gỡ site khỏi danh sách kích hoạt (giống nút Deactivate của Bricks)
            wp_remote_post(
                self::REMOTE_BASE_URL . 'license/deactivate_license',
                [
                    'sslverify' => false,
                    'timeout'   => 30,
                    'body'      => [
                        'license_key' => $license_key,
                        'site'        => get_site_url(),
                        'version'     => $theme ? $theme->get( 'Version' ) : '',
                    ],
                ]
            );
        }

        delete_option( 'bricks_license_key' );
        delete_transient( 'bricks_license_status' );
        delete_option( 'dawp_bricks_managed' );

        return rest_ensure_response(
            [
                'ket_qua' => 'ok',
                'site'    => get_site_url(),
                'message' => $license_key ? 'Đã thu hồi key khỏi web này.' : 'Web này không có key để thu hồi.',
            ]
        );
    }
}
