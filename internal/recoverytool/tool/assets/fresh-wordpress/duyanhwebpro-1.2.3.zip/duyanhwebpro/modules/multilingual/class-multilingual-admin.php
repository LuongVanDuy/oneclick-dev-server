<?php
defined( 'ABSPATH' ) || exit;

class DAWP_Multilingual_Admin {

    public function __construct() {
        global $pagenow;
        $is_ajax = wp_doing_ajax();

        // 1. Đăng ký AJAX handlers (luôn cần khi chạy AJAX)
        if ( $is_ajax ) {
            add_action( 'wp_ajax_dawp_get_translation_data', [ $this, 'ajax_get_translation_data' ] );
            add_action( 'wp_ajax_dawp_save_translation_data', [ $this, 'ajax_save_translation_data' ] );
        }

        // 2. Admin Bar & language switch (mọi trang admin, trừ AJAX)
        if ( ! $is_ajax ) {
            add_action( 'admin_bar_menu', [ $this, 'add_admin_bar_language_switcher' ], 90 );
            add_action( 'admin_init', [ $this, 'handle_admin_language_switch' ], 1 );
        }

        // 3. Đăng ký các hook Lưu dữ liệu toàn cục để tránh mất dữ liệu (Save hooks)
        add_action( 'save_post', [ $this, 'save_language_meta_data' ], 99, 2 );
        add_action( 'wp_update_nav_menu_item', [ $this, 'save_menu_item_translation_fields' ], 10, 3 );
        add_action( 'init', [ $this, 'register_taxonomy_save_hooks' ], 99 );

        // 4. Màn hình Sửa/Thêm bài viết (post.php, post-new.php)
        if ( $pagenow === 'post.php' || $pagenow === 'post-new.php' ) {
            add_action( 'add_meta_boxes', [ $this, 'add_language_meta_box' ] );
            add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_admin_assets' ] );
        }

        // 5. Màn hình Danh sách bài viết/trang (edit.php)
        if ( $pagenow === 'edit.php' ) {
            add_filter( 'manage_posts_columns', [ $this, 'add_language_column' ] );
            add_action( 'manage_posts_custom_column', [ $this, 'render_language_column' ], 10, 2 );
            add_filter( 'manage_pages_columns', [ $this, 'add_language_column' ] );
            add_action( 'manage_pages_custom_column', [ $this, 'render_language_column' ], 10, 2 );
            
            add_action( 'quick_edit_custom_box', [ $this, 'render_quick_edit_translation_fields' ], 10, 2 );
            add_action( 'admin_footer', [ $this, 'print_quick_edit_js' ] );
            add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_admin_assets' ] );
        }

        // 6. Màn hình Chuyên mục / Nhãn (edit-tags.php, term.php)
        if ( $pagenow === 'edit-tags.php' || $pagenow === 'term.php' ) {
            add_action( 'init', [ $this, 'register_taxonomy_render_hooks' ], 99 );
            add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_admin_assets' ] );
        }

        // 7. Màn hình Menu (nav-menus.php)
        if ( $pagenow === 'nav-menus.php' ) {
            add_action( 'wp_nav_menu_item_custom_fields', [ $this, 'render_menu_item_custom_fields' ], 10, 4 );
            add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_admin_assets' ] );
        }

        // 8. Trang Quản lý Bản dịch
        add_action( 'admin_menu', [ $this, 'register_translation_manager_page' ] );
    }

    public function register_taxonomy_save_hooks() {
        $taxonomies = get_taxonomies( [ 'public' => true ], 'names' );
        foreach ( $taxonomies as $taxonomy ) {
            add_action( "create_{$taxonomy}", [ $this, 'save_term_language_data' ] );
            add_action( "edit_{$taxonomy}", [ $this, 'save_term_language_data' ] );
        }
    }

    public function register_taxonomy_render_hooks() {
        $taxonomies = get_taxonomies( [ 'public' => true ], 'names' );
        foreach ( $taxonomies as $taxonomy ) {
            add_action( "{$taxonomy}_add_form_fields", [ $this, 'add_term_language_field' ] );
            add_action( "{$taxonomy}_edit_form_fields", [ $this, 'edit_term_language_field' ] );
        }
    }

    public function register_translation_manager_page() {
        add_submenu_page(
            'duyanhwebpro',
            'Quản lý Bản dịch',
            'Quản lý Bản dịch',
            'manage_options',
            'dawp-translation-manager',
            [ $this, 'render_translation_manager_page' ]
        );
    }

    public function enqueue_admin_assets() {
        wp_enqueue_editor();
        wp_add_inline_style( 'wp-admin', '
            .dawp-flag-badge { display: inline-block; width: 18px; height: 18px; border-radius: 50%; object-fit: cover; vertical-align: middle; margin-right: 5px; box-shadow: 0 1px 3px rgba(0,0,0,0.15); border: 1px solid #ddd; }
            .dawp-meta-lang-row { display: flex; align-items: center; margin-bottom: 12px; }
            .dawp-meta-lang-row strong { width: 120px; display: inline-block; }
            .dawp-meta-lang-list { border-top: 1px solid #eee; padding-top: 10px; margin-top: 10px; }
            .dawp-meta-lang-list-item { display: flex; align-items: center; justify-content: space-between; margin-bottom: 8px; }
            .dawp-meta-lang-list-item .lang-action { text-decoration: none; display: inline-flex; align-items: center; gap: 4px; }
            .dawp-meta-lang-list-item .lang-action:hover { text-decoration: underline; }
            .dawp-flag-column { display: inline-flex; align-items: center; gap: 4px; }
            .dawp-translation-notice { padding: 15px; background: #f0f6fc; border-left: 4px solid #72aee6; margin: 10px 0; border-radius: 3px; }
            .dawp-translation-notice p { margin: 0 0 8px 0; }
            .dawp-translation-notice p:last-child { margin-bottom: 0; }
        ' );
    }

    public function add_language_meta_box() {
        $post_types = get_post_types( [ 'show_ui' => true ] );
        foreach ( $post_types as $pt ) {
            if ( in_array( $pt, [ 'attachment' ] ) ) {
                continue;
            }
            add_meta_box(
                'dawp_translation_editor_meta_box',
                'Dịch nhanh đa ngôn ngữ (Quick Translate)',
                [ $this, 'render_translation_editor_meta_box' ],
                $pt,
                'normal',
                'high'
            );
        }
    }

    public function render_translation_editor_meta_box( $post ) {
        $active_langs = DAWP_Multilingual::get_active_languages();
        if ( count( $active_langs ) <= 1 ) {
            echo '<p>Vui lòng kích hoạt thêm ngôn ngữ phụ trong cài đặt hệ thống để sử dụng tính năng dịch thuật.</p>';
            return;
        }

        wp_nonce_field( 'dawp_save_language', 'dawp_language_nonce' );

        $default_lang = DAWP_Multilingual::get_default_language();
        $langs_to_translate = [];
        foreach ( $active_langs as $code => $info ) {
            if ( $code === $default_lang ) {
                continue;
            }
            $langs_to_translate[ $code ] = $info;
        }

        if ( empty( $langs_to_translate ) ) {
            echo '<p>Vui lòng kích hoạt thêm ngôn ngữ phụ trong cài đặt hệ thống để sử dụng tính năng dịch thuật.</p>';
            return;
        }

        // Nạp trực tiếp dữ liệu dịch từ Meta bài viết hiện tại
        $translations = [];
        $fields = [ 'title', 'content', 'excerpt', 'seo_title', 'seo_desc', 'og_title', 'og_desc', 'og_image' ];
        foreach ( $langs_to_translate as $code => $info ) {
            $translations[ $code ] = [];
            foreach ( $fields as $field ) {
                $translations[ $code ][ $field ] = get_post_meta( $post->ID, "_dawp_trans_{$code}_{$field}", true );
            }
        }
        ?>
        <!-- Container nguồn chứa các input dịch đa ngôn ngữ cho bài viết -->
        <div id="dawp-post-translations-source" style="display: none;">
            <!-- Tiêu đề -->
            <div id="dawp-tr-post-title-container" style="margin-top: 10px; max-width: 100%;">
                <?php foreach ( $langs_to_translate as $code => $info ) : 
                    $val = isset( $translations[ $code ]['title'] ) ? $translations[ $code ]['title'] : '';
                    ?>
                    <div style="margin-bottom: 8px;">
                        <span style="font-size: 11px; font-weight: 600; color: #475569; display: inline-flex; align-items: center; gap: 4px;">
                            <img class="dawp-flag-badge" src="https://flagcdn.com/w40/<?php echo esc_attr( $info['flag'] ); ?>.png" style="margin: 0; width: 14px; height: 14px;" /> TIÊU ĐỀ BẢN DỊCH (<?php echo esc_html( $info['name'] ); ?>)
                        </span>
                        <input type="text" name="dawp_tr_title[<?php echo esc_attr( $code ); ?>]" value="<?php echo esc_attr( $val ); ?>" style="width: 100%; margin-top: 3px; padding: 6px;" placeholder="Nhập tiêu đề <?php echo esc_attr( $info['name'] ); ?>..." />
                    </div>
                <?php endforeach; ?>
            </div>

            <!-- Nội dung -->
            <div id="dawp-tr-post-content-container" style="margin-top: 15px; margin-bottom: 15px; max-width: 100%;">
                <?php foreach ( $langs_to_translate as $code => $info ) : 
                    $val = isset( $translations[ $code ]['content'] ) ? $translations[ $code ]['content'] : '';
                    ?>
                    <div style="margin-bottom: 12px;">
                        <span style="font-size: 11px; font-weight: 600; color: #475569; display: inline-flex; align-items: center; gap: 4px; margin-bottom: 5px;">
                            <img class="dawp-flag-badge" src="https://flagcdn.com/w40/<?php echo esc_attr( $info['flag'] ); ?>.png" style="margin: 0; width: 14px; height: 14px;" /> NỘI DUNG BẢN DỊCH (<?php echo esc_html( $info['name'] ); ?>)
                        </span>
                        <div class="dawp-tr-editor-wrapper" style="margin-top: 5px; position: relative;">
                            <textarea 
                                name="dawp_tr_content[<?php echo esc_attr( $code ); ?>]" 
                                id="dawptrcontent<?php echo esc_attr( $code ); ?>" 
                                class="dawp-tr-content-textarea" 
                                style="width: 100%; height: 250px; padding: 10px; border: 1px solid #ccc; border-radius: 4px; font-family: monospace; box-sizing: border-box;" 
                                placeholder="Nhập nội dung <?php echo esc_attr( $info['name'] ); ?>..."
                            ><?php echo esc_textarea( $val ); ?></textarea>
                            <div class="dawp-tr-activate-btn-container" style="margin-top: 5px; text-align: right;">
                                <button type="button" class="button button-secondary dawp-tr-activate-editor-btn" data-id="dawptrcontent<?php echo esc_attr( $code ); ?>" style="font-size: 11px;">
                                    <span class="dashicons dashicons-editor-code" style="vertical-align: middle; font-size: 16px; width: 16px; height: 16px; margin-right: 4px;"></span> Kích hoạt trình soạn thảo trực quan (Rich Editor)
                                </button>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <!-- Tóm tắt -->
            <?php if ( post_type_supports( $post->post_type, 'excerpt' ) ) : ?>
                <div id="dawp-tr-post-excerpt-container" style="margin-top: 10px; max-width: 100%;">
                    <?php foreach ( $langs_to_translate as $code => $info ) : 
                        $val = isset( $translations[ $code ]['excerpt'] ) ? $translations[ $code ]['excerpt'] : '';
                        ?>
                        <div style="margin-bottom: 8px;">
                            <span style="font-size: 11px; font-weight: 600; color: #475569; display: inline-flex; align-items: center; gap: 4px;">
                                <img class="dawp-flag-badge" src="https://flagcdn.com/w40/<?php echo esc_attr( $info['flag'] ); ?>.png" style="margin: 0; width: 14px; height: 14px;" /> TÓM TẮT BẢN DỊCH (<?php echo esc_html( $info['name'] ); ?>)
                            </span>
                            <textarea name="dawp_tr_excerpt[<?php echo esc_attr( $code ); ?>]" rows="3" style="width: 100%; margin-top: 3px; padding: 6px;" placeholder="Tóm tắt <?php echo esc_attr( $info['name'] ); ?>..."><?php echo esc_textarea( $val ); ?></textarea>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <!-- Tiêu đề SEO -->
            <div id="dawp-tr-post-seo-title-container" style="margin-top: 10px; max-width: 100%;">
                <?php foreach ( $langs_to_translate as $code => $info ) : 
                    $val = isset( $translations[ $code ]['seo_title'] ) ? $translations[ $code ]['seo_title'] : '';
                    ?>
                    <div style="margin-bottom: 8px;">
                        <span style="font-size: 11px; font-weight: 600; color: #475569; display: inline-flex; align-items: center; gap: 4px;">
                            <img class="dawp-flag-badge" src="https://flagcdn.com/w40/<?php echo esc_attr( $info['flag'] ); ?>.png" style="margin: 0; width: 14px; height: 14px;" /> TIÊU ĐỀ SEO (<?php echo esc_html( $info['name'] ); ?>)
                        </span>
                        <input type="text" name="dawp_tr_seo_title[<?php echo esc_attr( $code ); ?>]" value="<?php echo esc_attr( $val ); ?>" style="width: 100%; margin-top: 3px; padding: 6px;" placeholder="Mặc định lấy từ tiêu đề bản dịch..." />
                    </div>
                <?php endforeach; ?>
            </div>

            <!-- Mô tả Meta -->
            <div id="dawp-tr-post-seo-desc-container" style="margin-top: 10px; max-width: 100%;">
                <?php foreach ( $langs_to_translate as $code => $info ) : 
                    $val = isset( $translations[ $code ]['seo_desc'] ) ? $translations[ $code ]['seo_desc'] : '';
                    ?>
                    <div style="margin-bottom: 8px;">
                        <span style="font-size: 11px; font-weight: 600; color: #475569; display: inline-flex; align-items: center; gap: 4px;">
                            <img class="dawp-flag-badge" src="https://flagcdn.com/w40/<?php echo esc_attr( $info['flag'] ); ?>.png" style="margin: 0; width: 14px; height: 14px;" /> MÔ TẢ META (<?php echo esc_html( $info['name'] ); ?>)
                        </span>
                        <textarea name="dawp_tr_seo_desc[<?php echo esc_attr( $code ); ?>]" rows="3" style="width: 100%; margin-top: 3px; padding: 6px;" placeholder="Nhập mô tả Meta <?php echo esc_attr( $info['name'] ); ?>..."><?php echo esc_textarea( $val ); ?></textarea>
                    </div>
                <?php endforeach; ?>
            </div>

            <!-- Tiêu đề MXH -->
            <div id="dawp-tr-post-og-title-container" style="margin-top: 10px; max-width: 100%;">
                <?php foreach ( $langs_to_translate as $code => $info ) : 
                    $val = isset( $translations[ $code ]['og_title'] ) ? $translations[ $code ]['og_title'] : '';
                    ?>
                    <div style="margin-bottom: 8px;">
                        <span style="font-size: 11px; font-weight: 600; color: #475569; display: inline-flex; align-items: center; gap: 4px;">
                            <img class="dawp-flag-badge" src="https://flagcdn.com/w40/<?php echo esc_attr( $info['flag'] ); ?>.png" style="margin: 0; width: 14px; height: 14px;" /> TIÊU ĐỀ CHIA SẺ MXH (<?php echo esc_html( $info['name'] ); ?>)
                        </span>
                        <input type="text" name="dawp_tr_og_title[<?php echo esc_attr( $code ); ?>]" value="<?php echo esc_attr( $val ); ?>" style="width: 100%; margin-top: 3px; padding: 6px;" placeholder="Mặc định lấy từ tiêu đề SEO bản dịch..." />
                    </div>
                <?php endforeach; ?>
            </div>

            <!-- Mô tả MXH -->
            <div id="dawp-tr-post-og-desc-container" style="margin-top: 10px; max-width: 100%;">
                <?php foreach ( $langs_to_translate as $code => $info ) : 
                    $val = isset( $translations[ $code ]['og_desc'] ) ? $translations[ $code ]['og_desc'] : '';
                    ?>
                    <div style="margin-bottom: 8px;">
                        <span style="font-size: 11px; font-weight: 600; color: #475569; display: inline-flex; align-items: center; gap: 4px;">
                            <img class="dawp-flag-badge" src="https://flagcdn.com/w40/<?php echo esc_attr( $info['flag'] ); ?>.png" style="margin: 0; width: 14px; height: 14px;" /> MÔ TẢ CHIA SẺ MXH (<?php echo esc_html( $info['name'] ); ?>)
                        </span>
                        <textarea name="dawp_tr_og_desc[<?php echo esc_attr( $code ); ?>]" rows="2" style="width: 100%; margin-top: 3px; padding: 6px;" placeholder="Mặc định lấy từ mô tả Meta bản dịch..."><?php echo esc_textarea( $val ); ?></textarea>
                    </div>
                <?php endforeach; ?>
            </div>

            <!-- Ảnh MXH -->
            <div id="dawp-tr-post-og-image-container" style="margin-top: 10px; max-width: 100%;">
                <?php foreach ( $langs_to_translate as $code => $info ) : 
                    $val = isset( $translations[ $code ]['og_image'] ) ? $translations[ $code ]['og_image'] : '';
                    ?>
                    <div style="margin-bottom: 8px;">
                        <span style="font-size: 11px; font-weight: 600; color: #475569; display: inline-flex; align-items: center; gap: 4px;">
                            <img class="dawp-flag-badge" src="https://flagcdn.com/w40/<?php echo esc_attr( $info['flag'] ); ?>.png" style="margin: 0; width: 14px; height: 14px;" /> ẢNH CHIA SẺ MXH (<?php echo esc_html( $info['name'] ); ?>)
                        </span>
                        <div style="display: flex; gap: 10px; margin-top: 3px;">
                            <input type="text" name="dawp_tr_og_image[<?php echo esc_attr( $code ); ?>]" id="dawp_tr_og_image_<?php echo esc_attr( $code ); ?>" value="<?php echo esc_attr( $val ); ?>" style="flex: 1; padding: 6px;" placeholder="Mặc định lấy từ ảnh đại diện..." />
                            <button type="button" class="button dawp-tr-seo-upload-btn" data-target="dawp_tr_og_image_<?php echo esc_attr( $code ); ?>">Chọn ảnh</button>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <div id="dawp-tr-gutenberg-fields" style="display:none; margin-top: 15px;">
            <p id="dawp-tr-gutenberg-notice" style="display:none; color: #64748b; font-size: 13px; font-style: italic; margin-bottom: 15px;">
                ⚠️ Bạn đang dùng Block Editor (Gutenberg). Các trường dịch tay được quy tụ tại đây để sửa đổi trực tiếp.
            </p>
        </div>

        <script>
        jQuery(document).ready(function($) {
            if ($('#titlewrap').length) {
                // Classic Editor: Di chuyển các trường vào đúng vị trí
                $('#titlewrap').append($('#dawp-tr-post-title-container'));
                $('#postdivrich').after($('#dawp-tr-post-content-container'));
                if ($('#postexcerpt .inside').length) {
                    $('#postexcerpt .inside').append($('#dawp-tr-post-excerpt-container'));
                }
                
                setTimeout(function() {
                    $('#dawp_seo_title').parent().append($('#dawp-tr-post-seo-title-container'));
                    $('#dawp_seo_desc').parent().append($('#dawp-tr-post-seo-desc-container'));
                    $('#dawp_seo_og_title').parent().append($('#dawp-tr-post-og-title-container'));
                    $('#dawp_seo_og_desc').parent().append($('#dawp-tr-post-og-desc-container'));
                    $('#dawp_seo_og_image').parent().parent().append($('#dawp-tr-post-og-image-container'));
                }, 200);

                $('#dawp_translation_editor_meta_box').css({
                    'background': 'transparent',
                    'border': 'none',
                    'box-shadow': 'none'
                });
                $('#dawp_translation_editor_meta_box h2').hide();
                $('#dawp_translation_editor_meta_box .inside').css('padding', '0');
            } else {
                // Gutenberg Editor: Đưa vào metabox stacked
                $('#dawp-tr-gutenberg-notice').show();
                $('#dawp-tr-gutenberg-fields').show();
                
                $('#dawp-tr-post-title-container').appendTo('#dawp-tr-gutenberg-fields');
                $('#dawp-tr-post-content-container').appendTo('#dawp-tr-gutenberg-fields');
                $('#dawp-tr-post-excerpt-container').appendTo('#dawp-tr-gutenberg-fields');
                $('#dawp-tr-post-seo-title-container').appendTo('#dawp-tr-gutenberg-fields');
                $('#dawp-tr-post-seo-desc-container').appendTo('#dawp-tr-gutenberg-fields');
                $('#dawp-tr-post-og-title-container').appendTo('#dawp-tr-gutenberg-fields');
                $('#dawp-tr-post-og-desc-container').appendTo('#dawp-tr-gutenberg-fields');
                $('#dawp-tr-post-og-image-container').appendTo('#dawp-tr-gutenberg-fields');
            }

            $('.dawp-tr-seo-upload-btn').click(function(e) {
                e.preventDefault();
                var targetId = $(this).data('target');
                var $input = $('#' + targetId);
                
                var frame = wp.media({
                    title: 'Chọn ảnh đại diện chia sẻ MXH',
                    multiple: false,
                    library: { type: 'image' },
                    button: { text: 'Sử dụng ảnh này' }
                });
                
                frame.on('select', function() {
                    var attachment = frame.state().get('selection').first().toJSON();
                    $input.val(attachment.url);
                });
                
                frame.open();
            });

            // Khởi tạo tự động đồng bộ SEO cho Classic Editor
            $(document).on('input change', 'input[name^="dawp_tr_title["]', function() {
                var nameAttr = $(this).attr('name');
                var matches = nameAttr.match(/\[(.*?)\]/);
                if (matches && matches[1]) {
                    var code = matches[1];
                    var title = $(this).val();
                    var $seo = $('input[name="dawp_tr_seo_title[' + code + ']"]');
                    var $og = $('input[name="dawp_tr_og_title[' + code + ']"]');
                    if ($seo.val() === '') $seo.val(title);
                    if ($og.val() === '') $og.val(title);
                }
            });

            // Lazy load TinyMCE editors for secondary languages
            $(document).on('click', '.dawp-tr-activate-editor-btn', function(e) {
                e.preventDefault();
                var $btn = $(this);
                var editorId = $btn.data('id');
                
                if (typeof wp !== 'undefined' && wp.editor) {
                    if (typeof tinymce !== 'undefined' && tinymce.get(editorId)) {
                        return;
                    }
                    
                    // Hide activation container
                    $btn.closest('.dawp-tr-activate-btn-container').hide();
                    
                    // Initialize wp.editor with standard TinyMCE settings
                    wp.editor.initialize(editorId, {
                        tinymce: {
                            wpautop: true,
                            plugins: 'charmap,colorpicker,hr,lists,media,paste,tabfocus,textcolor,fullscreen,wordpress,wpeditimage,wplink,wpdialogs',
                            toolbar1: 'formatselect,bold,italic,bullist,numlist,blockquote,alignleft,aligncenter,alignright,link,wp_more,fullscreen,wp_adv',
                            toolbar2: 'strikethrough,hr,forecolor,pastetext,removeformat,charmap,outdent,indent,undo,redo,wp_help',
                            setup: function(editor) {
                                editor.on('change keyup', function() {
                                    editor.save(); // Sync back to textarea on any change
                                });
                            }
                        },
                        quicktags: true
                    });
                }
            });

            // Chốt an toàn: Gọi tinymce.triggerSave() trước submit form
            $(document).on('submit', 'form', function() {
                if (typeof tinymce !== 'undefined') {
                    tinymce.triggerSave();
                }
            });
        });
        </script>
        <?php
    }

    public function save_language_meta_data( $post_id, $post ) {
        // Hỗ trợ kiểm tra bảo mật tương thích cho cả Save bài viết thông thường và Sửa nhanh (Quick Edit)
        $is_quick_edit = isset( $_POST['action'] ) && $_POST['action'] === 'inline-save';
        if ( ! $is_quick_edit ) {
            if ( ! isset( $_POST['dawp_language_nonce'] ) || ! wp_verify_nonce( $_POST['dawp_language_nonce'], 'dawp_save_language' ) ) {
                return;
            }
        } else {
            if ( ! isset( $_POST['_inline_edit'] ) || ! wp_verify_nonce( $_POST['_inline_edit'], 'inlineeditnonce' ) ) {
                return;
            }
        }

        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
        if ( ! current_user_can( 'edit_post', $post_id ) ) return;

        // Lưu trực tiếp các trường bản dịch nhanh (Quick Translate) từ Metabox
        $tr_titles   = isset( $_POST['dawp_tr_title'] ) ? (array)$_POST['dawp_tr_title'] : [];
        $tr_contents = isset( $_POST['dawp_tr_content'] ) ? (array)$_POST['dawp_tr_content'] : [];
        $tr_excerpts = isset( $_POST['dawp_tr_excerpt'] ) ? (array)$_POST['dawp_tr_excerpt'] : [];
        
        $tr_seo_titles = isset( $_POST['dawp_tr_seo_title'] ) ? (array)$_POST['dawp_tr_seo_title'] : [];
        $tr_seo_descs  = isset( $_POST['dawp_tr_seo_desc'] ) ? (array)$_POST['dawp_tr_seo_desc'] : [];
        $tr_og_titles  = isset( $_POST['dawp_tr_og_title'] ) ? (array)$_POST['dawp_tr_og_title'] : [];
        $tr_og_descs   = isset( $_POST['dawp_tr_og_desc'] ) ? (array)$_POST['dawp_tr_og_desc'] : [];
        $tr_og_images  = isset( $_POST['dawp_tr_og_image'] ) ? (array)$_POST['dawp_tr_og_image'] : [];
        
        $active_langs = DAWP_Multilingual::get_active_languages();
        $default_lang = DAWP_Multilingual::get_default_language();
        
        foreach ( $active_langs as $code => $info ) {
            if ( $code === $default_lang ) continue;
            
            if ( isset( $tr_titles[ $code ] ) ) update_post_meta( $post_id, "_dawp_trans_{$code}_title", sanitize_text_field( $tr_titles[ $code ] ) );
            
            // Đối với content, bỏ qua khi Sửa nhanh (vì Quick Edit không gửi lên Content, tránh ghi đè rỗng)
            if ( ! $is_quick_edit && isset( $tr_contents[ $code ] ) ) {
                update_post_meta( $post_id, "_dawp_trans_{$code}_content", wp_kses_post( wp_unslash( $tr_contents[ $code ] ) ) );
            }
            if ( ! $is_quick_edit && isset( $tr_excerpts[ $code ] ) ) {
                update_post_meta( $post_id, "_dawp_trans_{$code}_excerpt", sanitize_textarea_field( $tr_excerpts[ $code ] ) );
            }
            if ( isset( $tr_seo_titles[ $code ] ) ) update_post_meta( $post_id, "_dawp_trans_{$code}_seo_title", sanitize_text_field( $tr_seo_titles[ $code ] ) );
            if ( isset( $tr_seo_descs[ $code ] ) )  update_post_meta( $post_id, "_dawp_trans_{$code}_seo_desc", sanitize_text_field( $tr_seo_descs[ $code ] ) );
            if ( isset( $tr_og_titles[ $code ] ) )  update_post_meta( $post_id, "_dawp_trans_{$code}_og_title", sanitize_text_field( $tr_og_titles[ $code ] ) );
            if ( isset( $tr_og_descs[ $code ] ) )   update_post_meta( $post_id, "_dawp_trans_{$code}_og_desc", sanitize_text_field( $tr_og_descs[ $code ] ) );
            if ( isset( $tr_og_images[ $code ] ) )  update_post_meta( $post_id, "_dawp_trans_{$code}_og_image", sanitize_text_field( $tr_og_images[ $code ] ) );
        }
        
        DAWP_Multilingual::clear_transients();
    }

    public function add_language_column( $columns ) {
        $new_columns = [];
        foreach ( $columns as $key => $title ) {
            if ( $key === 'title' ) {
                $new_columns[ $key ] = $title;
                $new_columns['dawp_language'] = 'Dịch thuật';
            } else {
                $new_columns[ $key ] = $title;
            }
        }
        return $new_columns;
    }

    public function render_language_column( $column, $post_id ) {
        if ( 'dawp_language' === $column ) {
            $active_langs = DAWP_Multilingual::get_active_languages();
            $default_lang = DAWP_Multilingual::get_default_language();
            
            // Batch fetch all post metadata in a single call
            $all_meta = get_post_meta( $post_id );
            
            echo '<div class="dawp-flag-column" style="display: flex; gap: 8px; align-items: center;">';
            foreach ( $active_langs as $code => $info ) {
                $flag_url = 'https://flagcdn.com/w40/' . $info['flag'] . '.png';
                if ( $code === $default_lang ) {
                    echo '<img class="dawp-flag-badge" src="' . esc_url( $flag_url ) . '" title="Ngôn ngữ gốc: ' . esc_attr( $info['name'] ) . '" style="width: 18px; height: 18px; border-radius: 50%; border: 1px solid #0068ff;" />';
                } else {
                    $meta_key = "_dawp_trans_{$code}_title";
                    $trans_title = ( isset( $all_meta[ $meta_key ][0] ) ) ? $all_meta[ $meta_key ][0] : '';
                    $has_trans = ! empty( $trans_title );
                    $opacity = $has_trans ? '1' : '0.25';
                    $title_attr = $has_trans ? 'Đã dịch sang ' . $info['name'] : 'Chưa dịch sang ' . $info['name'];
                    echo '<img class="dawp-flag-badge" src="' . esc_url( $flag_url ) . '" title="' . esc_attr( $title_attr ) . '" style="width: 18px; height: 18px; border-radius: 50%; opacity: ' . $opacity . '; border: 1px solid #ddd;" />';
                }
            }
            echo '</div>';

            // Xuất dữ liệu ẩn cho Quick Edit
            echo '<div class="dawp-quick-edit-tr-data" style="display:none;"';
            foreach ( $active_langs as $code => $info ) {
                if ( $code === $default_lang ) continue;
                $meta_key = "_dawp_trans_{$code}_title";
                $trans_title = ( isset( $all_meta[ $meta_key ][0] ) ) ? $all_meta[ $meta_key ][0] : '';
                echo ' data-tr-title-' . esc_attr( $code ) . '="' . esc_attr( $trans_title ) . '"';
            }
            echo '></div>';
        }
    }

    public function add_term_language_field() {
        $active_langs = DAWP_Multilingual::get_active_languages();
        if ( count( $active_langs ) <= 1 ) return;

        $default_lang = DAWP_Multilingual::get_default_language();
        $langs_to_translate = [];
        foreach ( $active_langs as $code => $info ) {
            if ( $code === $default_lang ) continue;
            $langs_to_translate[ $code ] = $info;
        }

        if ( empty( $langs_to_translate ) ) return;
        ?>
        <div id="dawp-term-translations-container" style="margin-top: 15px;">
            <div id="dawp-tr-field-name" style="margin-top: 10px; max-width: 100%;">
                <?php foreach ( $langs_to_translate as $code => $info ) : ?>
                    <div style="margin-bottom: 8px;">
                        <span style="font-size: 11px; font-weight: 600; color: #475569; display: inline-flex; align-items: center; gap: 4px;">
                            <img class="dawp-flag-badge" src="https://flagcdn.com/w40/<?php echo esc_attr( $info['flag'] ); ?>.png" style="margin: 0; width: 14px; height: 14px;" /> TÊN BẢN DỊCH (<?php echo esc_html( $info['name'] ); ?>)
                        </span>
                        <input type="text" name="dawp_tr_term_name[<?php echo esc_attr( $code ); ?>]" value="" style="width: 100%; margin-top: 3px; padding: 6px;" placeholder="Tên <?php echo esc_attr( $info['name'] ); ?>..." />
                    </div>
                <?php endforeach; ?>
            </div>

            <div id="dawp-tr-field-desc" style="margin-top: 10px; max-width: 100%;">
                <?php foreach ( $langs_to_translate as $code => $info ) : ?>
                    <div style="margin-bottom: 8px;">
                        <span style="font-size: 11px; font-weight: 600; color: #475569; display: inline-flex; align-items: center; gap: 4px;">
                            <img class="dawp-flag-badge" src="https://flagcdn.com/w40/<?php echo esc_attr( $info['flag'] ); ?>.png" style="margin: 0; width: 14px; height: 14px;" /> MÔ TẢ (<?php echo esc_html( $info['name'] ); ?>)
                        </span>
                        <textarea name="dawp_tr_term_desc[<?php echo esc_attr( $code ); ?>]" rows="3" style="width: 100%; margin-top: 3px; padding: 6px;" placeholder="Mô tả <?php echo esc_attr( $info['name'] ); ?>..."></textarea>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <script>
        jQuery(document).ready(function($) {
            if ($('#tag-name').length) $('#tag-name').parent().append($('#dawp-tr-field-name'));
            if ($('#tag-description').length) $('#tag-description').parent().append($('#dawp-tr-field-desc'));
        });
        </script>
        <?php
    }

    public function edit_term_language_field( $term ) {
        $active_langs = DAWP_Multilingual::get_active_languages();
        if ( count( $active_langs ) <= 1 ) return;

        $default_lang = DAWP_Multilingual::get_default_language();
        $langs_to_translate = [];
        foreach ( $active_langs as $code => $info ) {
            if ( $code === $default_lang ) continue;
            $langs_to_translate[ $code ] = $info;
        }

        if ( empty( $langs_to_translate ) ) return;

        $translations = [];
        foreach ( $langs_to_translate as $code => $info ) {
            $translations[ $code ] = [
                'name'        => get_term_meta( $term->term_id, "_dawp_trans_{$code}_name", true ),
                'description' => get_term_meta( $term->term_id, "_dawp_trans_{$code}_description", true ),
                'seo_title'   => get_term_meta( $term->term_id, "_dawp_trans_{$code}_seo_title", true ),
                'seo_desc'    => get_term_meta( $term->term_id, "_dawp_trans_{$code}_seo_desc", true ),
            ];
        }
        ?>
        <tr style="display:none;">
            <td colspan="2">
                <div id="dawp-term-translations-container">
                    <div id="dawp-tr-field-name" style="margin-top: 10px; max-width: 800px;">
                        <?php foreach ( $langs_to_translate as $code => $info ) : 
                            $val = isset( $translations[ $code ]['name'] ) ? $translations[ $code ]['name'] : '';
                            ?>
                            <div style="margin-bottom: 8px;">
                                <span style="font-size: 11px; font-weight: 600; color: #475569; display: inline-flex; align-items: center; gap: 4px;">
                                    <img class="dawp-flag-badge" src="https://flagcdn.com/w40/<?php echo esc_attr( $info['flag'] ); ?>.png" style="margin: 0; width: 14px; height: 14px;" /> TÊN BẢN DỊCH (<?php echo esc_html( $info['name'] ); ?>)
                                </span>
                                <input type="text" name="dawp_tr_term_name[<?php echo esc_attr( $code ); ?>]" value="<?php echo esc_attr( $val ); ?>" style="width: 100%; margin-top: 3px;" placeholder="Tên <?php echo esc_attr( $info['name'] ); ?>..." />
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <div id="dawp-tr-field-desc" style="margin-top: 10px; max-width: 800px;">
                        <?php foreach ( $langs_to_translate as $code => $info ) : 
                            $val = isset( $translations[ $code ]['description'] ) ? $translations[ $code ]['description'] : '';
                            ?>
                            <div style="margin-bottom: 8px;">
                                <span style="font-size: 11px; font-weight: 600; color: #475569; display: inline-flex; align-items: center; gap: 4px;">
                                    <img class="dawp-flag-badge" src="https://flagcdn.com/w40/<?php echo esc_attr( $info['flag'] ); ?>.png" style="margin: 0; width: 14px; height: 14px;" /> MÔ TẢ (<?php echo esc_html( $info['name'] ); ?>)
                                </span>
                                <textarea name="dawp_tr_term_desc[<?php echo esc_attr( $code ); ?>]" rows="3" style="width: 100%; margin-top: 3px;" placeholder="Mô tả <?php echo esc_attr( $info['name'] ); ?>..."><?php echo esc_textarea( $val ); ?></textarea>
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <div id="dawp-tr-field-seo-title" style="margin-top: 10px; max-width: 800px;">
                        <?php foreach ( $langs_to_translate as $code => $info ) : 
                            $val = isset( $translations[ $code ]['seo_title'] ) ? $translations[ $code ]['seo_title'] : '';
                            ?>
                            <div style="margin-bottom: 8px;">
                                <span style="font-size: 11px; font-weight: 600; color: #475569; display: inline-flex; align-items: center; gap: 4px;">
                                    <img class="dawp-flag-badge" src="https://flagcdn.com/w40/<?php echo esc_attr( $info['flag'] ); ?>.png" style="margin: 0; width: 14px; height: 14px;" /> TIÊU ĐỀ SEO (<?php echo esc_html( $info['name'] ); ?>)
                                </span>
                                <input type="text" name="dawp_tr_term_seo_title[<?php echo esc_attr( $code ); ?>]" value="<?php echo esc_attr( $val ); ?>" style="width: 100%; margin-top: 3px;" placeholder="Mặc định lấy từ tên bản dịch..." />
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <div id="dawp-tr-field-seo-desc" style="margin-top: 10px; max-width: 800px;">
                        <?php foreach ( $langs_to_translate as $code => $info ) : 
                            $val = isset( $translations[ $code ]['seo_desc'] ) ? $translations[ $code ]['seo_desc'] : '';
                            ?>
                            <div style="margin-bottom: 8px;">
                                <span style="font-size: 11px; font-weight: 600; color: #475569; display: inline-flex; align-items: center; gap: 4px;">
                                    <img class="dawp-flag-badge" src="https://flagcdn.com/w40/<?php echo esc_attr( $info['flag'] ); ?>.png" style="margin: 0; width: 14px; height: 14px;" /> MÔ TẢ META (<?php echo esc_html( $info['name'] ); ?>)
                                </span>
                                <textarea name="dawp_tr_term_seo_desc[<?php echo esc_attr( $code ); ?>]" rows="3" style="width: 100%; margin-top: 3px;" placeholder="Mô tả Meta <?php echo esc_attr( $info['name'] ); ?>..."><?php echo esc_textarea( $val ); ?></textarea>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </td>
        </tr>
        
        <script>
        jQuery(document).ready(function($) {
            $('#name').parent().append($('#dawp-tr-field-name'));
            $('#description').parent().append($('#dawp-tr-field-desc'));
            
            setTimeout(function() {
                $('#dawp_seo_title').parent().append($('#dawp-tr-field-seo-title'));
                $('#dawp_seo_desc').parent().append($('#dawp-tr-field-seo-desc'));
            }, 200);
        });
        </script>
        <?php
    }

    public function save_term_language_data( $term_id ) {
        $term = get_term( $term_id );
        if ( ! $term || is_wp_error( $term ) ) return;
        
        $tr_names = isset( $_POST['dawp_tr_term_name'] ) ? (array)$_POST['dawp_tr_term_name'] : [];
        $tr_descs = isset( $_POST['dawp_tr_term_desc'] ) ? (array)$_POST['dawp_tr_term_desc'] : [];
        $tr_seo_titles = isset( $_POST['dawp_tr_term_seo_title'] ) ? (array)$_POST['dawp_tr_term_seo_title'] : [];
        $tr_seo_descs  = isset( $_POST['dawp_tr_term_seo_desc'] ) ? (array)$_POST['dawp_tr_term_seo_desc'] : [];

        $active_langs = DAWP_Multilingual::get_active_languages();
        $default_lang = DAWP_Multilingual::get_default_language();

        foreach ( $active_langs as $code => $info ) {
            if ( $code === $default_lang ) continue;

            if ( isset( $tr_names[ $code ] ) ) update_term_meta( $term_id, "_dawp_trans_{$code}_name", sanitize_text_field( $tr_names[ $code ] ) );
            if ( isset( $tr_descs[ $code ] ) ) update_term_meta( $term_id, "_dawp_trans_{$code}_description", sanitize_textarea_field( $tr_descs[ $code ] ) );
            if ( isset( $tr_seo_titles[ $code ] ) ) update_term_meta( $term_id, "_dawp_trans_{$code}_seo_title", sanitize_text_field( $tr_seo_titles[ $code ] ) );
            if ( isset( $tr_seo_descs[ $code ] ) )  update_term_meta( $term_id, "_dawp_trans_{$code}_seo_desc", sanitize_text_field( $tr_seo_descs[ $code ] ) );
        }

        DAWP_Multilingual::clear_transients();
    }

    public function render_translation_manager_page() {
        if ( ! current_user_can( 'manage_options' ) ) return;
        include plugin_dir_path( __FILE__ ) . 'views/admin-translation-manager.php';
    }

    public function ajax_get_translation_data() {
        check_ajax_referer( 'dawp_translation_ajax', 'nonce' );
        if ( ! current_user_can( 'edit_posts' ) ) wp_send_json_error( 'Permission denied' );
        
        $post_id = intval( $_POST['post_id'] );
        $lang = sanitize_key( $_POST['lang'] );

        // Chỉ chấp nhận mã ngôn ngữ đang kích hoạt, chặn tạo meta key tùy biến
        if ( ! array_key_exists( $lang, DAWP_Multilingual::get_active_languages() ) ) {
            wp_send_json_error( 'Invalid language' );
        }

        $post = get_post( $post_id );
        if ( ! $post ) wp_send_json_error( 'Post not found' );

        // Chặn IDOR: chỉ cho đọc bài mà người dùng có quyền sửa bài ĐÓ. Nếu chỉ
        // kiểm 'edit_posts' chung thì Contributor/Author đọc được cả tiêu đề + nội
        // dung bài nháp/riêng tư của người khác qua endpoint này.
        if ( ! current_user_can( 'edit_post', $post_id ) ) wp_send_json_error( 'Permission denied' );

        $target_title = get_post_meta( $post_id, "_dawp_trans_{$lang}_title", true );
        $target_content = get_post_meta( $post_id, "_dawp_trans_{$lang}_content", true );
        
        wp_send_json_success([
            'orig_title' => $post->post_title,
            'orig_content' => $post->post_content,
            'target_title' => $target_title,
            'target_content' => $target_content,
            'target_id' => $post_id
        ]);
    }

    public function ajax_save_translation_data() {
        check_ajax_referer( 'dawp_translation_ajax', 'nonce' );
        if ( ! current_user_can( 'edit_posts' ) ) wp_send_json_error( 'Permission denied' );
        
        $source_id = intval( $_POST['source_post_id'] );
        $lang = sanitize_key( $_POST['lang'] );

        // Chỉ chấp nhận mã ngôn ngữ đang kích hoạt, chặn tạo meta key tùy biến
        if ( ! array_key_exists( $lang, DAWP_Multilingual::get_active_languages() ) ) {
            wp_send_json_error( 'Invalid language' );
        }

        $title = sanitize_text_field( $_POST['title'] );
        $content = wp_kses_post( wp_unslash( $_POST['content'] ) );
        
        $source_post = get_post( $source_id );
        if ( ! $source_post ) wp_send_json_error( 'Source post not found' );

        // Chặn IDOR/deface: chỉ cho lưu bản dịch của bài mà người dùng có quyền sửa
        // bài ĐÓ. Meta _dawp_trans_{lang}_content được render thẳng ra frontend, nên
        // nếu bỏ kiểm tra này thì Contributor/Author ghi đè được nội dung bài người khác.
        if ( ! current_user_can( 'edit_post', $source_id ) ) wp_send_json_error( 'Permission denied' );

        update_post_meta( $source_id, "_dawp_trans_{$lang}_title", $title );
        update_post_meta( $source_id, "_dawp_trans_{$lang}_content", $content );
        
        DAWP_Multilingual::clear_transients();
        wp_send_json_success([ 'new_id' => $source_id ]);
    }

    public function handle_admin_language_switch() {
        if ( isset( $_GET['dawp_admin_lang'] ) ) {
            $lang = sanitize_text_field( $_GET['dawp_admin_lang'] );
            $active_langs = DAWP_Multilingual::get_active_languages();
            if ( array_key_exists( $lang, $active_langs ) ) {
                setcookie( 'dawp_admin_lang', $lang, time() + 30 * DAY_IN_SECONDS, COOKIEPATH, COOKIE_DOMAIN );
                $redirect_url = remove_query_arg( 'dawp_admin_lang' );
                wp_safe_redirect( $redirect_url );
                exit;
            }
        }
    }

    public function add_admin_bar_language_switcher( $wp_admin_bar ) {
        $active_langs = DAWP_Multilingual::get_active_languages();
        if ( count( $active_langs ) <= 1 ) return;

        $current_lang = DAWP_Multilingual::get_admin_language();
        $curr_info = isset( $active_langs[ $current_lang ] ) ? $active_langs[ $current_lang ] : reset( $active_langs );

        $wp_admin_bar->add_node( [
            'id'    => 'dawp-admin-lang',
            'title' => '<img class="dawp-flag-badge" src="https://flagcdn.com/w40/' . esc_attr( $curr_info['flag'] ) . '.png" style="width:16px; height:12px; border-radius:2px; margin-right:6px; vertical-align:middle;" />' . esc_html( $curr_info['name'] ),
            'href'  => '#',
            'meta'  => [ 'title' => 'Ngôn ngữ trang quản trị' ],
        ] );

        foreach ( $active_langs as $code => $info ) {
            $is_current = ( $code === $current_lang );
            $title = '<img class="dawp-flag-badge" src="https://flagcdn.com/w40/' . esc_attr( $info['flag'] ) . '.png" style="width:16px; height:12px; border-radius:2px; margin-right:6px; vertical-align:middle;" />' . esc_html( $info['name'] );
            if ( $is_current ) {
                $title .= ' <span class="dashicons dashicons-yes" style="font-size:16px; width:16px; height:16px; vertical-align:middle; margin-left:6px; color:#46b450;"></span>';
            }

            $wp_admin_bar->add_node( [
                'id'     => 'dawp-admin-lang-' . $code,
                'parent' => 'dawp-admin-lang',
                'title'  => $title,
                'href'   => add_query_arg( 'dawp_admin_lang', $code ),
            ] );
        }
    }

    public function render_menu_item_custom_fields( $item_id, $item, $depth, $args ) {
        $active_langs = DAWP_Multilingual::get_active_languages();
        if ( count( $active_langs ) <= 1 ) return;

        $default_lang = DAWP_Multilingual::get_default_language();
        $langs_to_translate = [];
        foreach ( $active_langs as $code => $info ) {
            if ( $code === $default_lang ) continue;
            $langs_to_translate[ $code ] = $info;
        }

        if ( empty( $langs_to_translate ) ) return;

        $translations = [];
        foreach ( $langs_to_translate as $code => $info ) {
            $translations[ $code ] = [
                'label' => get_post_meta( $item_id, "_dawp_menu_item_label_{$code}", true ),
            ];
        }
        ?>
        <div class="dawp-menu-item-translations" style="margin: 10px 0; padding: 10px 0; border-top: 1px dashed #ccd0d4; border-bottom: 1px dashed #ccd0d4; background: #fafafa; padding-left: 10px; padding-right: 10px;">
            <p style="margin: 0 0 8px 0; font-weight: 600; font-size: 11px; color: #1d2327; text-transform: uppercase;">DỊCH TAY SONG SONG (PARALLEL TRANSLATIONS)</p>
            
            <?php foreach ( $langs_to_translate as $code => $info ) : 
                $label_val = isset( $translations[ $code ]['label'] ) ? $translations[ $code ]['label'] : '';
                ?>
                <div style="margin-bottom: 8px;">
                    <label style="display: block; font-size: 11px; font-weight: 600; color: #475569; margin-bottom: 3px;">
                        <img class="dawp-flag-badge" src="https://flagcdn.com/w40/<?php echo esc_attr( $info['flag'] ); ?>.png" style="margin: 0; width: 14px; height: 14px; vertical-align: middle;" /> NHÃN ĐIỀU HƯỚNG (<?php echo esc_html( $info['name'] ); ?>)
                    </label>
                    <input type="text" name="dawp_menu_item_label[<?php echo esc_attr( $item_id ); ?>][<?php echo esc_attr( $code ); ?>]" value="<?php echo esc_attr( $label_val ); ?>" class="widefat" style="margin-top: 3px;" placeholder="Navigation Label (<?php echo esc_attr( $info['name'] ); ?>)..." />
                </div>
            <?php endforeach; ?>

        </div>
        <?php
    }

    public function save_menu_item_translation_fields( $menu_id, $menu_item_db_id, $args ) {
        if ( isset( $_POST['dawp_menu_item_label'][ $menu_item_db_id ] ) ) {
            $labels = $_POST['dawp_menu_item_label'][ $menu_item_db_id ];
            foreach ( $labels as $lang => $val ) {
                $val = sanitize_text_field( $val );
                update_post_meta( $menu_item_db_id, '_dawp_menu_item_label_' . $lang, $val );
            }
        }

    }

    public function render_quick_edit_translation_fields( $column_name, $post_type ) {
        if ( 'dawp_language' !== $column_name ) return;

        $active_langs = DAWP_Multilingual::get_active_languages();
        if ( count( $active_langs ) <= 1 ) return;

        $default_lang = DAWP_Multilingual::get_default_language();
        $langs_to_translate = [];
        foreach ( $active_langs as $code => $info ) {
            if ( $code === $default_lang ) continue;
            $langs_to_translate[ $code ] = $info;
        }

        if ( empty( $langs_to_translate ) ) return;
        ?>
        <fieldset class="inline-edit-col-right inline-edit-dawp-translations" style="margin-top: 10px;">
            <div class="inline-edit-col">
                <span class="title" style="font-weight: 600; color: #1e293b; border-bottom: 1px solid #e2e8f0; padding-bottom: 5px; margin-bottom: 10px; display: block;">
                    🌐 BẢN DỊCH SONG NGỮ (DAW PRO)
                </span>
                
                <?php foreach ( $langs_to_translate as $code => $info ) : ?>
                    <div style="margin-bottom: 10px;">
                        <div>
                            <span style="font-size: 11px; font-weight: 600; color: #475569; display: inline-flex; align-items: center; gap: 4px;">
                                <img class="dawp-flag-badge" src="https://flagcdn.com/w40/<?php echo esc_attr( $info['flag'] ); ?>.png" style="margin: 0; width: 14px; height: 14px;" /> TIÊU ĐỀ (<?php echo esc_html( $info['name'] ); ?>)
                            </span>
                            <input type="text" name="dawp_tr_title[<?php echo esc_attr( $code ); ?>]" class="dawp-tr-quick-title-<?php echo esc_attr( $code ); ?>" value="" style="width: 100%; margin-top: 3px; padding: 4px;" />
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </fieldset>
        <?php
    }

    public function print_quick_edit_js() {
        $screen = get_current_screen();
        if ( ! $screen || 'edit' !== $screen->base ) return;

        $active_langs = DAWP_Multilingual::get_active_languages();
        $default_lang = DAWP_Multilingual::get_default_language();
        $sub_langs = [];
        foreach ( $active_langs as $code => $info ) {
            if ( $code === $default_lang ) continue;
            $sub_langs[] = $code;
        }
        ?>
        <script>
        jQuery(document).ready(function($) {
            var subLangs = <?php echo json_encode( $sub_langs ); ?>;
            $(document).on('click', '.editinline', function() {
                var $row = $(this).closest('tr');
                var postId = $row.attr('id').replace('post-', '');
                var $trData = $row.find('.dawp-quick-edit-tr-data');
                
                if ($trData.length && subLangs.length > 0) {
                    var $editRow = $('#edit-' + postId);
                    subLangs.forEach(function(code) {
                        var titleVal = $trData.data('tr-title-' + code) || '';
                        $editRow.find('.dawp-tr-quick-title-' + code).val(titleVal);
                    });
                }
            });
        });
        </script>
        <?php
    }
}
