<?php
defined( 'ABSPATH' ) || exit;

class DAWP_Smtp {
    public function __construct() {
        add_action( 'phpmailer_init', [ $this, 'configure_smtp' ], 999 );
    }

    public function configure_smtp( $phpmailer ) {
        $options = get_option( 'dawp_settings', [] );

        if ( empty( $options['smtp_host'] ) || empty( $options['smtp_user'] ) ) {
            return;
        }

        try {
            $phpmailer->isSMTP();
            $phpmailer->CharSet    = 'UTF-8';
            $phpmailer->Encoding   = 'base64';
            $phpmailer->Host       = sanitize_text_field( $options['smtp_host'] );
            $phpmailer->SMTPAuth   = true;
            $phpmailer->Port       = (int) ( isset($options['smtp_port']) ? $options['smtp_port'] : 587 );
            $phpmailer->Username   = sanitize_text_field( $options['smtp_user'] );
            $phpmailer->Password   = isset($options['smtp_pass']) ? $options['smtp_pass'] : '';
            $phpmailer->SMTPSecure = isset($options['smtp_enc']) ? sanitize_text_field($options['smtp_enc']) : 'ssl';

            // Mặc định XÁC THỰC chứng chỉ đầy đủ. Chỉ bỏ qua khi admin chủ động bật
            // "Bỏ qua xác thực SSL" (dành cho localhost/Laragon, server thiếu bộ CA)
            // hoặc site khai báo môi trường local/development — tắt verify trên
            // production mở đường MITM đánh cắp mật khẩu SMTP.
            $skip_verify = ! empty( $options['smtp_insecure'] )
                || in_array( wp_get_environment_type(), [ 'local', 'development' ], true );

            if ( $skip_verify ) {
                $phpmailer->SMTPAutoTLS = false;
                $phpmailer->SMTPOptions = [
                    'ssl' => [
                        'verify_peer'       => false,
                        'verify_peer_name'  => false,
                        'allow_self_signed' => true,
                    ],
                ];
            }

            $from_email = !empty($options['smtp_user']) ? $options['smtp_user'] : get_option('admin_email');
            $from_name  = !empty($options['smtp_from_name']) ? $options['smtp_from_name'] : get_bloginfo( 'name' );

            if ( is_email( $from_email ) ) {
                $phpmailer->setFrom( $from_email, $from_name );
                $phpmailer->Sender = $from_email; // Return-Path khớp, tránh bị Gmail từ chối
            }
        } catch ( \Throwable $e ) {
            // Chống crash site hành chính
        }
    }
}
