<?php
defined( 'ABSPATH' ) || exit;

class DAWP_Contact_Buttons {
    public function __construct() {
        add_action( 'wp_footer', [ $this, 'render_buttons' ] );
    }

    public function render_buttons() {
        $options = get_option( 'dawp_settings', [] );
        
        $active = isset($options['contact_buttons_active']) ? (bool)$options['contact_buttons_active'] : true;
        if ( ! $active ) {
            return;
        }

        $hotline_input  = isset($options['hotline_number']) ? trim($options['hotline_number']) : '';
        $zalo_input     = isset($options['zalo_link']) ? trim($options['zalo_link']) : '';
        $whatsapp_input = isset($options['whatsapp_number']) ? trim($options['whatsapp_number']) : '';
        $messenger      = isset($options['messenger_link']) ? trim($options['messenger_link']) : '';
        $map            = isset($options['map_link']) ? trim($options['map_link']) : '';

        // Multilingual override for contact numbers/links (should be done before any URL calculation)
        if ( class_exists( 'DAWP_Multilingual' ) ) {
            $lang = DAWP_Multilingual::get_current_language();
            $default_lang = DAWP_Multilingual::get_default_language();
            if ( $lang !== $default_lang ) {
                if ( isset( $options['trans_hotline_' . $lang] ) && ! empty( trim( $options['trans_hotline_' . $lang] ) ) ) {
                    $hotline_input = trim( $options['trans_hotline_' . $lang] );
                }
                if ( isset( $options['trans_zalo_' . $lang] ) && ! empty( trim( $options['trans_zalo_' . $lang] ) ) ) {
                    $zalo_input = trim( $options['trans_zalo_' . $lang] );
                }
                if ( isset( $options['trans_whatsapp_' . $lang] ) && ! empty( trim( $options['trans_whatsapp_' . $lang] ) ) ) {
                    $whatsapp_input = trim( $options['trans_whatsapp_' . $lang] );
                }
                if ( isset( $options['trans_messenger_' . $lang] ) && ! empty( trim( $options['trans_messenger_' . $lang] ) ) ) {
                    $messenger = trim( $options['trans_messenger_' . $lang] );
                }
                if ( isset( $options['trans_map_' . $lang] ) && ! empty( trim( $options['trans_map_' . $lang] ) ) ) {
                    $map = trim( $options['trans_map_' . $lang] );
                }
            }
        }

        // Split multiple phone, Zalo, and Whatsapp numbers (max 5)
        $hotlines = [];
        if ( ! empty( $hotline_input ) ) {
            $hotlines = array_filter( array_map( 'trim', preg_split( '/[,\;|\\r\\n]+/', $hotline_input ) ) );
            $hotlines = array_slice( $hotlines, 0, 5 );
        }

        $zalos = [];
        if ( ! empty( $zalo_input ) ) {
            $zalos = array_filter( array_map( 'trim', preg_split( '/[,\;|\\r\\n]+/', $zalo_input ) ) );
            $zalos = array_slice( $zalos, 0, 5 );
        }

        $whatsapps = [];
        if ( ! empty( $whatsapp_input ) ) {
            $whatsapps = array_filter( array_map( 'trim', preg_split( '/[,\;|\\r\\n]+/', $whatsapp_input ) ) );
            $whatsapps = array_slice( $whatsapps, 0, 5 );
        }

        if ( empty($hotlines) && empty($zalos) && empty($whatsapps) && empty($messenger) && empty($map) ) {
            return;
        }

        // Configuration
        $style    = isset($options['contact_buttons_style']) ? $options['contact_buttons_style'] : 'classic';
        $position = isset($options['contact_buttons_position']) ? $options['contact_buttons_position'] : 'left';

        // Colors
        $c_hotline   = isset($options['hotline_color']) ? $options['hotline_color'] : '#f44336';
        $c_zalo      = isset($options['zalo_color']) ? $options['zalo_color'] : '#0068ff';
        $c_whatsapp  = isset($options['whatsapp_color']) ? $options['whatsapp_color'] : '#25d366';
        $c_messenger = isset($options['messenger_color']) ? $options['messenger_color'] : '#0084ff';
        $c_map       = isset($options['map_color']) ? $options['map_color'] : '#4caf50';

        $c_hotline_light   = $this->adjust_brightness($c_hotline, 35);
        $c_zalo_light      = $this->adjust_brightness($c_zalo, 35);
        $c_whatsapp_light  = $this->adjust_brightness($c_whatsapp, 35);
        $c_messenger_light = $this->adjust_brightness($c_messenger, 35);
        $c_map_light       = $this->adjust_brightness($c_map, 35);

        $c_hotline_shadow   = $this->hex2rgba($c_hotline, 0.35);
        $c_zalo_shadow      = $this->hex2rgba($c_zalo, 0.35);
        $c_whatsapp_shadow  = $this->hex2rgba($c_whatsapp, 0.35);
        $c_messenger_shadow = $this->hex2rgba($c_messenger, 0.35);
        $c_map_shadow       = $this->hex2rgba($c_map, 0.35);

        // SVG Icons
        $phone_svg = '<svg viewBox="0 0 24 24" class="dawp-svg-icon"><path d="M20.01 15.38c-1.23 0-2.42-.2-3.53-.56a.977.977 0 0 0-1.01.24l-1.57 1.97c-2.83-1.35-5.48-3.9-6.89-6.83l1.95-1.66c.27-.28.35-.67.24-1.02-.37-1.11-.56-2.3-.56-3.53 0-.54-.45-.99-.99-.99H4.19C3.65 3 3 3.24 3 3.99 3 13.28 10.73 21 20.03 21c.74 0 1.01-.63 1.01-1.18v-3.45c0-.54-.45-.99-.99-.99z"/></svg>';
        $zalo_svg = '<svg viewBox="0 0 24 24" class="dawp-svg-icon" width="24" height="24"><text x="50%" y="50%" dominant-baseline="central" text-anchor="middle" font-family="Arial, Helvetica, sans-serif" font-weight="bold" font-size="9" fill="currentColor">Zalo</text></svg>';
        $whatsapp_svg = '<svg viewBox="0 0 24 24" class="dawp-svg-icon"><path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946C.06 5.348 5.397.01 12.008.01c3.202.001 6.212 1.246 8.477 3.513 2.266 2.268 3.507 5.28 3.505 8.484-.004 6.657-5.34 11.997-11.953 11.997-2.005-.001-3.973-.5-5.739-1.446L0 24zm6.59-4.846c1.6.95 3.188 1.449 4.825 1.451 5.436 0 9.86-4.37 9.864-9.799.002-2.63-1.023-5.101-2.885-6.963C16.273 2.015 13.8 1.01 11.99 1.01c-5.434 0-9.858 4.372-9.862 9.802-.001 1.742.47 3.442 1.36 4.952L2.457 20.25l4.19-1.096zM17.47 14.86c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347z"/></svg>';
        $messenger_svg = '<svg viewBox="0 0 24 24" class="dawp-svg-icon"><path d="M12 2C6.477 2 2 6.145 2 11.243c0 2.908 1.448 5.503 3.7 7.202V22l3.39-1.86a11.77 11.77 0 0 0 2.91.36c5.523 0 10-4.146 10-9.243S17.523 2 12 2zm1.07 12.56-2.54-2.72-4.96 2.72 5.45-5.8 2.59 2.72 4.91-2.72-5.45 5.8z"/></svg>';
        $chat_svg = '<svg viewBox="0 0 24 24" class="dawp-svg-icon"><path d="M20 2H4c-1.1 0-1.99.9-1.99 2L2 22l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zM6 9h12v2H6V9zm8 5H6v-2h8v2zm4-6H6V6h12v2z"/></svg>';
        $close_svg = '<svg viewBox="0 0 24 24" class="dawp-svg-icon"><path d="M19 6.41 17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/></svg>';
        $map_svg = '<svg viewBox="0 0 24 24" class="dawp-svg-icon"><path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/></svg>';

        // Render CSS styles
        $side = ($position === 'right') ? 'right' : 'left';

        $sticky_items_count = count($hotlines) + count($zalos) + count($whatsapps) + (!empty($messenger) ? 1 : 0) + (!empty($map) ? 1 : 0);

        ob_start();
        echo '<style>
            /* Reset & Base variables */
            .dawp-contact-wrap {
                position: fixed !important;
                bottom: 40px !important;
                ' . $side . ': 30px !important;
                z-index: 99999 !important;
                display: flex !important;
                flex-direction: column !important;
                gap: 15px !important;
                font-family: system-ui, -apple-system, sans-serif !important;
                padding: 0 !important;
                margin: 0 !important;
                box-sizing: border-box !important;
                width: auto !important;
                height: auto !important;
            }
            .dawp-btn {
                position: relative !important;
                display: flex !important;
                align-items: center !important;
                justify-content: center !important;
                text-decoration: none !important;
                color: white !important;
                transition: transform 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275), box-shadow 0.4s !important;
                padding: 0 !important;
                margin: 0 !important;
                line-height: 1 !important;
                box-sizing: border-box !important;
                border: none !important;
                outline: none !important;
            }
            .dawp-btn:hover {
                transform: scale(1.12) translateY(-5px) !important;
            }
            
            /* Premium Gradients and Glow Shadows */
            .dawp-btn-zalo, .dawp-zalo {
                background: linear-gradient(135deg, ' . esc_attr($c_zalo) . ', ' . esc_attr($c_zalo_light) . ') !important;
                box-shadow: 0 8px 20px ' . esc_attr($c_zalo_shadow) . ' !important;
            }
            .dawp-btn-zalo:hover, .dawp-zalo:hover {
                box-shadow: 0 12px 28px ' . esc_attr($this->hex2rgba($c_zalo, 0.5)) . ' !important;
            }
            
            .dawp-btn-whatsapp, .dawp-whatsapp {
                background: linear-gradient(135deg, ' . esc_attr($c_whatsapp) . ', ' . esc_attr($c_whatsapp_light) . ') !important;
                box-shadow: 0 8px 20px ' . esc_attr($c_whatsapp_shadow) . ' !important;
            }
            .dawp-btn-whatsapp:hover, .dawp-whatsapp:hover {
                box-shadow: 0 12px 28px ' . esc_attr($this->hex2rgba($c_whatsapp, 0.5)) . ' !important;
            }
            
            .dawp-btn-messenger, .dawp-messenger {
                background: linear-gradient(135deg, ' . esc_attr($c_messenger) . ', ' . esc_attr($c_messenger_light) . ') !important;
                box-shadow: 0 8px 20px ' . esc_attr($c_messenger_shadow) . ' !important;
            }
            .dawp-btn-messenger:hover, .dawp-messenger:hover {
                box-shadow: 0 12px 28px ' . esc_attr($this->hex2rgba($c_messenger, 0.5)) . ' !important;
            }
            
            .dawp-btn-hotline, .dawp-hotline {
                background: linear-gradient(135deg, ' . esc_attr($c_hotline) . ', ' . esc_attr($c_hotline_light) . ') !important;
                box-shadow: 0 8px 20px ' . esc_attr($c_hotline_shadow) . ' !important;
            }
            .dawp-btn-hotline:hover, .dawp-hotline:hover {
                box-shadow: 0 12px 28px ' . esc_attr($this->hex2rgba($c_hotline, 0.5)) . ' !important;
            }
            
            .dawp-btn-map, .dawp-map {
                background: linear-gradient(135deg, ' . esc_attr($c_map) . ', ' . esc_attr($c_map_light) . ') !important;
                box-shadow: 0 8px 20px ' . esc_attr($c_map_shadow) . ' !important;
            }
            .dawp-btn-map:hover, .dawp-map:hover {
                box-shadow: 0 12px 28px ' . esc_attr($this->hex2rgba($c_map, 0.5)) . ' !important;
            }
            
            /* Viền phát sáng tĩnh (Halo ring pulse) */
            .dawp-btn::before, .dawp-btn::after {
                content: "" !important;
                position: absolute !important;
                top: 0 !important;
                left: 0 !important;
                right: 0 !important;
                bottom: 0 !important;
                border-radius: inherit !important;
                background: inherit !important;
                z-index: -1 !important;
                opacity: 0 !important;
                transform: scale(1) !important;
                pointer-events: none !important;
            }
            .dawp-btn::before {
                animation: dawp-ripple 2.4s infinite cubic-bezier(0.25, 0, 0, 1) !important;
            }
            .dawp-btn::after {
                animation: dawp-ripple 2.4s infinite cubic-bezier(0.25, 0, 0, 1) !important;
                animation-delay: 1.2s !important;
            }
 
            /* Theme Compatibility for SVGs - Forced Centering */
            .dawp-contact-wrap svg.dawp-svg-icon {
                width: 25px !important;
                height: 25px !important;
                fill: #ffffff !important;
                stroke: none !important;
                display: block !important;
                margin: 0 auto !important;
                padding: 0 !important;
                box-sizing: border-box !important;
            }
 
            /* Hoạt ảnh rung chuông cho Hotline */
            .dawp-btn-hotline svg,
            .dawp-hotline svg {
                animation: dawp-ring 2s infinite ease-in-out !important;
                transform-origin: center !important;
            }
 
            @keyframes dawp-pulse {
                0% { transform: scale(1); opacity: 0.5; }
                70% { transform: scale(1.6); opacity: 0; }
                100% { transform: scale(1.6); opacity: 0; }
            }
            @keyframes dawp-ripple {
                0% { transform: scale(1); opacity: 0.6; }
                100% { transform: scale(1.5); opacity: 0; }
            }
            @keyframes dawp-ring {
                0%, 100% { transform: rotate(0) scale(1); }
                10%, 20% { transform: rotate(-12deg) scale(1.05); }
                30%, 40% { transform: rotate(12deg) scale(1.05); }
                50%, 60% { transform: rotate(-12deg) scale(1.05); }
                70%, 80% { transform: rotate(12deg) scale(1.05); }
                90% { transform: rotate(0) scale(1); }
            }
            @keyframes dawp-heartbeat {
                0%, 100% { transform: scale(1); }
                50% { transform: scale(1.08); }
            }
 
            /* ==========================================================================
               STYLE 1 & 2 & 4: CIRCULAR BUTTONS
               ========================================================================== */
            .dawp-style-classic .dawp-btn,
            .dawp-style-classic_horizontal .dawp-btn,
            .dawp-style-expand .dawp-btn {
                width: 56px !important;
                height: 56px !important;
                border-radius: 50% !important;
            }
 
            .dawp-style-classic .dawp-btn span,
            .dawp-style-classic_horizontal .dawp-btn span,
            .dawp-style-expand .dawp-btn span {
                display: none !important;
            }
 
            /* STYLE 2: CLASSIC HORIZONTAL */
            .dawp-style-classic_horizontal {
                flex-direction: row !important;
            }
 
            /* ==========================================================================
               STYLE 3: MODERN PILL WIDGET
               ========================================================================== */
            .dawp-style-pill .dawp-btn {
                width: auto !important;
                height: 48px !important;
                border-radius: 28px !important;
                padding: 0 20px 0 6px !important;
                display: flex !important;
                align-items: center !important;
                justify-content: flex-start !important;
                gap: 12px !important;
                font-weight: 700 !important;
                font-size: 14px !important;
                letter-spacing: 0.3px !important;
                white-space: nowrap !important;
                flex-direction: row !important;
            }
            .dawp-style-pill .dawp-icon-circle {
                width: 36px !important;
                height: 36px !important;
                border-radius: 50% !important;
                background: rgba(255, 255, 255, 0.2) !important;
                display: flex !important;
                align-items: center !important;
                justify-content: center !important;
                backdrop-filter: blur(5px) !important;
                -webkit-backdrop-filter: blur(5px) !important;
            }
            .dawp-style-pill .dawp-btn svg.dawp-svg-icon {
                width: 20px !important;
                height: 20px !important;
            }
            .dawp-style-pill .dawp-btn span {
                color: #ffffff !important;
                font-family: system-ui, -apple-system, sans-serif !important;
                line-height: 1 !important;
                margin: 0 !important;
                padding: 0 !important;
                display: inline-block !important;
            }
            .dawp-style-pill .dawp-btn::before,
            .dawp-style-pill .dawp-btn::after {
                border-radius: 28px !important;
                transform: scale(1.05, 1.12) !important;
                animation: dawp-pill-pulse 2.4s infinite cubic-bezier(0.25, 0, 0, 1) !important;
            }
            .dawp-style-pill .dawp-btn::after {
                animation-delay: 1.2s !important;
            }
            @keyframes dawp-pill-pulse {
                0% { transform: scale(1, 1); opacity: 0.6; }
                100% { transform: scale(1.15, 1.35); opacity: 0; }
            }
 
            /* ==========================================================================
               STYLE 4: COLLAPSIBLE EXPAND MENU
               ========================================================================== */
            .dawp-style-expand {
                width: 60px !important;
                height: 60px !important;
            }
            .dawp-style-expand .dawp-main-btn {
                position: relative !important;
                width: 60px !important;
                height: 60px !important;
                border-radius: 50% !important;
                background: linear-gradient(135deg, ' . esc_attr($c_zalo) . ', ' . esc_attr($c_hotline) . ') !important;
                box-shadow: 0 8px 25px rgba(255, 65, 108, 0.4) !important;
                display: flex !important;
                align-items: center !important;
                justify-content: center !important;
                cursor: pointer !important;
                z-index: 10 !important;
                transition: transform 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275) !important;
            }
            .dawp-style-expand .dawp-main-btn:hover {
                transform: scale(1.08) !important;
            }
            .dawp-style-expand .dawp-main-btn .dawp-icon-close { display: none !important; }
            .dawp-style-expand .dawp-main-btn .dawp-icon-open {
                display: flex !important;
                animation: dawp-heartbeat 1.5s infinite !important;
            }
            .dawp-style-expand .dawp-pulse-ring {
                position: absolute !important;
                top: -5px !important; left: -5px !important; right: -5px !important; bottom: -5px !important;
                border-radius: 50% !important;
                background: inherit !important;
                opacity: 0.3 !important;
                z-index: -1 !important;
                animation: dawp-pulse 2s infinite !important;
            }
            .dawp-style-expand .dawp-expand-menu {
                display: flex !important;
                flex-direction: column !important;
                gap: 12px !important;
                position: absolute !important;
                bottom: 72px !important;
                left: 2px !important;
                opacity: 0 !important;
                visibility: hidden !important;
                transform: translateY(20px) scale(0.8) !important;
                transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275) !important;
                z-index: 9 !important;
            }
            .dawp-style-expand .dawp-btn {
                width: 52px !important;
                height: 52px !important;
            }
            .dawp-style-expand .dawp-toggle-checkbox:checked ~ .dawp-expand-menu {
                opacity: 1 !important;
                visibility: visible !important;
                transform: translateY(0) scale(1) !important;
            }
            .dawp-style-expand .dawp-toggle-checkbox:checked ~ .dawp-main-btn .dawp-icon-open { display: none !important; }
            .dawp-style-expand .dawp-toggle-checkbox:checked ~ .dawp-main-btn .dawp-icon-close { display: flex !important; }
            .dawp-style-expand .dawp-toggle-checkbox:checked ~ .dawp-main-btn {
                background: #232329 !important;
                box-shadow: 0 8px 25px rgba(0,0,0,0.35) !important;
            }
 
            /* ==========================================================================
               STYLE 5: STICKY BOTTOM BAR (MOBILE) & FLOATING DOCK (DESKTOP)
               ========================================================================== */
            .dawp-sticky-bar {
                position: fixed !important;
                z-index: 999999 !important;
                margin: 0 !important;
                box-sizing: border-box !important;
                transition: all 0.3s ease !important;
            }
            
            @media (min-width: 768px) {
                .dawp-sticky-bar {
                    bottom: 25px !important;
                    left: 50% !important;
                    transform: translateX(-50%) !important;
                    width: auto !important;
                    max-width: 90% !important;
                    background: rgba(255, 255, 255, 0.85) !important;
                    backdrop-filter: blur(12px) !important;
                    -webkit-backdrop-filter: blur(12px) !important;
                    box-shadow: 0 10px 30px rgba(0,0,0,0.12) !important;
                    border: 1px solid rgba(255, 255, 255, 0.4) !important;
                    border-radius: 40px !important;
                    padding: 8px 30px !important;
                    display: flex !important;
                    align-items: center !important;
                    justify-content: center !important;
                    gap: 25px !important;
                }
                .dawp-sticky-item {
                    display: flex !important;
                    flex-direction: row !important;
                    align-items: center !important;
                    gap: 10px !important;
                    padding: 6px 12px !important;
                    border-radius: 20px !important;
                    transition: background-color 0.2s, transform 0.2s !important;
                    color: #1e293b !important;
                    font-size: 13.5px !important;
                    font-weight: 700 !important;
                    text-decoration: none !important;
                    background: transparent !important;
                    border: none !important;
                    box-shadow: none !important;
                }
                .dawp-sticky-item:hover {
                    background-color: rgba(0, 0, 0, 0.05) !important;
                    transform: translateY(-2px) !important;
                }
                .dawp-sticky-icon-wrapper {
                    width: 32px !important;
                    height: 32px !important;
                    border-radius: 50% !important;
                    display: flex !important;
                    align-items: center !important;
                    justify-content: center !important;
                    color: #fff !important;
                }
                .dawp-sticky-item .dawp-sticky-icon-wrapper svg.dawp-svg-icon {
                    width: 18px !important;
                    height: 18px !important;
                }
            }
 
            @media (max-width: 767px) {
                .dawp-sticky-bar {
                    bottom: 0 !important;
                    left: 0 !important;
                    width: 100% !important;
                    background: #ffffff !important;
                    box-shadow: 0 -3px 20px rgba(0,0,0,0.08) !important;
                    border-top: 1px solid #e2e8f0 !important;
                    display: grid !important;
                    grid-template-columns: repeat(' . $sticky_items_count . ', 1fr) !important;
                    padding: 0 !important;
                }
                .dawp-sticky-item {
                    display: flex !important;
                    flex-direction: column !important;
                    align-items: center !important;
                    justify-content: center !important;
                    padding: 8px 3px 10px 3px !important;
                    text-decoration: none !important;
                    font-size: 11.5px !important;
                    font-weight: 700 !important;
                    color: #334155 !important;
                    transition: background-color 0.2s !important;
                    border: none !important;
                    box-shadow: none !important;
                    background: transparent !important;
                }
                .dawp-sticky-item:active {
                    background-color: #f1f5f9 !important;
                }
                .dawp-sticky-icon-wrapper {
                    width: 36px !important;
                    height: 36px !important;
                    border-radius: 50% !important;
                    display: flex !important;
                    align-items: center !important;
                    justify-content: center !important;
                    margin-bottom: 4px !important;
                    color: #fff !important;
                    transition: transform 0.1s !important;
                }
                .dawp-sticky-item .dawp-sticky-icon-wrapper svg.dawp-svg-icon {
                    width: 20px !important;
                    height: 20px !important;
                }
                .dawp-sticky-item:active .dawp-sticky-icon-wrapper {
                    transform: scale(0.9) !important;
                }
            }

            /* ==========================================================================
               HIỆU NĂNG HOẠT ẢNH — đo được trên PageSpeed mobile
               Cụm nút có ~20 lớp hoạt ảnh "infinite" (ripple x2/nút, rung chuông, nhịp
               tim, vòng pulse). Không có will-change nên Chrome phải paint lại mỗi
               khung hình → main thread bận suốt (Style&Layout 1,8s + Rendering 1,2s),
               ảnh hero đã tải về nhưng bị hoãn vẽ → LCP 5-6s dù mạng đã sạch.
               1) will-change đưa lên GPU (composite), main thread rảnh.
               2) Đứng yên trong lúc trang đang tải; JS bật lại sau khi trang yên
                  (window load + 3s) — người dùng thật không nhận ra vì lúc đó họ
                  đang nhìn nội dung chính; hoạt ảnh vẫn chạy đầy đủ về sau.
               3) Tôn trọng prefers-reduced-motion.
               ========================================================================== */
            .dawp-btn::before, .dawp-btn::after,
            .dawp-btn-hotline svg, .dawp-hotline svg,
            .dawp-style-expand .dawp-main-btn .dawp-icon-open,
            .dawp-style-expand .dawp-pulse-ring {
                will-change: transform, opacity;
                backface-visibility: hidden;
            }
            html:not(.dawp-anim-ready) .dawp-btn::before,
            html:not(.dawp-anim-ready) .dawp-btn::after,
            html:not(.dawp-anim-ready) .dawp-btn-hotline svg,
            html:not(.dawp-anim-ready) .dawp-hotline svg,
            html:not(.dawp-anim-ready) .dawp-style-expand .dawp-main-btn .dawp-icon-open,
            html:not(.dawp-anim-ready) .dawp-style-expand .dawp-pulse-ring {
                animation-play-state: paused !important;
            }
            @media (prefers-reduced-motion: reduce) {
                .dawp-btn::before, .dawp-btn::after,
                .dawp-btn-hotline svg, .dawp-hotline svg,
                .dawp-style-expand .dawp-main-btn .dawp-icon-open,
                .dawp-style-expand .dawp-pulse-ring {
                    animation: none !important;
                }
            }
        </style>';
        $css_html = ob_get_clean();
        $minify = ! isset( $options['ps_minify_inline'] ) || ! empty( $options['ps_minify_inline'] );
        if ( $minify && class_exists( 'DAWP_Helpers' ) ) {
            $css_content = str_replace( array( '<style>', '</style>' ), '', $css_html );
            $css_html = '<style>' . DAWP_Helpers::minify_css( $css_content ) . '</style>';
        }
        echo $css_html;
        // Bật lại hoạt ảnh sau khi trang yên (xem chú thích HIỆU NĂNG HOẠT ẢNH ở trên)
        echo '<script data-dawp-keep="1">(function(){function go(){document.documentElement.classList.add("dawp-anim-ready");}var t=function(){setTimeout(go,3000);};if(document.readyState==="complete"){t();}else{window.addEventListener("load",t);}var e=["pointerdown","touchstart","keydown","wheel"];function h(){e.forEach(function(x){window.removeEventListener(x,h,{passive:true});});go();}e.forEach(function(x){window.addEventListener(x,h,{passive:true});});})();</script>';

        echo '<!-- Contact Buttons by Duy Anh Web Pro -->';

        // Khởi tạo nhãn mặc định tiếng Việt
        $txt_call = 'Gọi điện';
        $txt_zalo = 'Nhắn Zalo';
        $txt_whatsapp = 'Chat Whatsapp';
        $txt_messenger = 'Messenger';
        $txt_map = 'Chỉ đường';

        if ( class_exists( 'DAWP_Multilingual' ) ) {
            $lang = DAWP_Multilingual::get_current_language();
            $default_lang = DAWP_Multilingual::get_default_language();
            if ( $lang !== $default_lang ) {
                $trans_call = isset( $options['trans_hotline_lbl_' . $lang] ) ? trim( $options['trans_hotline_lbl_' . $lang] ) : '';
                $trans_zalo = isset( $options['trans_zalo_lbl_' . $lang] ) ? trim( $options['trans_zalo_lbl_' . $lang] ) : '';
                $trans_whatsapp = isset( $options['trans_whatsapp_lbl_' . $lang] ) ? trim( $options['trans_whatsapp_lbl_' . $lang] ) : '';
                $trans_msg  = isset( $options['trans_messenger_lbl_' . $lang] ) ? trim( $options['trans_messenger_lbl_' . $lang] ) : '';
                $trans_map  = isset( $options['trans_map_lbl_' . $lang] ) ? trim( $options['trans_map_lbl_' . $lang] ) : '';
                
                if ( ! empty( $trans_call ) ) {
                    $txt_call = $trans_call;
                } else {
                    if ( $lang === 'zh' ) {
                        $txt_call = '联系电话';
                    } elseif ( $lang === 'ja' ) {
                        $txt_call = '電話をかける';
                    } elseif ( $lang === 'ko' ) {
                        $txt_call = '전화 걸기';
                    } else {
                        $txt_call = 'Call Us';
                    }
                }
                
                if ( ! empty( $trans_zalo ) ) {
                    $txt_zalo = $trans_zalo;
                } else {
                    if ( $lang === 'zh' ) {
                        $txt_zalo = 'Zalo 咨询';
                    } elseif ( $lang === 'ja' ) {
                        $txt_zalo = 'Zalo 咨询';
                    } elseif ( $lang === 'ko' ) {
                        $txt_zalo = 'Zalo 문의';
                    } else {
                        $txt_zalo = 'Chat Zalo';
                    }
                }

                if ( ! empty( $trans_whatsapp ) ) {
                    $txt_whatsapp = $trans_whatsapp;
                } else {
                    if ( $lang === 'zh' ) {
                        $txt_whatsapp = 'Whatsapp 咨询';
                    } elseif ( $lang === 'ja' ) {
                        $txt_whatsapp = 'Whatsapp 咨询';
                    } elseif ( $lang === 'ko' ) {
                        $txt_whatsapp = 'Whatsapp 문의';
                    } else {
                        $txt_whatsapp = 'Chat Whatsapp';
                    }
                }
                
                if ( ! empty( $trans_msg ) ) {
                    $txt_messenger = $trans_msg;
                } else {
                    if ( $lang === 'zh' ) {
                        $txt_messenger = 'Messenger 咨询';
                    } elseif ( $lang === 'ja' ) {
                        $txt_messenger = 'Messenger 咨询';
                    } elseif ( $lang === 'ko' ) {
                        $txt_messenger = 'Messenger 문의';
                    } else {
                        $txt_messenger = 'Messenger';
                    }
                }

                if ( ! empty( $trans_map ) ) {
                    $txt_map = $trans_map;
                } else {
                    if ( $lang === 'zh' ) {
                        $txt_map = '地图导航';
                    } elseif ( $lang === 'ja' ) {
                        $txt_map = '地図案内';
                    } elseif ( $lang === 'ko' ) {
                        $txt_map = '지도 안내';
                    } else {
                        $txt_map = 'Directions';
                    }
                }
            }
        }

        if ( $style !== 'sticky_bar' ) {
            echo '<div class="dawp-contact-wrap dawp-style-' . esc_attr($style) . '">';
            
            if ( $style === 'expand' ) {
                // Collapsible Menu HTML
                echo '<input type="checkbox" id="dawp-menu-toggle" class="dawp-toggle-checkbox" style="display:none;" />';
                echo '<div class="dawp-expand-menu">';
                
                // Loop Zalo numbers
                foreach ( $zalos as $index => $zalo_item ) {
                    if ( strpos( $zalo_item, 'zalo.me' ) !== false || strpos( $zalo_item, 'http' ) === 0 ) {
                        $z_url = esc_url( $zalo_item );
                    } else {
                        $z_num = preg_replace('/[^0-9]/', '', $zalo_item);
                        $z_url = 'https://zalo.me/' . $z_num;
                    }
                    echo '<a href="' . esc_url($z_url) . '" target="_blank" rel="nofollow" class="dawp-btn dawp-zalo dawp-btn-zalo" title="' . esc_attr($txt_zalo) . '">' . $zalo_svg . '</a>';
                }

                // Loop Whatsapp numbers
                foreach ( $whatsapps as $index => $whatsapp_item ) {
                    if ( strpos( $whatsapp_item, 'wa.me' ) !== false || strpos( $whatsapp_item, 'http' ) === 0 ) {
                        $w_url = esc_url( $whatsapp_item );
                    } else {
                        $w_num = preg_replace('/[^0-9]/', '', $whatsapp_item);
                        $w_url = 'https://wa.me/' . $w_num;
                    }
                    echo '<a href="' . esc_url($w_url) . '" target="_blank" rel="nofollow" class="dawp-btn dawp-whatsapp dawp-btn-whatsapp" title="' . esc_attr($txt_whatsapp) . '">' . $whatsapp_svg . '</a>';
                }

                if ( !empty($messenger) ) {
                    echo '<a href="' . esc_url($messenger) . '" target="_blank" rel="nofollow" class="dawp-btn dawp-messenger dawp-btn-messenger" title="' . esc_attr($txt_messenger) . '">' . $messenger_svg . '</a>';
                }
                if ( !empty($map) ) {
                    echo '<a href="' . esc_url($map) . '" target="_blank" rel="nofollow" class="dawp-btn dawp-map dawp-btn-map" title="' . esc_attr($txt_map) . '">' . $map_svg . '</a>';
                }

                // Loop Hotline numbers
                foreach ( $hotlines as $index => $hotline_item ) {
                    echo '<a href="tel:' . esc_attr($hotline_item) . '" class="dawp-btn dawp-hotline dawp-btn-hotline" title="' . esc_attr($txt_call) . '">' . $phone_svg . '</a>';
                }
                
                echo '</div>';
                echo '<label for="dawp-menu-toggle" class="dawp-main-btn">';
                echo '<span class="dawp-icon-open">' . $chat_svg . '</span>';
                echo '<span class="dawp-icon-close">' . $close_svg . '</span>';
                echo '<span class="dawp-pulse-ring"></span>';
                echo '</label>';
                
            } else {
                // Classic, Classic Horizontal, or Pill HTML
                // Loop Zalo numbers
                foreach ( $zalos as $index => $zalo_item ) {
                    if ( strpos( $zalo_item, 'zalo.me' ) !== false || strpos( $zalo_item, 'http' ) === 0 ) {
                        $z_url = esc_url( $zalo_item );
                    } else {
                        $z_num = preg_replace('/[^0-9]/', '', $zalo_item);
                        $z_url = 'https://zalo.me/' . $z_num;
                    }
                    $icon_html = ($style === 'pill') ? '<div class="dawp-icon-circle">' . $zalo_svg . '</div>' : $zalo_svg;
                    $label = ($style === 'pill') ? '<span>' . esc_html($txt_zalo) . '</span>' : '';
                    echo '<a href="' . esc_url($z_url) . '" target="_blank" rel="nofollow" class="dawp-btn dawp-zalo dawp-btn-zalo" title="' . esc_attr($txt_zalo) . '">' . $icon_html . $label . '</a>';
                }

                // Loop Whatsapp numbers
                foreach ( $whatsapps as $index => $whatsapp_item ) {
                    if ( strpos( $whatsapp_item, 'wa.me' ) !== false || strpos( $whatsapp_item, 'http' ) === 0 ) {
                        $w_url = esc_url( $whatsapp_item );
                    } else {
                        $w_num = preg_replace('/[^0-9]/', '', $whatsapp_item);
                        $w_url = 'https://wa.me/' . $w_num;
                    }
                    $icon_html = ($style === 'pill') ? '<div class="dawp-icon-circle">' . $whatsapp_svg . '</div>' : $whatsapp_svg;
                    $label = ($style === 'pill') ? '<span>' . esc_html($txt_whatsapp) . '</span>' : '';
                    echo '<a href="' . esc_url($w_url) . '" target="_blank" rel="nofollow" class="dawp-btn dawp-whatsapp dawp-btn-whatsapp" title="' . esc_attr($txt_whatsapp) . '">' . $icon_html . $label . '</a>';
                }

                if ( !empty($messenger) ) {
                    $icon_html = ($style === 'pill') ? '<div class="dawp-icon-circle">' . $messenger_svg . '</div>' : $messenger_svg;
                    $label = ($style === 'pill') ? '<span>' . esc_html($txt_messenger) . '</span>' : '';
                    echo '<a href="' . esc_url($messenger) . '" target="_blank" rel="nofollow" class="dawp-btn dawp-messenger dawp-btn-messenger" title="' . esc_attr($txt_messenger) . '">' . $icon_html . $label . '</a>';
                }
                if ( !empty($map) ) {
                    $icon_html = ($style === 'pill') ? '<div class="dawp-icon-circle">' . $map_svg . '</div>' : $map_svg;
                    $label = ($style === 'pill') ? '<span>' . esc_html($txt_map) . '</span>' : '';
                    echo '<a href="' . esc_url($map) . '" target="_blank" rel="nofollow" class="dawp-btn dawp-map dawp-btn-map" title="' . esc_attr($txt_map) . '">' . $icon_html . $label . '</a>';
                }

                // Loop Hotline numbers
                foreach ( $hotlines as $index => $hotline_item ) {
                    $pill_text = $txt_call . ': ' . $hotline_item;
                    $icon_html = ($style === 'pill') ? '<div class="dawp-icon-circle">' . $phone_svg . '</div>' : $phone_svg;
                    $label = ($style === 'pill') ? '<span>' . esc_html($pill_text) . '</span>' : '';
                    echo '<a href="tel:' . esc_attr($hotline_item) . '" class="dawp-btn dawp-hotline dawp-btn-hotline" title="' . esc_attr($txt_call) . '">' . $icon_html . $label . '</a>';
                }
            }
            
            echo '</div>';
        } else {
            // Render Sticky Bottom Bar / Desktop Dock (only output if style is sticky_bar)
            echo '<div class="dawp-sticky-bar">';
            
            // Loop Hotline numbers
            foreach ( $hotlines as $index => $hotline_item ) {
                echo '<a href="tel:' . esc_attr($hotline_item) . '" class="dawp-sticky-item">';
                echo '  <span class="dawp-sticky-icon-wrapper" style="background:' . esc_attr($c_hotline) . ';">' . $phone_svg . '</span>';
                echo '  <span>' . esc_html($txt_call) . '</span>';
                echo '</a>';
            }

            // Loop Zalo numbers
            foreach ( $zalos as $index => $zalo_item ) {
                if ( strpos( $zalo_item, 'zalo.me' ) !== false || strpos( $zalo_item, 'http' ) === 0 ) {
                    $z_url = esc_url( $zalo_item );
                } else {
                    $z_num = preg_replace('/[^0-9]/', '', $zalo_item);
                    $z_url = 'https://zalo.me/' . $z_num;
                }
                echo '<a href="' . esc_url($z_url) . '" target="_blank" rel="nofollow" class="dawp-sticky-item">';
                echo '  <span class="dawp-sticky-icon-wrapper" style="background:' . esc_attr($c_zalo) . ';">' . $zalo_svg . '</span>';
                echo '  <span>' . esc_html($txt_zalo) . '</span>';
                echo '</a>';
            }

            // Loop Whatsapp numbers
            foreach ( $whatsapps as $index => $whatsapp_item ) {
                if ( strpos( $whatsapp_item, 'wa.me' ) !== false || strpos( $whatsapp_item, 'http' ) === 0 ) {
                    $w_url = esc_url( $whatsapp_item );
                } else {
                    $w_num = preg_replace('/[^0-9]/', '', $whatsapp_item);
                    $w_url = 'https://wa.me/' . $w_num;
                }
                echo '<a href="' . esc_url($w_url) . '" target="_blank" rel="nofollow" class="dawp-sticky-item">';
                echo '  <span class="dawp-sticky-icon-wrapper" style="background:' . esc_attr($c_whatsapp) . ';">' . $whatsapp_svg . '</span>';
                echo '  <span>' . esc_html($txt_whatsapp) . '</span>';
                echo '</a>';
            }

            if ( !empty($messenger) ) {
                echo '<a href="' . esc_url($messenger) . '" target="_blank" rel="nofollow" class="dawp-sticky-item">';
                echo '  <span class="dawp-sticky-icon-wrapper" style="background:' . esc_attr($c_messenger) . ';">' . $messenger_svg . '</span>';
                echo '  <span>' . esc_html($txt_messenger) . '</span>';
                echo '</a>';
            }
            if ( !empty($map) ) {
                echo '<a href="' . esc_url($map) . '" target="_blank" rel="nofollow" class="dawp-sticky-item">';
                echo '  <span class="dawp-sticky-icon-wrapper" style="background:' . esc_attr($c_map) . ';">' . $map_svg . '</span>';
                echo '  <span>' . esc_html($txt_map) . '</span>';
                echo '</a>';
            }
            
            echo '</div>';
        }
    }

    private function hex2rgba($hex, $opacity = 0.35) {
        $hex = str_replace('#', '', $hex);
        if (strlen($hex) == 3) {
            $r = hexdec(substr($hex,0,1).substr($hex,0,1));
            $g = hexdec(substr($hex,1,1).substr($hex,1,1));
            $b = hexdec(substr($hex,2,1).substr($hex,2,1));
        } else {
            $r = hexdec(substr($hex,0,2));
            $g = hexdec(substr($hex,2,2));
            $b = hexdec(substr($hex,4,2));
        }
        return "rgba($r, $g, $b, $opacity)";
    }

    private function adjust_brightness($hex, $steps) {
        $steps = max(-255, min(255, $steps));
        $hex = str_replace('#', '', $hex);
        if (strlen($hex) == 3) {
            $hex = substr($hex,0,1).substr($hex,0,1).substr($hex,1,1).substr($hex,1,1).substr($hex,2,1).substr($hex,2,1);
        }
        $r = hexdec(substr($hex,0,2));
        $g = hexdec(substr($hex,2,2));
        $b = hexdec(substr($hex,4,2));

        $r = max(0, min(255, $r + $steps));
        $g = max(0, min(255, $g + $steps));
        $b = max(0, min(255, $b + $steps));

        return '#' . str_pad(dechex($r), 2, '0', STR_PAD_LEFT) . str_pad(dechex($g), 2, '0', STR_PAD_LEFT) . str_pad(dechex($b), 2, '0', STR_PAD_LEFT);
    }
}
