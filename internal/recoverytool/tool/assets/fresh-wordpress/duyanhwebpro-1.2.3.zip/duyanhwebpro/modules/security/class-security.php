<?php
defined( 'ABSPATH' ) || exit;

class DAWP_Security {
    public function __construct() {
        $options = get_option( 'dawp_settings', false );
        if ( $options === false ) {
            $options = [
                'sec_xmlrpc' => 1,
                'sec_hide_version' => 1,
                'sec_svg' => 1,
                'sec_disable_comments' => 0,
                'sec_comment_captcha' => 1,
                'sec_chrome_cleaner' => 1
            ];
        }

        // 1. Tắt XML-RPC (Chống DDoS / Brute Force)
        if ( !empty($options['sec_xmlrpc']) ) {
            add_filter( 'xmlrpc_enabled', '__return_false' );
            add_filter( 'wp_headers', [ $this, 'remove_x_pingback' ] );
        }

        // 2. Ẩn phiên bản WordPress
        if ( !empty($options['sec_hide_version']) ) {
            add_filter( 'the_generator', '__return_empty_string' );
        }

        // 3. Upload SVG An toàn & Bộ lọc làm sạch (Sanitize)
        if ( !empty($options['sec_svg']) ) {
            add_filter( 'upload_mimes', [ $this, 'allow_svg_upload' ] );
            add_filter( 'wp_check_filetype_and_ext', [ $this, 'check_svg_filetype' ], 10, 4 );
            add_filter( 'wp_handle_upload_prefilter', [ $this, 'sanitize_svg_upload' ] );
        }

        // 4. Tắt bình luận (Disable Comments)
        if ( !empty($options['sec_disable_comments']) ) {
            $this->disable_comments();
        }

        // Luôn đảm bảo sản phẩm mới tạo mặc định mở đánh giá (reviews)
        add_filter( 'get_default_comment_status', [ $this, 'allow_product_default_comments' ], 10, 3 );

        // 5. Bật Math CAPTCHA cho bình luận
        $comment_captcha_active = ! isset( $options['sec_comment_captcha'] ) || ! empty( $options['sec_comment_captcha'] );
        if ( empty($options['sec_disable_comments']) && $comment_captcha_active ) {
            add_filter( 'comment_form_submit_field', [ $this, 'add_math_captcha' ], 10, 2 );
            add_filter( 'preprocess_comment', [ $this, 'verify_math_captcha' ] );
            
            // Đăng ký AJAX endpoints để tải captcha động bypass cache
            add_action( 'wp_ajax_dawp_get_comment_captcha', [ $this, 'ajax_get_comment_captcha' ] );
            add_action( 'wp_ajax_nopriv_dawp_get_comment_captcha', [ $this, 'ajax_get_comment_captcha' ] );
        }

        // 5. Chặn mã độc/script tiêm nhiễm từ Trình duyệt quản trị (Chrome Extension Sanitizer)
        $chrome_cleaner_active = ! isset( $options['sec_chrome_cleaner'] ) || ! empty( $options['sec_chrome_cleaner'] );
        if ( $chrome_cleaner_active ) {
            add_filter( 'wp_insert_post_data', [ $this, 'sanitize_post_content_on_save' ], 99, 2 );
        }

        // 7. Bảo vệ luồng tải lên (Upload Anti-Back-Infection)
        $upload_protection_active = ! isset( $options['sec_upload_protection'] ) || ! empty( $options['sec_upload_protection'] );
        if ( $upload_protection_active ) {
            add_filter( 'wp_handle_upload_prefilter', [ $this, 'sanitize_uploaded_file' ], 9 );
            add_filter( 'upgrader_source_selection', [ $this, 'scan_uploaded_zip_plugin' ], 9, 4 );
        }

        // 8. Tự động bóc tách mã độc tại trình duyệt máy khách (Client-side editor cleaner)
        if ( is_admin() ) {
            add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_editor_cleaner' ] );
        }

        // Đảm bảo đồng bộ trạng thái cài đặt vào DB (chỉ chạy trong admin)
        if ( is_admin() ) {
            add_action( 'admin_init', [ $this, 'enforce_comment_settings' ] );
        }

        // 9. Tường lửa ứng dụng (WAF) — chặn khai thác lỗ hổng theme/plugin
        // (PHP Object Injection, XSS UX Builder, SQLi, web shell...). Mặc định BẬT.
        $firewall_active = ! isset( $options['sec_firewall'] ) || ! empty( $options['sec_firewall'] );
        if ( $firewall_active ) {
            add_action( 'init', [ $this, 'run_firewall' ], 1 );
        }

        // 10. Thêm Security Headers (chống clickjacking, MIME sniffing, rò rỉ referrer). Mặc định BẬT.
        $headers_active = ! isset( $options['sec_headers'] ) || ! empty( $options['sec_headers'] );
        if ( $headers_active ) {
            add_action( 'send_headers', [ $this, 'add_security_headers' ] );
        }

        // 11. Chặn thực thi PHP trong thư mục uploads (vô hiệu hóa web shell). Mặc định BẬT.
        $uploads_noexec = ! isset( $options['sec_uploads_noexec'] ) || ! empty( $options['sec_uploads_noexec'] );
        if ( $uploads_noexec && is_admin() ) {
            add_action( 'admin_init', [ $this, 'harden_uploads_dir' ] );
        }
    }

    /**
     * TƯỜNG LỬA (WAF): quét dữ liệu request tìm các dấu hiệu tấn công phổ biến
     * và chặn (403) nếu phát hiện. Bỏ qua quản trị viên có quyền đăng HTML thô
     * (đang soạn nội dung hợp lệ qua trình dựng trang) để tránh chặn nhầm.
     */
    public function run_firewall() {
        if ( ( defined( 'DOING_CRON' ) && DOING_CRON ) || ( defined( 'WP_CLI' ) && WP_CLI ) ) {
            return;
        }
        // Không quét quản trị viên tin cậy (họ được phép đăng script/HTML thô).
        if ( is_user_logged_in() && current_user_can( 'unfiltered_html' ) ) {
            return;
        }

        $patterns = [
            // PHP Object Injection (dữ liệu serialized) & phar deserialization
            '/O:\d+:"[a-z0-9_\\\\]+":\d+:\{/i',
            '/(phar|expect|glob|zip):\/\//i',
            '/php:\/\/(input|filter|memory)/i',
            // Chèn/thực thi mã PHP
            '/\b(eval|assert|create_function|base64_decode|gzinflate|gzuncompress|str_rot13|system|shell_exec|passthru|proc_open|popen|pcntl_exec)\s*\(/i',
            '/\$_(GET|POST|REQUEST|SERVER|COOKIE|FILES|SESSION)\s*\[/i',
            '/\b(call_user_func|file_put_contents|fwrite|move_uploaded_file)\s*\(/i',
            // XSS
            '/<script[\s\/>]/i',
            '/<iframe[\s\/>]/i',
            '/javascript:/i',
            '/on(error|load|mouseover|click|focus|submit|toggle)\s*=/i',
            '/document\.cookie/i',
            '/String\.fromCharCode/i',
            // SQL Injection
            '/union[\s\/\*!]+select/i',
            '/information_schema/i',
            '/\b(sleep|benchmark|updatexml|extractvalue|load_file)\s*\(/i',
            '/into\s+(out|dump)file/i',
            // Truy cập file nhạy cảm / path traversal
            '/\.\.[\/\\\\]\.\.[\/\\\\]/',
            '/(wp-config\.php|\/etc\/passwd|boot\.ini|\.env)/i',
        ];

        $values = $this->collect_request_values();
        foreach ( $values as $val ) {
            if ( ! is_string( $val ) || '' === $val ) {
                continue;
            }
            $decoded = rawurldecode( $val );
            foreach ( $patterns as $re ) {
                if ( preg_match( $re, $val ) || ( $decoded !== $val && preg_match( $re, $decoded ) ) ) {
                    $this->firewall_block();
                }
            }
        }
    }

    /**
     * Gom toàn bộ giá trị scalar trong GET/POST/COOKIE để quét.
     */
    private function collect_request_values() {
        $out = [];
        $walk = function( $arr ) use ( &$out, &$walk ) {
            foreach ( (array) $arr as $v ) {
                if ( is_array( $v ) ) {
                    $walk( $v );
                } elseif ( is_scalar( $v ) ) {
                    $out[] = (string) $v;
                }
            }
        };
        $walk( $_GET );
        $walk( $_POST );
        $walk( $_COOKIE );
        return $out;
    }

    /**
     * Trả về 403 và dừng khi tường lửa phát hiện tấn công.
     */
    private function firewall_block() {
        if ( ! headers_sent() ) {
            status_header( 403 );
            nocache_headers();
            header( 'Content-Type: text/html; charset=UTF-8' );
        }
        echo '<!doctype html><html lang="vi"><head><meta charset="utf-8"><title>403 Forbidden</title></head><body>';
        echo '<div style="font-family:-apple-system,Segoe UI,Roboto,sans-serif;max-width:520px;margin:80px auto;text-align:center;">';
        echo '<h1 style="font-size:64px;margin:0;color:#d63638;">403</h1>';
        echo '<p style="font-size:16px;color:#333;">Yêu cầu của bạn đã bị Tường lửa bảo mật chặn.</p>';
        echo '<p style="font-size:12px;color:#999;">Duy Anh Web Pro — Security Firewall</p>';
        echo '</div></body></html>';
        exit;
    }

    /**
     * Thêm các HTTP security header giúp giảm rủi ro XSS/clickjacking.
     */
    public function add_security_headers() {
        if ( headers_sent() ) {
            return;
        }
        header( 'X-Content-Type-Options: nosniff' );
        header( 'X-Frame-Options: SAMEORIGIN' );
        header( 'Referrer-Policy: strict-origin-when-cross-origin' );
        header( 'X-XSS-Protection: 0' );
        header( 'Permissions-Policy: geolocation=(), microphone=(), camera=()' );
    }

    /**
     * Ghi .htaccess vào thư mục uploads để chặn thực thi file PHP (vô hiệu web shell).
     * Chỉ chạy 1 lần cho mỗi phiên bản để tránh ghi lặp.
     */
    public function harden_uploads_dir() {
        $ver = defined( 'DAWP_VERSION' ) ? DAWP_VERSION : '1';
        if ( get_option( 'dawp_uploads_hardened' ) === $ver ) {
            return;
        }

        $upload = wp_upload_dir();
        if ( empty( $upload['basedir'] ) || ! is_dir( $upload['basedir'] ) || ! is_writable( $upload['basedir'] ) ) {
            return;
        }

        $htaccess = trailingslashit( $upload['basedir'] ) . '.htaccess';
        $existing = file_exists( $htaccess ) ? (string) @file_get_contents( $htaccess ) : '';

        if ( strpos( $existing, 'DAWP_UPLOADS_HARDENING' ) === false ) {
            $rules  = "# BEGIN DAWP_UPLOADS_HARDENING\n";
            $rules .= "<FilesMatch \"\\.(?i:php|php3|php4|php5|php7|phtml|pht|phar)$\">\n";
            $rules .= "  <IfModule mod_authz_core.c>\n    Require all denied\n  </IfModule>\n";
            $rules .= "  <IfModule !mod_authz_core.c>\n    Order Deny,Allow\n    Deny from all\n  </IfModule>\n";
            $rules .= "</FilesMatch>\n";
            $rules .= "# END DAWP_UPLOADS_HARDENING\n\n";
            @file_put_contents( $htaccess, $rules . $existing );
        }

        update_option( 'dawp_uploads_hardened', $ver, false );
    }

    public function enforce_comment_settings() {
        $options = get_option( 'dawp_settings', [] );
        $is_disabled = !empty($options['sec_disable_comments']);
        
        $current_comment_status = get_option('default_comment_status');
        $current_ping_status = get_option('default_ping_status');
 
        if ( $is_disabled ) {
            if ( $current_comment_status !== 'closed' ) update_option( 'default_comment_status', 'closed' );
            if ( $current_ping_status !== 'closed' ) update_option( 'default_ping_status', 'closed' );
        } else {
            // Nếu admin tắt chức năng chặn comment trong plugin, trả lại trạng thái open nếu nó đang bị closed
            // (Chỉ mở lại nếu đúng là đang bị plugin đóng)
            if ( $current_comment_status === 'closed' ) update_option( 'default_comment_status', 'open' );
            if ( $current_ping_status === 'closed' ) update_option( 'default_ping_status', 'open' );
        }
    }

    private function disable_comments() {
        // Tắt comments và pings trên tất cả bài viết cũ/mới (2 lớp bảo vệ) - Ngoại trừ Sản phẩm WooCommerce
        add_filter( 'comments_open', [ $this, 'disable_comments_except_product' ], 20, 2 );
        add_filter( 'pings_open', [ $this, 'disable_comments_except_product' ], 20, 2 );

        // Ẩn các comment hiện tại ngoài Frontend - Ngoại trừ Sản phẩm WooCommerce
        add_filter( 'comments_array', [ $this, 'hide_comments_except_product' ], 10, 2 );
    }

    public function disable_comments_except_product( $open, $post_id ) {
        $post = get_post( $post_id );
        if ( $post && $post->post_type === 'product' ) {
            // Nếu WooCommerce bật đánh giá toàn cục, ta mở lại đánh giá cho sản phẩm
            if ( get_option( 'woocommerce_enable_reviews' ) === 'yes' ) {
                return true;
            }
            return $open;
        }
        return false;
    }

    public function hide_comments_except_product( $comments, $post_id = 0 ) {
        if ( is_admin() ) {
            return $comments;
        }
        if ( ! $post_id ) {
            $post_id = get_the_ID();
        }
        $post = get_post( $post_id );
        if ( $post && $post->post_type === 'product' ) {
            return $comments;
        }
        return array();
    }

    public function allow_product_default_comments( $status, $post_type, $comment_type ) {
        if ( 'product' === $post_type ) {
            return 'open';
        }
        return $status;
    }

    public function remove_x_pingback( $headers ) {
        unset( $headers['X-Pingback'] );
        return $headers;
    }

    public function allow_svg_upload( $mimes ) {
        $mimes['svg'] = 'image/svg+xml';
        return $mimes;
    }

    public function check_svg_filetype( $data, $file = '', $filename = '', $mimes = null ) {
        $ext = isset( $data['ext'] ) ? $data['ext'] : '';
        if ( $ext === 'svg' ) {
            $data['type'] = 'image/svg+xml';
            $data['ext']  = 'svg';
        }
        return $data;
    }

    /**
     * Bắt và làm sạch mã độc (Sanitize) trong file SVG trước khi hoàn tất upload
     */
    public function sanitize_svg_upload( $file ) {
        if ( isset( $file['type'] ) && $file['type'] === 'image/svg+xml' ) {
            $file_path = isset( $file['tmp_name'] ) ? $file['tmp_name'] : '';
            if ( ! empty( $file_path ) && file_exists( $file_path ) ) {
                $svg_code = file_get_contents( $file_path );
                if ( ! empty( $svg_code ) ) {
                    $clean_svg = $this->sanitize_svg_content( $svg_code );
                    if ( $clean_svg === false ) {
                        $file['error'] = 'Mã độc XSS/XML hoặc nguy cơ XXE bị phát hiện, hoặc máy chủ không hỗ trợ xử lý SVG an toàn. Đã chặn tải lên để bảo vệ hệ thống tuyệt đối!';
                    } else {
                        file_put_contents( $file_path, $clean_svg );
                    }
                }
            }
        }
        return $file;
    }

    /**
     * Thuật toán làm sạch mã độc trong nội dung file SVG (Bảo mật tuyệt đối)
     */
    private function sanitize_svg_content( $svg_code ) {
        // 1. Máy chủ bắt buộc phải hỗ trợ DOMDocument để xử lý an toàn
        if ( ! class_exists( 'DOMDocument' ) ) {
            return false; // Chặn thẳng nếu không thể quét an toàn (tránh dùng regex fallback lỏng lẻo)
        }

        // 2. Kiểm tra nhanh bằng regex các tag nguy hiểm
        if ( preg_match( '/<\s*script/i', $svg_code ) ) {
            return false; // Chặn thẳng nếu có thẻ <script>
        }

        // 3. Triệt tiêu triệt để nguy cơ XXE và XML Bomb bằng cách bóc tách hoàn toàn DOCTYPE và ENTITY trước khi parse XML
        $svg_code = preg_replace( '/<!DOCTYPE[^>]*>/is', '', $svg_code );
        $svg_code = preg_replace( '/<!ENTITY[^>]*>/is', '', $svg_code );

        $dom = new DOMDocument();
        
        // Tắt nạp thực thể bên ngoài và lỗi nội bộ của libxml
        $libxml_behavior = libxml_use_internal_errors( true );
        
        // Tắt bộ tải thực thể ngoài cho các phiên bản PHP < 8.0
        $disable_entity_loader = false;
        if ( PHP_VERSION_ID < 80000 && function_exists( 'libxml_disable_entity_loader' ) ) {
            $disable_entity_loader = libxml_disable_entity_loader( true );
        }

        // Nạp XML an toàn và loại trừ truy cập mạng
        $load_success = $dom->loadXML( $svg_code, LIBXML_NONET );

        // Trả lại trạng thái ban đầu của PHP
        if ( PHP_VERSION_ID < 80000 && function_exists( 'libxml_disable_entity_loader' ) ) {
            libxml_disable_entity_loader( $disable_entity_loader );
        }

        if ( ! $load_success ) {
            libxml_use_internal_errors( $libxml_behavior );
            return false; // File XML lỗi cấu trúc hoặc chứa mã độc DTD
        }
        
        // Danh sách thẻ SVG được phép hoạt động (Whitelist)
        $allowed_tags = [
            'svg', 'path', 'rect', 'circle', 'ellipse', 'line', 'polyline', 'polygon',
            'g', 'text', 'tspan', 'defs', 'use', 'symbol', 'clippath', 'mask',
            'lineargradient', 'radialgradient', 'stop', 'image', 'filter',
            'fegaussianblur', 'feoffset', 'femerge', 'femergenode', 'style'
        ];
        
        // Duyệt qua toàn bộ phần tử trong DOM
        $elements = $dom->getElementsByTagName( '*' );
        $to_remove = [];
        
        foreach ( $elements as $element ) {
            $tag_name = strtolower( $element->nodeName );
            
            // Nếu thẻ không nằm trong Whitelist -> Đánh dấu để xóa sổ
            if ( ! in_array( $tag_name, $allowed_tags, true ) ) {
                $to_remove[] = $element;
                continue;
            }

            // Làm sạch nội dung thẻ style đề phòng XSS ẩn giấu qua CSS
            if ( $tag_name === 'style' ) {
                $style_content = $element->nodeValue;
                if ( preg_match( '/expression|javascript:|url\s*\(|behavior/i', $style_content ) ) {
                    $to_remove[] = $element;
                    continue;
                }
            }
            
            // Quét và xóa các thuộc tính nguy hiểm (Attributes)
            if ( $element->hasAttributes() ) {
                $attrs_to_remove = [];
                foreach ( $element->attributes as $attr ) {
                    $attr_name = strtolower( $attr->nodeName );
                    
                    // 1. Xóa toàn bộ thuộc tính sự kiện bắt đầu bằng "on" (onload, onclick, onmouseover...)
                    if ( strpos( $attr_name, 'on' ) === 0 ) {
                        $attrs_to_remove[] = $attr->nodeName;
                    }
                    
                    // 2. Chặn các liên kết chứa giao thức nguy hiểm "javascript:" hoặc "data:"
                    if ( in_array( $attr_name, [ 'href', 'xlink:href' ], true ) ) {
                        $val = strtolower( trim( $attr->nodeValue ) );
                        if ( strpos( $val, 'javascript:' ) === 0 || strpos( $val, 'data:' ) === 0 ) {
                            $attrs_to_remove[] = $attr->nodeName;
                        }
                    }
                }
                
                // Thực thi xóa thuộc tính rác độc hại
                foreach ( $attrs_to_remove as $attr_name ) {
                    $element->removeAttribute( $attr_name );
                }
            }
        }
        
        // Xóa hoàn toàn các thẻ không an toàn khỏi cây DOM
        foreach ( $to_remove as $element ) {
            if ( $element->parentNode ) {
                $element->parentNode->removeChild( $element );
            }
        }
        
        // Xuất lại chuỗi XML sạch sẽ
        $clean_svg = $dom->saveXML();
        libxml_use_internal_errors( $libxml_behavior );
        
        return $clean_svg;
    }

    /**
     * Tích hợp Math CAPTCHA vào form bình luận (Không dùng Session)
     */
    public function add_math_captcha( $submit_field, $args ) {
        if ( is_user_logged_in() ) {
            return $submit_field;
        }

        // Bỏ qua nếu là trang sản phẩm WooCommerce
        if ( function_exists( 'is_product' ) && is_product() ) {
            return $submit_field;
        }

        $captcha_html = '
        <p class="comment-form-dawp-captcha" style="margin: 15px 0; display: none;">
            <label for="dawp_captcha_ans" style="display: block; margin-bottom: 5px; font-weight: 600;">
                <span class="dawp-captcha-question">...</span> <span class="required" style="color: red;">*</span>
            </label>
            <input type="number" id="dawp_captcha_ans" name="dawp_captcha_ans" class="regular-text" style="width: 100px; padding: 6px; border: 1px solid #ddd; border-radius: 4px;" required />
            <input type="hidden" id="dawp_captcha_hash" name="dawp_captcha_hash" value="" />
        </p>
        <script>
        (function() {
            var commentForm = document.getElementById("commentform");
            if (!commentForm) return;

            var commentField = commentForm.querySelector("textarea[name=\'comment\']");
            var captchaLoaded = false;

            var loadCaptcha = function() {
                if (captchaLoaded) return;
                captchaLoaded = true;

                var xhr = new XMLHttpRequest();
                xhr.open("POST", "' . admin_url('admin-ajax.php') . '");
                xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                xhr.onload = function() {
                    if (xhr.status === 200) {
                        try {
                            var res = JSON.parse(xhr.responseText);
                            if (res.success) {
                                var wrap = commentForm.querySelector(".comment-form-dawp-captcha");
                                if (wrap) {
                                    wrap.querySelector(".dawp-captcha-question").textContent = res.data.question;
                                    wrap.querySelector("#dawp_captcha_hash").value = res.data.hash;
                                    wrap.style.display = "block";
                                }
                            }
                        } catch(e) {}
                    }
                };
                xhr.send("action=dawp_get_comment_captcha");
            };

            if (commentField) {
                commentField.addEventListener("focus", loadCaptcha);
            }
        })();
        </script>';

        return $captcha_html . $submit_field;
    }

    /**
     * AJAX endpoint sinh CAPTCHA động bypass cache cho bình luận
     */
    public function ajax_get_comment_captcha() {
        $num1 = rand( 1, 9 );
        $num2 = rand( 1, 9 );
        $ans  = $num1 + $num2;

        $salt_today = date('Ymd') . wp_salt( 'nonce' );
        $hash = md5( $ans . $salt_today );

        $lang = 'vi';
        if ( class_exists( 'DAWP_Multilingual' ) ) {
            $lang = DAWP_Multilingual::get_current_language();
        }

        $lbl_captcha = 'Xác minh bảo mật:';
        if ( $lang !== 'vi' ) {
            $options = get_option( 'dawp_settings', [] );
            $trans_captcha = isset( $options['trans_captcha_label_' . $lang] ) ? trim( $options['trans_captcha_label_' . $lang] ) : '';
            if ( ! empty( $trans_captcha ) ) {
                $lbl_captcha = $trans_captcha;
            } else {
                $translations = [
                    'en' => 'Security verification:',
                    'ja' => 'セキュリティ検証:',
                    'zh' => '安全验证:',
                    'ko' => '보안 확인:',
                    'fr' => 'Vérification de sécurité:',
                    'de' => 'Sicherheitsüberprüfung:',
                    'ru' => 'Проверка безопасности:'
                ];
                if ( isset( $translations[ $lang ] ) ) {
                    $lbl_captcha = $translations[ $lang ];
                }
            }
        }

        $question = $lbl_captcha . ' ' . $num1 . ' + ' . $num2 . ' = ?';

        wp_send_json_success([
            'question' => $question,
            'hash'     => $hash
        ]);
    }

    /**
     * Xác thực kết quả Math CAPTCHA khi gửi bình luận
     */
    public function verify_math_captcha( $commentdata ) {
        if ( is_user_logged_in() ) {
            return $commentdata;
        }

        // Bỏ qua kiểm tra nếu là đánh giá sản phẩm WooCommerce
        $post_id = isset( $commentdata['comment_post_ID'] ) ? $commentdata['comment_post_ID'] : 0;
        if ( $post_id ) {
            $post = get_post( $post_id );
            if ( $post && $post->post_type === 'product' ) {
                return $commentdata;
            }
        }

        $ans  = isset( $_POST['dawp_captcha_ans'] ) ? trim( $_POST['dawp_captcha_ans'] ) : '';
        $hash = isset( $_POST['dawp_captcha_hash'] ) ? trim( $_POST['dawp_captcha_hash'] ) : '';

        $err_empty = '<strong>LỖI:</strong> Vui lòng hoàn thành phép tính bảo mật để gửi bình luận.';
        $err_wrong = '<strong>LỖI:</strong> Phép tính chống spam không chính xác. Vui lòng quay lại và thử lại!';

        if ( class_exists( 'DAWP_Multilingual' ) ) {
            $lang = DAWP_Multilingual::get_current_language();
            $default_lang = DAWP_Multilingual::get_default_language();
            if ( $lang !== $default_lang ) {
                $options = get_option( 'dawp_settings', [] );
                $trans_empty = isset( $options['trans_captcha_empty_' . $lang] ) ? trim( $options['trans_captcha_empty_' . $lang] ) : '';
                $trans_wrong = isset( $options['trans_captcha_wrong_' . $lang] ) ? trim( $options['trans_captcha_wrong_' . $lang] ) : '';

                if ( ! empty( $trans_empty ) ) {
                    $err_empty = '<strong>ERROR:</strong> ' . $trans_empty;
                } else {
                    $empty_translations = [
                        'en' => '<strong>ERROR:</strong> Please complete the security calculation to post comment.',
                        'ja' => '<strong>エラー:</strong> コメントを投稿するには、セキュリティの計算を完了してください。',
                        'zh' => '<strong>错误:</strong> 请完成安全计算以发表评论。',
                        'ko' => '<strong>오류:</strong> 댓글을 게시하려면 보안 계산을 완료해 주세요.',
                        'fr' => '<strong>ERREUR:</strong> Veuillez effectuer le calcul de sécurité pour publier un commentaire.',
                        'de' => '<strong>FEHLER:</strong> Bitte führen Sie die Sicherheitsberechnung durch, um einen Kommentar zu veröffentlichen.',
                        'ru' => '<strong>ОШИБКА:</strong> Пожалуйста, выполните проверку безопасности, чтобы опубликовать комментарий.'
                    ];
                    if ( isset( $empty_translations[ $lang ] ) ) {
                        $err_empty = $empty_translations[ $lang ];
                    }
                }

                if ( ! empty( $trans_wrong ) ) {
                    $err_wrong = '<strong>ERROR:</strong> ' . $trans_wrong;
                } else {
                    $wrong_translations = [
                        'en' => '<strong>ERROR:</strong> Incorrect anti-spam calculation. Please go back and try again!',
                        'ja' => '<strong>エラー:</strong> スパム防止の計算が正しくありません。戻ってやり直してください！',
                        'zh' => '<strong>错误:</strong> 防垃圾邮件计算错误。请返回重试！',
                        'ko' => '<strong>오류:</strong> 스팸 방지 계산이 올바르지 않습니다. 돌아가서 다시 시도해 주세요!',
                        'fr' => '<strong>ERREUR:</strong> Calcul anti-spam incorrect. Veuillez revenir en arrière et réessayer !',
                        'de' => '<strong>FEHLER:</strong> Ungültige Anti-Spam-Berechnung. Bitte gehen Sie zurück und versuchen Sie es erneut!',
                        'ru' => '<strong>ОШИБКА:</strong> Неверный расчет для защиты от спама. Пожалуйста, вернитесь и попробуйте еще раз!'
                    ];
                    if ( isset( $wrong_translations[ $lang ] ) ) {
                        $err_wrong = $wrong_translations[ $lang ];
                    }
                }
            }
        }

        if ( empty( $ans ) || empty( $hash ) ) {
            wp_die( $err_empty );
        }

        $salt_today = date('Ymd') . wp_salt( 'nonce' );
        $salt_yesterday = date('Ymd', strtotime('-1 day')) . wp_salt( 'nonce' );

        $verify_today = md5( $ans . $salt_today );
        $verify_yesterday = md5( $ans . $salt_yesterday );

        if ( hash_equals( $hash, $verify_today ) || hash_equals( $hash, $verify_yesterday ) ) {
            return $commentdata;
        }

        wp_die( $err_wrong );
    }

    /**
     * Xóa vĩnh viễn toàn bộ bình luận bằng SQL Truncate (Siêu tốc - Chuẩn tương thích LTS 10 năm)
     * 
     * @return bool
     */
    public static function clean_all_comments() : bool {
        global $wpdb;
        $wpdb->query( "TRUNCATE TABLE {$wpdb->comments}" );
        $wpdb->query( "TRUNCATE TABLE {$wpdb->commentmeta}" );
        $wpdb->query( "UPDATE {$wpdb->posts} SET comment_count = 0" );
        return true;
    }

    /**
     * Tự động lọc sạch mã độc/script/iframe chrome-extension tiêm nhiễm từ trình duyệt quản trị trước khi lưu database
     */
    public function sanitize_post_content_on_save( $data, $postarr ) {
        if ( isset( $data['post_content'] ) && ! empty( $data['post_content'] ) ) {
            $content = $data['post_content'];
            
            // Xóa thẻ script/iframe chứa nguồn chrome-extension://
            $cleaned_content = preg_replace( '/<(script|iframe)[^>]*chrome-extension:\/\/[^>]*>.*?<\/\1>/is', '', $content );
            $cleaned_content = preg_replace( '/<(script|iframe)[^>]*chrome-extension:\/\/[^>]*>/i', '', $cleaned_content );
            
            if ( $cleaned_content !== $content ) {
                $data['post_content'] = $cleaned_content;
            }
        }
        return $data;
    }

    /**
     * Nạp script làm sạch editor tại trình duyệt của admin
     */
    public function enqueue_editor_cleaner( $hook ) {
        if ( in_array( $hook, [ 'post.php', 'post-new.php' ], true ) ) {
            wp_enqueue_script(
                'dawp-editor-cleaner',
                DAWP_URL . 'assets/js/dawp-editor-cleaner.js',
                [ 'jquery' ],
                DAWP_VERSION,
                true
            );
        }
    }

    /**
     * Lọc và làm sạch tệp tin tải lên (Ngăn chặn lây nhiễm ngược qua upload ảnh/file)
     */
    public function sanitize_uploaded_file( $file ) {
        $name = isset( $file['name'] ) ? $file['name'] : '';
        $tmp_name = isset( $file['tmp_name'] ) ? $file['tmp_name'] : '';
        
        if ( empty( $name ) || empty( $tmp_name ) || ! file_exists( $tmp_name ) ) {
            return $file;
        }

        // 1. Kiểm tra Null-byte trong tên file
        if ( strpos( $name, chr(0) ) !== false || strpos( $name, '%00' ) !== false ) {
            $file['error'] = 'Chặn tải lên: Tên tệp tin chứa ký tự điều khiển trái phép (Null-byte)!';
            return $file;
        }

        // 2. Chặn đuôi kép nguy hại (Double Extension Protection)
        $file_info = pathinfo( $name );
        $ext = isset( $file_info['extension'] ) ? strtolower( $file_info['extension'] ) : '';
        
        $blocked_exts = [ 'php', 'php3', 'php4', 'php5', 'php7', 'php8', 'phtml', 'phps', 'pl', 'py', 'cgi', 'asp', 'aspx', 'jsp', 'sh', 'exe', 'bat', 'cmd', 'htaccess' ];
        
        $parts = explode( '.', strtolower( $name ) );
        if ( count( $parts ) > 2 ) {
            $middle_parts = array_slice( $parts, 1, -1 );
            foreach ( $middle_parts as $part ) {
                if ( in_array( $part, $blocked_exts, true ) ) {
                    $file['error'] = 'Chặn tải lên: Tên tệp chứa đuôi kép nguy hại (.php.* hoặc tương tự)!';
                    return $file;
                }
            }
        }
        
        if ( in_array( $ext, $blocked_exts, true ) ) {
            $file['error'] = 'Chặn tải lên: Loại tệp tin thực thi này bị cấm vì lý do bảo mật!';
            return $file;
        }

        // 3. Polyglot Image Scanner: Quét mã nhúng PHP ẩn giấu trong ảnh
        $img_exts = [ 'jpg', 'jpeg', 'png', 'gif', 'webp', 'svg' ];
        if ( in_array( $ext, $img_exts, true ) ) {
            $file_size = @filesize( $tmp_name );
            $content_to_scan = '';
            
            $handle = @fopen( $tmp_name, 'rb' );
            if ( $handle ) {
                if ( $file_size <= 1024 * 1024 ) {
                    $content_to_scan = @fread( $handle, $file_size );
                } else {
                    $content_to_scan .= @fread( $handle, 512 * 1024 );
                    if ( @fseek( $handle, -512 * 1024, SEEK_END ) === 0 ) {
                        $content_to_scan .= @fread( $handle, 512 * 1024 );
                    }
                }
                @fclose( $handle );
            }
            
            if ( ! empty( $content_to_scan ) ) {
                // Tránh viết thẳng các tag gốc PHP để tránh AV trên máy khách nhận diện nhầm
                $php_patterns = [
                    '<' . '?php',
                    '<' . 'script language="php"',
                    '<' . 'script language=\'php\'',
                ];
                
                foreach ( $php_patterns as $pat ) {
                    if ( stripos( $content_to_scan, $pat ) !== false ) {
                        $file['error'] = 'Chặn tải lên: Phát hiện mã thực thi PHP/ASP ẩn giấu bên trong tệp tin hình ảnh! Máy tính của bạn có thể đã bị lây nhiễm mã độc tự động tiêm.';
                        return $file;
                    }
                }
            }
        }
        
        return $file;
    }

    /**
     * Quét và ngăn chặn cài đặt plugin/theme qua tệp ZIP chứa backdoor mã độc
     */
    public function scan_uploaded_zip_plugin( $source, $remote_source, $upgrader, $extra ) {
        if ( is_wp_error( $source ) ) {
            return $source;
        }

        $files_to_scan = $this->get_files_in_dir_recursive( $source );
        
        // Tránh viết thẳng chữ ký để tránh AV quét nhầm file php của plugin
        $suspicious_patterns = [
            'e' . 'v' . 'a' . 'l' . '(' . 'b' . 'a' . 's' . 'e' . '6' . '4' . '_' . 'd' . 'e' . 'c' . 'o' . 'd' . 'e',
            'e' . 'v' . 'a' . 'l' . '(' . 'g' . 'z' . 'i' . 'n' . 'f' . 'l' . 'a' . 't' . 'e',
            'p' . 'r' . 'e' . 'g' . '_' . 'r' . 'e' . 'p' . 'l' . 'a' . 'c' . 'e' . '(' . '[\'"]' . '/' . '.*' . '/' . 'e',
            'w' . 's' . 'o' . '_' . 's' . 'h' . 'e' . 'l' . 'l',
            'c' . '9' . '9' . 's' . 'h' . 'e' . 'l' . 'l',
            'r' . '5' . '7' . 's' . 'h' . 'e' . 'l' . 'l',
        ];

        foreach ( $files_to_scan as $file ) {
            if ( pathinfo( $file, PATHINFO_EXTENSION ) === 'php' ) {
                $content = @file_get_contents( $file );
                if ( ! empty( $content ) ) {
                    foreach ( $suspicious_patterns as $pattern ) {
                        if ( preg_match( '/' . preg_quote( $pattern, '/' ) . '/i', $content ) ) {
                            return new WP_Error(
                                'dawp_malicious_plugin',
                                sprintf( __( '⚠️ CẢNH BÁO BẢO MẬT: Phát hiện mã nguồn độc hại hoặc backdoor ẩn giấu trong tệp tin: <code>%s</code>. Đã chặn đứng cài đặt để bảo vệ an toàn hệ thống!', 'duyanhwebpro' ), basename( $file ) )
                            );
                        }
                    }
                }
            }
        }

        return $source;
    }

    private function get_files_in_dir_recursive( $dir ) {
        $files = [];
        if ( is_dir( $dir ) ) {
            $items = @scandir( $dir );
            foreach ( $items as $item ) {
                if ( $item === '.' || $item === '..' ) continue;
                $path = $dir . '/' . $item;
                if ( is_dir( $path ) ) {
                    $files = array_merge( $files, $this->get_files_in_dir_recursive( $path ) );
                } else {
                    $files[] = $path;
                }
            }
        }
        return $files;
    }

    /**
     * Quét các bài viết bị nhiễm mã độc chrome-extension
     */
    public static function scan_infected_posts() {
        global $wpdb;
        $query = "SELECT ID, post_title, post_type FROM {$wpdb->posts} WHERE post_content LIKE '%chrome-extension://%'";
        $results = $wpdb->get_results( $query, ARRAY_A );
        return $results ? $results : [];
    }

    /**
     * Làm sạch mã độc chrome-extension trong các bài viết
     */
    public static function clean_infected_posts() {
        global $wpdb;
        $query = "SELECT ID, post_content, post_title FROM {$wpdb->posts} WHERE post_content LIKE '%chrome-extension://%'";
        $results = $wpdb->get_results( $query, ARRAY_A );
        
        if ( empty( $results ) ) {
            return [
                'success' => true,
                'count'   => 0,
                'cleaned' => []
            ];
        }
        
        $cleaned_posts = [];
        $count = 0;
        
        foreach ( $results as $post ) {
            $content = $post['post_content'];
            $cleaned_content = preg_replace( '/<(script|iframe)[^>]*chrome-extension:\/\/[^>]*>.*?<\/\1>/is', '', $content );
            $cleaned_content = preg_replace( '/<(script|iframe)[^>]*chrome-extension:\/\/[^>]*>/i', '', $cleaned_content );
            
            if ( $cleaned_content !== $content ) {
                $updated = $wpdb->update(
                    $wpdb->posts,
                    [ 'post_content' => $cleaned_content ],
                    [ 'ID' => $post['ID'] ],
                    [ '%s' ],
                    [ '%d' ]
                );
                
                if ( $updated !== false ) {
                    $count++;
                    $cleaned_posts[] = [
                        'id'    => $post['ID'],
                        'title' => $post['post_title']
                    ];
                }
            }
        }
        
        return [
            'success' => true,
            'count'   => $count,
            'cleaned' => $cleaned_posts
        ];
    }
}
