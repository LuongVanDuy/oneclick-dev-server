/**
 * Duy Anh Web Pro - Client-Side Chrome Extension Sanitizer & Malicious Script Interceptor
 * 
 * Phòng chống và loại bỏ mã độc chèn từ trình duyệt/tiện ích mở rộng độc hại (Chrome Extensions)
 * chạy hoàn toàn trên máy khách (0% CPU máy chủ).
 */
(function($) {
    'use strict';

    // Hàm hiển thị thông báo cảnh báo bảo mật tinh tế dạng Admin Notice
    var alertTimer = null;
    function showCleanerAlert() {
        if ($('#dawp-extension-cleaner-notice').length === 0) {
            var noticeHtml = '<div id="dawp-extension-cleaner-notice" class="notice notice-error is-dismissible" style="position: fixed; top: 40px; right: 20px; z-index: 99999; border-left-color: #d63638; box-shadow: 0 4px 15px rgba(0,0,0,0.15); display: none; max-width: 400px; background: #fff; padding: 15px; border-radius: 4px; border-left-width: 4px;">' +
                '<h4 style="margin: 0 0 5px 0; color: #d63638; font-weight: 600;">🔒 Bảo Vệ Duy Anh Web Pro</h4>' +
                '<p style="margin: 0; font-size: 13px; color: #3c434a;">Hệ thống đã chặn đứng một hành vi tự động tiêm (inject) mã độc hoặc tiện ích lạ từ trình duyệt quản trị vào nội dung soạn thảo. Bài viết của bạn đã được bảo vệ an toàn!</p>' +
                '<button type="button" class="notice-dismiss" style="top: 10px; right: 10px;" onclick="jQuery(\'#dawp-extension-cleaner-notice\').fadeOut();"><span class="screen-reader-text">Bỏ qua thông báo này.</span></button>' +
                '</div>';
            $('body').append(noticeHtml);
        }
        
        var $notice = $('#dawp-extension-cleaner-notice');
        $notice.fadeIn();
        
        // Tự động ẩn sau 8 giây
        if (alertTimer) {
            clearTimeout(alertTimer);
        }
        alertTimer = setTimeout(function() {
            $notice.fadeOut();
        }, 8000);
    }

    // --- LỚP 1: THEO DÕI DOM THỜI GIAN THỰC (MUTATION OBSERVER) ---
    // Phát hiện và xóa ngay lập tức bất kỳ thẻ script hoặc iframe trỏ tới chrome-extension:// nào vừa được tiêm vào DOM
    if (window.MutationObserver) {
        var observer = new MutationObserver(function(mutations) {
            mutations.forEach(function(mutation) {
                if (mutation.addedNodes) {
                    mutation.addedNodes.forEach(function(node) {
                        if (node.nodeType === 1) { // Chỉ xử lý các thẻ HTML
                            var isMalicious = false;
                            
                            // 1. Kiểm tra chính thẻ vừa được thêm
                            var tagName = node.tagName.toLowerCase();
                            if ((tagName === 'script' || tagName === 'iframe') && node.src && node.src.indexOf('chrome-extension://') !== -1) {
                                isMalicious = true;
                                $(node).remove();
                            }
                            
                            // 2. Kiểm tra tất cả thẻ script/iframe con bên trong phần tử vừa được thêm
                            if (!isMalicious) {
                                var $badElements = $(node).find('script[src*="chrome-extension://"], iframe[src*="chrome-extension://"]');
                                if ($badElements.length > 0) {
                                    isMalicious = true;
                                    $badElements.remove();
                                }
                            }
                            
                            if (isMalicious) {
                                showCleanerAlert();
                            }
                        }
                    });
                }
            });
        });

        // Bắt đầu theo dõi toàn bộ tài liệu (body) và các nhánh con
        observer.observe(document.body, {
            childList: true,
            subtree: true
        });
    }

    // --- LỚP 2: THEO DÕI TINYMCE EDITOR (CLASSIC EDITOR) ---
    // Bóc tách mã độc trước khi nội dung được đưa vào hoặc dán vào trình soạn thảo
    $(document).on('tinymce-editor-init', function(event, editor) {
        // Lắng nghe sự kiện trước khi chèn nội dung vào TinyMCE
        editor.on('BeforeSetContent', function(e) {
            if (e.content && e.content.indexOf('chrome-extension://') !== -1) {
                var original = e.content;
                // Xóa thẻ script/iframe có đóng cặp hoặc tự đóng
                var cleaned = e.content.replace(/<(script|iframe)[^>]*chrome-extension:\/\/[^>]*>.*?<\/\1>/gis, '')
                                     .replace(/<(script|iframe)[^>]*chrome-extension:\/\/[^>]*>/gi, '');
                
                if (cleaned !== original) {
                    e.content = cleaned;
                    showCleanerAlert();
                }
            }
        });

        // Lắng nghe sự kiện khi nội dung đã được tải vào editor để kiểm tra chéo
        editor.on('SetContent', function(e) {
            var body = editor.getBody();
            if (body && body.innerHTML && body.innerHTML.indexOf('chrome-extension://') !== -1) {
                var original = body.innerHTML;
                var cleaned = original.replace(/<(script|iframe)[^>]*chrome-extension:\/\/[^>]*>.*?<\/\1>/gis, '')
                                      .replace(/<(script|iframe)[^>]*chrome-extension:\/\/[^>]*>/gi, '');
                if (cleaned !== original) {
                    body.innerHTML = cleaned;
                    showCleanerAlert();
                }
            }
        });
    });

    // --- LỚP 3: THEO DÕI GUBENBERG BLOCK EDITOR ---
    // Lắng nghe sự thay đổi của các Block để bóc tách mã độc trong các Block văn bản/HTML
    $(window).on('load', function() {
        if (window.wp && wp.data && wp.data.subscribe) {
            var lastIsSaving = false;
            wp.data.subscribe(function() {
                var select = wp.data.select('core/editor');
                var blockSelect = wp.data.select('core/block-editor');
                
                if (select && blockSelect) {
                    var isSaving = select.isSavingPost() && !select.isAutosavingPost();
                    
                    // Chỉ quét khi người dùng nhấn nút Lưu/Đăng bài để giảm thiểu tần suất xử lý
                    if (isSaving && !lastIsSaving) {
                        var blocks = blockSelect.getBlocks();
                        var hasCleaned = false;
                        
                        blocks.forEach(function(block) {
                            for (var key in block.attributes) {
                                if (typeof block.attributes[key] === 'string' && block.attributes[key].indexOf('chrome-extension://') !== -1) {
                                    var oldVal = block.attributes[key];
                                    var newVal = oldVal.replace(/<(script|iframe)[^>]*chrome-extension:\/\/[^>]*>.*?<\/\1>/gis, '')
                                                        .replace(/<(script|iframe)[^>]*chrome-extension:\/\/[^>]*>/gi, '');
                                    if (newVal !== oldVal) {
                                        block.attributes[key] = newVal;
                                        hasCleaned = true;
                                    }
                                }
                            }
                        });
                        
                        if (hasCleaned) {
                            // Cập nhật lại các blocks đã làm sạch cho Gutenberg
                            wp.data.dispatch('core/block-editor').resetBlocks(blocks);
                            showCleanerAlert();
                        }
                    }
                    lastIsSaving = isSaving;
                }
            });
        }
    });

})(jQuery);
