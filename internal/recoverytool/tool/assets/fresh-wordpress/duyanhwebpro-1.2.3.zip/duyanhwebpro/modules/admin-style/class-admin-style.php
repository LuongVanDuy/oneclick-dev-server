<?php
defined( 'ABSPATH' ) || exit;

class DAWP_Admin_Style {
    public function __construct() {
        add_action( 'wp_dashboard_setup', [ $this, 'clean_dashboard' ], 999 );
        add_action( 'admin_head', [ $this, 'hide_notices' ] );
        add_action( 'admin_enqueue_scripts', [ $this, 'load_admin_css' ] );
    }

    public function clean_dashboard() {
        global $wp_meta_boxes;
        
        // Xóa sổ tất cả widget mặc định của WordPress và các Plugin bên thứ 3
        if ( isset($wp_meta_boxes['dashboard']) ) {
            unset($wp_meta_boxes['dashboard']['normal']);
            unset($wp_meta_boxes['dashboard']['side']);
            unset($wp_meta_boxes['dashboard']['advanced']);
        }
        
        // Tắt Welcome Panel mặc định của WP
        remove_action( 'welcome_panel', 'wp_welcome_panel' );
        
        // Thêm Widget App Launcher của Duy Anh Web Pro
        add_meta_box( 'dawp_app_launcher_widget', 'Trang quản trị', [ $this, 'render_app_launcher' ], 'dashboard', 'normal', 'high' );
    }

    public function render_app_launcher() {
        global $menu;
        
        // Xử lý thông tin hiển thị trên Banner
        $current_user = wp_get_current_user();
        $name = !empty($current_user->first_name) ? $current_user->first_name : $current_user->user_login;
        
        $hours = (int) current_time('H');
        $greeting = 'Chào buổi sáng';
        if ( $hours >= 12 && $hours < 18 ) $greeting = 'Chào buổi chiều';
        elseif ( $hours >= 18 ) $greeting = 'Chào buổi tối';
        
        // Thứ tiếng Việt
        $weekdays = ['Sunday' => 'Chủ Nhật', 'Monday' => 'Thứ Hai', 'Tuesday' => 'Thứ Ba', 'Wednesday' => 'Thứ Tư', 'Thursday' => 'Thứ Năm', 'Friday' => 'Thứ Sáu', 'Saturday' => 'Thứ Bảy'];
        $day_en = date_i18n('l');
        $day_vn = isset($weekdays[$day_en]) ? $weekdays[$day_en] : $day_en;
        $date_str = $day_vn . ', ' . date_i18n('d/m/Y');
        
        // 1. In Banner
        echo '<div class="dawp-banner">';
        echo '<h2>' . esc_html( $greeting ) . ', ' . esc_html( $name ) . '! 👋</h2>';
        echo '<p>Hôm nay là ' . esc_html( $date_str ) . '. Chúc bạn một ngày làm việc tràn đầy năng lượng và hiệu quả.</p>';
        echo '</div>';
        
        // 2. In Tiêu đề App Launcher
        echo '<div class="dawp-launcher-title">Truy cập nhanh (App Launcher)</div>';
        
        // 3. In Grid Các ứng dụng từ Menu
        echo '<div class="dawp-app-grid">';
        
        foreach ( $menu as $item ) {
            // Bỏ qua thẻ chia tách separator
            if ( isset($item[4]) && strpos($item[4], 'wp-menu-separator') !== false ) continue;
            if ( empty($item[0]) ) continue;
            
            // Lọc tên menu (Bỏ đi thẻ span chứa số lượng bình luận/update, loại bỏ các con số thừa)
            $title = preg_replace('/<span.*?<\/span>/', '', $item[0]);
            $title = trim( strip_tags($title) );
            $title = preg_replace('/ \d+$/', '', $title); // Xóa số đếm cuối tên (vd: Bình luận 0)
            
            if ( empty($title) ) continue;
            
            $slug = $item[2];
            $url = ( strpos($slug, '.php') !== false ) ? admin_url($slug) : admin_url('admin.php?page=' . $slug);
            
            // Xử lý Icon
            $icon_class = 'dashicons-admin-generic'; 
            if ( isset($item[6]) && strpos($item[6], 'dashicons-') !== false ) {
                $icon_class = esc_attr($item[6]);
            }
            
            // Khối HTML thẻ App Card
            echo '<a href="' . esc_url($url) . '" class="dawp-app-card">';
            echo '<div class="dawp-app-icon"><span class="dashicons ' . $icon_class . '"></span></div>';
            echo '<div class="dawp-app-title">' . esc_html($title) . '</div>';
            echo '</a>';
        }
        
        echo '</div>';
    }

    public function hide_notices() {
        // Ẩn các thông báo rác (khuyên cài plugin, quảng cáo, update) trên TOÀN BỘ trang quản trị (Siêu nhẹ)
        echo '<style>
            /* CÀN QUÉT TOÀN BỘ THÔNG BÁO RÁC NHƯNG TÔN TRỌNG NATIVE DISPLAY CỦA WORDPRESS.
               Chừa .dawp-notice: thông báo của chính plugin (kết quả kiểm tra cập nhật...)
               không được phép bị bộ lọc thông báo rác của plugin nuốt mất. */
            .notice:not(.notice-error):not(.dawp-notice):not(#setting-error-settings_updated):not(.inline),
            .updated:not(#setting-error-settings_updated),
            .update-nag, .tgmpa, .tgmpa-notice, .rs-update-notice-wrap { display: none !important; }
        </style>';

        // [TỐI ƯU HIỆU NĂNG] Google Fonts và CSS trang trí chỉ được tải khi đang ở Bảng tin (Dashboard)
        // Tránh tải font Sora chặn render làm chậm các trang quản trị khác như Soạn bài viết, Plugin, Cài đặt...
        $screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
        if ( $screen && $screen->id === 'dashboard' ) {
            // Tải phông chữ bằng thẻ link preload thay vì @import để tránh Render-Blocking làm chậm trang
            echo '<link rel="preconnect" href="https://fonts.googleapis.com">';
            echo '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>';
            echo '<link href="https://fonts.googleapis.com/css2?family=Sora:wght@400;600;700&display=swap" rel="stylesheet">';
            echo '<style>
                /* Ẩn tiêu đề, viền và thanh Header của widget */
                #dawp_app_launcher_widget.postbox { border: none !important; box-shadow: none !important; background: transparent !important; margin-bottom: 0 !important; }
                #dawp_app_launcher_widget .postbox-header, #dawp_app_launcher_widget .hndle, #dawp_app_launcher_widget .handlediv { display: none !important; }
                #dawp_app_launcher_widget .inside { padding: 0 !important; margin: 0 !important; }
                
                /* Tối đa hóa chiều rộng cho Widget của chúng ta (Bỏ chia cột WP mặc định) */
                #dashboard-widgets-wrap .postbox-container { width: 100% !important; }
                #dashboard-widgets-wrap .meta-box-sortables { min-height: 0 !important; }
                
                /* Đổi màu nền của khung WordPress admin */
                .index-php #wpcontent, .index-php #wpwrap { background-color: #f8fafc !important; }
                
                /* Thiết kế Banner */
                .dawp-banner {
                    background: linear-gradient(135deg, #1d9af2 0%, #0d63f3 100%); /* Màu xanh dương hiện đại */
                    border-radius: 16px;
                    padding: 40px;
                    color: #fff;
                    margin-bottom: 40px;
                    box-shadow: 0 10px 30px rgba(13, 99, 243, 0.25);
                    font-family: "Sora", sans-serif;
                }
                .dawp-banner h2 { color: #fff; font-size: 32px; font-weight: 700; margin: 0 0 15px 0; font-family: "Sora", sans-serif; }
                .dawp-banner p { font-size: 16px; margin: 0; opacity: 0.9; }
                
                /* Thiết kế Tiêu đề Truy cập nhanh */
                .dawp-launcher-title {
                    font-size: 18px;
                    font-weight: 600;
                    color: #333;
                    margin-bottom: 25px;
                    font-family: "Sora", sans-serif;
                    position: relative;
                    display: inline-block;
                }
                .dawp-launcher-title::after {
                    content: "";
                    position: absolute;
                    bottom: -8px;
                    left: 0;
                    width: 60%;
                    height: 3px;
                    background: #1d9af2;
                    border-radius: 3px;
                }
                
                /* CSS Grid Lưới App Card */
                .dawp-app-grid {
                    display: grid;
                    grid-template-columns: repeat(auto-fill, minmax(135px, 1fr));
                    gap: 20px;
                    padding-bottom: 30px;
                }
                
                /* Thẻ App Card nổi 3D */
                .dawp-app-card {
                    background: #fff;
                    border-radius: 16px;
                    padding: 25px 10px;
                    text-align: center;
                    text-decoration: none !important;
                    box-shadow: 0 4px 15px rgba(0,0,0,0.03);
                    transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
                    display: flex;
                    flex-direction: column;
                    align-items: center;
                    justify-content: center;
                    border: 1px solid rgba(0,0,0,0.02);
                }
                .dawp-app-card:hover {
                    transform: translateY(-5px);
                    box-shadow: 0 12px 25px rgba(29, 154, 242, 0.15);
                    border-color: rgba(29, 154, 242, 0.1);
                }
                
                /* Icon của App Card */
                .dawp-app-icon {
                    width: 56px;
                    height: 56px;
                    background: #f0f7ff;
                    border-radius: 14px;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    margin-bottom: 15px;
                    color: #1d9af2;
                    transition: all 0.3s;
                }
                .dawp-app-card:hover .dawp-app-icon {
                    background: #1d9af2;
                    color: #fff;
                }
                .dawp-app-icon .dashicons {
                    font-size: 26px;
                    width: 26px;
                    height: 26px;
                }
                
                /* Chữ Tiêu đề App */
                .dawp-app-title {
                    color: #444;
                    font-size: 14px;
                    font-weight: 600;
                    font-family: "Sora", sans-serif;
                    word-break: break-word;
                    transition: color 0.3s;
                }
                .dawp-app-card:hover .dawp-app-title {
                    color: #1d9af2;
                }
                
                /* Hiệu ứng Rắn cắn */
                @keyframes dawp-bite {
                    0% { transform: scale(1); }
                    50% { transform: scale(0.9); box-shadow: inset 0 0 10px rgba(0,0,0,0.1); }
                    100% { transform: scale(1); }
                }
                .dawp-card-bitten { animation: dawp-bite 0.4s ease-out; }
                
                /* Hiệu ứng Nổ tung */
                @keyframes dawp-explode {
                    0% { transform: scale(1); opacity: 1; filter: brightness(1); }
                    50% { transform: scale(1.2); opacity: 0.8; filter: brightness(2) hue-rotate(-50deg); box-shadow: 0 0 30px red; }
                    100% { transform: scale(1); opacity: 1; filter: brightness(1); }
                }
                .dawp-card-explode { animation: dawp-explode 0.6s ease-out; border-color: red !important; }
            </style>';
        }
    }

    public function load_admin_css() {
        $screen = get_current_screen();
        if ( $screen && $screen->id === 'dashboard' ) {
            $js_path = DAWP_DIR . 'assets/js/dawp-admin-snake.js';
            $ver = file_exists( $js_path ) ? filemtime( $js_path ) : DAWP_VERSION;
            wp_enqueue_script( 'dawp-snake-js', DAWP_URL . 'assets/js/dawp-admin-snake.js', [], $ver, true );
        }
    }
}
