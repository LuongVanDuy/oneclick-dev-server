/**
 * Giao diện Đánh giá sản phẩm thông minh - Premium WooCommerce Reviews
 * Xử lý tương tác phía Client (Vanilla JS - Zero jQuery)
 * Tích hợp nén ảnh client-side sang WebP bằng Canvas API
 */

function initDawpReviews() {
    if (window.dawpReviewsInitialized) return;
    const appContainer = document.getElementById('dawp-reviews-app');
    if (!appContainer) return;

    // Đảm bảo đối tượng ajax đã được định nghĩa (Tránh lỗi do cơ chế trì hoãn JavaScript của Pagespeed)
    if (typeof dawp_reviews_ajax === 'undefined') {
        setTimeout(initDawpReviews, 100);
        return;
    }
    window.dawpReviewsInitialized = true;

    const productId = appContainer.getAttribute('data-product-id');
    const ajaxUrl = dawp_reviews_ajax.ajax_url;
    const nonce = dawp_reviews_ajax.nonce;
    const maxImages = parseInt(dawp_reviews_ajax.max_images) || 3;

    // Trạng thái cục bộ
    let selectedImages = []; // Chứa chuỗi base64 của ảnh WebP đã nén
    let activeRatingFilter = 'all';
    let activeHasImagesFilter = 0;
    let currentReviewsPage = 1;

    // 1. Điều khiển đóng/mở Form viết đánh giá dưới dạng Popup Modal
    const btnToggleForm = document.getElementById('dawp-write-review-btn');
    const formBox = document.getElementById('dawp-review-form-box');
    const btnCloseModal = document.getElementById('dawp-modal-close-btn');

    function openReviewsModal() {
        if (formBox) {
            formBox.style.display = 'flex';
            document.body.style.overflow = 'hidden'; // Khóa cuộn trang
            loadReviewsCaptcha();
        }
    }

    function closeReviewsModal() {
        if (formBox) {
            formBox.style.display = 'none';
            document.body.style.overflow = ''; // Mở khóa cuộn trang
        }
    }

    if (btnToggleForm) {
        btnToggleForm.addEventListener('click', openReviewsModal);
    }

    if (btnCloseModal) {
        btnCloseModal.addEventListener('click', closeReviewsModal);
    }

    // Đóng khi click ngoài vùng modal content
    if (formBox) {
        formBox.addEventListener('click', function (e) {
            if (e.target === formBox) {
                closeReviewsModal();
            }
        });
    }

    // 2. Tương tác chọn số sao đánh giá (Star Rating Selector)
    const starInputContainer = document.querySelector('.dawp-rating-stars-input');
    const stars = document.querySelectorAll('.dawp-star-select');
    const ratingText = document.getElementById('dawp-rating-text');
    const ratingValueInput = document.getElementById('dawp-rating-value');

    const starDescriptions = {
        1: 'Tệ - Không hài lòng',
        2: 'Tạm ổn - Chưa hài lòng lắm',
        3: 'Bình thường - Chấp nhận được',
        4: 'Tốt - Hài lòng',
        5: 'Rất tốt - Rất hài lòng'
    };

    if (stars.length && ratingValueInput) {
        stars.forEach(star => {
            star.addEventListener('click', function () {
                const val = parseInt(this.getAttribute('data-value'));
                ratingValueInput.value = val;
                ratingText.textContent = starDescriptions[val] || '';
                ratingText.style.color = '#fbbf24';

                // Cập nhật class selected cho các sao
                stars.forEach(s => {
                    const sVal = parseInt(s.getAttribute('data-value'));
                    if (sVal <= val) {
                        s.classList.add('selected');
                    } else {
                        s.classList.remove('selected');
                    }
                });
            });

            star.addEventListener('mouseenter', function () {
                const val = parseInt(this.getAttribute('data-value'));
                ratingText.textContent = starDescriptions[val] || '';
            });
        });

        if (starInputContainer) {
            starInputContainer.addEventListener('mouseleave', function () {
                const val = parseInt(ratingValueInput.value);
                if (val > 0) {
                    ratingText.textContent = starDescriptions[val];
                } else {
                    ratingText.textContent = 'Vui lòng chọn số sao';
                    ratingText.style.color = '';
                }
            });
        }
    }

    // 3. Tải lên và nén ảnh Client-side sang WebP bằng Canvas API
    const uploadZone = document.getElementById('dawp-upload-zone');
    const fileInput = document.getElementById('dawp-file-input');
    const previewGrid = document.getElementById('dawp-preview-grid');

    if (uploadZone && fileInput && previewGrid) {
        uploadZone.addEventListener('click', function () {
            fileInput.click();
        });

        // Kéo thả file
        ['dragenter', 'dragover'].forEach(eventName => {
            uploadZone.addEventListener(eventName, function (e) {
                e.preventDefault();
                uploadZone.classList.add('dragover');
            }, false);
        });

        ['dragleave', 'drop'].forEach(eventName => {
            uploadZone.addEventListener(eventName, function (e) {
                e.preventDefault();
                uploadZone.classList.remove('dragover');
            }, false);
        });

        uploadZone.addEventListener('drop', function (e) {
            const dt = e.dataTransfer;
            const files = dt.files;
            handleSelectedFiles(files);
        }, false);

        fileInput.addEventListener('change', function () {
            handleSelectedFiles(this.files);
        });
    }

    function handleSelectedFiles(files) {
        if (!files || !files.length) return;

        const remainingSlots = maxImages - selectedImages.length;
        if (remainingSlots <= 0) {
            alert(`Bạn chỉ được đính kèm tối đa ${maxImages} hình ảnh!`);
            return;
        }

        const filesArray = Array.from(files).slice(0, remainingSlots);

        filesArray.forEach(file => {
            if (!file.type.startsWith('image/')) {
                alert('Vui lòng chỉ tải lên tệp tin hình ảnh!');
                return;
            }

            const reader = new FileReader();
            reader.readAsDataURL(file);
            reader.onload = function (event) {
                const img = new Image();
                img.src = event.target.result;
                img.onload = function () {
                    // Cấu hình kích thước tối đa cho ảnh nén
                    const maxW = 1000;
                    const maxH = 1000;
                    let width = img.width;
                    let height = img.height;

                    if (width > maxW || height > maxH) {
                        if (width > height) {
                            height = Math.round((height * maxW) / width);
                            width = maxW;
                        } else {
                            width = Math.round((width * maxH) / height);
                            height = maxH;
                        }
                    }

                    // Thực hiện nén bằng Canvas
                    const canvas = document.createElement('canvas');
                    canvas.width = width;
                    canvas.height = height;
                    const ctx = canvas.getContext('2d');
                    ctx.drawImage(img, 0, 0, width, height);

                    // Xuất ra WebP với chất lượng nén 0.8
                    const compressedBase64 = canvas.toDataURL('image/webp', 0.8);
                    
                    selectedImages.push(compressedBase64);
                    renderImagePreviews();
                };
            };
        });

        // Reset file input value để có thể chọn lại cùng 1 file
        fileInput.value = '';
    }

    function renderImagePreviews() {
        previewGrid.innerHTML = '';
        selectedImages.forEach((imgBase64, idx) => {
            const item = document.createElement('div');
            item.className = 'dawp-preview-item';
            
            const img = document.createElement('img');
            img.src = imgBase64;
            
            const removeBtn = document.createElement('button');
            removeBtn.type = 'button';
            removeBtn.className = 'remove-btn';
            removeBtn.innerHTML = '&times;';
            removeBtn.addEventListener('click', function (e) {
                e.stopPropagation(); // Ngăn kích hoạt click uploadZone
                selectedImages.splice(idx, 1);
                renderImagePreviews();
            });

            item.appendChild(img);
            item.appendChild(removeBtn);
            previewGrid.appendChild(item);
        });
    }

    // 4. Gửi form Đánh giá AJAX
    const reviewForm = document.getElementById('dawp-frontend-review-form');
    const submitBtn = document.getElementById('dawp-submit-review-btn');
    const submitSpinner = submitBtn ? submitBtn.querySelector('.dawp-spinner') : null;
    const statusMsg = document.getElementById('dawp-form-status-msg');

    // Logic nạp CAPTCHA chống spam động bypass cache cho khách vãng lai
    const captchaWrap = document.querySelector('.dawp-reviews-captcha-wrap');
    const captchaAnsInput = document.getElementById('dawp-reviews-captcha-ans');
    const captchaHashInput = document.getElementById('dawp-reviews-captcha-hash');
    const captchaQuestionSpan = document.querySelector('.dawp-reviews-captcha-question');

    let captchaLoaded = false;

    function loadReviewsCaptcha() {
        if (captchaLoaded || parseInt(dawp_reviews_ajax.is_logged_in) === 1) return;
        if (!captchaWrap) return;

        captchaLoaded = true;
        captchaWrap.style.display = 'block';

        const formData = new URLSearchParams();
        formData.append('action', 'dawp_woo_reviews_get_captcha');

        fetch(ajaxUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
            },
            body: formData.toString()
        })
        .then(res => res.json())
        .then(res => {
            if (res.success && res.data) {
                captchaQuestionSpan.textContent = res.data.question;
                captchaHashInput.value = res.data.hash;
            } else {
                captchaLoaded = false;
            }
        })
        .catch(err => {
            captchaLoaded = false;
        });
    }


    // Nạp CAPTCHA khi người dùng tương tác với bất cứ trường nhập liệu nào
    const inputFields = ['dawp-review-name', 'dawp-review-email', 'dawp-review-content'];
    inputFields.forEach(id => {
        const el = document.getElementById(id);
        if (el) {
            el.addEventListener('focus', loadReviewsCaptcha);
        }
    });

    if (reviewForm) {
        reviewForm.addEventListener('submit', function (e) {
            e.preventDefault();

            const rating = parseInt(ratingValueInput.value);
            if (!rating || rating < 1 || rating > 5) {
                showStatus('Vui lòng xếp hạng số sao đánh giá sản phẩm!', 'error');
                return;
            }

            const name = document.getElementById('dawp-review-name').value.trim();
            const email = document.getElementById('dawp-review-email').value.trim();
            const content = document.getElementById('dawp-review-content').value.trim();

            if (!name || !email || !content) {
                showStatus('Vui lòng điền đầy đủ thông tin bắt buộc!', 'error');
                return;
            }

            // Kiểm tra CAPTCHA nếu là khách vãng lai
            let captchaAns = '';
            let captchaHash = '';
            if (parseInt(dawp_reviews_ajax.is_logged_in) === 0) {
                captchaAns = captchaAnsInput ? captchaAnsInput.value.trim() : '';
                captchaHash = captchaHashInput ? captchaHashInput.value : '';
                if (!captchaAns) {
                    showStatus('Vui lòng hoàn thành phép tính bảo mật chống spam!', 'error');
                    if (captchaAnsInput) captchaAnsInput.focus();
                    return;
                }
            }

            // Thu thập các tags được chọn
            const selectedTags = [];
            document.querySelectorAll('input[name="tags[]"]:checked').forEach(cb => {
                selectedTags.push(cb.value);
            });

            // Lock submit button
            submitBtn.disabled = true;
            if (submitSpinner) submitSpinner.style.display = 'block';
            statusMsg.style.display = 'none';

            const formData = new URLSearchParams();
            formData.append('action', 'dawp_woo_reviews_submit_review');
            formData.append('nonce', nonce);
            formData.append('product_id', productId);
            formData.append('rating', rating);
            formData.append('name', name);
            formData.append('email', email);
            formData.append('content', content);
            
            // Đính kèm CAPTCHA nếu có
            if (parseInt(dawp_reviews_ajax.is_logged_in) === 0) {
                formData.append('dawp_reviews_captcha_ans', captchaAns);
                formData.append('dawp_reviews_captcha_hash', captchaHash);
            }

            // Đính kèm các tags
            selectedTags.forEach((tag, idx) => {
                formData.append(`tags[${idx}]`, tag);
            });

            // Đính kèm các ảnh đã nén
            selectedImages.forEach((imgBase64, index) => {
                formData.append(`images[${index}]`, imgBase64);
            });

            fetch(ajaxUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
                },
                body: formData.toString()
            })
            .then(res => res.json())
            .then(data => {
                submitBtn.disabled = false;
                if (submitSpinner) submitSpinner.style.display = 'none';

                if (data.success) {
                    showStatus(data.data.message, 'success');
                    reviewForm.reset();
                    selectedImages = [];
                    renderImagePreviews();
                    ratingValueInput.value = 0;
                    stars.forEach(s => s.classList.remove('selected'));
                    ratingText.textContent = 'Vui lòng chọn số sao';
                    ratingText.style.color = '';

                    // Reset CAPTCHA
                    if (captchaAnsInput) captchaAnsInput.value = '';
                    captchaLoaded = false;

                    // Uncheck các tags
                    document.querySelectorAll('input[name="tags[]"]').forEach(cb => cb.checked = false);

                    // Đóng form sau 2 giây
                    setTimeout(() => {
                        closeReviewsModal();
                        statusMsg.style.display = 'none';
                    }, 2000);

                    // Tải lại danh sách review
                    loadReviewsList(1);
                } else {
                    showStatus(data.data.message || 'Có lỗi xảy ra, vui lòng tải lại trang và thử lại.', 'error');
                    // Reset CAPTCHA để nhập phép tính mới nếu gửi lỗi
                    if (captchaAnsInput) captchaAnsInput.value = '';
                    captchaLoaded = false;
                    loadReviewsCaptcha();
                }
            })
            .catch(err => {
                submitBtn.disabled = false;
                if (submitSpinner) submitSpinner.style.display = 'none';
                showStatus('Lỗi kết nối máy chủ. Vui lòng thử lại!', 'error');
                // Reset CAPTCHA
                if (captchaAnsInput) captchaAnsInput.value = '';
                captchaLoaded = false;
                loadReviewsCaptcha();
            });
        });
    }

    function showStatus(msg, type) {
        statusMsg.textContent = msg;
        statusMsg.className = `dawp-form-message ${type}`;
        statusMsg.style.display = 'block';
    }

    // 5. Tải danh sách đánh giá AJAX & phân trang, lọc sao
    const reviewsListContainer = document.getElementById('dawp-reviews-list-container');

    function loadReviewsList(page = 1) {
        if (!reviewsListContainer) return;

        reviewsListContainer.innerHTML = '<div class="dawp-reviews-loading">Đang tải danh sách đánh giá...</div>';

        const formData = new URLSearchParams();
        formData.append('action', 'dawp_woo_reviews_get_reviews');
        formData.append('product_id', productId);
        formData.append('page', page);
        formData.append('rating', activeRatingFilter);
        formData.append('has_images', activeHasImagesFilter);

        fetch(ajaxUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
            },
            body: formData.toString()
        })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                reviewsListContainer.innerHTML = data.data.html;
                currentReviewsPage = page;
                bindPaginationEvents();
                bindLightboxEvents();
            } else {
                reviewsListContainer.innerHTML = '<div class="dawp-no-reviews">Không thể tải danh sách đánh giá. Vui lòng F5 trang!</div>';
            }
        })
        .catch(err => {
            reviewsListContainer.innerHTML = '<div class="dawp-no-reviews">Lỗi kết nối khi tải đánh giá. Vui lòng thử lại!</div>';
        });
    }

    // Khởi động load lần đầu
    loadReviewsList(1);

    // Xử lý chuyển trang pagination
    function bindPaginationEvents() {
        const pageBtns = reviewsListContainer.querySelectorAll('.dawp-page-btn');
        pageBtns.forEach(btn => {
            btn.addEventListener('click', function () {
                const page = parseInt(this.getAttribute('data-page'));
                loadReviewsList(page);
                
                // Cuộn mượt tới đầu khối review
                appContainer.scrollIntoView({ behavior: 'smooth' });
            });
        });
    }

    // 6. Xử lý các nút bộ lọc đánh giá
    const filterButtons = document.querySelectorAll('.dawp-filter-btn');
    filterButtons.forEach(btn => {
        btn.addEventListener('click', function () {
            // Gỡ bỏ active cũ
            filterButtons.forEach(b => b.classList.remove('active'));
            this.classList.add('active');

            const ratingAttr = this.getAttribute('data-rating');
            const imagesAttr = this.getAttribute('data-images');

            if (ratingAttr) {
                activeRatingFilter = ratingAttr;
                activeHasImagesFilter = 0;
            } else if (imagesAttr) {
                activeRatingFilter = 'all';
                activeHasImagesFilter = 1;
            }

            loadReviewsList(1);
        });
    });

    // 7. Lightbox xem ảnh lớn với phòng triển lãm (Gallery) trượt trái/phải
    const lightbox = document.getElementById('dawp-reviews-lightbox');
    const lightboxImg = document.getElementById('dawp-lightbox-image');
    const lightboxClose = document.querySelector('.dawp-lightbox-close');
    const lightboxPrev = document.querySelector('.dawp-lightbox-prev');
    const lightboxNext = document.querySelector('.dawp-lightbox-next');

    let galleryImages = []; // Danh sách link ảnh trong đánh giá hiện tại
    let currentGalleryIdx = 0;

    function bindLightboxEvents() {
        if (!lightbox || !lightboxImg) return;

        // Thumbs trong các review item lẻ
        const thumbs = reviewsListContainer.querySelectorAll('.dawp-review-img-thumb');
        thumbs.forEach(thumb => {
            thumb.addEventListener('click', function () {
                const parentReview = this.closest('.dawp-review-item');
                if (!parentReview) return;

                // Thu thập toàn bộ ảnh đính kèm của review cụ thể này để tạo Gallery
                const siblingThumbs = parentReview.querySelectorAll('.dawp-review-img-thumb');
                galleryImages = Array.from(siblingThumbs).map(t => t.getAttribute('data-src'));
                
                const currentSrc = this.getAttribute('data-src');
                currentGalleryIdx = galleryImages.indexOf(currentSrc);

                openLightbox(currentSrc);
            });
        });

        // Thumbs trong khối gallery tổng quan "Hình ảnh từ khách hàng"
        const galleryScroll = document.querySelector('.dawp-gallery-scroll');
        if (galleryScroll) {
            const galleryThumbs = galleryScroll.querySelectorAll('.dawp-gallery-item');
            galleryThumbs.forEach(thumb => {
                // Đảm bảo không đăng ký trùng sự kiện click
                thumb.removeAttribute('onclick'); // Xóa inline click nếu có
                
                // Clone node để dọn sạch event listeners cũ (tránh trùng lặp)
                const newThumb = thumb.cloneNode(true);
                thumb.parentNode.replaceChild(newThumb, thumb);

                newThumb.addEventListener('click', function () {
                    const siblingThumbs = galleryScroll.querySelectorAll('.dawp-gallery-item');
                    galleryImages = Array.from(siblingThumbs).map(t => t.getAttribute('data-src'));

                    const currentSrc = this.getAttribute('data-src');
                    currentGalleryIdx = galleryImages.indexOf(currentSrc);

                    openLightbox(currentSrc);
                });
            });
        }
    }

    function openLightbox(src) {
        lightboxImg.src = src;
        lightbox.style.display = 'flex';
        updateLightboxNav();
        document.body.style.overflow = 'hidden'; // Khóa cuộn trang
    }

    function closeLightbox() {
        lightbox.style.display = 'none';
        lightboxImg.src = '';
        document.body.style.overflow = '';
    }

    function updateLightboxNav() {
        if (galleryImages.length <= 1) {
            lightboxPrev.style.display = 'none';
            lightboxNext.style.display = 'none';
        } else {
            lightboxPrev.style.display = 'block';
            lightboxNext.style.display = 'block';
        }
    }

    function navigateGallery(direction) {
        if (galleryImages.length <= 1) return;

        currentGalleryIdx += direction;
        if (currentGalleryIdx < 0) {
            currentGalleryIdx = galleryImages.length - 1;
        } else if (currentGalleryIdx >= galleryImages.length) {
            currentGalleryIdx = 0;
        }

        lightboxImg.src = galleryImages[currentGalleryIdx];
    }

    if (lightboxClose) {
        lightboxClose.addEventListener('click', closeLightbox);
    }

    if (lightbox) {
        // Click ra ngoài ảnh để đóng
        lightbox.addEventListener('click', function (e) {
            if (e.target === lightbox || e.target.classList.contains('dawp-lightbox-content-wrap')) {
                closeLightbox();
            }
        });
    }

    if (lightboxPrev) {
        lightboxPrev.addEventListener('click', function (e) {
            e.stopPropagation();
            navigateGallery(-1);
        });
    }

    if (lightboxNext) {
        lightboxNext.addEventListener('click', function (e) {
            e.stopPropagation();
            navigateGallery(1);
        });
    }

    // Đóng và điều hướng Lightbox bằng bàn phím
    document.addEventListener('keydown', function (e) {
        if (lightbox && lightbox.style.display === 'flex') {
            if (e.key === 'Escape') {
                closeLightbox();
            } else if (e.key === 'ArrowLeft') {
                navigateGallery(-1);
            } else if (e.key === 'ArrowRight') {
                navigateGallery(1);
            }
        }
    });
}

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initDawpReviews);
} else {
    initDawpReviews();
}
