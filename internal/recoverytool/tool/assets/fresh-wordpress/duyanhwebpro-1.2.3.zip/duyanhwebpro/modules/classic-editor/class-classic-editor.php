<?php
defined( 'ABSPATH' ) || exit;
 
class DAWP_Classic_Editor {
    public function __construct() {
        // Tắt Gutenberg Editor cho Post/Page
        add_filter( 'use_block_editor_for_post', '__return_false', 10 );
        add_filter( 'use_block_editor_for_post_type', '__return_false', 10 );

        // Tắt Gutenberg Widgets
        add_filter( 'use_widgets_block_editor', '__return_false' );
        
        // ================= KÍCH HOẠT FULL CÔNG CỤ TINYMCE ================= //
        // 1. Luôn mở rộng dòng 2 (Kitchen Sink) và áp dụng cấu hình nâng cao (Ưu tiên cao nhất)
        add_filter( 'tiny_mce_before_init', [ $this, 'always_show_kitchen_sink' ], 9999 );
        // 2. Sắp xếp lại hàng 1, 2, 3, 4 (Ưu tiên cao nhất)
        add_filter( 'mce_buttons', [ $this, 'extended_mce_buttons_1' ], 9999 );
        add_filter( 'mce_buttons_2', [ $this, 'extended_mce_buttons_2' ], 9999 );
        add_filter( 'mce_buttons_3', [ $this, 'extended_mce_buttons_3' ], 9999 );
        add_filter( 'mce_buttons_4', [ $this, 'extended_mce_buttons_4' ], 9999 );
        // 3. Tích hợp các plugin Table, Line Height và CDN plugins (Ưu tiên cao nhất)
        add_filter( 'mce_external_plugins', [ $this, 'add_tinymce_plugins' ], 9999 );
    }

    public function always_show_kitchen_sink( $args ) {
        $args['wordpress_adv_hidden'] = false; // Tự động bung dòng 2
        
        // Kích hoạt Menubar đầy đủ để có menu Table và các tùy chọn khác
        $args['menubar'] = 'edit insert view format table tools';
        
        // Tăng chiều cao trình soạn thảo mặc định lên 550px cho rộng rãi
        $args['height'] = 550;
        
        // Bật thanh trạng thái ở dưới (đếm từ, hiển thị thẻ html)
        $args['statusbar'] = true;
        
        // Cấu hình kéo bảng và các tính năng bảng nâng cao
        $args['table_responsive_width'] = true;
        $args['table_appearance_options'] = true;
        $args['table_grid'] = true; // Bật bảng lưới (grid) chọn dòng/cột trực quan
        $args['table_advtab'] = true;
        $args['table_cell_advtab'] = true;
        $args['table_row_advtab'] = true;
        $args['table_toolbar'] = 'tableproperties | tablerowsettings tableinsertrowbefore tableinsertrowafter tabledeleterow | tablecolsettings tableinsertcolbefore tableinsertcolafter tabledeletecol';

        // Đặt kiểu dáng mặc định của bảng khi tạo để hiển thị rõ ràng, đẹp đẽ ngay lập tức
        $args['table_default_attributes'] = json_encode([
            'border'      => '1',
            'cellpadding' => '8',
            'cellspacing' => '0',
            'style'       => 'border-collapse: collapse; width: 100%; border: 1px solid #ddd;'
        ]);

        // Cung cấp danh sách Class tạo bảng nhanh để áp dụng CSS đẹp
        $args['table_class_list'] = json_encode([
            ['title' => 'Mặc định (Default)', 'value' => 'table-default'],
            ['title' => 'Kẻ sọc ngang (Striped)', 'value' => 'table-striped'],
            ['title' => 'Viền mỏng (Bordered)', 'value' => 'table-bordered'],
            ['title' => 'Không viền (Borderless)', 'value' => 'table-borderless']
        ]);

        // Thiết kế các định dạng đặc biệt (Style Formats) cho dropdown "Định dạng" (styleselect)
        $style_formats = [
            [
                'title' => 'Định dạng Chữ (Inline)',
                'items' => [
                    ['title' => 'Nổi bật đỏ', 'inline' => 'span', 'styles' => ['color' => '#d63638', 'font-weight' => 'bold']],
                    ['title' => 'Nổi bật xanh', 'inline' => 'span', 'styles' => ['color' => '#0068ff', 'font-weight' => 'bold']],
                    ['title' => 'Chữ nhỏ (Small)', 'inline' => 'small'],
                    ['title' => 'Đánh dấu (Highlight)', 'inline' => 'mark']
                ]
            ],
            [
                'title' => 'Hộp Thông Tin (Boxes)',
                'items' => [
                    ['title' => 'Hộp thông báo (Info)', 'block' => 'div', 'styles' => ['background' => '#e3f2fd', 'border-left' => '4px solid #2196f3', 'padding' => '15px', 'margin' => '15px 0']],
                    ['title' => 'Hộp cảnh báo (Warning)', 'block' => 'div', 'styles' => ['background' => '#fff3e0', 'border-left' => '4px solid #ff9800', 'padding' => '15px', 'margin' => '15px 0']],
                    ['title' => 'Hộp thành công (Success)', 'block' => 'div', 'styles' => ['background' => '#e8f5e9', 'border-left' => '4px solid #4caf50', 'padding' => '15px', 'margin' => '15px 0']],
                    ['title' => 'Hộp lỗi (Danger)', 'block' => 'div', 'styles' => ['background' => '#ffebee', 'border-left' => '4px solid #f44336', 'padding' => '15px', 'margin' => '15px 0']]
                ]
            ],
            [
                'title' => 'Nút Bấm (Buttons)',
                'items' => [
                    ['title' => 'Nút liên hệ xanh', 'selector' => 'a', 'styles' => ['background' => '#0068ff', 'color' => '#fff', 'padding' => '10px 20px', 'text-decoration' => 'none', 'border-radius' => '5px', 'display' => 'inline-block']],
                    ['title' => 'Nút liên hệ đỏ', 'selector' => 'a', 'styles' => ['background' => '#d63638', 'color' => '#fff', 'padding' => '10px 20px', 'text-decoration' => 'none', 'border-radius' => '5px', 'display' => 'inline-block']]
                ]
            ]
        ];
        $args['style_formats'] = json_encode( $style_formats );

        // Cấu hình cỡ chữ chi tiết
        $args['fontsize_formats'] = '8px 9px 10px 11px 12px 13px 14px 15px 16px 17px 18px 20px 24px 28px 32px 36px 40px 48px 56px 72px';
        
        // Cấu hình phông chữ phong phú
        $args['font_formats'] = 'Arial=arial,helvetica,sans-serif;Arial Black=arial black,avant garde;Book Antiqua=book antiqua,palatino;Comic Sans MS=comic sans ms,sans-serif;Courier New=courier new,courier;Georgia=georgia,palatino;Helvetica=helvetica;Impact=impact,chicago;Symbol=symbol;Tahoma=tahoma,arial,helvetica,sans-serif;Terminal=terminal,monaco;Times New Roman=times new roman,times;Trebuchet MS=trebuchet ms,geneva;Verdana=verdana,geneva;Webdings=webdings;Wingdings=wingdings,zapf dingbats;Roboto=roboto,sans-serif;Inter=inter,sans-serif;SVN-Arial=svn-arial;SVN-Times New Roman=svn-times new roman';

        return $args;
    }

    public function extended_mce_buttons_1( $buttons ) {
        // Hàng 1: Font chữ, Cỡ chữ, Dãn dòng (Line Height), Định dạng nâng cao, Định dạng khối, Đậm, Nghiêng, Gạch chân, Gạch ngang, Chỉ số trên, Chỉ số dưới, Xóa định dạng
        return [
            'fontselect', 'fontsizeselect', 'lineheightselect', 'styleselect', 'formatselect', 
            'bold', 'italic', 'underline', 'strikethrough', 'superscript', 'subscript', 'removeformat'
        ];
    }

    public function extended_mce_buttons_2( $buttons ) {
        // Hàng 2: Màu chữ, Màu nền, Căn lề trái/giữa/phải/đều, Bullet, Number, Thụt lề, Blockquote, Đường kẻ, Ký tự đặc biệt, Chèn ngày giờ, Khoảng trắng cứng
        return [
            'forecolor', 'backcolor', 'alignleft', 'aligncenter', 'alignright', 'alignjustify', 
            'bullist', 'numlist', 'outdent', 'indent', 'blockquote', 'hr', 'charmap', 'insertdatetime', 'nonbreaking'
        ];
    }

    public function extended_mce_buttons_3( $buttons ) {
        // Hàng 3: Thêm/Hủy liên kết, Neo, Thêm ảnh, Thêm media, Bảng (Table), Undo, Redo, Tìm & Thay thế, Mã HTML, Khung khối, Ký tự ẩn, Toàn màn hình
        return [
            'link', 'unlink', 'anchor', 'image', 'media', 'table', 'undo', 'redo', 
            'searchreplace', 'code', 'visualblocks', 'visualchars', 'fullscreen'
        ];
    }

    public function extended_mce_buttons_4( $buttons ) {
        // Hàng 4: Cắt, Sao chép, Dán, Dán dạng văn bản, In ấn, Xem trước, Ngắt trang, Đọc tiếp, Thẻ trang mới, Viết từ trái sang, Viết từ phải sang, Trợ giúp
        return [
            'cut', 'copy', 'paste', 'pastetext', 'print', 'preview', 'pagebreak', 'wp_more', 'wp_page', 'ltr', 'rtl', 'wp_help'
        ];
    }

    public function add_tinymce_plugins( $plugins ) {
        // Plugin nội bộ
        $plugins['table'] = DAWP_URL . 'assets/js/table/plugin.min.js';
        $plugins['lineheight'] = DAWP_URL . 'assets/js/tinymce-lineheight.min.js';
        
        // Plugin soạn thảo nâng cao tự lưu trữ (self-host) trong plugin — không nạp
        // JS từ CDN ngoài vào ngữ cảnh admin để tránh rủi ro supply-chain
        foreach ( [ 'searchreplace', 'visualblocks', 'visualchars', 'nonbreaking', 'pagebreak', 'print', 'preview' ] as $mce_plugin ) {
            $plugins[ $mce_plugin ] = DAWP_URL . 'assets/js/tinymce/' . $mce_plugin . '.min.js';
        }
        
        return $plugins;
    }
}
