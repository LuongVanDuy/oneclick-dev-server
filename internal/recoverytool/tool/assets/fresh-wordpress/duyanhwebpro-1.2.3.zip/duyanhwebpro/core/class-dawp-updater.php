<?php
defined( 'ABSPATH' ) || exit;

/**
 * Bộ cập nhật từ xa của Duy Anh Web Pro.
 *
 * Kênh cập nhật là một tệp JSON tĩnh đặt trên máy chủ riêng
 * (mặc định: https://update.duyanhweb.com.vn/duyanhwebpro/info.json).
 *
 * Cấu trúc JSON tối thiểu:
 *   {
 *     "name": "Duy Anh Web Pro",
 *     "slug": "duyanhwebpro",
 *     "version": "4.25.21",
 *     "requires": "6.0",
 *     "tested": "6.9",
 *     "requires_php": "7.4",
 *     "last_updated": "2026-08-15 10:00:00",
 *     "url": "https://duyanhweb.com.vn/",
 *     "download_url": "https://update.duyanhweb.com.vn/duyanhwebpro/duyanhwebpro-4.25.21.zip",
 *     "checksum_sha256": "<64 ký tự hex của gói .zip>",
 *     "sections": { "description": "...", "changelog": "..." }
 *   }
 *
 * Ba lớp bảo vệ trước khi một gói được cài lên site khách:
 *   1. Bắt buộc xác thực chứng chỉ SSL khi tải JSON (chống MITM).
 *   2. download_url bắt buộc dùng HTTPS và cùng host với máy chủ cập nhật
 *      (JSON bị can thiệp cũng không thể trỏ gói tải sang máy chủ lạ).
 *   3. Bắt buộc đối chiếu SHA256 của gói .zip trước khi cho WordPress cài.
 */
class DAWP_Updater {
    /**
     * @var string Slug của plugin (tên thư mục trong wp-content/plugins)
     */
    private $plugin_slug;

    /**
     * @var string Đường dẫn chính của plugin (tương đối so với wp-content/plugins/)
     */
    private $plugin_path;

    /**
     * @var string URL tệp tin cấu hình JSON cập nhật từ xa
     */
    private $update_url;

    /**
     * @var bool Ép bỏ qua mọi lớp cache khi quản trị viên bấm "Kiểm tra cập nhật"
     */
    private $force_refresh = false;

    /**
     * @var string Khóa transient lưu thông tin phiên bản từ xa.
     *
     * Đổi hậu tố _v2 khi chuyển sang máy chủ update.duyanhweb.com.vn để site vừa
     * nâng cấp không phải chờ hết 24 giờ cache của máy chủ cũ mới hỏi máy chủ mới.
     */
    const CACHE_KEY = 'dawp_update_info_v2';

    /**
     * Khởi tạo các hook lọc cập nhật của WordPress
     */
    public function __construct() {
        $this->plugin_path = plugin_basename( DAWP_FILE );

        // Trích xuất thư mục gốc của plugin trong thư mục plugins
        $path_parts        = explode( '/', $this->plugin_path );
        $this->plugin_slug = ! empty( $path_parts[0] ) ? $path_parts[0] : 'duyanhwebpro';

        $this->update_url  = defined( 'DAWP_UPDATE_URL' ) ? DAWP_UPDATE_URL : '';

        // Site phát triển gốc (khai báo DAWP_DISABLE_UPDATE trong wp-config.php):
        // không kiểm tra, không thông báo, và dọn sạch thông báo tồn đọng nếu có.
        if ( $this->is_update_disabled() ) {
            add_action( 'admin_init', [ $this, 'purge_update_notice' ] );
            return;
        }

        if ( empty( $this->update_url ) ) {
            return;
        }

        // Móc vào bộ lọc transient kiểm tra cập nhật của WordPress
        add_filter( 'pre_set_site_transient_update_plugins', [ $this, 'check_update' ] );

        // Móc vào bộ lọc hiển thị popup thông tin chi tiết bản nâng cấp
        add_filter( 'plugins_api', [ $this, 'get_plugin_info' ], 20, 3 );

        // Tự động xóa cache cập nhật của plugin khi admin bấm "Kiểm tra lại" (Clear WordPress Cache)
        add_action( 'delete_site_transient_update_plugins', [ $this, 'clear_update_cache' ] );

        // Dọn cache sau khi nâng cấp xong để không hiển thị lại thông báo đã cũ
        add_action( 'upgrader_process_complete', [ $this, 'clear_cache_after_upgrade' ], 10, 2 );

        // Thêm liên kết "Kiểm tra cập nhật" trong danh sách plugin
        add_filter( 'plugin_action_links_' . $this->plugin_path, [ $this, 'add_action_links' ] );

        // Xử lý khi bấm nút kiểm tra cập nhật thủ công
        add_action( 'admin_init', [ $this, 'handle_manual_check' ] );

        // Hiển thị thông báo kết quả kiểm tra cập nhật
        add_action( 'admin_notices', [ $this, 'display_check_notice' ] );

        // Tự động chuyển hướng về trang plugin sau khi nâng cấp thành công trên trang update.php
        add_action( 'admin_footer', [ $this, 'maybe_redirect_after_update' ] );

        // Xác minh SHA256 gói cập nhật trước khi cài
        add_filter( 'upgrader_pre_download', [ $this, 'verify_download_package' ], 10, 3 );
    }

    /**
     * Kênh cập nhật có đang bị tắt hay không.
     *
     * Bật lại bằng cách gỡ hằng số trong wp-config.php:
     *   define( 'DAWP_DISABLE_UPDATE', true );
     */
    public function is_update_disabled() {
        if ( defined( 'DAWP_DISABLE_UPDATE' ) && DAWP_DISABLE_UPDATE ) {
            return true;
        }
        return (bool) apply_filters( 'dawp_disable_update', false );
    }

    /**
     * Gỡ plugin khỏi danh sách cập nhật của WordPress trên site đã tắt kênh cập nhật,
     * tránh trường hợp thông báo cũ còn nằm lại trong transient.
     */
    public function purge_update_notice() {
        delete_site_transient( self::CACHE_KEY );

        $transient = get_site_transient( 'update_plugins' );
        if ( is_object( $transient ) && isset( $transient->response ) && is_array( $transient->response ) && isset( $transient->response[ $this->plugin_path ] ) ) {
            unset( $transient->response[ $this->plugin_path ] );
            set_site_transient( 'update_plugins', $transient );
        }
    }

    /**
     * Chỉ chấp nhận URL gói cập nhật dùng HTTPS và cùng host với máy chủ cập nhật,
     * chặn trường hợp JSON bị can thiệp trỏ gói tải sang máy chủ lạ.
     */
    private function is_trusted_package_url( $url ) {
        $package_host = wp_parse_url( $url, PHP_URL_HOST );
        $update_host  = wp_parse_url( $this->update_url, PHP_URL_HOST );
        return 'https' === wp_parse_url( $url, PHP_URL_SCHEME )
            && ! empty( $package_host )
            && ! empty( $update_host )
            && strtolower( $package_host ) === strtolower( $update_host );
    }

    /**
     * Dữ liệu JSON từ xa có đủ và hợp lệ để dùng hay không.
     */
    private function is_valid_remote_info( $info ) {
        if ( ! is_array( $info ) || empty( $info['version'] ) || empty( $info['download_url'] ) ) {
            return false;
        }
        // Chuỗi phiên bản phải sạch, tránh dữ liệu rác lọt vào version_compare
        if ( ! preg_match( '/^[0-9][0-9a-zA-Z.\-+]{0,31}$/', (string) $info['version'] ) ) {
            return false;
        }
        return $this->is_trusted_package_url( $info['download_url'] );
    }

    /**
     * Bắt buộc đối chiếu SHA256 của gói .zip trước khi cho WordPress cài đặt.
     * Thiếu checksum hoặc hash lệch đều hủy cài để chống gói bị tráo.
     */
    public function verify_download_package( $reply, $package, $upgrader ) {
        if ( false !== $reply ) {
            return $reply;
        }

        $remote_info = get_site_transient( self::CACHE_KEY );
        if ( ! is_array( $remote_info ) || empty( $remote_info['download_url'] ) || $package !== $remote_info['download_url'] ) {
            return $reply;
        }

        $checksum = isset( $remote_info['checksum_sha256'] ) ? strtolower( trim( $remote_info['checksum_sha256'] ) ) : '';
        if ( ! preg_match( '/^[a-f0-9]{64}$/', $checksum ) ) {
            return new WP_Error(
                'dawp_checksum_missing',
                'Máy chủ cập nhật không công bố mã kiểm tra SHA256 cho gói này — đã hủy cài đặt để bảo vệ website. Vui lòng liên hệ Duy Anh Web.'
            );
        }

        if ( ! function_exists( 'download_url' ) ) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
        }

        $file = download_url( $package, 300 );
        if ( is_wp_error( $file ) ) {
            return $file;
        }

        if ( ! hash_equals( $checksum, (string) hash_file( 'sha256', $file ) ) ) {
            @unlink( $file );
            return new WP_Error(
                'dawp_checksum_mismatch',
                'Gói cập nhật Duy Anh Web Pro không khớp mã kiểm tra SHA256 công bố — đã hủy cài đặt để bảo vệ website.'
            );
        }

        return $file;
    }

    /**
     * Thêm liên kết "Kiểm tra cập nhật" vào danh sách plugin
     */
    public function add_action_links( $links ) {
        $check_url = wp_nonce_url( admin_url( 'plugins.php?dawp_check_update=1' ), 'dawp_check_update_action' );
        $links['check_update'] = '<a href="' . esc_url( $check_url ) . '" style="color: #0068ff; font-weight: bold;">Kiểm tra cập nhật</a>';
        return $links;
    }

    /**
     * Xử lý hành động kiểm tra cập nhật thủ công
     */
    public function handle_manual_check() {
        if ( ! isset( $_GET['dawp_check_update'] ) || $_GET['dawp_check_update'] != '1' ) {
            return;
        }

        if ( ! current_user_can( 'manage_options' ) || ! isset( $_GET['_wpnonce'] ) || ! wp_verify_nonce( $_GET['_wpnonce'], 'dawp_check_update_action' ) ) {
            return;
        }

        // Bỏ qua cả cache cục bộ lẫn cache biên (CDN) cho đúng một lần gọi này
        $this->force_refresh = true;
        $this->clear_update_cache();

        // Gọi thẳng máy chủ cập nhật TRƯỚC. Không được phụ thuộc vào wp_update_plugins():
        // hàm đó hỏi api.wordpress.org trước, và nếu không kết nối được thì nó thoát
        // giữa chừng, không ghi transient — kéo theo bộ lọc của plugin không bao giờ
        // chạy, nút "Kiểm tra cập nhật" bấm mãi mà im lìm.
        $remote_info = $this->fetch_remote_info();
        $this->force_refresh = false; // đã có dữ liệu mới, các lần gọi sau dùng cache vừa lưu

        // Xóa cache transient cập nhật của WordPress để ép kiểm tra lại
        delete_site_transient( 'update_plugins' );
        wp_clean_plugins_cache();

        // Gọi WordPress kiểm tra lại cập nhật ngay lập tức
        wp_update_plugins();

        // Dự phòng: WordPress bỏ cuộc giữa chừng thì tự dựng lấy dữ liệu cập nhật
        // để bản mới vẫn hiện ra trong danh sách plugin.
        if ( $remote_info ) {
            $transient = get_site_transient( 'update_plugins' );
            if ( ! is_object( $transient ) ) {
                $transient = new stdClass();
            }
            if ( empty( $transient->response ) || ! isset( $transient->response[ $this->plugin_path ] ) ) {
                if ( empty( $transient->checked ) ) {
                    $transient->checked = [ $this->plugin_path => DAWP_VERSION ];
                }
                $transient->last_checked = time();
                set_site_transient( 'update_plugins', $this->check_update( $transient ) );
            }
        }

        // Điều hướng quay lại trang trước đó
        $referer = wp_get_referer();
        if ( ! $referer || false !== strpos( $referer, 'dawp_check_update' ) ) {
            $redirect_url = admin_url( 'plugins.php' );
        } else {
            $redirect_url = remove_query_arg( [ 'dawp_update_checked', 'purged' ], $referer );
        }
        $redirect_url = add_query_arg( 'dawp_update_checked', '1', $redirect_url );

        wp_redirect( $redirect_url );
        exit;
    }

    /**
     * Hiển thị thông báo kết quả kiểm tra cập nhật ngoài giao diện Admin
     */
    public function display_check_notice() {
        if ( ! isset( $_GET['dawp_update_checked'] ) || $_GET['dawp_update_checked'] != '1' ) {
            return;
        }

        $update_plugins = get_site_transient( 'update_plugins' );
        $has_update = ( is_object( $update_plugins ) && isset( $update_plugins->response ) && is_array( $update_plugins->response ) && isset( $update_plugins->response[ $this->plugin_path ] ) );

        // Lớp dawp-notice bắt buộc phải có: bộ lọc thông báo rác của module Giao diện
        // quản trị ẩn mọi .notice không phải notice-error, kể cả thông báo của plugin.
        if ( $has_update ) {
            $new_ver = $update_plugins->response[ $this->plugin_path ]->new_version;
            echo '<div class="notice notice-warning dawp-notice is-dismissible" style="border-left-color: #0068ff;">';
            echo '<p><strong>Duy Anh Web Pro:</strong> Đã phát hiện phiên bản mới <strong>' . esc_html( $new_ver ) . '</strong>! Vui lòng thực hiện cập nhật ngay dưới đây.</p>';
            echo '</div>';
            return;
        }

        // Không có bản mới: phân biệt "đã mới nhất" với "không kết nối được máy chủ cập nhật"
        $cached = get_site_transient( self::CACHE_KEY );
        if ( ! is_array( $cached ) ) {
            echo '<div class="notice notice-error dawp-notice is-dismissible">';
            echo '<p><strong>Duy Anh Web Pro:</strong> Không kết nối được máy chủ cập nhật (' . esc_html( wp_parse_url( $this->update_url, PHP_URL_HOST ) ) . '). Hệ thống sẽ tự thử lại sau, website của bạn vẫn hoạt động bình thường.</p>';
            echo '</div>';
            return;
        }

        $ban_tren_may_chu = isset( $cached['version'] ) ? $cached['version'] : DAWP_VERSION;

        echo '<div class="notice notice-success dawp-notice is-dismissible" style="border-left-color: #4caf50;">';
        echo '<p><strong>Duy Anh Web Pro:</strong> Đã kiểm tra xong — <strong>chưa có bản cập nhật mới</strong>. Bạn đang dùng phiên bản <strong>' . esc_html( DAWP_VERSION ) . '</strong>, đây cũng là bản mới nhất trên máy chủ (' . esc_html( $ban_tren_may_chu ) . ').</p>';
        echo '</div>';
    }

    /**
     * Gọi máy chủ cập nhật lấy thông tin phiên bản mới (có cache transient 24 giờ)
     *
     * @return array|null Mảng thông tin cập nhật hoặc null nếu lỗi
     */
    private function fetch_remote_info() {
        if ( ! $this->force_refresh ) {
            $cached_info = get_site_transient( self::CACHE_KEY );
            if ( false !== $cached_info ) {
                return $cached_info;
            }
        }

        // Cache-buster theo giờ: vẫn cho CDN lưu đệm trong 1 tiếng nhưng không để
        // gói cũ kẹt lại nhiều ngày. Khi bấm "Kiểm tra cập nhật" thì phá cache tuyệt đối.
        $bucket = $this->force_refresh ? time() : (int) floor( time() / HOUR_IN_SECONDS );

        // Khai báo website cho máy chủ cập nhật: không có mã kích hoạt, không chặn
        // ai — chỉ để biết plugin đang chạy ở đâu, bản nào, phục vụ hỗ trợ kỹ thuật.
        $request_url = add_query_arg( [
            't'    => $bucket,
            'site' => rawurlencode( home_url( '/' ) ),
            'v'    => rawurlencode( DAWP_VERSION ),
            'wp'   => rawurlencode( get_bloginfo( 'version' ) ),
            'php'  => rawurlencode( PHP_VERSION ),
        ], $this->update_url );

        $response = wp_remote_get( $request_url, [
            'timeout'   => 15,
            // Bắt buộc xác thực chứng chỉ SSL: kênh cập nhật không xác minh là cửa ngõ MITM
            // cài mã tùy ý lên mọi site client. Môi trường test đặc biệt có thể tắt qua filter.
            'sslverify' => apply_filters( 'dawp_updater_sslverify', true ),
            'headers'   => [
                'Accept'        => 'application/json',
                'Cache-Control' => 'no-cache',
            ],
            'user-agent' => 'DAWP-Updater/' . DAWP_VERSION . '; ' . home_url( '/' ),
        ] );

        if ( is_wp_error( $response ) || wp_remote_retrieve_response_code( $response ) !== 200 ) {
            // Nếu lỗi kết nối, cache tạm 2 giờ để tránh spam truy vấn khi máy chủ sập hoặc ngắt kết nối
            set_site_transient( self::CACHE_KEY, null, 2 * HOUR_IN_SECONDS );
            return null;
        }

        $data = json_decode( wp_remote_retrieve_body( $response ), true );

        if ( ! $this->is_valid_remote_info( $data ) ) {
            set_site_transient( self::CACHE_KEY, null, 2 * HOUR_IN_SECONDS );
            return null;
        }

        // Lưu bộ đệm thành công trong 24 giờ
        set_site_transient( self::CACHE_KEY, $data, DAY_IN_SECONDS );

        return $data;
    }

    /**
     * Chuẩn hóa mảng ảnh icon / banner công bố trong JSON
     */
    private function sanitize_image_set( $images ) {
        if ( ! is_array( $images ) ) {
            return [];
        }
        $clean = [];
        foreach ( $images as $key => $url ) {
            $key = sanitize_key( $key );
            $url = esc_url_raw( (string) $url );
            if ( $key && $url ) {
                $clean[ $key ] = $url;
            }
        }
        return $clean;
    }

    /**
     * Can thiệp transient cập nhật của WordPress để thêm bản cập nhật mới
     *
     * @param object $transient Transient chứa danh sách cập nhật của WP
     * @return object
     */
    public function check_update( $transient ) {
        if ( ! is_object( $transient ) || empty( $transient->checked ) ) {
            return $transient;
        }

        $remote_info = $this->fetch_remote_info();
        if ( ! $remote_info ) {
            return $transient;
        }

        // Lấy phiên bản hiện tại
        $current_version = isset( $transient->checked[ $this->plugin_path ] ) ? $transient->checked[ $this->plugin_path ] : DAWP_VERSION;

        // So sánh phiên bản. Nếu bản từ xa cao hơn bản hiện tại, thêm vào danh sách phản hồi
        if ( version_compare( $current_version, $remote_info['version'], '<' ) ) {
            $obj = new stdClass();
            $obj->slug         = $this->plugin_slug;
            $obj->plugin       = $this->plugin_path;
            $obj->new_version  = sanitize_text_field( $remote_info['version'] );
            $obj->url          = esc_url( isset( $remote_info['url'] ) ? $remote_info['url'] : 'https://duyanhweb.com.vn/' );
            $obj->package      = esc_url_raw( $remote_info['download_url'] );

            if ( ! empty( $remote_info['tested'] ) ) {
                $obj->tested   = sanitize_text_field( $remote_info['tested'] );
            }
            if ( ! empty( $remote_info['requires'] ) ) {
                $obj->requires = sanitize_text_field( $remote_info['requires'] );
            }
            if ( ! empty( $remote_info['requires_php'] ) ) {
                $obj->requires_php = sanitize_text_field( $remote_info['requires_php'] );
            }

            $icons = $this->sanitize_image_set( isset( $remote_info['icons'] ) ? $remote_info['icons'] : [] );
            if ( ! empty( $icons ) ) {
                $obj->icons = $icons;
            }
            $banners = $this->sanitize_image_set( isset( $remote_info['banners'] ) ? $remote_info['banners'] : [] );
            if ( ! empty( $banners ) ) {
                $obj->banners = $banners;
            }

            if ( ! isset( $transient->response ) || ! is_array( $transient->response ) ) {
                $transient->response = [];
            }
            $transient->response[ $this->plugin_path ] = $obj;
        }

        return $transient;
    }

    /**
     * Trả về thông tin chi tiết của plugin hiển thị trong modal popup xem thay đổi
     *
     * @param object|false $result
     * @param string $action
     * @param object $args
     * @return object|false
     */
    public function get_plugin_info( $result, $action, $args ) {
        if ( 'plugin_information' !== $action ) {
            return $result;
        }

        if ( empty( $args->slug ) || $args->slug !== $this->plugin_slug ) {
            return $result;
        }

        $remote_info = $this->fetch_remote_info();
        if ( ! $remote_info ) {
            return $result;
        }

        $res = new stdClass();
        $res->name           = sanitize_text_field( isset( $remote_info['name'] ) ? $remote_info['name'] : 'Duy Anh Web Pro' );
        $res->slug           = $this->plugin_slug;
        $res->version        = sanitize_text_field( $remote_info['version'] );
        $res->tested         = sanitize_text_field( isset( $remote_info['tested'] ) ? $remote_info['tested'] : '' );
        $res->requires       = sanitize_text_field( isset( $remote_info['requires'] ) ? $remote_info['requires'] : '' );
        $res->requires_php   = sanitize_text_field( isset( $remote_info['requires_php'] ) ? $remote_info['requires_php'] : '' );
        $res->last_updated   = sanitize_text_field( isset( $remote_info['last_updated'] ) ? $remote_info['last_updated'] : '' );
        $res->author         = '<a href="https://duyanhweb.com.vn/" target="_blank">Duy Anh Web</a>';
        $res->download_link  = esc_url( $remote_info['download_url'] );
        $res->homepage       = esc_url( isset( $remote_info['url'] ) ? $remote_info['url'] : 'https://duyanhweb.com.vn/' );

        $icons = $this->sanitize_image_set( isset( $remote_info['icons'] ) ? $remote_info['icons'] : [] );
        if ( ! empty( $icons ) ) {
            $res->icons = $icons;
        }
        $banners = $this->sanitize_image_set( isset( $remote_info['banners'] ) ? $remote_info['banners'] : [] );
        if ( ! empty( $banners ) ) {
            $res->banners = $banners;
        }

        // Nạp cấu trúc các tab hiển thị popup (Mô tả, Changelog)
        $res->sections = [];
        if ( isset( $remote_info['sections'] ) && is_array( $remote_info['sections'] ) ) {
            foreach ( $remote_info['sections'] as $key => $content ) {
                $res->sections[ sanitize_key( $key ) ] = wp_kses_post( $content );
            }
        }
        if ( empty( $res->sections['description'] ) ) {
            $res->sections['description'] = 'Bộ giải pháp tối ưu hóa hiệu năng, tăng tốc độ tải trang thực tế vượt trội và bảo mật toàn diện tối thượng dành riêng cho WordPress.';
        }

        return $res;
    }

    /**
     * Dọn dẹp cache cục bộ khi quản trị viên click nút làm mới danh sách update của WP
     */
    public function clear_update_cache() {
        delete_site_transient( self::CACHE_KEY );
    }

    /**
     * Dọn cache sau khi WordPress nâng cấp xong chính plugin này
     */
    public function clear_cache_after_upgrade( $upgrader, $options ) {
        if ( ! is_array( $options ) || 'update' !== ( isset( $options['action'] ) ? $options['action'] : '' ) ) {
            return;
        }
        if ( 'plugin' !== ( isset( $options['type'] ) ? $options['type'] : '' ) ) {
            return;
        }
        $plugins = isset( $options['plugins'] ) ? (array) $options['plugins'] : [];
        if ( in_array( $this->plugin_path, $plugins, true ) ) {
            $this->clear_update_cache();
        }
    }

    /**
     * Tự động chuyển hướng về trang plugin sau khi nâng cấp thành công trên trang update.php
     */
    public function maybe_redirect_after_update() {
        global $pagenow;
        if ( $pagenow === 'update.php' && isset( $_GET['action'] ) && $_GET['action'] === 'upgrade-plugin' ) {
            $plugin = isset( $_GET['plugin'] ) ? $_GET['plugin'] : '';
            if ( $plugin === $this->plugin_path ) {
                ?>
                <script>
                jQuery(document).ready(function($) {
                    var returnLink = $('a[href*="plugins.php"]').first();
                    var pageText = $('.wrap').text();
                    var successText = ['thành công', 'successfully', 'Success'];
                    var hasSuccess = false;
                    for (var i = 0; i < successText.length; i++) {
                        if (pageText.indexOf(successText[i]) !== -1) {
                            hasSuccess = true;
                            break;
                        }
                    }
                    if (returnLink.length > 0 && hasSuccess) {
                        var $statusDiv = $('<div class="notice notice-success inline" style="margin-top: 15px; border-left-color: #0068ff;"><p><strong>Duy Anh Web Pro:</strong> Nâng cấp thành công! Hệ thống đang tự động quay lại trang Plugin trong 3 giây...</p></div>');
                        $('.wrap').append($statusDiv);
                        setTimeout(function() {
                            window.location.href = returnLink.attr('href');
                        }, 3000);
                    }
                });
                </script>
                <?php
            }
        }
    }
}
