/**
 * DAWP WebP Converter - Điều khiển quá trình nén.
 *
 * Nguyên tắc hoạt động:
 *   1. Máy chủ chỉ trả về DANH SÁCH ảnh cần nén (một truy vấn rất nhẹ).
 *   2. Trình duyệt tải ảnh về, giải mã, resize và encode WebP bằng CPU/RAM MÁY KHÁCH.
 *   3. Trình duyệt gửi file WebP đã nén lên, máy chủ chỉ ghi đĩa và đổi URL trong DB.
 *   4. Xử lý TỪNG ẢNH MỘT và commit ngay sau mỗi ảnh - xong ảnh nào chắc ảnh đó.
 *      Nếu đóng trình duyệt giữa chừng, lần sau chạy tiếp từ đúng chỗ đang dở.
 */

/* global window, document, Worker, FormData, fetch */

( function () {
	'use strict';

	const cfg = window.dawpWebpData || {};

	// PHP giới hạn số file mỗi request (max_file_uploads, mặc định 20) và tổng
	// dung lượng body (post_max_size, mặc định 8M). Nên ảnh có nhiều kích thước
	// được gửi làm NHIỀU LƯỢT thay vì bỏ bớt — không kích thước nào bị bỏ sót.
	const MAX_FILES_PER_REQUEST = 12;
	const MAX_BYTES_PER_REQUEST = 6 * 1024 * 1024;

	const state = {
		running: false,
		aborted: false,
		// Dừng ÊM: không nhận ảnh mới nhưng hoàn thiện nốt ảnh đang dở.
		// aborted = ngắt lập tức; stopping = dừng có trật tự.
		stopping: false,
		queue: [],
		total: 0,
		done: 0,
		failed: 0,
		bytesBefore: 0,
		bytesAfter: 0,
		startedAt: 0,
		workers: [],
		jobSeq: 0,
		// Ảnh đã lỗi trong PHIÊN NÀY: không bao giờ lấy lại từ hàng đợi nữa,
		// kể cả khi việc đánh dấu trên server thất bại. Chặn đứng mọi khả năng
		// lặp vô hạn quanh một ảnh hỏng.
		failedIds: new Set(),
		// Ảnh đang được một làn xử lý — làn khác không được lấy trùng.
		inFlight: new Set(),
		// Thời điểm được phép gửi request tiếp theo. Khi server báo 503/429
		// (quá tải / chống flood), MỌI request đều chờ qua mốc này mới gửi —
		// cả hệ thống tự "hạ nhiệt" thay vì tiếp tục dội vào server.
		cooldownUntil: 0
	};

	const el = {};

	/* ----------------------------------------------------------------
	 * Tiện ích
	 * ---------------------------------------------------------------- */

	function $( id ) {
		return document.getElementById( id );
	}

	function formatBytes( bytes ) {
		bytes = Number( bytes ) || 0;
		if ( 1024 > bytes ) {
			return bytes + ' B';
		}
		const units = [ 'KB', 'MB', 'GB' ];
		let value = bytes / 1024;
		let index = 0;
		while ( 1024 <= value && index < units.length - 1 ) {
			value /= 1024;
			index++;
		}
		return value.toFixed( value < 10 ? 2 : 1 ) + ' ' + units[ index ];
	}

	function escapeHtml( text ) {
		const div = document.createElement( 'div' );
		div.textContent = String( text == null ? '' : text );
		return div.innerHTML;
	}

	/**
	 * Gọi REST API với TIMEOUT bắt buộc.
	 *
	 * Không có timeout thì chỉ cần một request bị máy chủ "ngậm" (PHP treo,
	 * phần mềm bảo mật chặn, mất mạng nửa chừng) là toàn bộ hàng đợi đứng im
	 * vĩnh viễn — đây chính là lỗi treo từng gặp.
	 *
	 * @param {string} path    Đường dẫn endpoint.
	 * @param {Object} options Tuỳ chọn fetch + { timeoutMs, retries }.
	 */
	function api( path, options ) {
		options = options || {};
		options.headers = options.headers || {};
		options.headers['X-WP-Nonce'] = cfg.nonce;
		options.credentials = 'same-origin';

		const timeoutMs = options.timeoutMs || 60000;
		let retriesLeft = options.retries || 0;

		// 503/429 = server quá tải hoặc firewall chống flood chặn tạm.
		// Đây KHÔNG phải lỗi của ảnh — luôn đáng chờ rồi thử lại, kể cả
		// với commit (request bị chặn nghĩa là server chưa xử lý gì cả).
		let overloadLeft = 4;

		return ( async function attempt() {
			for ( ;; ) {
				// Server vừa báo quá tải -> mọi request cùng chờ "hạ nhiệt".
				const cool = state.cooldownUntil - Date.now();
				if ( 0 < cool && ! state.aborted ) {
					await sleep( cool );
				}

				const controller = new AbortController();
				const timer = setTimeout( function () {
					controller.abort();
				}, timeoutMs );

				options.signal = controller.signal;

				try {
					const response = await fetch( cfg.restUrl + path, options );

					// Đọc dạng text rồi tự parse: server có thể trả HTML
					// (trang lỗi PHP, trang đăng nhập, WAF...) thay vì JSON.
					const text = await response.text();

					let body = null;
					try {
						body = JSON.parse( text );
					} catch ( e ) {
						body = null;
					}

					if ( ! response.ok ) {
						const err = new Error(
							body && body.message
								? body.message
								: 'Máy chủ trả về lỗi HTTP ' + response.status
						);
						err.httpStatus = response.status;
						throw err;
					}

					if ( null === body ) {
						throw new Error(
							'Máy chủ trả về nội dung không phải JSON (thường do lỗi PHP, plugin cache/bảo mật hoặc phiên đăng nhập hết hạn).'
						);
					}

					return body;
				} catch ( error ) {
					if ( 'AbortError' === error.name ) {
						error = new Error(
							'Máy chủ không phản hồi sau ' + Math.round( timeoutMs / 1000 ) + ' giây.'
						);
					}

					const overloaded = 503 === error.httpStatus || 429 === error.httpStatus;

					if ( overloaded && 0 < overloadLeft && ! state.aborted ) {
						overloadLeft--;
						// Hạ nhiệt TOÀN BỘ hệ thống 15 giây rồi thử lại.
						state.cooldownUntil = Date.now() + 15000;
						continue;
					}

					// Thử lại cho các lỗi tạm thời khác.
					if ( 0 < retriesLeft && ! state.aborted ) {
						retriesLeft--;
						await sleep( 2000 );
						continue;
					}

					throw error;
				} finally {
					clearTimeout( timer );
				}
			}
		} )();
	}

	function log( message, type ) {
		if ( ! el.log ) {
			return;
		}

		const row = document.createElement( 'div' );
		row.className = 'dawp-webp-log-row dawp-webp-log-' + ( type || 'info' );

		const time = new Date().toLocaleTimeString();
		row.innerHTML = '<span class="dawp-webp-log-time">' + time + '</span> ' + message;

		el.log.insertBefore( row, el.log.firstChild );

		// Giữ tối đa 300 dòng để không phình bộ nhớ.
		while ( 300 < el.log.childNodes.length ) {
			el.log.removeChild( el.log.lastChild );
		}
	}

	/* ----------------------------------------------------------------
	 * Bộ nén chạy trên máy khách
	 * ---------------------------------------------------------------- */

	const supportsWorker = ( 'undefined' !== typeof Worker ) && ( 'undefined' !== typeof OffscreenCanvas );

	function createWorkerPool( size ) {
		destroyWorkerPool();

		if ( ! supportsWorker ) {
			return;
		}

		for ( let i = 0; i < size; i++ ) {
			state.workers.push( {
				worker: new Worker( cfg.workerUrl ),
				busy: false
			} );
		}
	}

	function destroyWorkerPool() {
		state.workers.forEach( function ( slot ) {
			slot.worker.terminate();
		} );
		state.workers = [];
	}

	/**
	 * Thay một worker đã chết/treo bằng worker mới để pool không teo dần.
	 *
	 * @param {Object} slot Slot chứa worker hỏng.
	 */
	function replaceWorker( slot ) {
		try {
			slot.worker.terminate();
		} catch ( e ) {
			// Bỏ qua.
		}

		// Pool đã bị huỷ (người dùng bấm Dừng) thì không tạo lại.
		if ( -1 === state.workers.indexOf( slot ) ) {
			return;
		}

		slot.worker = new Worker( cfg.workerUrl );
		slot.busy = false;
	}

	// Mỗi file tối đa 2 phút; quá hạn coi như worker treo và bị thay mới.
	const WORKER_JOB_TIMEOUT = 120000;

	/**
	 * Gửi một file cho worker rảnh, chờ kết quả.
	 *
	 * Nếu mọi worker đều bận thì CHỜ tới khi có worker rảnh, tuyệt đối không
	 * dồn hai job lên cùng một worker — làm vậy sẽ hỏng cờ busy và về sau mọi
	 * job đổ dồn về một luồng duy nhất.
	 */
	function compressInWorker( job ) {
		return new Promise( function ( resolve, reject ) {
			function dispatch() {
				const slot = state.workers.find( function ( s ) {
					return ! s.busy;
				} );

				if ( ! slot ) {
					// Pool đã bị huỷ (người dùng bấm Dừng) -> kết thúc sớm.
					if ( 0 === state.workers.length ) {
						reject( new Error( 'Đã dừng theo yêu cầu.' ) );
						return;
					}
					setTimeout( dispatch, 50 );
					return;
				}

				slot.busy = true;
				job.id = ++state.jobSeq;

				// Ba đường thoát: kết quả về, worker lỗi, hoặc quá hạn.
				// Bảo đảm promise LUÔN kết thúc — không bao giờ treo cả hàng đợi.
				let settled = false;

				function cleanup() {
					clearTimeout( timer );
					slot.worker.removeEventListener( 'message', onMessage );
					slot.worker.removeEventListener( 'error', onError );
					slot.worker.removeEventListener( 'messageerror', onError );
				}

				function onMessage( event ) {
					if ( event.data.id !== job.id || settled ) {
						return;
					}

					settled = true;
					cleanup();
					slot.busy = false;

					if ( event.data.ok ) {
						resolve( event.data );
					} else {
						reject( new Error( event.data.error ) );
					}
				}

				function onError( event ) {
					if ( settled ) {
						return;
					}

					settled = true;
					cleanup();
					replaceWorker( slot );
					reject( new Error(
						'Luồng nén gặp lỗi' +
						( event && event.message ? ': ' + event.message : ' không xác định.' ) +
						' Đã khởi động lại luồng.'
					) );
				}

				const timer = setTimeout( function () {
					if ( settled ) {
						return;
					}

					settled = true;
					cleanup();
					replaceWorker( slot );
					reject( new Error(
						'Nén quá ' + Math.round( WORKER_JOB_TIMEOUT / 60000 ) +
						' phút không xong — đã khởi động lại luồng nén để không kẹt hàng đợi.'
					) );
				}, WORKER_JOB_TIMEOUT );

				slot.worker.addEventListener( 'message', onMessage );
				slot.worker.addEventListener( 'error', onError );
				slot.worker.addEventListener( 'messageerror', onError );
				slot.worker.postMessage( job );
			}

			dispatch();
		} );
	}

	/**
	 * Phương án dự phòng cho trình duyệt cũ: nén trên luồng chính.
	 */
	function compressOnMainThread( job ) {
		const controller = new AbortController();
		const timer = setTimeout( function () {
			controller.abort();
		}, 60000 );

		return fetch( job.url, { credentials: 'same-origin', cache: 'no-store', signal: controller.signal } )
			.then( function ( response ) {
				if ( ! response.ok ) {
					throw new Error( 'Không tải được ảnh (HTTP ' + response.status + ')' );
				}
				return response.blob();
			} )
			.catch( function ( error ) {
				if ( 'AbortError' === error.name ) {
					throw new Error( 'Tải ảnh quá 60 giây không xong.' );
				}
				throw error;
			} )
			.finally( function () {
				clearTimeout( timer );
			} )
			.then( function ( blob ) {
				const originalSize = blob.size;

				return new Promise( function ( resolve, reject ) {
					const img = new Image();
					const objectUrl = URL.createObjectURL( blob );

					img.onload = function () {
						let width = img.naturalWidth;
						let height = img.naturalHeight;

						// Giới hạn cạnh dài nhất — cùng logic với worker.
						const isMainImage = 'full' === job.key || 'original_image' === job.key;

						if ( isMainImage && 0 < job.maxWidth ) {
							const longest = Math.max( width, height );

							if ( longest > job.maxWidth ) {
								const scale = job.maxWidth / longest;
								width = Math.max( 1, Math.round( width * scale ) );
								height = Math.max( 1, Math.round( height * scale ) );
							}
						}

						const canvas = document.createElement( 'canvas' );
						canvas.width = width;
						canvas.height = height;

						const ctx = canvas.getContext( '2d' );
						ctx.imageSmoothingEnabled = true;
						ctx.imageSmoothingQuality = 'high';
						ctx.drawImage( img, 0, 0, width, height );

						URL.revokeObjectURL( objectUrl );

						canvas.toBlob(
							function ( webp ) {
								if ( ! webp ) {
									reject( new Error( 'Trình duyệt không tạo được WebP.' ) );
									return;
								}
								resolve( {
									key: job.key,
									blob: webp,
									width: width,
									height: height,
									originalSize: originalSize,
									newSize: webp.size
								} );
							},
							'image/webp',
							job.quality
						);
					};

					img.onerror = function () {
						URL.revokeObjectURL( objectUrl );
						reject( new Error( 'Không giải mã được ảnh.' ) );
					};

					img.src = objectUrl;
				} );
			} );
	}

	function compress( job ) {
		return supportsWorker ? compressInWorker( job ) : compressOnMainThread( job );
	}

	/* ----------------------------------------------------------------
	 * Giao diện
	 * ---------------------------------------------------------------- */

	function renderProgress( currentLabel, subCurrent, subTotal ) {
		const processed = state.done + state.failed;
		const percent = 0 < state.total ? Math.min( 100, ( processed / state.total ) * 100 ) : 0;

		el.barFill.style.width = percent.toFixed( 2 ) + '%';
		el.barText.textContent = percent.toFixed( 1 ) + '%';

		el.counter.textContent = processed + ' / ' + state.total;
		el.failedCount.textContent = state.failed;

		const saved = Math.max( 0, state.bytesBefore - state.bytesAfter );
		const savedPercent = 0 < state.bytesBefore
			? ( ( saved / state.bytesBefore ) * 100 ).toFixed( 1 )
			: '0.0';

		el.saved.textContent = formatBytes( saved ) + ' (' + savedPercent + '%)';

		if ( currentLabel ) {
			let text = currentLabel;
			if ( subTotal ) {
				text += ' — file ' + subCurrent + '/' + subTotal;
			}
			el.current.textContent = text;
		}

		// Ước lượng thời gian còn lại.
		if ( state.running && 0 < processed && 0 < state.startedAt ) {
			const elapsed = ( Date.now() - state.startedAt ) / 1000;
			const perItem = elapsed / processed;
			const remaining = Math.max( 0, state.total - processed ) * perItem;
			el.eta.textContent = formatDuration( remaining );
		}
	}

	function formatDuration( seconds ) {
		seconds = Math.round( seconds );
		if ( 60 > seconds ) {
			return seconds + ' giây';
		}
		const minutes = Math.floor( seconds / 60 );
		if ( 60 > minutes ) {
			return minutes + ' phút ' + ( seconds % 60 ) + ' giây';
		}
		return Math.floor( minutes / 60 ) + ' giờ ' + ( minutes % 60 ) + ' phút';
	}

	function setRunningUI( running ) {
		el.start.disabled = running;
		el.stop.disabled = ! running;
		el.quality.disabled = running;
		el.maxWidth.disabled = running;
		el.concurrency.disabled = running;
		el.statusBadge.textContent = running ? 'Đang chạy' : 'Sẵn sàng';
		el.statusBadge.className = 'dawp-webp-badge ' + ( running ? 'is-running' : 'is-idle' );
	}

	/* ----------------------------------------------------------------
	 * Vòng lặp xử lý: MỖI LẦN ĐÚNG MỘT ẢNH
	 * ---------------------------------------------------------------- */

	function sleep( ms ) {
		return new Promise( function ( resolve ) {
			setTimeout( resolve, ms );
		} );
	}

	/**
	 * Giới hạn cứng cho một promise: quá hạn là bỏ, tuyệt đối không chờ vô hạn.
	 *
	 * @param {Promise} promise Promise cần giới hạn.
	 * @param {number}  ms      Thời gian tối đa.
	 * @param {string}  message Thông báo khi quá hạn.
	 */
	function withTimeout( promise, ms, message ) {
		return Promise.race( [
			promise,
			sleep( ms ).then( function () {
				throw new Error( message );
			} )
		] );
	}

	/**
	 * Đánh dấu bỏ qua một ảnh.
	 *
	 * @param {number}  attachmentId ID ảnh.
	 * @param {string}  reason       Lý do.
	 * @param {boolean} retry        true = lỗi tạm, lần chạy sau tự thử lại;
	 *                               false = bỏ qua vĩnh viễn (đã tối ưu sẵn...).
	 */
	function skipAttachment( attachmentId, reason, retry ) {
		return api( '/skip', {
			method: 'POST',
			headers: { 'Content-Type': 'application/json' },
			retries: 1,
			body: JSON.stringify( {
				attachment_id: attachmentId,
				reason: reason,
				retry: retry ? 1 : 0
			} )
		} );
	}

	// Giới hạn cứng cho TRỌN VẸN một ảnh (tải + nén + upload mọi lượt).
	// Quá hạn là bỏ qua tạm thời và đi tiếp — không gì có thể kẹt hàng đợi.
	const PER_IMAGE_TIMEOUT = 3 * 60 * 1000;

	// Đồng hồ đếm ngược khi đang dừng êm.
	let stopTickerId = null;

	function startStopCountdown() {
		const startedStopping = Date.now();

		stopTickerId = setInterval( function () {
			if ( ! state.stopping || state.aborted || ! state.running ) {
				clearInterval( stopTickerId );
				stopTickerId = null;
				return;
			}

			// Mỗi ảnh bị giới hạn cứng 3 phút nên thời gian chờ dừng hẳn
			// không bao giờ vượt quá mức đó — đếm ngược cho người dùng biết.
			const remain = Math.max( 0, PER_IMAGE_TIMEOUT - ( Date.now() - startedStopping ) );

			el.current.textContent = 'Hoàn thiện nốt ' + state.inFlight.size +
				' ảnh dở dang — dừng hẳn sau tối đa ' + Math.ceil( remain / 1000 ) + ' giây…';
			el.statusBadge.textContent = 'Đang dừng (' + Math.ceil( remain / 1000 ) + 's)';
		}, 1000 );
	}

	/**
	 * Chạy một danh sách công việc với số luồng giới hạn.
	 *
	 * @param {Array}    items   Danh sách.
	 * @param {Function} handler Hàm xử lý một phần tử.
	 * @param {number}   limit   Số luồng tối đa.
	 */
	function runPool( items, handler, limit ) {
		let index = 0;

		function worker() {
			if ( index >= items.length ) {
				return Promise.resolve();
			}
			const item = items[ index++ ];
			return Promise.resolve( handler( item ) ).then( worker );
		}

		const runners = [];
		for ( let i = 0; i < Math.min( limit, items.length ); i++ ) {
			runners.push( worker() );
		}

		return Promise.all( runners );
	}

	async function refillQueue() {
		const response = await api( '/queue?limit=50', { retries: 2 } );

		const fresh = ( response.ids || [] ).filter( function ( id ) {
			return ! state.failedIds.has( id ) &&
				! state.inFlight.has( id ) &&
				-1 === state.queue.indexOf( id );
		} );

		state.queue = state.queue.concat( fresh );

		// Hàng đợi chỉ còn toàn ảnh đã lỗi/đang xử lý -> coi như hết việc mới,
		// tránh vòng lặp xin hàng đợi mãi không có gì.
		if ( 0 === fresh.length && 0 < ( response.ids || [] ).length && 0 === state.queue.length && 0 === state.inFlight.size ) {
			log( 'ℹ️ Các ảnh còn lại đều đã lỗi trong phiên này — sẽ được thử lại ở lần chạy sau.', 'info' );
		}
	}

	/**
	 * Chia danh sách kết quả thành các lượt gửi vừa với giới hạn của PHP.
	 *
	 * Ảnh gốc (key 'full') luôn được xếp vào lượt CUỐI CÙNG. Lý do: chừng nào
	 * ảnh gốc chưa đổi sang WebP thì attachment vẫn giữ MIME jpeg/png nên vẫn
	 * nằm trong hàng đợi. Nếu người dùng bấm Dừng hay mất mạng giữa chừng, lần
	 * chạy sau ảnh này vẫn được lấy ra xử lý tiếp phần còn thiếu.
	 *
	 * @param {Array} results Danh sách kết quả đã nén.
	 * @return {Array} Mảng các lượt, mỗi lượt là một mảng kết quả.
	 */
	function buildChunks( results ) {
		const ordered = results.slice().sort( function ( a, b ) {
			if ( 'full' === a.key ) {
				return 1;
			}
			if ( 'full' === b.key ) {
				return -1;
			}
			return 0;
		} );

		const chunks = [];
		let current = [];
		let currentBytes = 0;

		ordered.forEach( function ( result ) {
			const tooManyFiles = MAX_FILES_PER_REQUEST <= current.length;
			const tooManyBytes = 0 < current.length &&
				MAX_BYTES_PER_REQUEST < currentBytes + result.blob.size;

			if ( tooManyFiles || tooManyBytes ) {
				chunks.push( current );
				current = [];
				currentBytes = 0;
			}

			current.push( result );
			currentBytes += result.blob.size;
		} );

		if ( 0 < current.length ) {
			chunks.push( current );
		}

		return chunks;
	}

	/**
	 * Xử lý trọn vẹn một ảnh: tải -> nén mọi kích thước -> gửi lên -> commit DB.
	 */
	async function processOne( attachmentId ) {
		const item = await api( '/item/' + attachmentId, { retries: 2 } );
		const label = '#' + attachmentId + ' ' + ( item.title || '' );
		const files = item.files || [];

		// Không còn file nào thuộc diện nén (quá nhỏ, hoặc đã nén hết) ->
		// đánh dấu bỏ qua êm thấm, không phải lỗi.
		if ( 0 === files.length ) {
			// Bỏ qua vĩnh viễn: không có gì để nén, thử lại cũng vô ích.
			await skipAttachment( attachmentId, item.reason || 'Không có file cần nén.', false );

			log( '➖ ' + escapeHtml( label ) + ' — ' + escapeHtml( item.reason || 'không có file cần nén.' ), 'muted' );
			state.done++;
			return;
		}

		// Mã phiên: chống hai tab admin cùng xử lý một ảnh.
		const token = Date.now().toString( 36 ) + '-' + Math.random().toString( 36 ).slice( 2, 10 );

		renderProgress( label, 0, files.length );

		const quality = parseFloat( el.quality.value );
		const maxWidth = parseInt( el.maxWidth.value, 10 ) || 0;

		const results = [];
		let doneFiles = 0;

		/**
		 * Nén một kích thước và giữ lại kết quả.
		 */
		async function handleFile( file ) {
			if ( state.aborted ) {
				throw new Error( 'Đã dừng theo yêu cầu.' );
			}

			let result;
			try {
				result = await compress( {
					key: file.key,
					url: file.url,
					quality: quality,
					maxWidth: maxWidth
				} );
			} catch ( error ) {
				log(
					'⚠️ ' + escapeHtml( label ) + ' — bỏ qua kích thước <code>' +
					escapeHtml( file.key ) + '</code>: ' + escapeHtml( error.message ),
					'warn'
				);
				doneFiles++;
				renderProgress( label, doneFiles, files.length );
				return;
			}

			// LUÔN chuyển sang WebP — worker đã tự hạ chất lượng từng nấc để
			// gần như chắc chắn nhẹ hơn gốc. Toàn thư viện về MỘT định dạng,
			// lần chạy sau không còn phải tải về kiểm tra lại ảnh nào nữa.
			results.push( {
				key: file.key,
				blob: result.blob,
				width: result.width,
				height: result.height,
				name: file.relative.split( '/' ).pop().replace( /\.(jpe?g|png)$/i, '.webp' )
			} );

			doneFiles++;
			renderProgress( label, doneFiles, files.length );
		}

		// Nén song song các kích thước của cùng một ảnh, tối đa N luồng.
		await runPool( files, handleFile, Math.max( 1, state.workers.length || 1 ) );

		if ( 0 === results.length ) {
			// Mọi kích thước đều nén thất bại -> lỗi tạm, lần chạy sau thử lại.
			throw new Error( 'Không nén được kích thước nào của ảnh.' );
		}

		// Gửi lên thành nhiều lượt nếu ảnh có quá nhiều kích thước.
		const chunks = buildChunks( results );

		let totalBefore = 0;
		let totalAfter = 0;
		let totalFiles = 0;
		let totalRows = 0;

		for ( let i = 0; i < chunks.length; i++ ) {
			const isFinal = ( i === chunks.length - 1 );
			const form = new FormData();
			const dims = {};

			form.append( 'attachment_id', String( attachmentId ) );
			form.append( 'is_final', isFinal ? '1' : '0' );
			form.append( 'token', token );

			chunks[ i ].forEach( function ( result ) {
				form.append( 'file_' + result.key, result.blob, result.name );
				dims[ result.key ] = { w: result.width, h: result.height };
			} );

			form.append( 'dims', JSON.stringify( dims ) );

			if ( 1 < chunks.length ) {
				renderProgress( label + ' — gửi lượt ' + ( i + 1 ) + '/' + chunks.length );
			}

			// Upload + ghi đĩa + đổi DB có thể chậm với ảnh lớn -> timeout dài hơn.
			const commit = await api( '/commit', { method: 'POST', body: form, timeoutMs: 120000 } );

			totalBefore += commit.size_before || 0;
			totalAfter += commit.size_after || 0;
			totalFiles += commit.files || 0;
			totalRows += commit.db_rows || 0;
		}

		state.bytesBefore += totalBefore;
		state.bytesAfter += totalAfter;
		state.done++;

		if ( 0 === totalFiles ) {
			log( '➖ ' + escapeHtml( label ) + ' — ảnh đã tối ưu sẵn, giữ nguyên.', 'muted' );
			return;
		}

		const percent = 0 < totalBefore
			? ( ( totalBefore - totalAfter ) / totalBefore * 100 ).toFixed( 1 )
			: '0.0';

		// Ảnh gắn vào bài viết/sản phẩm bằng ID (trường hợp phổ biến nhất) thì
		// không có URL nào trong nội dung cần thay — đó là bình thường, không
		// phải lỗi. Chỉ ảnh chèn thẳng URL vào nội dung mới phát sinh số này.
		const dbNote = 0 < totalRows
			? totalRows + ' dòng DB đã đổi đường dẫn'
			: 'DB không có URL cũ cần đổi (ảnh gắn theo ID)';

		log(
			'✅ ' + escapeHtml( label ) + ' — ' +
			formatBytes( totalBefore ) + ' → <strong>' + formatBytes( totalAfter ) + '</strong> ' +
			'(giảm ' + percent + '%), ' +
			totalFiles + '/' + files.length + ' kích thước' +
			( 1 < chunks.length ? ' qua ' + chunks.length + ' lượt' : '' ) + ', ' +
			'<em>' + dbNote + '</em>',
			'ok'
		);
	}

	async function run() {
		state.running = true;
		state.aborted = false;
		state.stopping = false;
		state.startedAt = Date.now();

		createWorkerPool( parseInt( el.concurrency.value, 10 ) || 1 );
		setRunningUI( true );

		if ( ! supportsWorker ) {
			log( 'ℹ️ Trình duyệt không hỗ trợ OffscreenCanvas — chuyển sang nén trên luồng chính (chậm hơn một chút).', 'warn' );
		}

		try {
			// Đưa ảnh lỗi của các lần chạy trước trở lại hàng đợi: ảnh lỗi chỉ
			// bị bỏ qua TẠM THỜI, không bao giờ bị bỏ sót vĩnh viễn.
			try {
				const reset = await api( '/reset-errors', { method: 'POST', retries: 2 } );
				if ( 0 < reset.requeued ) {
					log( '🔄 Đưa ' + reset.requeued + ' ảnh lỗi lần trước vào lại hàng đợi để thử lại.', 'info' );
				}
			} catch ( e ) {
				log( '⚠️ Không reset được danh sách ảnh lỗi: ' + escapeHtml( e.message ) + ' — vẫn chạy tiếp.', 'warn' );
			}

			const status = await api( '/status', { retries: 3 } );
			state.total = status.pending;
			state.done = 0;
			state.failed = 0;
			state.failedIds.clear();
			state.inFlight.clear();
			state.queue = [];
			state.bytesBefore = 0;
			state.bytesAfter = 0;

			if ( 0 === state.total ) {
				log( '🎉 Không còn ảnh nào cần nén.', 'ok' );
				stop();
				return;
			}

			log( '🚀 Bắt đầu nén ' + state.total + ' ảnh bằng CPU/RAM máy của bạn.', 'info' );
			renderProgress( 'Đang chuẩn bị…' );

			// ----------------------------------------------------------
			// XỬ LÝ SONG SONG NHIỀU ẢNH: nhiều "làn" cùng chạy, mỗi làn
			// lấy một ảnh từ hàng đợi chung. Ảnh nhỏ không còn làm cả
			// dây chuyền phải chờ — nhanh gấp nhiều lần so với tuần tự.
			// ----------------------------------------------------------

			// Số lần lỗi hàng đợi LIÊN TIẾP. Mỗi lần lỗi chờ 30 giây rồi thử
			// tiếp (server có thể chỉ chập chờn tạm thời, nhất là khi chạy qua
			// đêm). Chỉ bó tay khi lỗi liên tục quá 20 lần (~10 phút).
			let queueFailures = 0;
			let refillPromise = null;

			// Nạp hàng đợi có khoá: nhiều làn cùng cần thì chỉ gọi server MỘT
			// lần, và tự chờ-thử-lại khi server chập chờn.
			async function refillShared() {
				for ( ;; ) {
					if ( state.aborted ) {
						return;
					}

					try {
						await refillQueue();
						queueFailures = 0;
						return;
					} catch ( error ) {
						queueFailures++;

						if ( 20 < queueFailures ) {
							throw new Error( 'Máy chủ không phản hồi liên tục hơn 10 phút: ' + error.message );
						}

						log(
							'⚠️ Không lấy được hàng đợi (' + escapeHtml( error.message ) +
							') — thử lại sau 30 giây (lần ' + queueFailures + '/20).',
							'warn'
						);
						await sleep( 30000 );
					}
				}
			}

			// Lấy ID tiếp theo; trả về null khi thật sự hết việc.
			async function nextId() {
				while ( ! state.aborted ) {
					// Đang dừng êm -> không phát ảnh mới, để làn tự kết thúc
					// sau khi hoàn thiện ảnh đang cầm.
					if ( state.stopping ) {
						return null;
					}

					if ( 0 < state.queue.length ) {
						return state.queue.shift();
					}

					if ( ! refillPromise ) {
						refillPromise = refillShared().finally( function () {
							refillPromise = null;
						} );
					}

					await refillPromise;

					if ( 0 === state.queue.length ) {
						return null;
					}
				}
				return null;
			}

			// Một làn xử lý: lặp lấy ảnh -> xử lý trọn vẹn -> lấy ảnh tiếp.
			async function lane() {
				for ( ;; ) {
					if ( state.aborted ) {
						return;
					}

					const attachmentId = await nextId();

					if ( null === attachmentId || undefined === attachmentId ) {
						return;
					}

					state.inFlight.add( attachmentId );

					try {
						// Timeout cứng: một ảnh dù tệ đến đâu cũng không được
						// chiếm quá 10 phút. Quá hạn -> bỏ qua tạm, đi tiếp.
						await withTimeout(
							processOne( attachmentId ),
							PER_IMAGE_TIMEOUT,
							'Xử lý quá 3 phút không xong.'
						);
					} catch ( error ) {
						state.failed++;
						state.failedIds.add( attachmentId );

						log(
							'❌ #' + attachmentId + ' — ' + escapeHtml( error.message ) +
							' (bỏ qua tạm thời, lần chạy sau sẽ tự thử lại)',
							'error'
						);

						// Đánh dấu lỗi TẠM THỜI: lần chạy này không đụng lại
						// ảnh này nữa, lần bấm "Bắt đầu nén" sau tự thử lại.
						try {
							await skipAttachment( attachmentId, error.message, true );
						} catch ( e ) {
							// Server chập chờn: failedIds đã chặn phía trình duyệt.
						}
					} finally {
						state.inFlight.delete( attachmentId );
					}

					renderProgress();
				}
			}

			const laneCount = Math.min( 4, Math.max( 1, state.workers.length || 1 ) );

			if ( 1 < laneCount ) {
				log( '⚡ Chạy ' + laneCount + ' ảnh song song để tăng tốc.', 'info' );
			}

			const lanes = [];
			for ( let i = 0; i < laneCount; i++ ) {
				lanes.push( lane() );
			}
			await Promise.all( lanes );

			if ( state.aborted ) {
				log( '⏹️ Đã ngắt lập tức. Những ảnh đã nén xong vẫn được giữ nguyên kết quả.', 'warn' );
			} else if ( state.stopping ) {
				log( '✅ Đã dừng hẳn — mọi ảnh dở dang đều được hoàn thiện trọn vẹn, không ảnh nào bị bỏ giữa chừng. Tắt máy an toàn.', 'ok' );
			} else {
				const saved = Math.max( 0, state.bytesBefore - state.bytesAfter );
				log(
					'🎉 Hoàn tất! Đã nén ' + state.done + ' ảnh, tiết kiệm ' + formatBytes( saved ) + '.' +
					( 0 < state.failed
						? ' Có ' + state.failed + ' ảnh lỗi sẽ tự được thử lại ở lần chạy sau.'
						: '' ),
					'ok'
				);
			}
		} catch ( error ) {
			log( '❌ Lỗi nghiêm trọng: ' + escapeHtml( error.message ), 'error' );
		} finally {
			stop();
		}
	}

	function stop() {
		state.running = false;
		state.aborted = true;
		state.stopping = false;

		if ( stopTickerId ) {
			clearInterval( stopTickerId );
			stopTickerId = null;
		}

		destroyWorkerPool();
		setRunningUI( false );
		el.stop.textContent = 'Dừng nén';
		el.current.textContent = '—';
		el.eta.textContent = '—';
	}

	/* ----------------------------------------------------------------
	 * Khởi tạo
	 * ---------------------------------------------------------------- */

	function bind() {
		el.start = $( 'dawp-webp-start' );
		el.stop = $( 'dawp-webp-stop' );
		el.quality = $( 'dawp-webp-quality' );
		el.qualityOut = $( 'dawp-webp-quality-out' );
		el.maxWidth = $( 'dawp-webp-max-width' );
		el.concurrency = $( 'dawp-webp-concurrency' );
		el.barFill = $( 'dawp-webp-bar-fill' );
		el.barText = $( 'dawp-webp-bar-text' );
		el.counter = $( 'dawp-webp-counter' );
		el.failedCount = $( 'dawp-webp-failed' );
		el.saved = $( 'dawp-webp-saved' );
		el.current = $( 'dawp-webp-current' );
		el.eta = $( 'dawp-webp-eta' );
		el.log = $( 'dawp-webp-log' );
		el.statusBadge = $( 'dawp-webp-status-badge' );

		if ( ! el.start ) {
			return;
		}

		el.quality.addEventListener( 'input', function () {
			el.qualityOut.textContent = Math.round( parseFloat( el.quality.value ) * 100 ) + '%';
		} );

		el.start.addEventListener( 'click', function () {
			if ( ! state.running ) {
				run();
			}
		} );

		el.stop.addEventListener( 'click', function () {
			if ( ! state.running ) {
				return;
			}

			// Lần 1: DỪNG ÊM — không nhận ảnh mới, hoàn thiện nốt ảnh đang dở
			// rồi mới dừng hẳn. An toàn tuyệt đối để tắt máy.
			if ( ! state.stopping ) {
				state.stopping = true;
				el.stop.textContent = 'Dừng ngay';

				log(
					'⏹️ Đã nhận lệnh dừng — hoàn thiện nốt ' + state.inFlight.size +
					' ảnh đang dở rồi dừng hẳn (tối đa ' + Math.round( PER_IMAGE_TIMEOUT / 60000 ) +
					' phút). Muốn ngắt lập tức thì bấm "Dừng ngay".',
					'warn'
				);

				startStopCountdown();
				return;
			}

			// Lần 2: NGẮT LẬP TỨC — ảnh dở dang sẽ được làm nốt ở lần chạy sau.
			state.aborted = true;
			log( '⏹️ Ngắt lập tức theo yêu cầu. Ảnh dở dang sẽ được làm nốt ở lần chạy sau.', 'warn' );
		} );

		// Công cụ quét và sửa đường dẫn ảnh.
		const repairBtn = $( 'dawp-webp-repair' );
		const repairStatus = $( 'dawp-webp-repair-status' );

		if ( repairBtn ) {
			repairBtn.addEventListener( 'click', async function () {
				repairBtn.disabled = true;
				repairStatus.textContent = ' Đang quét…';

				let offset = 0;
				let totalFixed = 0;

				try {
					for ( ;; ) {
						const result = await api( '/repair', {
							method: 'POST',
							headers: { 'Content-Type': 'application/json' },
							body: JSON.stringify( { offset: offset } )
						} );

						totalFixed += result.fixed;
						offset = result.offset;

						repairStatus.textContent = ' Đã kiểm tra ' + offset + '/' + result.total +
							' ảnh, sửa ' + totalFixed + ' mục.';

						( result.details || [] ).forEach( function ( item ) {
							log(
								'🔧 #' + item.id + ' — sửa ' + item.fixed + ' mục: <code>' +
								escapeHtml( ( item.notes || [] ).join( ', ' ) ) + '</code>',
								'warn'
							);
						} );

						if ( result.done ) {
							break;
						}
					}

					repairStatus.textContent = ' Xong. Đã sửa ' + totalFixed + ' mục.';
					log(
						0 === totalFixed
							? '✅ Quét xong, không phát hiện đường dẫn nào bị sai.'
							: '✅ Quét xong, đã sửa ' + totalFixed + ' mục metadata trỏ sai.',
						'ok'
					);
				} catch ( error ) {
					repairStatus.textContent = ' Lỗi: ' + error.message;
					log( '❌ Quét sửa thất bại: ' + escapeHtml( error.message ), 'error' );
				} finally {
					repairBtn.disabled = false;
				}
			} );
		}

		// Dọn sạch URL cũ trong toàn bộ database (chuẩn bị gỡ plugin).
		const sweepBtn = $( 'dawp-webp-sweep' );
		const sweepStatus = $( 'dawp-webp-sweep-status' );

		if ( sweepBtn ) {
			sweepBtn.addEventListener( 'click', async function () {
				sweepBtn.disabled = true;
				sweepStatus.textContent = ' Đang quét database…';

				let table = 0;
				let lastPk = 0;
				let totalFixed = 0;
				let totalLeftover = 0;

				try {
					for ( ;; ) {
						const result = await api( '/sweep', {
							method: 'POST',
							headers: { 'Content-Type': 'application/json' },
							retries: 2,
							timeoutMs: 120000,
							body: JSON.stringify( { table: table, last_pk: lastPk } )
						} );

						if ( result.done_all ) {
							break;
						}

						totalFixed += result.fixed || 0;
						totalLeftover += result.leftover || 0;
						table = result.table;
						lastPk = result.last_pk;

						sweepStatus.textContent = ' Đang quét bảng ' + Math.min( table + 1, result.tables ) +
							'/' + result.tables + ' — đã sửa ' + totalFixed + ' dòng.';
					}

					if ( 0 === totalLeftover ) {
						sweepStatus.textContent = ' ✅ Xong. Đã sửa ' + totalFixed +
							' dòng. Database SẠCH — gỡ plugin an toàn trên mọi máy chủ.';
						log( '✅ Dọn database xong: sửa ' + totalFixed + ' dòng, không còn URL cũ nào sót. Gỡ plugin an toàn trên mọi máy chủ.', 'ok' );
					} else {
						sweepStatus.textContent = ' ⚠️ Xong. Đã sửa ' + totalFixed + ' dòng, còn ' +
							totalLeftover + ' tham chiếu không có bản .webp thay thế (xem chi tiết bằng nút Quét và sửa đường dẫn).';
						log(
							'⚠️ Dọn database xong: sửa ' + totalFixed + ' dòng nhưng còn ' + totalLeftover +
							' tham chiếu .jpg/.png không có file .webp tương ứng. Chạy nén hết ảnh rồi quét lại trước khi gỡ plugin.',
							'warn'
						);
					}
				} catch ( error ) {
					sweepStatus.textContent = ' Lỗi: ' + error.message;
					log( '❌ Dọn database thất bại: ' + escapeHtml( error.message ), 'error' );
				} finally {
					sweepBtn.disabled = false;
				}
			} );
		}

		// Cảnh báo khi đóng tab lúc đang chạy.
		window.addEventListener( 'beforeunload', function ( event ) {
			if ( state.running ) {
				event.preventDefault();
				event.returnValue = '';
			}
		} );

		setRunningUI( false );
	}

	if ( 'loading' === document.readyState ) {
		document.addEventListener( 'DOMContentLoaded', bind );
	} else {
		bind();
	}
} )();



