<?php
/**
 * Search-replace URL ảnh trong toàn bộ database, an toàn với dữ liệu serialize.
 *
 * Được gọi ngay sau khi một ảnh được nén xong, nên mỗi ảnh là một giao dịch
 * độc lập: xong ảnh nào chắc ảnh đó, không sợ treo giữa chừng làm hỏng dữ liệu.
 *
 * @package duyanhweb
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DAWP_WebP_Replacer {

	/**
	 * Thay thế nhiều cặp URL/đường dẫn trong toàn bộ các bảng liên quan.
	 *
	 * @param array $pairs Mảng dạng array( 'old' => 'new', ... ).
	 * @return int Số dòng đã cập nhật.
	 */
	public static function replace_pairs( $pairs ) {
		$pairs = self::expand_pairs( $pairs );

		if ( empty( $pairs ) ) {
			return 0;
		}

		// Needle dùng cho mệnh đề WHERE: chỉ cần tên file, vì mọi biến thể mã hoá
		// (JSON escaped, urlencode, đổi scheme) đều giữ nguyên phần tên file.
		// Lọc rộng ở SQL rồi thay chính xác bằng PHP là cách vừa nhanh vừa an toàn.
		$needles = self::needles_from_pairs( $pairs );

		$updated = 0;
		foreach ( self::targets() as $target ) {
			$updated += self::process_table( $target, $pairs, $needles );
		}

		self::flush_caches();

		return $updated;
	}

	/**
	 * Mở rộng danh sách cặp thay thế để phủ các biến thể mã hoá thường gặp:
	 * URL tuyệt đối, URL không scheme, JSON escaped slashes, urlencode.
	 *
	 * @param array $pairs Cặp gốc.
	 * @return array
	 */
	private static function expand_pairs( $pairs ) {
		$expanded = array();

		foreach ( $pairs as $old => $new ) {
			$old = (string) $old;
			$new = (string) $new;

			if ( '' === $old || $old === $new ) {
				continue;
			}

			// Dạng nguyên bản.
			$expanded[ $old ] = $new;

			// Dạng JSON escaped: https:\/\/site.com\/wp-content\/...
			$json_old = str_replace( '/', '\\/', $old );
			$json_new = str_replace( '/', '\\/', $new );
			if ( $json_old !== $old ) {
				$expanded[ $json_old ] = $json_new;
			}

			// Dạng không scheme: //site.com/...
			if ( preg_match( '#^https?://#i', $old ) ) {
				$schemeless_old = preg_replace( '#^https?:#i', '', $old );
				$schemeless_new = preg_replace( '#^https?:#i', '', $new );
				$expanded[ $schemeless_old ] = $schemeless_new;

				// Dạng scheme đối lập (http <-> https).
				$alt_old = ( 0 === stripos( $old, 'https://' ) )
					? 'http://' . substr( $old, 8 )
					: 'https://' . substr( $old, 7 );
				$alt_new = ( 0 === stripos( $new, 'https://' ) )
					? 'http://' . substr( $new, 8 )
					: 'https://' . substr( $new, 7 );
				$expanded[ $alt_old ] = $alt_new;
			}

			// Dạng urlencode (hay gặp trong link ?url=...).
			$enc_old = rawurlencode( $old );
			$enc_new = rawurlencode( $new );
			if ( $enc_old !== $old ) {
				$expanded[ $enc_old ] = $enc_new;
			}
		}

		// Thay chuỗi dài trước để tránh thay nhầm chuỗi con.
		uksort(
			$expanded,
			static function ( $a, $b ) {
				return strlen( $b ) - strlen( $a );
			}
		);

		return $expanded;
	}

	/**
	 * Rút ra danh sách tên file duy nhất để lọc ở SQL.
	 *
	 * @param array $pairs Cặp thay thế đã mở rộng.
	 * @return string[]
	 */
	private static function needles_from_pairs( $pairs ) {
		$needles = array();

		foreach ( array_keys( $pairs ) as $old ) {
			// Tách lấy tên file, chấp nhận cả dấu / lẫn \/ (JSON escaped).
			$normalized = str_replace( '\\/', '/', $old );
			$basename   = basename( $normalized );

			if ( '' !== $basename ) {
				$needles[ $basename ] = true;
			}
		}

		return array_keys( $needles );
	}

	/**
	 * Danh sách bảng/cột cần quét.
	 *
	 * @return array
	 */
	private static function targets() {
		global $wpdb;

		$targets = array(
			array(
				'table'   => $wpdb->posts,
				'pk'      => 'ID',
				'columns' => array( 'post_content', 'post_excerpt', 'guid', 'post_content_filtered' ),
			),
			array(
				'table'   => $wpdb->postmeta,
				'pk'      => 'meta_id',
				'columns' => array( 'meta_value' ),
			),
			array(
				'table'   => $wpdb->options,
				'pk'      => 'option_id',
				'columns' => array( 'option_value' ),
			),
			array(
				'table'   => $wpdb->termmeta,
				'pk'      => 'meta_id',
				'columns' => array( 'meta_value' ),
			),
			array(
				'table'   => $wpdb->usermeta,
				'pk'      => 'umeta_id',
				'columns' => array( 'meta_value' ),
			),
			array(
				'table'   => $wpdb->comments,
				'pk'      => 'comment_ID',
				'columns' => array( 'comment_content' ),
			),
			array(
				'table'   => $wpdb->commentmeta,
				'pk'      => 'meta_id',
				'columns' => array( 'meta_value' ),
			),
		);

		/**
		 * Cho phép plugin/theme khác bổ sung bảng tuỳ biến cần thay URL.
		 *
		 * @param array $targets Danh sách bảng.
		 */
		return apply_filters( 'DAWP_WebP_replace_targets', $targets );
	}

	/**
	 * Quét và cập nhật một bảng.
	 *
	 * @param array $target  Mô tả bảng.
	 * @param array $pairs   Cặp thay thế.
	 * @param array $needles Tên file dùng để lọc ở SQL.
	 * @return int Số dòng đã cập nhật.
	 */
	private static function process_table( $target, $pairs, $needles ) {
		global $wpdb;

		$table   = $target['table'];
		$pk      = $target['pk'];
		$columns = $target['columns'];

		if ( empty( $needles ) || empty( $columns ) ) {
			return 0;
		}

		// Chỉ lấy các dòng thực sự có chứa tên file cần thay -> nhẹ hơn nhiều
		// so với việc quét mọi biến thể URL.
		$where  = array();
		$params = array();
		foreach ( $columns as $col ) {
			foreach ( $needles as $needle ) {
				$where[]  = "`{$col}` LIKE %s";
				$params[] = '%' . $wpdb->esc_like( $needle ) . '%';
			}
		}

		$select_cols = '`' . $pk . '`, `' . implode( '`, `', $columns ) . '`';
		$sql         = "SELECT {$select_cols} FROM `{$table}` WHERE " . implode( ' OR ', $where ) . ' LIMIT 5000';

		// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL
		$rows = $wpdb->get_results( $wpdb->prepare( $sql, $params ), ARRAY_A );
		// phpcs:enable

		if ( empty( $rows ) ) {
			return 0;
		}

		$updated = 0;

		foreach ( $rows as $row ) {
			$changes = array();

			foreach ( $columns as $col ) {
				if ( ! isset( $row[ $col ] ) || '' === $row[ $col ] ) {
					continue;
				}

				$new_value = self::recursive_replace( $row[ $col ], $pairs );

				if ( $new_value !== $row[ $col ] ) {
					$changes[ $col ] = $new_value;
				}
			}

			if ( ! empty( $changes ) ) {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery
				$result = $wpdb->update(
					$table,
					$changes,
					array( $pk => $row[ $pk ] )
				);

				if ( false !== $result ) {
					++$updated;
				}
			}
		}

		return $updated;
	}

	/**
	 * Thay thế đệ quy, giữ nguyên cấu trúc serialize.
	 *
	 * Dữ liệu serialize của PHP lưu kèm độ dài chuỗi (s:12:"...").
	 * Nếu str_replace thẳng vào chuỗi serialize thì độ dài sai và dữ liệu hỏng.
	 * Vì vậy phải unserialize -> thay -> serialize lại.
	 *
	 * @param mixed $data  Dữ liệu.
	 * @param array $pairs Cặp thay thế.
	 * @return mixed
	 */
	public static function recursive_replace( $data, $pairs ) {
		if ( is_string( $data ) ) {
			// Dữ liệu serialize: xử lý bằng cách giải tuần tự an toàn.
			if ( is_serialized( $data, false ) ) {
				$unserialized = @unserialize( $data, array( 'allowed_classes' => false ) ); // phpcs:ignore

				if ( false !== $unserialized || 'b:0;' === $data ) {
					$replaced = self::recursive_replace( $unserialized, $pairs );
					return serialize( $replaced ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions
				}

				// Không giải được (có object lạ) -> bỏ qua để tránh làm hỏng dữ liệu.
				return $data;
			}

			return strtr( $data, $pairs );
		}

		if ( is_array( $data ) ) {
			$out = array();
			foreach ( $data as $key => $value ) {
				$new_key         = is_string( $key ) ? strtr( $key, $pairs ) : $key;
				$out[ $new_key ] = self::recursive_replace( $value, $pairs );
			}
			return $out;
		}

		if ( is_object( $data ) ) {
			// Chỉ xử lý stdClass để tránh phá vỡ object có logic riêng.
			if ( $data instanceof stdClass ) {
				$out = new stdClass();
				foreach ( get_object_vars( $data ) as $key => $value ) {
					$out->{$key} = self::recursive_replace( $value, $pairs );
				}
				return $out;
			}
			return $data;
		}

		return $data;
	}

	/**
	 * QUÉT DỌN TOÀN BỘ DATABASE: tìm mọi tham chiếu .jpg/.png còn sót trỏ tới
	 * file đã bị thay bằng .webp và sửa lại.
	 *
	 * Mục đích: sau khi chạy xong công cụ này, database KHÔNG còn URL cũ nào —
	 * xoá plugin an toàn trên MỌI máy chủ (Apache, LiteSpeed, OpenLiteSpeed,
	 * Nginx) mà không cần rule rewrite đỡ phía sau.
	 *
	 * Nguyên tắc an toàn: chỉ đổi khi file cũ KHÔNG còn trên đĩa VÀ file .webp
	 * tương ứng CÓ trên đĩa. Mọi trường hợp khác giữ nguyên.
	 *
	 * @param int $table_index Chỉ số bảng đang quét (theo self::targets()).
	 * @param int $last_pk     Khoá chính cuối cùng đã xử lý của bảng đó.
	 * @param int $limit       Số dòng mỗi lượt.
	 * @return array Kết quả + con trỏ cho lượt sau.
	 */
	public static function sweep_batch( $table_index, $last_pk = 0, $limit = 200 ) {
		global $wpdb;

		$targets     = self::targets();
		$table_index = max( 0, (int) $table_index );

		if ( $table_index >= count( $targets ) ) {
			return array(
				'done_all' => true,
				'table'    => $table_index,
				'last_pk'  => 0,
				'fixed'    => 0,
				'leftover' => 0,
			);
		}

		$target  = $targets[ $table_index ];
		$table   = $target['table'];
		$pk      = $target['pk'];
		$columns = $target['columns'];

		$uploads  = wp_get_upload_dir();
		$base_dir = trailingslashit( $uploads['basedir'] );

		// Chỉ lấy dòng có khả năng chứa ảnh cũ.
		$like = array();
		foreach ( $columns as $col ) {
			$like[] = "`{$col}` LIKE '%.jpg%'";
			$like[] = "`{$col}` LIKE '%.jpeg%'";
			$like[] = "`{$col}` LIKE '%.png%'";
			$like[] = "`{$col}` LIKE '%.JPG%'";
			$like[] = "`{$col}` LIKE '%.PNG%'";
		}

		$select_cols = '`' . $pk . '`, `' . implode( '`, `', $columns ) . '`';
		$sql         = "SELECT {$select_cols} FROM `{$table}`
			WHERE `{$pk}` > %d AND ( " . implode( ' OR ', $like ) . " )
			ORDER BY `{$pk}` ASC LIMIT %d";

		// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL
		$rows = $wpdb->get_results( $wpdb->prepare( $sql, $last_pk, $limit ), ARRAY_A );
		// phpcs:enable

		$fixed    = 0;
		$leftover = 0;
		$max_pk   = $last_pk;

		foreach ( (array) $rows as $row ) {
			$max_pk  = max( $max_pk, (int) $row[ $pk ] );
			$changes = array();

			foreach ( $columns as $col ) {
				if ( ! isset( $row[ $col ] ) || '' === $row[ $col ] ) {
					continue;
				}

				$pairs = self::pairs_from_text( $row[ $col ], $base_dir, $leftover );

				if ( empty( $pairs ) ) {
					continue;
				}

				$new_value = self::recursive_replace( $row[ $col ], $pairs );

				if ( $new_value !== $row[ $col ] ) {
					$changes[ $col ] = $new_value;
				}
			}

			if ( ! empty( $changes ) ) {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery
				$result = $wpdb->update( $table, $changes, array( $pk => $row[ $pk ] ) );

				if ( false !== $result ) {
					++$fixed;
				}
			}
		}

		$table_done = count( (array) $rows ) < $limit;

		if ( $table_done ) {
			self::flush_caches();
		}

		return array(
			'done_all'   => false,
			'table'      => $table_done ? $table_index + 1 : $table_index,
			'last_pk'    => $table_done ? 0 : $max_pk,
			'fixed'      => $fixed,
			'leftover'   => $leftover,
			'table_name' => $table,
			'tables'     => count( $targets ),
		);
	}

	/**
	 * Tìm trong một đoạn text mọi đường dẫn ảnh cũ có thể sửa được.
	 *
	 * @param string $text     Nội dung cột.
	 * @param string $base_dir Thư mục uploads tuyệt đối.
	 * @param int    $leftover Đếm tham chiếu không sửa được (truyền tham chiếu).
	 * @return array Cặp thay thế old => new.
	 */
	private static function pairs_from_text( $text, $base_dir, &$leftover ) {
		$pairs = array();

		// Bắt các chuỗi kết thúc .jpg/.jpeg/.png, chấp nhận cả dạng JSON
		// escaped ( \/ ) và urlencode ( %2F ).
		if ( ! preg_match_all( '#[A-Za-z0-9_\-./\\\\%+~()@]+\.(?:jpe?g|png)#i', $text, $matches ) ) {
			return $pairs;
		}

		foreach ( array_unique( $matches[0] ) as $found ) {
			// Chuẩn hoá về dạng đường dẫn thường để soi trên đĩa.
			$normal = str_replace( array( '\\/', '%2F', '%2f' ), '/', $found );

			// Chỉ xử lý đường dẫn thuộc uploads.
			$pos = stripos( $normal, 'wp-content/uploads/' );
			if ( false === $pos ) {
				continue;
			}

			$relative = substr( $normal, $pos + strlen( 'wp-content/uploads/' ) );

			// Chống path traversal.
			if ( false !== strpos( $relative, '..' ) ) {
				continue;
			}

			$old_path = $base_dir . $relative;
			$new_rel  = preg_replace( '/\.(jpe?g|png)$/i', '.webp', $relative );
			$new_path = $base_dir . $new_rel;

			// File cũ vẫn còn -> không đụng (có thể người dùng giữ ảnh gốc).
			if ( file_exists( $old_path ) ) {
				continue;
			}

			// Không có bản .webp thay thế -> ghi nhận để báo cáo, giữ nguyên.
			if ( ! file_exists( $new_path ) ) {
				++$leftover;
				continue;
			}

			// Thay đúng theo dạng gốc tìm thấy (giữ nguyên kiểu escape).
			$replacement = preg_replace( '/\.(jpe?g|png)$/i', '.webp', $found );

			$pairs[ $found ] = $replacement;
		}

		return $pairs;
	}

	/**
	 * Xoá cache sau khi sửa DB trực tiếp.
	 */
	private static function flush_caches() {
		$groups = array( 'posts', 'post_meta', 'options', 'term_meta', 'user_meta', 'comment_meta' );
		foreach ( $groups as $group ) {
			if ( function_exists( 'wp_cache_flush_group' ) ) {
				wp_cache_flush_group( $group );
			}
		}

		wp_cache_delete( 'alloptions', 'options' );
		wp_cache_delete( 'notoptions', 'options' );

		// Xoá cache của các plugin cache phổ biến nếu có.
		if ( function_exists( 'wp_cache_clear_cache' ) ) {
			wp_cache_clear_cache();
		}
		if ( function_exists( 'rocket_clean_domain' ) ) {
			rocket_clean_domain();
		}
		if ( class_exists( 'LiteSpeed\Purge' ) && method_exists( 'LiteSpeed\Purge', 'purge_all' ) ) {
			LiteSpeed\Purge::purge_all();
		}
	}
}

