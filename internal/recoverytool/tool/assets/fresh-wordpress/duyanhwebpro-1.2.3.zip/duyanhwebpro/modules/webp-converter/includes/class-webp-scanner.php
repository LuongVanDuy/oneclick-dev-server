<?php
/**
 * Quét thư viện media, xây hàng đợi ảnh cần nén.
 *
 * @package duyanhweb
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DAWP_WebP_Scanner {

	/**
	 * Đếm số ảnh còn lại chưa nén.
	 *
	 * @return int
	 */
	public static function count_pending() {
		global $wpdb;

		$mimes = DAWP_WebP_Settings::enabled_mimes();
		if ( empty( $mimes ) ) {
			return 0;
		}

		$placeholders = implode( ', ', array_fill( 0, count( $mimes ), '%s' ) );

		$sql = "SELECT COUNT(p.ID)
			FROM {$wpdb->posts} p
			LEFT JOIN {$wpdb->postmeta} m_done
				ON m_done.post_id = p.ID AND m_done.meta_key = %s
			LEFT JOIN {$wpdb->postmeta} m_skip
				ON m_skip.post_id = p.ID AND m_skip.meta_key = %s
			LEFT JOIN {$wpdb->postmeta} m_err
				ON m_err.post_id = p.ID AND m_err.meta_key = %s
			WHERE p.post_type = 'attachment'
				AND p.post_mime_type IN ({$placeholders})
				AND m_done.post_id IS NULL
				AND m_skip.post_id IS NULL
				AND m_err.post_id IS NULL";

		$params = array_merge( array( DAWP_WebP_META_DONE, DAWP_WebP_META_SKIP, DAWP_WebP_META_ERROR ), $mimes );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL
		return (int) $wpdb->get_var( $wpdb->prepare( $sql, $params ) );
	}

	/**
	 * Tổng số ảnh thuộc diện xử lý (đã nén + chưa nén).
	 *
	 * @return int
	 */
	public static function count_total() {
		global $wpdb;

		$mimes = DAWP_WebP_Settings::enabled_mimes();
		$mimes = array_merge( $mimes, array( 'image/webp' ) );

		$placeholders = implode( ', ', array_fill( 0, count( $mimes ), '%s' ) );

		$sql = "SELECT COUNT(ID) FROM {$wpdb->posts}
			WHERE post_type = 'attachment' AND post_mime_type IN ({$placeholders})";

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL
		return (int) $wpdb->get_var( $wpdb->prepare( $sql, $mimes ) );
	}

	/**
	 * Lấy danh sách ID ảnh cần nén tiếp theo.
	 *
	 * @param int $limit Số lượng.
	 * @return int[]
	 */
	public static function next_batch( $limit = 20 ) {
		global $wpdb;

		$mimes = DAWP_WebP_Settings::enabled_mimes();
		if ( empty( $mimes ) ) {
			return array();
		}

		$limit        = max( 1, min( 100, absint( $limit ) ) );
		$placeholders = implode( ', ', array_fill( 0, count( $mimes ), '%s' ) );

		$sql = "SELECT p.ID
			FROM {$wpdb->posts} p
			LEFT JOIN {$wpdb->postmeta} m_done
				ON m_done.post_id = p.ID AND m_done.meta_key = %s
			LEFT JOIN {$wpdb->postmeta} m_skip
				ON m_skip.post_id = p.ID AND m_skip.meta_key = %s
			LEFT JOIN {$wpdb->postmeta} m_err
				ON m_err.post_id = p.ID AND m_err.meta_key = %s
			WHERE p.post_type = 'attachment'
				AND p.post_mime_type IN ({$placeholders})
				AND m_done.post_id IS NULL
				AND m_skip.post_id IS NULL
				AND m_err.post_id IS NULL
			ORDER BY p.ID ASC
			LIMIT %d";

		$params = array_merge( array( DAWP_WebP_META_DONE, DAWP_WebP_META_SKIP, DAWP_WebP_META_ERROR ), $mimes, array( $limit ) );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL
		$ids = $wpdb->get_col( $wpdb->prepare( $sql, $params ) );

		return array_map( 'absint', (array) $ids );
	}

	/**
	 * Mô tả chi tiết một ảnh: tất cả các kích thước cần nén.
	 *
	 * Trả về mảng để JavaScript biết cần tải và nén những file nào.
	 *
	 * @param int $attachment_id ID ảnh.
	 * @return array|WP_Error
	 */
	public static function describe( $attachment_id ) {
		$attachment_id = absint( $attachment_id );
		$post          = get_post( $attachment_id );

		if ( ! $post || 'attachment' !== $post->post_type ) {
			return new WP_Error( 'DAWP_WebP_not_found', __( 'Không tìm thấy ảnh.', 'duyanhwebpro' ) );
		}

		// Chấp nhận cả ảnh đã đổi sang WebP, vì một ảnh có thể được nén làm
		// nhiều lượt: lượt trước đã đổi ảnh gốc sang WebP nhưng vẫn còn các
		// kích thước con chưa xử lý. Việc lọc thật sự nằm ở từng file bên dưới.
		$allowed = array_merge( DAWP_WebP_Settings::enabled_mimes(), array( 'image/webp' ) );

		if ( ! in_array( $post->post_mime_type, $allowed, true ) ) {
			return new WP_Error( 'DAWP_WebP_mime', __( 'Định dạng ảnh không nằm trong danh sách chuyển đổi.', 'duyanhwebpro' ) );
		}

		$relative = get_post_meta( $attachment_id, '_wp_attached_file', true );
		if ( ! $relative ) {
			return new WP_Error( 'DAWP_WebP_no_file', __( 'Ảnh không có file đính kèm.', 'duyanhwebpro' ) );
		}

		$uploads  = wp_get_upload_dir();
		$base_dir = trailingslashit( $uploads['basedir'] );
		$base_url = trailingslashit( $uploads['baseurl'] );
		$sub_dir  = ltrim( trailingslashit( dirname( $relative ) ), './' );
		$sub_dir  = ( '.' === rtrim( $sub_dir, '/' ) || '' === $sub_dir ) ? '' : $sub_dir;

		$metadata = wp_get_attachment_metadata( $attachment_id );
		$metadata = is_array( $metadata ) ? $metadata : array();

		$files      = array();
		$total_size = 0;

		// Ảnh gốc (full size). Bỏ qua nếu đã là WebP từ lượt nén trước.
		$full_path = $base_dir . $relative;
		if ( DAWP_WebP_Settings::is_convertible_file( $relative ) && file_exists( $full_path ) ) {
			$size        = (int) filesize( $full_path );
			$total_size += $size;
			$files[]     = array(
				'key'      => 'full',
				'relative' => $relative,
				'url'      => $base_url . $relative,
				'size'     => $size,
				'width'    => isset( $metadata['width'] ) ? (int) $metadata['width'] : 0,
				'height'   => isset( $metadata['height'] ) ? (int) $metadata['height'] : 0,
			);
		}

		// Ảnh gốc chưa scale. Với ảnh lớn, WordPress tự tạo bản "-scaled" làm
		// bản chính và giữ file gốc trong metadata['original_image']. File này
		// thường là file NẶNG NHẤT của cả ảnh nên không được bỏ sót.
		if ( ! empty( $metadata['original_image'] )
			&& $metadata['original_image'] !== basename( $relative )
			&& DAWP_WebP_Settings::is_convertible_file( $metadata['original_image'] ) ) {

			$orig_relative = $sub_dir . $metadata['original_image'];
			$orig_path     = $base_dir . $orig_relative;

			if ( file_exists( $orig_path ) ) {
				$size        = (int) filesize( $orig_path );
				$total_size += $size;
				$files[]     = array(
					'key'      => 'original_image',
					'relative' => $orig_relative,
					'url'      => $base_url . $orig_relative,
					'size'     => $size,
					'width'    => 0,
					'height'   => 0,
				);
			}
		}

		// Các kích thước thumbnail do WordPress sinh ra.
		if ( ! empty( $metadata['sizes'] ) && is_array( $metadata['sizes'] ) ) {
			foreach ( $metadata['sizes'] as $size_key => $size_data ) {
				if ( empty( $size_data['file'] ) ) {
					continue;
				}

				// Bỏ qua kích thước đã được nén ở lượt trước.
				if ( ! DAWP_WebP_Settings::is_convertible_file( $size_data['file'] ) ) {
					continue;
				}

				$size_relative = $sub_dir . $size_data['file'];
				$size_path     = $base_dir . $size_relative;

				if ( ! file_exists( $size_path ) ) {
					continue;
				}

				// Tránh nén trùng khi nhiều size trỏ về cùng một file.
				$already = wp_list_filter( $files, array( 'relative' => $size_relative ) );
				if ( ! empty( $already ) ) {
					continue;
				}

				$size        = (int) filesize( $size_path );
				$total_size += $size;
				$files[]     = array(
					'key'      => (string) $size_key,
					'relative' => $size_relative,
					'url'      => $base_url . $size_relative,
					'size'     => $size,
					'width'    => isset( $size_data['width'] ) ? (int) $size_data['width'] : 0,
					'height'   => isset( $size_data['height'] ) ? (int) $size_data['height'] : 0,
				);
			}
		}

		// KHÔNG bỏ qua file nhỏ: nén tất cả về WebP để toàn thư viện đồng nhất
		// một định dạng — lần chạy sau không phải kiểm tra lại bất kỳ ảnh nào.

		if ( empty( $files ) ) {
			// Trả về danh sách rỗng kèm lý do thay vì lỗi, để JavaScript đánh
			// dấu bỏ qua một cách êm thấm chứ không báo đỏ trong nhật ký.
			return array(
				'id'         => $attachment_id,
				'title'      => get_the_title( $attachment_id ),
				'mime'       => $post->post_mime_type,
				'files'      => array(),
				'total_size' => 0,
				'reason'     => __( 'Không tìm thấy file ảnh trên đĩa.', 'duyanhwebpro' ),
				'edit_link'  => get_edit_post_link( $attachment_id, 'raw' ),
			);
		}

		return array(
			'id'         => $attachment_id,
			'title'      => get_the_title( $attachment_id ),
			'mime'       => $post->post_mime_type,
			'files'      => $files,
			'total_size' => $total_size,
			'edit_link'  => get_edit_post_link( $attachment_id, 'raw' ),
		);
	}

	/**
	 * Đánh dấu bỏ qua một ảnh (quá nhỏ, lỗi, hoặc người dùng chọn bỏ qua).
	 *
	 * @param int    $attachment_id ID ảnh.
	 * @param string $reason        Lý do.
	 */
	public static function mark_skipped( $attachment_id, $reason = '' ) {
		update_post_meta( absint( $attachment_id ), DAWP_WebP_META_SKIP, $reason ? $reason : 'skipped' );
	}

	/**
	 * Đánh dấu ảnh gặp LỖI TẠM THỜI.
	 *
	 * Ảnh bị loại khỏi hàng đợi ngay lập tức (để lần chạy hiện tại không kẹt
	 * lặp vô hạn), nhưng KHÔNG bị bỏ vĩnh viễn: lần bấm "Bắt đầu nén" sau,
	 * reset_errors() sẽ đưa toàn bộ ảnh lỗi trở lại hàng đợi để thử lại.
	 *
	 * @param int    $attachment_id ID ảnh.
	 * @param string $reason        Lý do lỗi.
	 */
	public static function mark_error( $attachment_id, $reason = '' ) {
		update_post_meta( absint( $attachment_id ), DAWP_WebP_META_ERROR, $reason ? $reason : 'error' );
	}

	/**
	 * Xoá toàn bộ đánh dấu lỗi tạm thời — đưa ảnh lỗi trở lại hàng đợi.
	 *
	 * @return int Số ảnh được đưa lại vào hàng đợi.
	 */
	public static function reset_errors() {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$count = (int) $wpdb->query(
			$wpdb->prepare(
				"DELETE FROM {$wpdb->postmeta} WHERE meta_key = %s",
				DAWP_WebP_META_ERROR
			)
		);

		wp_cache_flush();

		return $count;
	}
}

