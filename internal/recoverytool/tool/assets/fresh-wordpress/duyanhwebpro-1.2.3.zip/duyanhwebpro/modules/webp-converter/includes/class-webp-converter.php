<?php
/**
 * Nhận file WebP đã nén sẵn từ trình duyệt của quản trị viên, ghi xuống đĩa
 * và cập nhật database.
 *
 * LƯU Ý QUAN TRỌNG: lớp này KHÔNG hề encode/decode ảnh. Toàn bộ việc giải mã,
 * resize và nén WebP đã được thực hiện bằng CPU/RAM máy khách (trình duyệt admin)
 * thông qua Canvas API. Máy chủ chỉ làm ba việc rất nhẹ: kiểm tra tính hợp lệ,
 * ghi file, và cập nhật DB.
 *
 * Mỗi lần gọi chỉ xử lý ĐÚNG MỘT ảnh và commit ngay, nên không bao giờ bị treo
 * giữa chừng: xong ảnh nào là chắc chắn ảnh đó.
 *
 * @package duyanhweb
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DAWP_WebP_Engine {

	/**
	 * Xử lý một ảnh: ghi các file WebP, xoá file gốc, cập nhật metadata và DB.
	 *
	 * Một ảnh có thể được gửi làm nhiều lượt (chunk) khi có quá nhiều kích thước,
	 * vì PHP giới hạn số file mỗi request. Chỉ lượt cuối mới đánh dấu hoàn tất
	 * và ghi nhật ký với số liệu tổng của cả ảnh.
	 *
	 * @param int    $attachment_id ID ảnh.
	 * @param array  $incoming      Mảng các file WebP: array( key => array( 'tmp' => path, 'width' => int, 'height' => int ) ).
	 * @param bool   $is_final      Đây có phải lượt cuối của ảnh này không.
	 * @param string $token         Mã phiên làm việc, chống hai tab admin cùng xử lý một ảnh.
	 * @return array|WP_Error
	 */
	public static function commit( $attachment_id, $incoming, $is_final = true, $token = '' ) {
		global $wpdb;

		$attachment_id = absint( $attachment_id );

		// Khoá theo từng ảnh: nếu một tab admin khác đang xử lý đúng ảnh này,
		// từ chối để tránh ghi file trùng lặp và cộng dồn số liệu sai.
		$lock_key = 'DAWP_WebP_lock_' . $attachment_id;
		$holder   = get_transient( $lock_key );

		if ( $holder && $token && $holder !== $token ) {
			return new WP_Error(
				'DAWP_WebP_locked',
				__( 'Ảnh này đang được một phiên khác xử lý. Không nên chạy nén ở hai tab cùng lúc.', 'duyanhwebpro' )
			);
		}

		if ( $token ) {
			set_transient( $lock_key, $token, 2 * MINUTE_IN_SECONDS );
		}

		$describe = DAWP_WebP_Scanner::describe( $attachment_id );

		if ( is_wp_error( $describe ) ) {
			return $describe;
		}

		if ( empty( $describe['files'] ) ) {
			// Không còn file nào thuộc diện nén (đã nén hết hoặc quá nhỏ).
			if ( $is_final ) {
				self::finalize( $attachment_id );
			}

			return array(
				'id'          => $attachment_id,
				'status'      => 'skipped',
				'message'     => isset( $describe['reason'] ) ? $describe['reason'] : '',
				'size_before' => 0,
				'size_after'  => 0,
				'files'       => 0,
				'db_rows'     => 0,
			);
		}

		$uploads  = wp_get_upload_dir();
		$base_dir = trailingslashit( $uploads['basedir'] );
		$base_url = trailingslashit( $uploads['baseurl'] );

		$planned      = array();
		$size_before  = 0;
		$size_after   = 0;

		// ---------------------------------------------------------------
		// GIAI ĐOẠN 1: kiểm tra toàn bộ. Chưa động vào file gốc nào cả.
		// ---------------------------------------------------------------
		foreach ( $describe['files'] as $file ) {
			$key = $file['key'];

			if ( ! isset( $incoming[ $key ] ) ) {
				// Trình duyệt không gửi bản nén cho size này (có thể nén ra to hơn) -> giữ nguyên.
				continue;
			}

			$tmp = $incoming[ $key ]['tmp'];

			if ( ! is_readable( $tmp ) ) {
				return new WP_Error( 'DAWP_WebP_tmp', __( 'Không đọc được file tạm tải lên.', 'duyanhwebpro' ) );
			}

			if ( ! self::is_webp( $tmp ) ) {
				return new WP_Error( 'DAWP_WebP_not_webp', __( 'File tải lên không phải định dạng WebP hợp lệ.', 'duyanhwebpro' ) );
			}

			$old_relative = $file['relative'];
			$old_path     = self::safe_path( $base_dir, $old_relative );

			if ( ! $old_path || ! file_exists( $old_path ) ) {
				continue;
			}

			$old_size = (int) filesize( $old_path );
			$new_size = (int) filesize( $tmp );

			// LUÔN chấp nhận bản WebP, kể cả khi không nhẹ hơn: mục tiêu là
			// đưa TOÀN BỘ thư viện về một định dạng duy nhất, để các lần chạy
			// sau không bao giờ phải kiểm tra lại ảnh nào. Trình duyệt đã tự
			// hạ chất lượng từng nấc nên trường hợp to hơn gốc là cực hiếm.

			// Tên file mới, tránh ghi đè file WebP đã tồn tại của ảnh khác.
			$dir_path     = dirname( $old_path );
			$new_basename = self::unique_webp_name( $dir_path, self::webp_name( basename( $old_relative ) ) );
			$new_relative = ltrim( trailingslashit( dirname( $old_relative ) ), './' );
			$new_relative = ( '.' === rtrim( $new_relative, '/' ) || '' === $new_relative ) ? $new_basename : $new_relative . $new_basename;

			$planned[] = array(
				'key'          => $key,
				'tmp'          => $tmp,
				'old_path'     => $old_path,
				'new_path'     => $dir_path . DIRECTORY_SEPARATOR . $new_basename,
				'old_relative' => $old_relative,
				'new_relative' => $new_relative,
				'old_basename' => basename( $old_relative ),
				'new_basename' => $new_basename,
				'old_size'     => $old_size,
				'new_size'     => $new_size,
				'width'        => isset( $incoming[ $key ]['width'] ) ? (int) $incoming[ $key ]['width'] : (int) $file['width'],
				'height'       => isset( $incoming[ $key ]['height'] ) ? (int) $incoming[ $key ]['height'] : (int) $file['height'],
			);

			$size_before += $old_size;
			$size_after  += $new_size;
		}

		if ( empty( $planned ) ) {
			if ( $is_final ) {
				// Không có gì đáng nén -> đánh dấu đã xử lý để không quét lại mãi.
				self::finalize( $attachment_id, $describe['files'][0]['relative'] );
			}

			return array(
				'id'          => $attachment_id,
				'status'      => 'skipped',
				'message'     => __( 'Ảnh đã tối ưu sẵn, giữ nguyên.', 'duyanhwebpro' ),
				'size_before' => 0,
				'size_after'  => 0,
				'files'       => 0,
				'db_rows'     => 0,
			);
		}

		// ---------------------------------------------------------------
		// GIAI ĐOẠN 2: ghi tất cả file WebP. Vẫn chưa xoá file gốc.
		// ---------------------------------------------------------------
		$written = array();

		foreach ( $planned as $item ) {
			$moved = @copy( $item['tmp'], $item['new_path'] ); // phpcs:ignore

			if ( ! $moved || ! file_exists( $item['new_path'] ) ) {
				// Rollback: xoá các file vừa ghi, không đụng gì tới ảnh gốc.
				foreach ( $written as $done ) {
					@unlink( $done['new_path'] ); // phpcs:ignore
				}
				return new WP_Error( 'DAWP_WebP_write', __( 'Không ghi được file WebP. Kiểm tra quyền ghi thư mục uploads.', 'duyanhwebpro' ) );
			}

			self::set_permissions( $item['new_path'] );
			$written[] = $item;
		}

		// ---------------------------------------------------------------
		// GIAI ĐOẠN 3: commit. Cập nhật metadata, xoá gốc, thay URL trong DB.
		// ---------------------------------------------------------------
		$metadata = wp_get_attachment_metadata( $attachment_id );
		$metadata = is_array( $metadata ) ? $metadata : array();

		$pairs        = array();
		$full_changed = null;

		foreach ( $written as $item ) {
			// Cặp thay thế cho search-replace database.
			$pairs[ $base_url . $item['old_relative'] ] = $base_url . $item['new_relative'];
			$pairs[ $item['old_relative'] ]             = $item['new_relative'];

			if ( 'full' === $item['key'] ) {
				$full_changed = $item;
			}

			// Bản gốc chưa scale (metadata['original_image']).
			if ( 'original_image' === $item['key'] ) {
				$metadata['original_image'] = $item['new_basename'];
			}
		}

		// Cập nhật MỌI mục size trỏ tới file vừa đổi tên, không chỉ key đã xử lý.
		//
		// WordPress hay đăng ký nhiều tên size dùng chung một file, ví dụ
		// woocommerce_thumbnail và shop_catalog cùng trỏ vào abc-400x400.jpg.
		// Nếu chỉ sửa một key, các key còn lại vẫn trỏ vào file đã bị xoá và
		// sinh ra lỗi 404 ngoài giao diện.
		$rename_map = array();
		foreach ( $written as $item ) {
			$rename_map[ $item['old_basename'] ] = array(
				'file' => $item['new_basename'],
				'size' => $item['new_size'],
			);
		}

		if ( ! empty( $metadata['sizes'] ) && is_array( $metadata['sizes'] ) ) {
			foreach ( $metadata['sizes'] as $size_key => $size_data ) {
				if ( empty( $size_data['file'] ) || ! isset( $rename_map[ $size_data['file'] ] ) ) {
					continue;
				}

				$metadata['sizes'][ $size_key ]['file']      = $rename_map[ $size_data['file'] ]['file'];
				$metadata['sizes'][ $size_key ]['mime-type'] = 'image/webp';
				$metadata['sizes'][ $size_key ]['filesize']  = $rename_map[ $size_data['file'] ]['size'];
			}
		}

		if ( $full_changed ) {
			update_post_meta( $attachment_id, '_wp_attached_file', $full_changed['new_relative'] );

			$metadata['file']     = $full_changed['new_relative'];
			$metadata['filesize'] = $full_changed['new_size'];

			if ( $full_changed['width'] > 0 ) {
				$metadata['width'] = $full_changed['width'];
			}
			if ( $full_changed['height'] > 0 ) {
				$metadata['height'] = $full_changed['height'];
			}

			// phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->update(
				$wpdb->posts,
				array(
					'post_mime_type' => 'image/webp',
					'guid'           => $base_url . $full_changed['new_relative'],
				),
				array( 'ID' => $attachment_id )
			);

			clean_post_cache( $attachment_id );
		}

		wp_update_attachment_metadata( $attachment_id, $metadata );

		// Xoá file gốc — chỉ khi người dùng chủ động tắt tuỳ chọn giữ ảnh gốc.
		// Giữ lại ảnh gốc là lớp bảo hiểm cuối cùng: nếu còn sót tham chiếu nào
		// tới đường dẫn cũ, ảnh vẫn hiển thị được thay vì trả về lỗi 404.
		if ( ! DAWP_WebP_Settings::get( 'keep_original' ) ) {
			foreach ( $written as $item ) {
				if ( $item['old_path'] !== $item['new_path'] && file_exists( $item['old_path'] ) ) {
					@unlink( $item['old_path'] ); // phpcs:ignore
				}
			}
		}

		// Thay URL cũ trong toàn bộ database.
		$db_rows = 0;
		if ( DAWP_WebP_Settings::get( 'update_database' ) ) {
			$db_rows = DAWP_WebP_Replacer::replace_pairs( $pairs );
		}

		// Cộng dồn số liệu của lượt này vào bộ đếm tạm của ảnh.
		self::accumulate(
			$attachment_id,
			array(
				'orig_file'   => $written[0]['old_relative'],
				'webp_file'   => $written[0]['new_relative'],
				'size_before' => $size_before,
				'size_after'  => $size_after,
				'files_count' => count( $written ),
				'db_rows'     => $db_rows,
			)
		);

		if ( $is_final ) {
			self::finalize( $attachment_id, $written[0]['old_relative'] );
		}

		return array(
			'id'          => $attachment_id,
			'status'      => 'done',
			'size_before' => $size_before,
			'size_after'  => $size_after,
			'saved'       => max( 0, $size_before - $size_after ),
			'percent'     => $size_before > 0 ? round( ( $size_before - $size_after ) / $size_before * 100, 1 ) : 0,
			'files'       => count( $written ),
			'db_rows'     => $db_rows,
			'new_url'     => $full_changed ? $base_url . $full_changed['new_relative'] : '',
		);
	}

	/**
	 * Cộng dồn số liệu của một lượt gửi vào bộ đếm tạm của ảnh.
	 *
	 * @param int   $attachment_id ID ảnh.
	 * @param array $chunk         Số liệu lượt này.
	 */
	private static function accumulate( $attachment_id, $chunk ) {
		$partial = get_post_meta( $attachment_id, DAWP_WebP_META_PARTIAL, true );
		$partial = is_array( $partial ) ? $partial : array();

		$partial['orig_file']   = isset( $partial['orig_file'] ) ? $partial['orig_file'] : $chunk['orig_file'];
		$partial['webp_file']   = isset( $partial['webp_file'] ) ? $partial['webp_file'] : $chunk['webp_file'];
		$partial['size_before'] = ( isset( $partial['size_before'] ) ? (int) $partial['size_before'] : 0 ) + (int) $chunk['size_before'];
		$partial['size_after']  = ( isset( $partial['size_after'] ) ? (int) $partial['size_after'] : 0 ) + (int) $chunk['size_after'];
		$partial['files_count'] = ( isset( $partial['files_count'] ) ? (int) $partial['files_count'] : 0 ) + (int) $chunk['files_count'];
		$partial['db_rows']     = ( isset( $partial['db_rows'] ) ? (int) $partial['db_rows'] : 0 ) + (int) $chunk['db_rows'];

		update_post_meta( $attachment_id, DAWP_WebP_META_PARTIAL, $partial );
	}

	/**
	 * Kết thúc xử lý một ảnh: ghi nhật ký tổng và đánh dấu hoàn tất.
	 *
	 * @param int    $attachment_id ID ảnh.
	 * @param string $fallback_file Tên file dùng khi chưa có số liệu tích luỹ.
	 */
	private static function finalize( $attachment_id, $fallback_file = '' ) {
		$partial = get_post_meta( $attachment_id, DAWP_WebP_META_PARTIAL, true );
		$partial = is_array( $partial ) ? $partial : array();

		// TỰ KIỂM TRA trước khi đóng sổ: duyệt lại toàn bộ metadata, nếu còn mục
		// nào trỏ tới file không tồn tại trên đĩa thì sửa ngay tại chỗ.
		//
		// Đây là lưới an toàn cho cả một lớp lỗi: WordPress cho phép nhiều tên
		// size dùng chung một file, và bất kỳ mục nào bị bỏ sót cũng sẽ thành
		// ảnh vỡ ngoài giao diện. Thao tác này chỉ gọi file_exists nên rất nhẹ.
		$repair = DAWP_WebP_Repair::fix( $attachment_id );

		if ( ! empty( $repair['fixed'] ) ) {
			$partial['repaired'] = (int) $repair['fixed'];
		}

		if ( empty( $partial['files_count'] ) ) {
			DAWP_WebP_DB::log(
				array(
					'attachment_id' => $attachment_id,
					'orig_file'     => $fallback_file,
					'status'        => 'skipped',
					'message'       => __( 'Nén không tiết kiệm đủ ngưỡng, giữ nguyên ảnh gốc.', 'duyanhwebpro' ),
				)
			);
		} else {
			DAWP_WebP_DB::log(
				array(
					'attachment_id'   => $attachment_id,
					'orig_file'       => isset( $partial['orig_file'] ) ? $partial['orig_file'] : $fallback_file,
					'webp_file'       => isset( $partial['webp_file'] ) ? $partial['webp_file'] : '',
					'size_before'     => (int) $partial['size_before'],
					'size_after'      => (int) $partial['size_after'],
					'files_count'     => (int) $partial['files_count'],
					'db_rows_updated' => (int) $partial['db_rows'],
					'status'          => 'done',
					'message'         => empty( $partial['repaired'] )
						? ''
						: sprintf(
							/* translators: %d: số mục metadata đã tự sửa */
							__( 'Đã tự sửa %d mục metadata trỏ sai.', 'duyanhwebpro' ),
							(int) $partial['repaired']
						),
				)
			);
		}

		delete_post_meta( $attachment_id, DAWP_WebP_META_PARTIAL );
		update_post_meta( $attachment_id, DAWP_WebP_META_DONE, time() );
		delete_transient( 'DAWP_WebP_lock_' . $attachment_id );
	}

	/**
	 * Kiểm tra magic bytes để chắc chắn đây là file WebP thật.
	 *
	 * @param string $path Đường dẫn file.
	 * @return bool
	 */
	private static function is_webp( $path ) {
		$handle = @fopen( $path, 'rb' ); // phpcs:ignore
		if ( ! $handle ) {
			return false;
		}

		$header = fread( $handle, 12 );
		fclose( $handle );

		if ( 12 > strlen( (string) $header ) ) {
			return false;
		}

		return 'RIFF' === substr( $header, 0, 4 ) && 'WEBP' === substr( $header, 8, 4 );
	}

	/**
	 * Đổi phần mở rộng sang .webp.
	 *
	 * @param string $filename Tên file.
	 * @return string
	 */
	private static function webp_name( $filename ) {
		// KHÔNG gọi sanitize_file_name() ở đây. Tên file gốc đã được WordPress
		// làm sạch lúc upload rồi, nhưng sanitize_file_name() lại xoá thêm các
		// ký tự như ~ ( ) { } % + & # nên tên WebP sẽ KHÔNG còn khớp với tên
		// ảnh gốc. Cả rule .htaccess lẫn bộ lọc HTML đều dựa vào giả định
		// "chỉ đổi phần đuôi, giữ nguyên phần tên", nên đổi tên là ảnh chết.
		$name = preg_replace( '/\.(jpe?g|png)$/i', '', $filename );

		// Chỉ chặn các ký tự thực sự nguy hiểm về đường dẫn.
		$name = str_replace( array( '/', '\\', "\0" ), '', $name );

		return $name . '.webp';
	}

	/**
	 * Tìm tên file WebP chưa bị trùng, GIỮ NGUYÊN phần tên gốc.
	 *
	 * Không dùng wp_unique_filename() của WordPress vì hàm đó gọi
	 * sanitize_file_name() bên trong, làm mất các ký tự như ~ ( ) { } % +
	 * khiến tên WebP không còn khớp với tên ảnh gốc.
	 *
	 * @param string $dir      Thư mục đích.
	 * @param string $filename Tên file mong muốn.
	 * @return string
	 */
	private static function unique_webp_name( $dir, $filename ) {
		$dir  = trailingslashit( $dir );
		$stem = preg_replace( '/\.webp$/i', '', $filename );

		$candidate = $filename;
		$counter   = 1;

		while ( file_exists( $dir . $candidate ) ) {
			$candidate = $stem . '-' . $counter . '.webp';
			++$counter;

			// Chốt chặn an toàn, không bao giờ nên chạm tới.
			if ( 1000 < $counter ) {
				$candidate = $stem . '-' . wp_generate_password( 6, false ) . '.webp';
				break;
			}
		}

		return $candidate;
	}

	/**
	 * Chống path traversal: đường dẫn bắt buộc phải nằm trong thư mục uploads.
	 *
	 * @param string $base_dir Thư mục gốc uploads.
	 * @param string $relative Đường dẫn tương đối.
	 * @return string|false
	 */
	private static function safe_path( $base_dir, $relative ) {
		if ( false !== strpos( $relative, '..' ) || false !== strpos( $relative, "\0" ) ) {
			return false;
		}

		$path = $base_dir . ltrim( $relative, '/\\' );
		$real = realpath( $path );

		if ( ! $real ) {
			return false;
		}

		$real_base = realpath( $base_dir );
		// So prefix kèm dấu phân cách để "/uploads-evil" không khớp nhầm "/uploads"
		if ( ! $real_base || ( $real !== $real_base && 0 !== strpos( $real, rtrim( $real_base, '/\\' ) . DIRECTORY_SEPARATOR ) ) ) {
			return false;
		}

		return $real;
	}

	/**
	 * Đặt quyền file giống các file media khác.
	 *
	 * @param string $path Đường dẫn.
	 */
	private static function set_permissions( $path ) {
		$perms = defined( 'FS_CHMOD_FILE' ) ? FS_CHMOD_FILE : ( fileperms( ABSPATH . 'index.php' ) & 0777 | 0644 );
		@chmod( $path, $perms ); // phpcs:ignore
	}
}


