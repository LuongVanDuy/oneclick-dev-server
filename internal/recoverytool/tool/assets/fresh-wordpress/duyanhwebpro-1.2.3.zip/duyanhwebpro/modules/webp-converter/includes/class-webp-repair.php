<?php
/**
 * Sửa lại metadata bị lệch sau khi nén.
 *
 * Dùng khi metadata còn trỏ tới file .jpg/.png đã bị xoá trong khi trên đĩa
 * chỉ còn bản .webp — nguyên nhân gây lỗi 404 ảnh ngoài giao diện.
 *
 * Công cụ này chỉ đọc đĩa và sửa metadata, KHÔNG đụng tới file ảnh, nên chạy
 * bao nhiêu lần cũng an toàn.
 *
 * @package duyanhweb
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DAWP_WebP_Repair {

	/**
	 * Lấy danh sách ID ảnh cần kiểm tra.
	 *
	 * @param int $offset Vị trí bắt đầu.
	 * @param int $limit  Số lượng.
	 * @return int[]
	 */
	public static function batch( $offset = 0, $limit = 50 ) {
		global $wpdb;

		$offset = max( 0, absint( $offset ) );
		$limit  = max( 1, min( 200, absint( $limit ) ) );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL
		$ids = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT ID FROM {$wpdb->posts}
				WHERE post_type = 'attachment'
					AND post_mime_type LIKE %s
				ORDER BY ID ASC
				LIMIT %d OFFSET %d",
				'image/%',
				$limit,
				$offset
			)
		);

		return array_map( 'absint', (array) $ids );
	}

	/**
	 * Tổng số ảnh cần kiểm tra.
	 *
	 * @return int
	 */
	public static function count_all() {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL
		return (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(ID) FROM {$wpdb->posts}
				WHERE post_type = 'attachment' AND post_mime_type LIKE %s",
				'image/%'
			)
		);
	}

	/**
	 * Kiểm tra và sửa một ảnh.
	 *
	 * @param int $attachment_id ID ảnh.
	 * @return array Kết quả: số mục đã sửa và mô tả.
	 */
	public static function fix( $attachment_id ) {
		global $wpdb;

		$attachment_id = absint( $attachment_id );
		$relative      = get_post_meta( $attachment_id, '_wp_attached_file', true );

		if ( ! $relative ) {
			return array(
				'fixed' => 0,
				'notes' => array(),
			);
		}

		$uploads  = wp_get_upload_dir();
		$base_dir = trailingslashit( $uploads['basedir'] );
		$base_url = trailingslashit( $uploads['baseurl'] );

		$sub_dir = ltrim( trailingslashit( dirname( $relative ) ), './' );
		$sub_dir = ( '.' === rtrim( $sub_dir, '/' ) || '' === $sub_dir ) ? '' : $sub_dir;

		$fixed = 0;
		$notes = array();

		// --- Ảnh gốc ---------------------------------------------------
		if ( ! file_exists( $base_dir . $relative ) ) {
			$candidate = self::webp_variant( $relative );

			if ( $candidate && file_exists( $base_dir . $candidate ) ) {
				update_post_meta( $attachment_id, '_wp_attached_file', $candidate );

				// phpcs:ignore WordPress.DB.DirectDatabaseQuery
				$wpdb->update(
					$wpdb->posts,
					array(
						'post_mime_type' => 'image/webp',
						'guid'           => $base_url . $candidate,
					),
					array( 'ID' => $attachment_id )
				);

				clean_post_cache( $attachment_id );

				$relative = $candidate;
				$notes[]  = 'ảnh gốc';
				++$fixed;
			}
		}

		// --- Các kích thước con ----------------------------------------
		$metadata = wp_get_attachment_metadata( $attachment_id );

		if ( ! is_array( $metadata ) ) {
			return array(
				'fixed' => $fixed,
				'notes' => $notes,
			);
		}

		$changed = false;

		if ( isset( $metadata['file'] ) && $metadata['file'] !== $relative ) {
			$metadata['file'] = $relative;
			$changed          = true;
		}

		// Bản gốc chưa scale.
		if ( ! empty( $metadata['original_image'] ) ) {
			$orig_path = $base_dir . $sub_dir . $metadata['original_image'];

			if ( ! file_exists( $orig_path ) ) {
				$candidate = self::webp_variant( $metadata['original_image'] );

				if ( $candidate && file_exists( $base_dir . $sub_dir . $candidate ) ) {
					$metadata['original_image'] = $candidate;
					$notes[]                    = 'original_image';
					$changed                    = true;
					++$fixed;
				}
			}
		}

		if ( ! empty( $metadata['sizes'] ) && is_array( $metadata['sizes'] ) ) {
			foreach ( $metadata['sizes'] as $size_key => $size_data ) {
				if ( empty( $size_data['file'] ) ) {
					continue;
				}

				$size_path = $base_dir . $sub_dir . $size_data['file'];

				// Còn tồn tại thì không cần đụng vào.
				if ( file_exists( $size_path ) ) {
					continue;
				}

				$candidate = self::webp_variant( $size_data['file'] );

				if ( ! $candidate || ! file_exists( $base_dir . $sub_dir . $candidate ) ) {
					continue;
				}

				$metadata['sizes'][ $size_key ]['file']      = $candidate;
				$metadata['sizes'][ $size_key ]['mime-type'] = 'image/webp';
				$metadata['sizes'][ $size_key ]['filesize']  = (int) filesize( $base_dir . $sub_dir . $candidate );

				$notes[] = $size_key;
				$changed = true;
				++$fixed;
			}
		}

		if ( $changed ) {
			wp_update_attachment_metadata( $attachment_id, $metadata );
		}

		return array(
			'fixed' => $fixed,
			'notes' => $notes,
		);
	}

	/**
	 * Đổi đuôi sang .webp.
	 *
	 * @param string $filename Tên file hoặc đường dẫn.
	 * @return string|false
	 */
	private static function webp_variant( $filename ) {
		if ( ! preg_match( '/\.(jpe?g|png)$/i', $filename ) ) {
			return false;
		}

		return preg_replace( '/\.(jpe?g|png)$/i', '.webp', $filename );
	}
}

