<?php
defined( 'ABSPATH' ) || exit;

class DAWP_Social_Share {
    private static $has_rendered = false;

    public function __construct() {
        // Chỉ chạy các tính năng nếu module chia sẻ MXH được bật trong cài đặt
        if ( ! class_exists( 'DAWP_Helpers' ) || ! DAWP_Helpers::is_module_active( 'social_share_active' ) ) {
            return;
        }

        // Tự động chèn nút chia sẻ dưới nội dung bài viết và trang tĩnh
        add_filter( 'the_content', [ $this, 'add_share_buttons_to_content' ], 99 );

        // Tự động chèn nút chia sẻ ở trang sản phẩm WooCommerce (mô tả ngắn)
        add_action( 'woocommerce_single_product_summary', [ $this, 'add_share_buttons_to_product' ], 45 );

        // Đăng ký Shortcode để người dùng chèn thủ công
        add_shortcode( 'dawp_social_share', [ $this, 'render_share_buttons_shortcode' ] );

        // Đăng ký tài nguyên inline CSS/JS tại footer nếu có hiển thị trên trang
        add_action( 'wp_footer', [ $this, 'enqueue_assets_in_footer' ], 99 );

        // Vô hiệu hóa cụm nút chia sẻ mặc định của giao diện Flatsome (tắt tận gốc, không render HTML)
        add_filter( 'flatsome_share_links', '__return_empty_array', 99 );
    }

    /**
     * Tự động chèn vào nội dung bài viết và trang tĩnh
     */
    public function add_share_buttons_to_content( $content ) {
        if ( ! is_singular() ) {
            return $content;
        }

        if ( ! class_exists( 'DAWP_Helpers' ) || ! DAWP_Helpers::is_module_active( 'social_share_active' ) ) {
            return $content;
        }

        $show_on_post = DAWP_Helpers::get_setting( 'social_share_on_post', 1 );
        $show_on_page = DAWP_Helpers::get_setting( 'social_share_on_page', 0 );

        $is_post = is_singular( 'post' ) && $show_on_post;
        $is_page = is_singular( 'page' ) && $show_on_page;

        if ( $is_post || $is_page ) {
            $content .= $this->render_share_buttons();
        }

        return $content;
    }

    /**
     * Tự động chèn vào trang chi tiết sản phẩm WooCommerce
     */
    public function add_share_buttons_to_product() {
        if ( ! class_exists( 'DAWP_Helpers' ) || ! DAWP_Helpers::is_module_active( 'social_share_active' ) ) {
            return;
        }

        $show_on_product = DAWP_Helpers::get_setting( 'social_share_on_product', 1 );

        if ( is_singular( 'product' ) && $show_on_product ) {
            echo $this->render_share_buttons();
        }
    }

    /**
     * Render qua shortcode [dawp_social_share]
     */
    public function render_share_buttons_shortcode() {
        if ( ! class_exists( 'DAWP_Helpers' ) || ! DAWP_Helpers::is_module_active( 'social_share_active' ) ) {
            return '';
        }
        return $this->render_share_buttons();
    }

    /**
     * Hàm render giao diện chính của các nút chia sẻ
     */
    public function render_share_buttons() {
        self::$has_rendered = true;

        $options = get_option( 'dawp_settings', [] );

        // Tiêu đề vùng chia sẻ
        $share_title = isset( $options['social_share_title'] ) ? esc_html( $options['social_share_title'] ) : 'Chia sẻ bài viết này:';

        if ( class_exists( 'DAWP_Multilingual' ) ) {
            $current_lang = DAWP_Multilingual::get_current_language();
            $default_lang = DAWP_Multilingual::get_default_language();
            if ( $current_lang !== $default_lang ) {
                $tr_title = DAWP_Multilingual::get_auto_translation( $share_title, $current_lang );
                if ( ! empty( $tr_title ) ) {
                    $share_title = esc_html( $tr_title );
                }
            }
        }

        // Giao diện hiển thị
        $style = isset( $options['social_share_style'] ) ? esc_attr( $options['social_share_style'] ) : 'minimal';

        // Các nút mạng xã hội được kích hoạt
        $networks = [
            'facebook'  => isset( $options['social_share_facebook'] ) ? (bool)$options['social_share_facebook'] : true,
            'zalo'      => isset( $options['social_share_zalo'] ) ? (bool)$options['social_share_zalo'] : true,
            'twitter'   => isset( $options['social_share_twitter'] ) ? (bool)$options['social_share_twitter'] : true,
            'telegram'  => isset( $options['social_share_telegram'] ) ? (bool)$options['social_share_telegram'] : true,
            'pinterest' => isset( $options['social_share_pinterest'] ) ? (bool)$options['social_share_pinterest'] : true,
            'linkedin'  => isset( $options['social_share_linkedin'] ) ? (bool)$options['social_share_linkedin'] : true,
            'copy'      => isset( $options['social_share_copy'] ) ? (bool)$options['social_share_copy'] : true,
        ];

        // Lấy thông tin URL, Tiêu đề, Ảnh đại diện của trang hiện tại
        $current_url = esc_url( home_url( add_query_arg( [], $GLOBALS['wp']->request ) ) );
        $current_title = esc_attr( get_the_title() );
        $featured_img = '';
        if ( has_post_thumbnail() ) {
            $featured_img = esc_url( get_the_post_thumbnail_url( get_the_ID(), 'full' ) );
        }

        // Định nghĩa các nút SVG và Liên kết chia sẻ
        $share_data = [
            'facebook' => [
                'name' => 'Facebook',
                'url'  => 'https://www.facebook.com/sharer/sharer.php?u=' . urlencode( $current_url ),
                'svg'  => '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M22 12c0-5.52-4.48-10-10-10S2 6.48 2 12c0 4.84 3.44 8.87 8 9.8V15H8v-3h2V9.5C10 7.57 11.57 6 13.5 6H16v3h-2c-.55 0-1 .45-1 1v2h3v3h-3v6.95c4.56-.93 8-4.96 8-9.75z"/></svg>'
            ],
            'zalo' => [
                'name' => 'Zalo',
                'url'  => 'https://sp.zalo.me/share_to_zalo?url=' . urlencode( $current_url ),
                'svg'  => '<svg viewBox="0 0 50 50" fill="currentColor"><path fill-rule="evenodd" clip-rule="evenodd" d="M7.779 43.5892C10.1019 43.846 13.0061 43.1836 15.0682 42.1825C24.0225 47.1318 38.0197 46.8954 46.4923 41.4732C46.8209 40.9803 47.1279 40.4677 47.4128 39.9363C49.1062 36.7779 50.0004 33.22 50.0004 27.1316V22.7175C50.0004 16.629 49.1062 13.0711 47.4128 9.91273C45.7385 6.75436 43.2461 4.28093 40.0877 2.58758C36.9293 0.894239 33.3714 0 27.283 0H22.8499C17.6644 0 14.2982 0.652754 11.4699 1.89893C11.3153 2.03737 11.1636 2.17818 11.0151 2.32135C2.71734 10.3203 2.08658 27.6593 9.12279 37.0782C9.13064 37.0921 9.13933 37.1061 9.14889 37.1203C10.2334 38.7185 9.18694 41.5154 7.55068 43.1516C7.28431 43.399 7.37944 43.5512 7.779 43.5892ZM20.5632 17H10.8382V19.0853H17.5869L10.9329 27.3317C10.7244 27.635 10.5728 27.9194 10.5728 28.5639V29.0947H19.748C20.203 29.0947 20.5822 28.7156 20.5822 28.2606V27.1421H13.4922L19.748 19.2938C19.8428 19.1801 20.0134 18.9716 20.0893 18.8768L20.1272 18.8199C20.4874 18.2891 20.5632 17.8341 20.5632 17.2844V17ZM32.9416 29.0947H34.3255V17H32.2402V28.3933C32.2402 28.7725 32.5435 29.0947 32.9416 29.0947ZM25.814 19.6924C23.1979 19.6924 21.0747 21.8156 21.0747 24.4317C21.0747 27.0478 23.1979 29.171 25.814 29.171C28.4301 29.171 30.5533 27.0478 30.5533 24.4317C30.5723 21.8156 28.4491 19.6924 25.814 19.6924ZM25.814 27.2184C24.2785 27.2184 23.0273 25.9672 23.0273 24.4317C23.0273 22.8962 24.2785 21.645 25.814 21.645C27.3495 21.645 28.6007 22.8962 28.6007 24.4317C28.6007 25.9672 27.3685 27.2184 25.814 27.2184ZM40.4867 19.6162C37.8516 19.6162 35.7095 21.7584 35.7095 24.3934C35.7095 27.0285 37.8516 29.1707 40.4867 29.1707C43.1217 29.1707 45.2639 27.0285 45.2639 24.3934C45.2639 21.7584 43.1217 19.6162 40.4867 19.6162ZM40.4867 27.2181C38.9322 27.2181 37.681 25.9669 37.681 24.4124C37.681 22.8579 38.9322 21.6067 40.4867 21.6067C42.0412 21.6067 43.2924 22.8579 43.2924 24.4124C43.2924 25.9669 42.0412 27.2181 40.4867 27.2181ZM29.4562 29.0944H30.5747V19.957H28.6221V28.2793C28.6221 28.7153 29.0012 29.0944 29.4562 29.0944Z\"/></svg>'
            ],
            'twitter' => [
                'name' => 'Twitter',
                'url'  => 'https://twitter.com/intent/tweet?url=' . urlencode( $current_url ) . '&text=' . urlencode( $current_title ),
                'svg'  => '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>'
            ],
            'telegram' => [
                'name' => 'Telegram',
                'url'  => 'https://t.me/share/url?url=' . urlencode( $current_url ) . '&text=' . urlencode( $current_title ),
                'svg'  => '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm4.64 6.8c-.12.82-.62 3.76-.88 5.16-.11.6-.33.8-.54.82-.46.04-.81-.31-1.26-.61-.7-.47-1.1-1.05-1.78-1.5-.78-.52-.27-.81.17-1.27.11-.12 2.11-1.94 2.15-2.11.01-.02.01-.1-.04-.15-.05-.05-.12-.03-.17-.02-.07.01-1.19.75-3.37 2.22-.32.22-.61.33-.87.32-.29-.01-.85-.17-1.26-.3l-1-.31c-.57-.18-.45-.55.07-.76 5.23-2.28 8.72-3.79 10.46-4.52.83-.35 1.57-.41 2.13-.39.12.01.39.04.57.18.15.12.2.28.22.49.02.21-.01.62-.03.95z"/></svg>'
            ],
            'pinterest' => [
                'name' => 'Pinterest',
                'url'  => 'https://pinterest.com/pin/create/button/?url=' . urlencode( $current_url ) . '&media=' . urlencode( $featured_img ) . '&description=' . urlencode( $current_title ),
                'svg'  => '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12.24 2C6.59 2 2 6.59 2 12.24c0 4.33 2.68 8.04 6.5 9.57-.1-.81-.19-2.06.04-2.95.21-.81 1.34-5.69 1.34-5.69s-.34-.68-.34-1.69c0-1.58.92-2.76 2.06-2.76.97 0 1.44.73 1.44 1.61 0 .98-.62 2.44-.94 3.8-.27 1.13.56 2.06 1.67 2.06 2 0 3.55-2.11 3.55-5.16 0-2.7-1.95-4.59-4.71-4.59-3.21 0-5.1 2.41-5.1 4.9 0 .97.37 2.01.84 2.58.09.11.1.21.07.32-.08.33-.26 1.05-.29 1.19-.04.16-.14.2-.32.12-1.18-.55-1.92-2.28-1.92-3.66 0-3.9 2.84-7.48 8.17-7.48 4.29 0 7.62 3.06 7.62 7.14 0 4.26-2.68 7.69-6.4 7.69-1.25 0-2.43-.65-2.83-1.42l-.77 2.94c-.28 1.07-1.04 2.41-1.55 3.24 1.13.35 2.33.54 3.58.54 5.65 0 10.24-4.59 10.24-10.24C22.48 6.59 17.89 2 12.24 2z"/></svg>'
            ],
            'linkedin' => [
                'name' => 'LinkedIn',
                'url'  => 'https://www.linkedin.com/sharing/share-offsite/?url=' . urlencode( $current_url ),
                'svg'  => '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M19 3a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h14m-.5 15.5v-5.3a3.26 3.26 0 0 0-3.26-3.26c-.85 0-1.84.52-2.32 1.3v-1.11h-2.79v8.37h2.79v-4.93c0-.77.62-1.4 1.39-1.4a1.4 1.4 0 0 1 1.4 1.4v4.93h2.79M6.88 8.56a1.68 1.68 0 0 0 1.68-1.68c0-.93-.75-1.69-1.68-1.69a1.69 1.69 0 0 0-1.69 1.69c0 .93.76 1.68 1.69 1.68m1.39 9.94v-8.37H5.5v8.37h2.77z"/></svg>'
            ],
            'copy' => [
                'name' => 'Copy Link',
                'url'  => '#',
                'svg'  => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"></path><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"></path></svg>'
            ]
        ];

        // Xây dựng chuỗi HTML của cụm nút chia sẻ
        $html = '<div class="dawp-social-share-container dawp-ss-' . esc_attr( $style ) . '">';
        if ( ! empty( $share_title ) ) {
            $html .= '  <div class="dawp-social-share-title">' . $share_title . '</div>';
        }
        $html .= '  <div class="dawp-ss-buttons">';

        foreach ( $networks as $net => $is_active ) {
            if ( ! $is_active || ! isset( $share_data[$net] ) ) {
                continue;
            }

            $item = $share_data[$net];
            if ( $net === 'copy' ) {
                $html .= sprintf(
                    '<a href="#" class="dawp-ss-btn dawp-ss-btn-copy" data-url="%s" aria-label="Sao chép liên kết">%s%s<span class="dawp-ss-tooltip">Đã sao chép!</span></a>',
                    $current_url,
                    $item['svg'],
                    $style === 'classic_rect' || $style === 'glassmorphism' ? ' <span>' . $item['name'] . '</span>' : ''
                );
            } else {
                $html .= sprintf(
                    '<a href="%s" class="dawp-ss-btn dawp-ss-btn-%s" target="_blank" rel="noopener noreferrer" aria-label="Chia sẻ qua %s">%s%s</a>',
                    $item['url'],
                    $net,
                    $item['name'],
                    $item['svg'],
                    $style === 'classic_rect' || $style === 'glassmorphism' ? ' <span>' . $item['name'] . '</span>' : ''
                );
            }
        }

        $html .= '  </div>';
        $html .= '</div>';

        return $html;
    }

    /**
     * Inject mã CSS và JS tối ưu ngay trước thẻ đóng body 
     * Chỉ thực thi khi các nút chia sẻ thực tế có hiển thị trên trang đó
     */
    public function enqueue_assets_in_footer() {
        if ( ! self::$has_rendered ) {
            return;
        }
        ?>
        <style>
            .dawp-social-share-container {
                margin: 25px 0;
                padding: 15px 0;
                border-top: 1px solid rgba(0,0,0,0.06);
                border-bottom: 1px solid rgba(0,0,0,0.06);
                width: 100%;
                clear: both;
            }
            .dawp-social-share-title {
                font-size: 14px;
                font-weight: 700;
                color: #2c3e50;
                margin-bottom: 12px;
                text-transform: uppercase;
                letter-spacing: 0.5px;
            }
            .dawp-ss-buttons {
                display: flex;
                flex-wrap: wrap;
                gap: 10px;
                align-items: center;
            }
            .dawp-ss-btn {
                display: inline-flex;
                align-items: center;
                justify-content: center;
                text-decoration: none;
                transition: all 0.25s cubic-bezier(0.4, 0, 0.2, 1);
                cursor: pointer;
                position: relative;
                outline: none;
                box-sizing: border-box;
            }
            .dawp-ss-btn svg {
                width: 18px;
                height: 18px;
                display: block;
            }

            /* --- 1. Minimal Style --- */
            .dawp-ss-minimal .dawp-ss-btn {
                width: 38px;
                height: 38px;
                border-radius: 50%;
                color: #ffffff !important;
            }
            .dawp-ss-minimal .dawp-ss-btn:hover {
                transform: translateY(-3px);
                box-shadow: 0 5px 12px rgba(0,0,0,0.15);
            }

            /* --- 2. Brand Outline Style --- */
            .dawp-ss-brand_outline .dawp-ss-btn {
                width: 36px;
                height: 36px;
                border-radius: 50%;
                background: transparent !important;
                border: 1.5px solid currentColor;
            }
            .dawp-ss-brand_outline .dawp-ss-btn:hover {
                background: currentColor !important;
                color: #ffffff !important;
                transform: translateY(-3px);
            }

            /* --- 3. Classic Rect Style --- */
            .dawp-ss-classic_rect .dawp-ss-btn {
                padding: 8px 15px;
                border-radius: 6px;
                color: #ffffff !important;
                font-size: 13px;
                font-weight: 600;
                gap: 8px;
            }
            .dawp-ss-classic_rect .dawp-ss-btn:hover {
                filter: brightness(1.08);
                transform: translateY(-2px);
                box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            }

            /* --- 4. Glassmorphism Style --- */
            .dawp-ss-glassmorphism .dawp-ss-btn {
                padding: 8px 15px;
                border-radius: 30px;
                background: rgba(0, 0, 0, 0.04) !important;
                border: 1px solid rgba(0, 0, 0, 0.08);
                color: #475569 !important;
                font-size: 13px;
                font-weight: 600;
                gap: 8px;
                backdrop-filter: blur(5px);
                -webkit-backdrop-filter: blur(5px);
            }
            .dawp-ss-glassmorphism .dawp-ss-btn:hover {
                background: rgba(0, 0, 0, 0.08) !important;
                border-color: rgba(0, 0, 0, 0.15);
                color: #0f172a !important;
                transform: translateY(-2px);
            }

            /* Màu thương hiệu chuẩn cho từng mạng xã hội */
            .dawp-ss-btn-facebook { color: #1877f2; }
            .dawp-ss-minimal .dawp-ss-btn-facebook,
            .dawp-ss-classic_rect .dawp-ss-btn-facebook { background-color: #1877f2 !important; }

            .dawp-ss-btn-zalo { color: #0068ff; }
            .dawp-ss-minimal .dawp-ss-btn-zalo,
            .dawp-ss-classic_rect .dawp-ss-btn-zalo { background-color: #0068ff !important; }

            .dawp-ss-btn-twitter { color: #0f1419; }
            .dawp-ss-minimal .dawp-ss-btn-twitter,
            .dawp-ss-classic_rect .dawp-ss-btn-twitter { background-color: #0f1419 !important; }

            .dawp-ss-btn-telegram { color: #229ed9; }
            .dawp-ss-minimal .dawp-ss-btn-telegram,
            .dawp-ss-classic_rect .dawp-ss-btn-telegram { background-color: #229ed9 !important; }

            .dawp-ss-btn-pinterest { color: #bd081c; }
            .dawp-ss-minimal .dawp-ss-btn-pinterest,
            .dawp-ss-classic_rect .dawp-ss-btn-pinterest { background-color: #bd081c !important; }

            .dawp-ss-btn-linkedin { color: #0077b5; }
            .dawp-ss-minimal .dawp-ss-btn-linkedin,
            .dawp-ss-classic_rect .dawp-ss-btn-linkedin { background-color: #0077b5 !important; }

            .dawp-ss-btn-copy { color: #475569; }
            .dawp-ss-minimal .dawp-ss-btn-copy,
            .dawp-ss-classic_rect .dawp-ss-btn-copy { background-color: #475569 !important; }

            /* Định dạng Tooltip của nút Copy Link */
            .dawp-ss-tooltip {
                position: absolute;
                bottom: 125%;
                left: 50%;
                transform: translateX(-50%) translateY(6px);
                background: #0f172a;
                color: #ffffff;
                padding: 6px 10px;
                border-radius: 4px;
                font-size: 11px;
                line-height: 1;
                font-weight: 500;
                white-space: nowrap;
                opacity: 0;
                visibility: hidden;
                transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
                box-shadow: 0 4px 8px rgba(0,0,0,0.12);
                z-index: 99999;
            }
            .dawp-ss-tooltip::after {
                content: "";
                position: absolute;
                top: 100%;
                left: 50%;
                transform: translateX(-50%);
                border-width: 5px;
                border-style: solid;
                border-color: #0f172a transparent transparent transparent;
            }
            .dawp-ss-tooltip.dawp-ss-show {
                opacity: 1;
                visibility: visible;
                transform: translateX(-50%) translateY(0);
            }
        </style>

        <script>
            (function() {
                document.addEventListener('DOMContentLoaded', function() {
                    // 1. Logic mở cửa sổ Popup chia sẻ dạng nhỏ (tránh bật sang tab trắng mới gây mất tập trung)
                    var shareBtns = document.querySelectorAll('.dawp-ss-btn:not(.dawp-ss-btn-copy)');
                    shareBtns.forEach(function(btn) {
                        btn.addEventListener('click', function(e) {
                            e.preventDefault();
                            var url = this.getAttribute('href');
                            window.open(url, '_blank', 'width=600,height=500,scrollbars=yes,resizable=yes');
                        });
                    });

                    // 2. Logic Sao chép liên kết vào Clipboard
                    var copyBtns = document.querySelectorAll('.dawp-ss-btn-copy');
                    copyBtns.forEach(function(btn) {
                        btn.addEventListener('click', function(e) {
                            e.preventDefault();
                            var url = this.getAttribute('data-url');
                            var self = this;
                            
                            if (navigator.clipboard && navigator.clipboard.writeText) {
                                navigator.clipboard.writeText(url).then(function() {
                                    showTooltip(self);
                                }).catch(function() {
                                    fallbackCopy(self, url);
                                });
                            } else {
                                fallbackCopy(self, url);
                            }
                        });
                    });

                    function fallbackCopy(element, text) {
                        var input = document.createElement('input');
                        input.value = text;
                        input.style.position = 'fixed'; // Tránh cuộn trang
                        document.body.appendChild(input);
                        input.select();
                        try {
                            document.execCommand('copy');
                            showTooltip(element);
                        } catch (err) {
                            console.error('Không thể sao chép liên kết: ', err);
                        }
                        document.body.removeChild(input);
                    }

                    function showTooltip(element) {
                        var tooltip = element.querySelector('.dawp-ss-tooltip');
                        if (tooltip) {
                            tooltip.classList.add('dawp-ss-show');
                            setTimeout(function() {
                                tooltip.classList.remove('dawp-ss-show');
                            }, 2000);
                        }
                    }
                });
            })();
        </script>
        <?php
    }
}
